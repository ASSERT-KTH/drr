import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(0, categoryURLGenerator12, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = statisticalBarRenderer0.getItemLabelGenerator(0, (int) '#');
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke20 = statisticalBarRenderer19.getBaseStroke();
        java.awt.Paint paint22 = statisticalBarRenderer19.getSeriesOutlinePaint((-1));
        boolean boolean23 = statisticalBarRenderer19.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = statisticalBarRenderer19.getPositiveItemLabelPosition(0, 15);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        java.awt.Paint paint30 = statisticalBarRenderer27.getSeriesOutlinePaint((-1));
        boolean boolean31 = statisticalBarRenderer27.getAutoPopulateSeriesOutlineStroke();
        boolean boolean32 = statisticalBarRenderer27.getBaseSeriesVisible();
        statisticalBarRenderer27.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis38.setPositiveArrowVisible(true);
        numberAxis38.setFixedAutoRange((double) (short) 0);
        numberAxis38.setRangeWithMargins((double) 0, (double) '#');
        numberAxis38.setAutoRange(false);
        java.awt.Font font49 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("ClassContext", font49);
        labelBlock50.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle();
        boolean boolean54 = labelBlock50.equals((java.lang.Object) textTitle53);
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle53.getBounds();
        statisticalBarRenderer27.drawRangeGridline(graphics2D35, categoryPlot36, (org.jfree.chart.axis.ValueAxis) numberAxis38, rectangle2D55, (double) (-16711681));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer58 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke59 = statisticalBarRenderer58.getBaseStroke();
        java.awt.Paint paint61 = statisticalBarRenderer58.getSeriesOutlinePaint((-1));
        java.awt.Shape shape63 = statisticalBarRenderer58.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer64 = null;
        statisticalBarRenderer58.setGradientPaintTransformer(gradientPaintTransformer64);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer67 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke68 = statisticalBarRenderer67.getBaseStroke();
        java.awt.Paint paint70 = statisticalBarRenderer67.getSeriesOutlinePaint((-1));
        boolean boolean71 = statisticalBarRenderer67.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition74 = statisticalBarRenderer67.getPositiveItemLabelPosition(0, 15);
        statisticalBarRenderer58.setSeriesPositiveItemLabelPosition(0, itemLabelPosition74, true);
        statisticalBarRenderer27.setNegativeItemLabelPositionFallback(itemLabelPosition74);
        statisticalBarRenderer19.setBasePositiveItemLabelPosition(itemLabelPosition74);
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(192, itemLabelPosition74);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNull(paint61);
        org.junit.Assert.assertNull(shape63);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(paint70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition74);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) '#', (int) (short) 10, rectangle2D5, rectangleEdge6);
        double double8 = categoryAxis0.getCategoryMargin();
        java.awt.Font font9 = categoryAxis0.getLabelFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        int int13 = categoryPlot12.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getRangeAxisEdge();
        java.awt.Paint paint15 = categoryPlot12.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot12.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot12.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot12.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo21, point2D22);
        boolean boolean24 = categoryPlot12.isDomainZoomable();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.Font font27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("ClassContext", font27);
        labelBlock28.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        boolean boolean32 = labelBlock28.equals((java.lang.Object) textTitle31);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        boolean boolean36 = categoryPlot12.render(graphics2D25, rectangle2D33, (int) (byte) 100, plotRenderingInfo35);
        org.jfree.chart.text.TextBlock textBlock37 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.Size2D size2D39 = textBlock37.calculateDimensions(graphics2D38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D43 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, 0.3d, (double) (short) 100, rectangleAnchor42);
        org.jfree.chart.util.UnitType unitType44 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        textTitle45.setURLText("hi!");
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = textTitle45.getPosition();
        boolean boolean49 = unitType44.equals((java.lang.Object) rectangleEdge48);
        java.lang.String str50 = rectangleEdge48.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        try {
            org.jfree.chart.axis.AxisState axisState52 = categoryAxis0.draw(graphics2D10, (double) 32.0f, rectangle2D33, rectangle2D43, rectangleEdge48, plotRenderingInfo51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(size2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(unitType44);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "RectangleEdge.TOP" + "'", str50.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 1.0E-8d, (java.lang.Number) (short) 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        java.awt.Shape shape19 = statisticalBarRenderer14.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        statisticalBarRenderer14.setGradientPaintTransformer(gradientPaintTransformer20);
        int int22 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double26 = categoryAxis23.getLabelAngle();
        java.lang.String str28 = categoryAxis23.getCategoryLabelToolTip((java.lang.Comparable) 100);
        java.util.List list29 = categoryPlot0.getCategoriesForAxis(categoryAxis23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke31 = statisticalBarRenderer30.getBaseStroke();
        java.awt.Paint paint33 = statisticalBarRenderer30.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke34 = statisticalBarRenderer30.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        statisticalBarRenderer30.setSeriesNegativeItemLabelPosition(255, itemLabelPosition36);
        boolean boolean38 = statisticalBarRenderer30.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator40 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer30.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator40);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation45 = null;
        categoryPlot43.setDomainAxisLocation(15, axisLocation45, true);
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = categoryPlot43.getDomainMarkers(layer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = categoryPlot43.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot43);
        java.lang.Object obj52 = jFreeChart51.clone();
        jFreeChart51.setBackgroundImageAlignment((-4194304));
        java.awt.Paint paint55 = jFreeChart51.getBorderPaint();
        statisticalBarRenderer30.setBaseFillPaint(paint55);
        java.awt.Paint paint58 = null;
        statisticalBarRenderer30.setSeriesFillPaint((int) (byte) 10, paint58);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator61 = statisticalBarRenderer30.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNull(categoryAxis50);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNull(categoryItemLabelGenerator61);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit1.toString();
        boolean boolean4 = numberTickUnit1.equals((java.lang.Object) 0L);
        java.lang.String str6 = numberTickUnit1.valueToString(3.0d);
        try {
            org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) numberTickUnit1, (double) 100.0f, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[size=1]" + "'", str2.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3" + "'", str6.equals("3"));
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
//        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
//        categoryPlot0.clearRangeAxes();
//        categoryPlot0.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str9 = projectInfo8.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getLibraries();
//        java.lang.String str11 = projectInfo8.getLicenceText();
//        java.awt.Image image12 = projectInfo8.getLogo();
//        categoryPlot0.setBackgroundImage(image12);
//        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
//        java.lang.String str17 = valueMarker15.getLabel();
//        org.junit.Assert.assertNotNull(projectInfo8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str9.equals("java.awt.Color[r=192,g=0,b=0]"));
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ThreadContext" + "'", str11.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(image12);
//        org.junit.Assert.assertNull(str17);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        int int6 = categoryPlot5.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        int int8 = categoryPlot7.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot7.setRenderer((int) (byte) 100, categoryItemRenderer11);
        boolean boolean13 = categoryPlot7.isDomainGridlinesVisible();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot7.getRowRenderingOrder();
        categoryPlot5.setColumnRenderingOrder(sortOrder14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot5.getRangeAxisLocation();
        boolean boolean17 = textAnchor4.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement28 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment25, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        textTitle29.setID("ClassContext");
        java.lang.Object obj32 = null;
        columnArrangement28.add((org.jfree.chart.block.Block) textTitle29, obj32);
        boolean boolean34 = textAnchor23.equals((java.lang.Object) textTitle29);
        textLine19.draw(graphics2D20, (float) '4', (float) (short) 10, textAnchor23, (float) (short) -1, (float) 0L, 0.0d);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextBlockAnchor.TOP_LEFT", graphics2D1, (float) 64, 0.0f, textAnchor4, (double) (byte) 100, textAnchor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator3);
        java.lang.Object obj5 = standardCategorySeriesLabelGenerator3.clone();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        double double3 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range5);
        double double7 = rectangleConstraint6.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.data.Range range9 = rectangleConstraint6.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setVisible(true);
        numberAxis11.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range17 = numberAxis11.getRange();
        double double18 = range17.getLength();
        org.jfree.data.Range range21 = org.jfree.data.Range.expand(range17, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint6.toRangeWidth(range21);
        numberAxis1.setRange(range21, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot26.setDomainAxisLocation(15, axisLocation28, true);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        textTitle31.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = textTitle31.getMargin();
        categoryPlot26.setInsets(rectangleInsets34, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = categoryPlot26.getInsets();
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot26);
        categoryPlot26.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 11.0d + "'", double18 == 11.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
//        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
//        categoryPlot0.clearRangeAxes();
//        categoryPlot0.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str9 = projectInfo8.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getLibraries();
//        java.lang.String str11 = projectInfo8.getLicenceText();
//        java.awt.Image image12 = projectInfo8.getLogo();
//        categoryPlot0.setBackgroundImage(image12);
//        java.awt.Paint paint14 = categoryPlot0.getDomainGridlinePaint();
//        int int15 = categoryPlot0.getDatasetCount();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
//        int int19 = categoryPlot18.getWeight();
//        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getRangeAxisEdge();
//        java.awt.Paint paint21 = categoryPlot18.getBackgroundPaint();
//        java.util.List list22 = categoryPlot18.getCategories();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
//        java.awt.geom.Rectangle2D rectangle2D26 = null;
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
//        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
//        categoryPlot18.zoomRangeAxes(0.0d, (double) 'a', plotRenderingInfo25, point2D28);
//        categoryPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo17, point2D28);
//        org.junit.Assert.assertNotNull(projectInfo8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str9.equals("java.awt.Color[r=192,g=0,b=0]"));
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ThreadContext" + "'", str11.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(image12);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(rectangleEdge20);
//        org.junit.Assert.assertNotNull(paint21);
//        org.junit.Assert.assertNull(list22);
//        org.junit.Assert.assertNotNull(point2D28);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Font font5 = statisticalBarRenderer0.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesVisible(4, (java.lang.Boolean) false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = statisticalBarRenderer0.getURLGenerator(64, (-16711681));
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        statisticalBarRenderer0.setBaseFillPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot10.setDomainAxisLocation(15, axisLocation12, true);
        categoryPlot10.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot10.getRendererForDataset(categoryDataset16);
        java.awt.Stroke stroke18 = categoryPlot10.getOutlineStroke();
        valueMarker9.setStroke(stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker9, layer20);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNull(legendItemCollection22);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color8, true);
        statisticalBarRenderer0.setBaseCreateEntities(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        java.lang.String str3 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ItemLabelAnchor.OUTSIDE3" + "'", str3.equals("ItemLabelAnchor.OUTSIDE3"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10, numberArray13, numberArray16, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray20);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset21);
        try {
            org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset21, (java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.0d + "'", number22.equals(0.0d));
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
//        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
//        categoryPlot0.clearRangeAxes();
//        categoryPlot0.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str9 = projectInfo8.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getLibraries();
//        java.lang.String str11 = projectInfo8.getLicenceText();
//        java.awt.Image image12 = projectInfo8.getLogo();
//        categoryPlot0.setBackgroundImage(image12);
//        java.awt.Stroke stroke14 = categoryPlot0.getOutlineStroke();
//        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//        numberAxis17.setPositiveArrowVisible(true);
//        numberAxis17.setFixedAutoRange((double) (short) 0);
//        numberAxis17.setRangeWithMargins((double) 0, (double) '#');
//        numberAxis17.setAutoRange(false);
//        boolean boolean27 = numberAxis17.isVerticalTickLabels();
//        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) numberAxis17, true);
//        org.junit.Assert.assertNotNull(projectInfo8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str9.equals("java.awt.Color[r=192,g=0,b=0]"));
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ThreadContext" + "'", str11.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(image12);
//        org.junit.Assert.assertNotNull(stroke14);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.lang.String str2 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SortOrder.ASCENDING" + "'", str2.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING");
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 1L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("VerticalAlignment.CENTER", graphics2D1, 0.8f, (float) 3, (double) 100, (float) 1, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        java.awt.Shape shape19 = statisticalBarRenderer14.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        statisticalBarRenderer14.setGradientPaintTransformer(gradientPaintTransformer20);
        int int22 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double26 = categoryAxis23.getLabelAngle();
        java.lang.String str28 = categoryAxis23.getCategoryLabelToolTip((java.lang.Comparable) 100);
        java.util.List list29 = categoryPlot0.getCategoriesForAxis(categoryAxis23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke31 = statisticalBarRenderer30.getBaseStroke();
        java.awt.Paint paint33 = statisticalBarRenderer30.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke34 = statisticalBarRenderer30.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        statisticalBarRenderer30.setSeriesNegativeItemLabelPosition(255, itemLabelPosition36);
        boolean boolean38 = statisticalBarRenderer30.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator40 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer30.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator40);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation45 = null;
        categoryPlot43.setDomainAxisLocation(15, axisLocation45, true);
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = categoryPlot43.getDomainMarkers(layer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = categoryPlot43.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot43);
        java.lang.Object obj52 = jFreeChart51.clone();
        jFreeChart51.setBackgroundImageAlignment((-4194304));
        java.awt.Paint paint55 = jFreeChart51.getBorderPaint();
        statisticalBarRenderer30.setBaseFillPaint(paint55);
        java.awt.Paint paint58 = null;
        statisticalBarRenderer30.setSeriesFillPaint((int) (byte) 10, paint58);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke62 = statisticalBarRenderer61.getBaseStroke();
        java.awt.Paint paint64 = statisticalBarRenderer61.getSeriesOutlinePaint((-1));
        boolean boolean65 = statisticalBarRenderer61.getAutoPopulateSeriesOutlineStroke();
        boolean boolean66 = statisticalBarRenderer61.getBaseSeriesVisible();
        statisticalBarRenderer61.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = null;
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis72.setPositiveArrowVisible(true);
        numberAxis72.setFixedAutoRange((double) (short) 0);
        numberAxis72.setRangeWithMargins((double) 0, (double) '#');
        numberAxis72.setAutoRange(false);
        java.awt.Font font83 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("ClassContext", font83);
        labelBlock84.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle87 = new org.jfree.chart.title.TextTitle();
        boolean boolean88 = labelBlock84.equals((java.lang.Object) textTitle87);
        java.awt.geom.Rectangle2D rectangle2D89 = textTitle87.getBounds();
        statisticalBarRenderer61.drawRangeGridline(graphics2D69, categoryPlot70, (org.jfree.chart.axis.ValueAxis) numberAxis72, rectangle2D89, (double) (-16711681));
        boolean boolean92 = numberAxis72.isTickMarksVisible();
        java.awt.Paint paint93 = numberAxis72.getTickLabelPaint();
        int int94 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis72);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNull(categoryAxis50);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNull(paint64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(font83);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(rectangle2D89);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertNotNull(paint93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setBaseItemLabelsVisible(false, false);
        boolean boolean6 = statisticalBarRenderer0.isSeriesVisible((int) (short) 100);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot10.setDomainAxisLocation(15, axisLocation12, true);
        categoryPlot10.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot10.getRendererForDataset(categoryDataset16);
        java.awt.Stroke stroke18 = categoryPlot10.getOutlineStroke();
        valueMarker9.setStroke(stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker9, layer20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNull(legendItemCollection23);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.Color color1 = java.awt.Color.CYAN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        float[] floatArray5 = new float[] { 1L, (byte) -1 };
        try {
            float[] floatArray6 = color0.getComponents(colorSpace2, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke5 = statisticalBarRenderer0.getBaseOutlineStroke();
        boolean boolean6 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean8 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke10 = statisticalBarRenderer9.getBaseStroke();
        java.awt.Paint paint12 = statisticalBarRenderer9.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke13 = statisticalBarRenderer9.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalBarRenderer9.setSeriesNegativeItemLabelPosition(255, itemLabelPosition15);
        boolean boolean17 = statisticalBarRenderer9.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer9.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        statisticalBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator22, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection14 = categoryPlot0.getDomainMarkers(layer13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo3.setLicenceName("");
//        org.jfree.chart.ui.Library[] libraryArray6 = projectInfo3.getLibraries();
//        projectInfo3.setVersion("ClassContext");
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo3.getLibraries();
//        java.util.List list11 = projectInfo3.getContributors();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str1.equals("java.awt.Color[r=192,g=0,b=0]"));
//        org.junit.Assert.assertNotNull(libraryArray2);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertNotNull(libraryArray6);
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertNotNull(list11);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        boolean boolean13 = statisticalBarRenderer0.getAutoPopulateSeriesPaint();
        int int14 = statisticalBarRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 0.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot1.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot1.setRenderer((int) (byte) 100, categoryItemRenderer5);
        boolean boolean7 = categoryPlot1.isDomainGridlinesVisible();
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot1.getRowRenderingOrder();
        java.awt.Paint paint9 = categoryPlot1.getOutlinePaint();
        java.awt.Stroke stroke10 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        int int13 = categoryPlot12.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getRangeAxisEdge();
        java.awt.Paint paint15 = categoryPlot12.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot12.getRangeAxisEdge();
        boolean boolean17 = categoryPlot12.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double21 = categoryAxis18.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int23 = numberTickUnit22.getMinorTickCount();
        java.awt.Font font24 = categoryAxis18.getTickLabelFont((java.lang.Comparable) numberTickUnit22);
        categoryPlot12.setNoDataMessageFont(font24);
        int int26 = categoryPlot12.getDatasetCount();
        java.awt.Stroke stroke27 = categoryPlot12.getRangeCrosshairStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 0.5f, paint9, stroke10, (java.awt.Paint) color11, stroke27, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        textBlock0.draw(graphics2D9, 0.8f, (float) 64, textBlockAnchor12);
        org.jfree.chart.text.TextLine textLine14 = textBlock0.getLastLine();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNull(textLine14);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        boolean boolean8 = categoryPlot0.isSubplot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        java.awt.Paint paint14 = categoryPlot11.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot11.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot11.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation23);
        categoryPlot0.setRangeAxisLocation(0, axisLocation10, false);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation31 = null;
        categoryPlot29.setDomainAxisLocation(15, axisLocation31, true);
        categoryPlot29.clearRangeAxes();
        categoryPlot29.setAnchorValue((double) (short) 0);
        categoryPlot29.setWeight((int) (byte) 10);
        categoryPlot29.setRangeCrosshairVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset42 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list43 = defaultStatisticalCategoryDataset42.getColumnKeys();
        categoryPlot29.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset42);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis46.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double49 = categoryAxis46.getLabelAngle();
        boolean boolean50 = categoryAxis46.isTickMarksVisible();
        categoryPlot29.setDomainAxis(255, categoryAxis46, true);
        categoryPlot0.setDomainAxis(categoryAxis46);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape10 = textBlock2.calculateBounds(graphics2D3, 0.0f, (float) (-1), textBlockAnchor6, 0.0f, (float) 10, (double) 10);
        numberAxis1.setLeftArrow(shape10);
        java.text.NumberFormat numberFormat12 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setTickMarksVisible(false);
        java.awt.Stroke stroke15 = numberAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("JFreeChart");
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        try {
            java.awt.Color color1 = java.awt.Color.decode("VerticalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"VerticalAlignment.CENTER\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 15);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge3);
        axisState1.moveCursor((double) '#', rectangleEdge3);
        double double6 = axisState1.getMax();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double10 = categoryAxis7.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int12 = numberTickUnit11.getMinorTickCount();
        java.awt.Font font13 = categoryAxis7.getTickLabelFont((java.lang.Comparable) numberTickUnit11);
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        int int19 = categoryPlot18.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getRangeAxisEdge();
        java.awt.Paint paint21 = categoryPlot18.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot18.getRangeAxisEdge();
        boolean boolean23 = categoryPlot18.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot18.getDomainAxisEdge((int) (short) -1);
        boolean boolean26 = categoryPlot18.isSubplot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        int int30 = categoryPlot29.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot29.getRangeAxisEdge();
        java.awt.Paint paint32 = categoryPlot29.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot29.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot29.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot29.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo38, point2D39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot29.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation28, plotOrientation41);
        categoryPlot18.setRangeAxisLocation(0, axisLocation28, false);
        try {
            categoryPlot0.setDomainAxisLocation((-4194304), axisLocation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        numberAxis1.setAutoRange(false);
        boolean boolean11 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot14.setDomainAxisLocation(15, axisLocation16, true);
        categoryPlot14.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot14.getRendererForDataset(categoryDataset20);
        java.awt.Stroke stroke22 = categoryPlot14.getOutlineStroke();
        valueMarker13.setStroke(stroke22);
        valueMarker13.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = valueMarker13.getLabelOffset();
        double double28 = rectangleInsets26.calculateLeftOutset(3.0d);
        numberAxis1.setLabelInsets(rectangleInsets26);
        numberAxis1.setAutoRangeMinimumSize((double) 3, true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot5.setDomainAxisLocation(15, axisLocation7, true);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot5.getDomainMarkers(layer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot5.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot5);
        jFreeChart13.clearSubtitles();
        java.awt.Stroke stroke15 = jFreeChart13.getBorderStroke();
        java.awt.Paint paint16 = jFreeChart13.getBorderPaint();
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) 10.0f, (double) 0.5f, (double) (-16711681), paint16);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isAxisLineVisible();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        statisticalBarRenderer0.notifyListeners(rendererChangeEvent6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke9 = statisticalBarRenderer5.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        statisticalBarRenderer5.setSeriesNegativeItemLabelPosition(255, itemLabelPosition11);
        java.lang.Boolean boolean14 = statisticalBarRenderer5.getSeriesVisible((int) (short) 0);
        statisticalBarRenderer5.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = statisticalBarRenderer5.getDrawingSupplier();
        boolean boolean19 = rectangleEdge4.equals((java.lang.Object) statisticalBarRenderer5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle0.setFont(font1);
        textTitle0.setHeight((double) (short) -1);
        java.lang.String str5 = textTitle0.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis3.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("ClassContext", font12);
        labelBlock13.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        boolean boolean17 = labelBlock13.equals((java.lang.Object) textTitle16);
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle16.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        int int20 = categoryPlot19.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot19.getRangeAxisEdge();
        java.awt.Paint paint22 = categoryPlot19.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot19.getRangeAxisEdge();
        java.util.List list24 = categoryAxis3.refreshTicks(graphics2D9, axisState10, rectangle2D18, rectangleEdge23);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment26, verticalAlignment27, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        textTitle31.setID("ClassContext");
        java.lang.Object obj34 = null;
        columnArrangement30.add((org.jfree.chart.block.Block) textTitle31, obj34);
        org.jfree.chart.util.VerticalAlignment verticalAlignment36 = textTitle31.getVerticalAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = null;
        categoryPlot37.setDomainAxisLocation(15, axisLocation39, true);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        textTitle42.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = textTitle42.getMargin();
        categoryPlot37.setInsets(rectangleInsets45, false);
        double double48 = rectangleInsets45.getLeft();
        double double49 = rectangleInsets45.getTop();
        try {
            org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("", font1, paint2, rectangleEdge23, horizontalAlignment25, verticalAlignment36, rectangleInsets45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(verticalAlignment36);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        boolean boolean10 = statisticalBarRenderer6.getAutoPopulateSeriesOutlineStroke();
        categoryPlot0.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6, true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot0.getRangeAxisForDataset((-4194304));
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke32 = statisticalBarRenderer31.getBaseStroke();
        java.awt.Paint paint34 = statisticalBarRenderer31.getSeriesOutlinePaint((-1));
        java.awt.Shape shape36 = statisticalBarRenderer31.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer37 = null;
        statisticalBarRenderer31.setGradientPaintTransformer(gradientPaintTransformer37);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke41 = statisticalBarRenderer40.getBaseStroke();
        java.awt.Paint paint43 = statisticalBarRenderer40.getSeriesOutlinePaint((-1));
        boolean boolean44 = statisticalBarRenderer40.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = statisticalBarRenderer40.getPositiveItemLabelPosition(0, 15);
        statisticalBarRenderer31.setSeriesPositiveItemLabelPosition(0, itemLabelPosition47, true);
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition47);
        java.awt.Font font52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.LabelBlock labelBlock54 = new org.jfree.chart.block.LabelBlock("hi!", font52, (java.awt.Paint) color53);
        boolean boolean55 = itemLabelPosition47.equals((java.lang.Object) font52);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNull(shape36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        int int1 = barRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color7);
        double double9 = statisticalBarRenderer0.getLowerClip();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.title.Title title4 = titleChangeEvent3.getTitle();
        org.jfree.chart.title.Title title5 = titleChangeEvent3.getTitle();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot9.setDomainAxisLocation(15, axisLocation11, true);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot9.getDomainMarkers(layer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot9.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot9);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent20 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) "ClassContext", jFreeChart17, (-4194304), (-4194304));
        org.jfree.chart.JFreeChart jFreeChart21 = chartProgressEvent20.getChart();
        titleChangeEvent3.setChart(jFreeChart21);
        org.junit.Assert.assertNotNull(title4);
        org.junit.Assert.assertNotNull(title5);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(jFreeChart21);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        numberAxis1.resizeRange((-1.0d));
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setUpperMargin(0.2d);
        numberAxis1.setUpperBound(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = textBlock0.calculateDimensions(graphics2D3);
        size2D4.setHeight(1.0E-8d);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(size2D4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.LegendItem legendItem4 = statisticalBarRenderer0.getLegendItem((int) (short) 100, (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition6, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(legendItem4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        boolean boolean8 = categoryPlot0.isSubplot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        java.awt.Paint paint14 = categoryPlot11.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot11.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot11.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation23);
        categoryPlot0.setRangeAxisLocation(0, axisLocation10, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        statisticalBarRenderer27.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer27.setBase(0.05d);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer27);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        boolean boolean10 = statisticalBarRenderer6.getAutoPopulateSeriesOutlineStroke();
        categoryPlot0.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6, true);
        java.awt.Shape shape14 = statisticalBarRenderer6.lookupSeriesShape((int) 'a');
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape14, "VerticalAlignment.CENTER", "ThreadContext");
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setDomainAxisLocation(15, axisLocation5, true);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot3.getDomainMarkers(layer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot3.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) "ClassContext", jFreeChart11, (-4194304), (-4194304));
        org.jfree.chart.JFreeChart jFreeChart15 = chartProgressEvent14.getChart();
        java.lang.String str16 = chartProgressEvent14.toString();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=ClassContext]" + "'", str16.equals("org.jfree.chart.event.ChartProgressEvent[source=ClassContext]"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        int int14 = categoryPlot0.getDatasetCount();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot17.setDomainAxisLocation(15, axisLocation19, true);
        categoryPlot17.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot17.getRendererForDataset(categoryDataset23);
        java.awt.Stroke stroke25 = categoryPlot17.getOutlineStroke();
        valueMarker16.setStroke(stroke25);
        valueMarker16.setLabel("ThreadContext");
        java.awt.Color color29 = java.awt.Color.BLUE;
        valueMarker16.setPaint((java.awt.Paint) color29);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke33 = statisticalBarRenderer32.getBaseStroke();
        valueMarker16.setStroke(stroke33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = null;
        try {
            valueMarker16.setLabelAnchor(rectangleAnchor35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setTickMarkOutsideLength((float) (short) 100);
        numberAxis1.setLabelAngle((double) '4');
        numberAxis1.setLowerBound((double) (byte) 100);
        double double8 = numberAxis1.getUpperMargin();
        numberAxis1.setInverted(false);
        double double11 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 100.0f, (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range8);
        double double10 = rectangleConstraint9.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toUnconstrainedWidth();
        org.jfree.data.Range range12 = rectangleConstraint9.getHeightRange();
        try {
            org.jfree.chart.util.Size2D size2D13 = blockContainer5.arrange(graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        boolean boolean31 = numberAxis11.isTickMarksVisible();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean36 = numberAxis35.isVerticalTickLabels();
        org.jfree.data.Range range37 = numberAxis35.getRange();
        org.jfree.data.Range range40 = org.jfree.data.Range.shift(range37, (double) 10.0f, false);
        org.jfree.data.Range range43 = org.jfree.data.Range.shift(range40, (double) (-4194304), false);
        numberAxis11.setRange(range43, false, true);
        double double47 = numberAxis11.getUpperBound();
        java.awt.Shape shape48 = numberAxis11.getUpArrow();
        numberAxis11.setUpperMargin(0.0d);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(shape48);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = null;
        textBlock0.draw(graphics2D3, (float) 10, (-1.0f), textBlockAnchor6);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke19 = statisticalBarRenderer18.getBaseStroke();
        statisticalBarRenderer14.setBaseStroke(stroke19, false);
        categoryPlot0.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent23);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        java.awt.Stroke stroke11 = jFreeChart9.getBorderStroke();
        java.lang.Object obj12 = null;
        boolean boolean13 = jFreeChart9.equals(obj12);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.setURLText("hi!");
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) textTitle10);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        textTitle15.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = textTitle15.getMargin();
        try {
            jFreeChart9.addSubtitle(4, (org.jfree.chart.title.Title) textTitle15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        int int4 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot5.setDomainAxisLocation(15, axisLocation7, true);
        categoryPlot5.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot5.getRendererForDataset(categoryDataset11);
        java.awt.Stroke stroke13 = categoryPlot5.getOutlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot5.getRangeAxis();
        java.awt.Font font15 = categoryPlot5.getNoDataMessageFont();
        boolean boolean16 = categoryAxis0.equals((java.lang.Object) font15);
        org.jfree.chart.plot.Plot plot17 = null;
        categoryAxis0.setPlot(plot17);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("");
        projectInfo0.setInfo("ThreadContext");
        projectInfo0.setCopyright("");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double10 = categoryAxis7.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int12 = numberTickUnit11.getMinorTickCount();
        java.awt.Font font13 = categoryAxis7.getTickLabelFont((java.lang.Comparable) numberTickUnit11);
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            categoryPlot0.addDomainMarker(0, categoryMarker16, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list19 = defaultStatisticalCategoryDataset18.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity22 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        int int23 = defaultStatisticalCategoryDataset18.getColumnCount();
        int int24 = defaultStatisticalCategoryDataset18.getColumnCount();
        org.jfree.data.Range range25 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18);
        org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, 2);
        boolean boolean28 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset27);
        org.jfree.data.general.PieDataset pieDataset31 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset27, (java.lang.Comparable) (short) 100, (double) (byte) 1);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(pieDataset27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(pieDataset31);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getUpArrow();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity2 = new org.jfree.chart.entity.LegendItemEntity(shape1);
        java.lang.Comparable comparable3 = legendItemEntity2.getSeriesKey();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(comparable3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "LengthConstraintType.FIXED", "JFreeChart", "");
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        int int3 = java.awt.Color.HSBtoRGB((float) 2, 0.95f, (float) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-12) + "'", int3 == (-12));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setURLText("hi!");
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle4.getPosition();
        boolean boolean8 = unitType3.equals((java.lang.Object) rectangleEdge7);
        boolean boolean9 = defaultDrawingSupplier0.equals((java.lang.Object) unitType3);
        java.awt.Paint paint10 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Font font15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ClassContext", font15);
        labelBlock16.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        boolean boolean20 = labelBlock16.equals((java.lang.Object) textTitle19);
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        boolean boolean24 = categoryPlot0.render(graphics2D13, rectangle2D21, (int) (byte) 100, plotRenderingInfo23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot0.getRenderer((int) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            categoryPlot0.handleClick((int) (byte) 10, (int) (byte) -1, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(categoryItemRenderer26);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        jFreeChart9.setBackgroundImageAlpha(0.5f);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart9.removeProgressListener(chartProgressListener13);
        java.lang.Object obj15 = jFreeChart9.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle16 = jFreeChart9.getLegend();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(legendTitle16);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis2.setPositiveArrowVisible(true);
        numberAxis2.setFixedAutoRange((double) (short) 0);
        numberAxis2.setRangeWithMargins((double) 0, (double) '#');
        numberAxis2.setAutoRange(false);
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape20 = textBlock12.calculateBounds(graphics2D13, 0.0f, (float) (-1), textBlockAnchor16, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        int int24 = categoryPlot23.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot23.getRangeAxisEdge();
        java.awt.Paint paint26 = categoryPlot23.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot23.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot23.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot23.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo32, point2D33);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = categoryPlot23.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation35);
        boolean boolean37 = legendItemEntity21.equals((java.lang.Object) rectangleEdge36);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge36);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleAnchor.CENTER", graphics2D1, (float) (byte) 10, (float) 10L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer0.getSeriesURLGenerator(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        try {
            statisticalBarRenderer0.setSeriesURLGenerator((int) (byte) -1, categoryURLGenerator11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(categoryURLGenerator9);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis5.setVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis5);
        categoryPlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot0.getRenderer(3);
        java.awt.Paint paint12 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        try {
            java.lang.Comparable comparable6 = defaultStatisticalCategoryDataset0.getRowKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        java.awt.Paint paint5 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer0.setBaseOutlineStroke(stroke6, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke10 = statisticalBarRenderer9.getBaseStroke();
        java.awt.Paint paint12 = statisticalBarRenderer9.getSeriesOutlinePaint((-1));
        boolean boolean13 = statisticalBarRenderer9.getAutoPopulateSeriesOutlineStroke();
        boolean boolean14 = statisticalBarRenderer9.getBaseSeriesVisible();
        statisticalBarRenderer9.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis20.setPositiveArrowVisible(true);
        numberAxis20.setFixedAutoRange((double) (short) 0);
        numberAxis20.setRangeWithMargins((double) 0, (double) '#');
        numberAxis20.setAutoRange(false);
        java.awt.Font font31 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("ClassContext", font31);
        labelBlock32.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        boolean boolean36 = labelBlock32.equals((java.lang.Object) textTitle35);
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle35.getBounds();
        statisticalBarRenderer9.drawRangeGridline(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis20, rectangle2D37, (double) (-16711681));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke41 = statisticalBarRenderer40.getBaseStroke();
        java.awt.Paint paint43 = statisticalBarRenderer40.getSeriesOutlinePaint((-1));
        java.awt.Shape shape45 = statisticalBarRenderer40.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer46 = null;
        statisticalBarRenderer40.setGradientPaintTransformer(gradientPaintTransformer46);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer49 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke50 = statisticalBarRenderer49.getBaseStroke();
        java.awt.Paint paint52 = statisticalBarRenderer49.getSeriesOutlinePaint((-1));
        boolean boolean53 = statisticalBarRenderer49.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = statisticalBarRenderer49.getPositiveItemLabelPosition(0, 15);
        statisticalBarRenderer40.setSeriesPositiveItemLabelPosition(0, itemLabelPosition56, true);
        statisticalBarRenderer9.setNegativeItemLabelPositionFallback(itemLabelPosition56);
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition56);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNull(shape45);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition56);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block11 = null;
        blockContainer10.add(block11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setWidth((double) '4');
        java.lang.Object obj16 = textTitle13.clone();
        double double17 = textTitle13.getContentYOffset();
        blockContainer10.add((org.jfree.chart.block.Block) textTitle13);
        legendTitle9.setWrapper(blockContainer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = legendTitle9.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str2 = color1.toString();
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color1, true);
        statisticalBarRenderer0.removeAnnotations();
        java.awt.Paint paint6 = null;
        try {
            statisticalBarRenderer0.setBaseOutlinePaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str2.equals("java.awt.Color[r=192,g=0,b=0]"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        double double7 = numberAxis1.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str9 = numberTickUnit8.toString();
        boolean boolean11 = numberTickUnit8.equals((java.lang.Object) 0L);
        numberAxis1.setTickUnit(numberTickUnit8, true, false);
        boolean boolean15 = numberAxis1.isAutoRange();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[size=1]" + "'", str9.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.title.Title title4 = titleChangeEvent3.getTitle();
        org.jfree.chart.title.Title title5 = titleChangeEvent3.getTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = title5.getVerticalAlignment();
        org.jfree.chart.block.BlockFrame blockFrame7 = title5.getFrame();
        java.awt.geom.Rectangle2D rectangle2D8 = title5.getBounds();
        org.junit.Assert.assertNotNull(title4);
        org.junit.Assert.assertNotNull(title5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertNotNull(blockFrame7);
        org.junit.Assert.assertNotNull(rectangle2D8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        boolean boolean10 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            boolean boolean12 = categoryPlot0.removeAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape10 = textBlock2.calculateBounds(graphics2D3, 0.0f, (float) (-1), textBlockAnchor6, 0.0f, (float) 10, (double) 10);
        numberAxis1.setLeftArrow(shape10);
        boolean boolean12 = numberAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
//        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
//        categoryPlot0.clearRangeAxes();
//        categoryPlot0.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str9 = projectInfo8.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getLibraries();
//        java.lang.String str11 = projectInfo8.getLicenceText();
//        java.awt.Image image12 = projectInfo8.getLogo();
//        categoryPlot0.setBackgroundImage(image12);
//        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
//        java.awt.Stroke stroke17 = valueMarker15.getStroke();
//        org.junit.Assert.assertNotNull(projectInfo8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ThreadContext" + "'", str11.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(image12);
//        org.junit.Assert.assertNotNull(stroke17);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        java.awt.Color color14 = java.awt.Color.BLUE;
        valueMarker1.setPaint((java.awt.Paint) color14);
        java.awt.Paint paint16 = valueMarker1.getOutlinePaint();
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition5);
        java.awt.Stroke stroke8 = statisticalBarRenderer0.lookupSeriesOutlineStroke((int) (short) -1);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true, true);
        statisticalBarRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setBaseSeriesVisible(false, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator7);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) '#', 0.0d, 3.0d, (double) 3);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        boolean boolean15 = blockBorder13.equals((java.lang.Object) color14);
        statisticalBarRenderer0.setBaseFillPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setBaseSeriesVisible(false, false);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setDomainAxisLocation(15, axisLocation15, true);
        categoryPlot13.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot13.getRendererForDataset(categoryDataset19);
        java.awt.Stroke stroke21 = categoryPlot13.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 10L, (double) (byte) 1, 0.0d);
        org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder(paint12, stroke21, rectangleInsets26);
        java.awt.Paint paint28 = lineBorder27.getPaint();
        try {
            statisticalBarRenderer0.setSeriesItemLabelPaint((-12), paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list6 = defaultStatisticalCategoryDataset5.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity9 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        java.util.List list11 = defaultStatisticalCategoryDataset5.getRowKeys();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        java.awt.Paint paint7 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        int int10 = categoryPlot9.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot9.getRangeAxisEdge();
        java.awt.Paint paint12 = categoryPlot9.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot9.getRangeAxisEdge();
        boolean boolean14 = categoryPlot9.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double18 = categoryAxis15.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int20 = numberTickUnit19.getMinorTickCount();
        java.awt.Font font21 = categoryAxis15.getTickLabelFont((java.lang.Comparable) numberTickUnit19);
        categoryPlot9.setNoDataMessageFont(font21);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke24 = statisticalBarRenderer23.getBaseStroke();
        java.awt.Paint paint26 = statisticalBarRenderer23.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        statisticalBarRenderer23.setBaseStroke(stroke28, false);
        categoryPlot9.setRangeGridlineStroke(stroke28);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot9.setRangeAxisLocation(axisLocation32, true);
        try {
            categoryPlot0.setRangeAxisLocation((-12), axisLocation32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(axisLocation32);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = legendTitle19.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean26 = numberAxis25.isVerticalTickLabels();
        org.jfree.data.Range range27 = numberAxis25.getRange();
        numberAxis25.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        categoryPlot30.setDomainAxisLocation(15, axisLocation32, true);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        textTitle35.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = textTitle35.getMargin();
        categoryPlot30.setInsets(rectangleInsets38, false);
        double double42 = rectangleInsets38.extendHeight((double) 100.0f);
        double double44 = rectangleInsets38.calculateTopOutset((double) 'a');
        java.awt.Font font46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("ClassContext", font46);
        labelBlock47.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        boolean boolean51 = labelBlock47.equals((java.lang.Object) textTitle50);
        java.awt.geom.Rectangle2D rectangle2D52 = textTitle50.getBounds();
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets38.createOutsetRectangle(rectangle2D52);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        int int55 = categoryPlot54.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot54.getRangeAxisEdge();
        java.awt.Paint paint57 = categoryPlot54.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot54.getRangeAxisEdge();
        boolean boolean59 = categoryPlot54.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot54.getDomainAxisEdge((int) (short) -1);
        boolean boolean63 = rectangleEdge61.equals((java.lang.Object) "hi!");
        double double64 = numberAxis25.valueToJava2D((double) 0.5f, rectangle2D52, rectangleEdge61);
        try {
            legendTitle19.draw(graphics2D23, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        int int7 = categoryPlot0.getDatasetCount();
        categoryPlot0.setAnchorValue((double) (byte) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        int int11 = categoryPlot10.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot10.getRangeAxisEdge();
        java.awt.Paint paint13 = categoryPlot10.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot10.getRangeAxisEdge();
        boolean boolean15 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot10.getDomainAxisEdge((int) (short) -1);
        categoryPlot10.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot10);
        categoryPlot0.notifyListeners(plotChangeEvent20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer0.getBaseURLGenerator();
        boolean boolean10 = statisticalBarRenderer0.getAutoPopulateSeriesFillPaint();
        statisticalBarRenderer0.setItemLabelAnchorOffset((double) (byte) 100);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.lang.Object obj3 = size2D2.clone();
        java.lang.String str4 = size2D2.toString();
        double double5 = size2D2.height;
        java.lang.String str6 = size2D2.toString();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str4.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str6.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.lang.Object obj3 = size2D2.clone();
        size2D2.setHeight((double) 1);
        size2D2.width = 100.0d;
        java.lang.String str8 = size2D2.toString();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Size2D[width=100.0, height=1.0]" + "'", str8.equals("Size2D[width=100.0, height=1.0]"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        java.awt.Paint paint6 = statisticalBarRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setWeight((int) (byte) 10);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Stroke stroke12 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent13);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list19 = defaultStatisticalCategoryDataset18.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity22 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        int int23 = defaultStatisticalCategoryDataset18.getColumnCount();
        int int24 = defaultStatisticalCategoryDataset18.getColumnCount();
        org.jfree.data.Range range25 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18);
        org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, 2);
        double double28 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset27);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(pieDataset27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis2.setVisible(true);
        numberAxis2.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range8 = numberAxis2.getRange();
        double double9 = range8.getLength();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range8, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (-16711681), range12);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray18, numberArray21, numberArray24, numberArray27, numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset35);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35, 0.0d);
        org.jfree.data.Range range39 = org.jfree.data.Range.combine(range12, range38);
        org.jfree.data.Range range41 = org.jfree.data.Range.expandToInclude(range38, (double) 10);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11.0d + "'", double9 == 11.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.3d + "'", number36.equals(0.3d));
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) 'a');
        double double5 = statisticalBarRenderer0.getItemMargin();
        java.awt.Paint paint8 = statisticalBarRenderer0.getItemOutlinePaint((-16711681), (int) (short) 0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke5 = statisticalBarRenderer0.getBaseOutlineStroke();
        boolean boolean6 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean8 = statisticalBarRenderer0.getIncludeBaseInRange();
        boolean boolean9 = statisticalBarRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Paint paint10 = statisticalBarRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (-1L));
        categoryAxis0.setCategoryMargin(0.0d);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot11.setRenderer((int) (byte) 100, categoryItemRenderer15);
        boolean boolean17 = categoryPlot11.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean20 = numberAxis19.isVerticalTickLabels();
        org.jfree.data.Range range21 = numberAxis19.getRange();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot24.setDomainAxisLocation(15, axisLocation26, true);
        categoryPlot24.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot24.getRendererForDataset(categoryDataset30);
        java.awt.Stroke stroke32 = categoryPlot24.getOutlineStroke();
        valueMarker23.setStroke(stroke32);
        valueMarker23.setLabel("ThreadContext");
        double double36 = valueMarker23.getValue();
        java.awt.Font font38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("ClassContext", font38);
        labelBlock39.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        boolean boolean43 = labelBlock39.equals((java.lang.Object) textTitle42);
        java.awt.geom.Rectangle2D rectangle2D44 = textTitle42.getBounds();
        statisticalBarRenderer8.drawRangeMarker(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.plot.Marker) valueMarker23, rectangle2D44);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot11.getDomainAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection48 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection49 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection48.addAll(legendItemCollection49);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis51.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis51.setTickLabelsVisible(true);
        boolean boolean56 = legendItemCollection49.equals((java.lang.Object) categoryAxis51);
        java.awt.Shape shape63 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color64 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem65 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape63, (java.awt.Paint) color64);
        java.awt.Stroke stroke66 = legendItem65.getLineStroke();
        legendItemCollection49.add(legendItem65);
        categoryPlot11.setFixedLegendItems(legendItemCollection49);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-1.0d) + "'", double36 == (-1.0d));
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        jFreeChart9.setBackgroundImageAlpha(0.5f);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart9.removeProgressListener(chartProgressListener13);
        java.lang.Object obj15 = jFreeChart9.getTextAntiAlias();
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart9.removeChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.awt.Paint paint1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        int int3 = categoryPlot2.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot2.getRangeAxisEdge();
        java.awt.Paint paint5 = categoryPlot2.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = categoryPlot2.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double11 = categoryAxis8.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int13 = numberTickUnit12.getMinorTickCount();
        java.awt.Font font14 = categoryAxis8.getTickLabelFont((java.lang.Comparable) numberTickUnit12);
        categoryPlot2.setNoDataMessageFont(font14);
        int int16 = categoryPlot2.getDatasetCount();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        categoryPlot19.setDomainAxisLocation(15, axisLocation21, true);
        categoryPlot19.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot19.getRendererForDataset(categoryDataset25);
        java.awt.Stroke stroke27 = categoryPlot19.getOutlineStroke();
        valueMarker18.setStroke(stroke27);
        valueMarker18.setLabel("ThreadContext");
        java.awt.Color color31 = java.awt.Color.BLUE;
        valueMarker18.setPaint((java.awt.Paint) color31);
        categoryPlot2.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker18);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke35 = statisticalBarRenderer34.getBaseStroke();
        valueMarker18.setStroke(stroke35);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator38 = null;
        statisticalBarRenderer37.setBaseToolTipGenerator(categoryToolTipGenerator38, false);
        java.awt.Paint paint42 = statisticalBarRenderer37.lookupSeriesFillPaint(0);
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker(50.0d, paint1, stroke35, paint42, stroke43, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleEdge.TOP", "CategoryAnchor.MIDDLE");
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0.95f, (double) 0, (double) 255, 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "Size2D[width=0.0, height=0.0]", "RectangleEdge.TOP", "DatasetRenderingOrder.FORWARD", "RectangleAnchor.CENTER");
        java.lang.String str6 = basicProjectInfo5.getVersion();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str6.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition5);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color14 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape13, (java.awt.Paint) color14);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color14);
        boolean boolean19 = statisticalBarRenderer0.isItemLabelVisible(2, 0);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        java.lang.String str6 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setCategoryMargin(0.5d);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = valueMarker1.getLabelOffset();
        double double15 = valueMarker1.getValue();
        try {
            valueMarker1.setAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        org.jfree.chart.entity.LegendItemEntity legendItemEntity31 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D28);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        int int34 = categoryPlot33.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot33.getRangeAxisEdge();
        java.awt.Paint paint36 = categoryPlot33.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot33.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot33.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot33.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo42, point2D43);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = categoryPlot33.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation32, plotOrientation45);
        boolean boolean47 = legendItemEntity31.equals((java.lang.Object) plotOrientation45);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toUnconstrainedHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        double double3 = rectangleInsets1.calculateLeftOutset((double) (short) 100);
        double double5 = rectangleInsets1.extendWidth(1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.00000001d + "'", double5 == 2.00000001d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle19.getLegendItemGraphicLocation();
        org.jfree.chart.text.TextBlock textBlock21 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape29 = textBlock21.calculateBounds(graphics2D22, 0.0f, (float) (-1), textBlockAnchor25, 0.0f, (float) 10, (double) 10);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.awt.Shape shape37 = textBlock21.calculateBounds(graphics2D30, (float) 1L, (float) 3, textBlockAnchor33, (float) 'a', 0.0f, (double) (byte) -1);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType38 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition40 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor20, textBlockAnchor33, categoryLabelWidthType38, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 10L, (double) (byte) 1, 0.0d);
        double double12 = rectangleInsets10.calculateRightInset(0.3d);
        categoryPlot0.setInsets(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setID("ClassContext");
        java.lang.Object obj9 = null;
        columnArrangement5.add((org.jfree.chart.block.Block) textTitle6, obj9);
        boolean boolean11 = textAnchor0.equals((java.lang.Object) textTitle6);
        double double12 = textTitle6.getWidth();
        double double13 = textTitle6.getHeight();
        textTitle6.setExpandToFitSpace(true);
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle6.getBounds();
        boolean boolean17 = textTitle6.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        java.awt.Stroke stroke14 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis16.setTickLabelsVisible(true);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis23.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.axis.AxisState axisState30 = null;
        java.awt.Font font32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("ClassContext", font32);
        labelBlock33.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        boolean boolean37 = labelBlock33.equals((java.lang.Object) textTitle36);
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle36.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        int int40 = categoryPlot39.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot39.getRangeAxisEdge();
        java.awt.Paint paint42 = categoryPlot39.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot39.getRangeAxisEdge();
        java.util.List list44 = categoryAxis23.refreshTicks(graphics2D29, axisState30, rectangle2D38, rectangleEdge43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean46 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge45);
        java.lang.String str47 = rectangleEdge45.toString();
        java.util.List list48 = categoryAxis16.refreshTicks(graphics2D21, axisState22, rectangle2D38, rectangleEdge45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        boolean boolean51 = categoryPlot0.render(graphics2D15, rectangle2D38, (-4194304), plotRenderingInfo50);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "RectangleEdge.RIGHT" + "'", str47.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke2 = statisticalBarRenderer1.getBaseStroke();
        java.awt.Paint paint4 = statisticalBarRenderer1.getSeriesOutlinePaint((-1));
        boolean boolean5 = statisticalBarRenderer1.getAutoPopulateSeriesOutlineStroke();
        boolean boolean6 = statisticalBarRenderer1.getBaseSeriesVisible();
        statisticalBarRenderer1.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis12.setPositiveArrowVisible(true);
        numberAxis12.setFixedAutoRange((double) (short) 0);
        numberAxis12.setRangeWithMargins((double) 0, (double) '#');
        numberAxis12.setAutoRange(false);
        java.awt.Font font23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("ClassContext", font23);
        labelBlock24.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        boolean boolean28 = labelBlock24.equals((java.lang.Object) textTitle27);
        java.awt.geom.Rectangle2D rectangle2D29 = textTitle27.getBounds();
        statisticalBarRenderer1.drawRangeGridline(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis12, rectangle2D29, (double) (-16711681));
        org.jfree.chart.entity.LegendItemEntity legendItemEntity32 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D29);
        boolean boolean33 = lengthAdjustmentType0.equals((java.lang.Object) legendItemEntity32);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        boolean boolean3 = numberAxis1.isInverted();
        boolean boolean4 = numberAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(4);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        boolean boolean13 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot14.setDomainAxisLocation(15, axisLocation16, true);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        textTitle19.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle19.getMargin();
        categoryPlot14.setInsets(rectangleInsets22, false);
        double double26 = rectangleInsets22.extendHeight((double) 100.0f);
        java.lang.String str27 = rectangleInsets22.toString();
        categoryPlot0.setInsets(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str27.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
//        java.lang.String str3 = projectInfo0.getLicenceText();
//        java.lang.String str4 = projectInfo0.toString();
//        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo0.getLibraries();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3" + "'", str3.equals("3"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version ClassContext.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\n3" + "'", str4.equals("JFreeChart version ClassContext.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\n3"));
//        org.junit.Assert.assertNotNull(libraryArray5);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setWeight((int) (byte) 10);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list14 = defaultStatisticalCategoryDataset13.getColumnKeys();
        categoryPlot0.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13);
        org.jfree.chart.plot.Plot plot16 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        categoryPlot1.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot1.getRendererForDataset(categoryDataset7);
        java.awt.Stroke stroke9 = categoryPlot1.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 10L, (double) (byte) 1, 0.0d);
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder(paint0, stroke9, rectangleInsets14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = lineBorder15.getInsets();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = statisticalBarRenderer0.getPlot();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryPlot6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setToolTipText("");
        java.lang.Object obj7 = labelBlock2.clone();
        labelBlock2.setToolTipText("3");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        categoryPlot0.setForegroundAlpha((float) 192);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke19 = statisticalBarRenderer18.getBaseStroke();
        statisticalBarRenderer14.setBaseStroke(stroke19, false);
        boolean boolean22 = statisticalBarRenderer14.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke24 = statisticalBarRenderer23.getBaseStroke();
        java.awt.Paint paint26 = statisticalBarRenderer23.getSeriesOutlinePaint((-1));
        boolean boolean27 = statisticalBarRenderer23.getAutoPopulateSeriesOutlineStroke();
        statisticalBarRenderer23.setDrawBarOutline(true);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font33 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle32.setFont(font33);
        java.awt.Paint paint35 = null;
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("", font33, paint35);
        statisticalBarRenderer23.setSeriesItemLabelFont((int) (short) 100, font33);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke39 = statisticalBarRenderer38.getBaseStroke();
        java.awt.Paint paint41 = statisticalBarRenderer38.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke42 = statisticalBarRenderer38.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = null;
        statisticalBarRenderer38.setSeriesNegativeItemLabelPosition(255, itemLabelPosition44);
        boolean boolean46 = statisticalBarRenderer38.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator48 = null;
        statisticalBarRenderer38.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator48, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke52 = statisticalBarRenderer51.getBaseStroke();
        java.awt.Paint paint54 = statisticalBarRenderer51.getSeriesOutlinePaint((-1));
        java.awt.Shape shape56 = statisticalBarRenderer51.getSeriesShape((int) (byte) 100);
        statisticalBarRenderer51.setAutoPopulateSeriesShape(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray59 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { statisticalBarRenderer14, statisticalBarRenderer23, statisticalBarRenderer38, statisticalBarRenderer51 };
        categoryPlot0.setRenderers(categoryItemRendererArray59);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNull(shape56);
        org.junit.Assert.assertNotNull(categoryItemRendererArray59);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.String str1 = lengthConstraintType0.toString();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape8, (java.awt.Paint) color9);
        java.lang.String str11 = legendItem10.getLabel();
        java.awt.Paint paint12 = legendItem10.getFillPaint();
        boolean boolean13 = legendItem10.isShapeFilled();
        boolean boolean14 = lengthConstraintType0.equals((java.lang.Object) boolean13);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.FIXED" + "'", str1.equals("LengthConstraintType.FIXED"));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ClassContext" + "'", str11.equals("ClassContext"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 0.2d, 0.05d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.setURLText("hi!");
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle1.getPosition();
        boolean boolean5 = unitType0.equals((java.lang.Object) rectangleEdge4);
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.RELATIVE" + "'", str6.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setWidth((double) '4');
        java.lang.Object obj3 = textTitle0.clone();
        double double4 = textTitle0.getContentYOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("ClassContext", font14);
        labelBlock15.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        boolean boolean19 = labelBlock15.equals((java.lang.Object) textTitle18);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle18.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        int int22 = categoryPlot21.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getRangeAxisEdge();
        java.awt.Paint paint24 = categoryPlot21.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot21.getRangeAxisEdge();
        java.util.List list26 = categoryAxis5.refreshTicks(graphics2D11, axisState12, rectangle2D20, rectangleEdge25);
        textTitle0.setBounds(rectangle2D20);
        java.lang.String str28 = textTitle0.getURLText();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.cyan;
        int int6 = color5.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color5);
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("java.awt.Color[r=192,g=0,b=0]", "LegendItemEntity: seriesKey=, dataset=null", "", "java.awt.Color[r=192,g=0,b=0]", shape4, (java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-16711681) + "'", int6 == (-16711681));
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
//        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
//        org.jfree.chart.util.Layer layer6 = null;
//        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
//        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
//        java.lang.Object obj10 = jFreeChart9.clone();
//        jFreeChart9.setBackgroundImageAlignment((-4194304));
//        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//        java.awt.Stroke stroke14 = statisticalBarRenderer13.getBaseStroke();
//        java.awt.Paint paint16 = statisticalBarRenderer13.getSeriesOutlinePaint((-1));
//        boolean boolean17 = statisticalBarRenderer13.getAutoPopulateSeriesOutlineStroke();
//        boolean boolean18 = statisticalBarRenderer13.getBaseSeriesVisible();
//        java.awt.Color color20 = java.awt.Color.white;
//        statisticalBarRenderer13.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color20);
//        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer13);
//        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
//        categoryPlot23.setDomainAxisLocation(15, axisLocation25, true);
//        categoryPlot23.clearRangeAxes();
//        categoryPlot23.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo31 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str32 = projectInfo31.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray33 = projectInfo31.getLibraries();
//        java.lang.String str34 = projectInfo31.getLicenceText();
//        java.awt.Image image35 = projectInfo31.getLogo();
//        categoryPlot23.setBackgroundImage(image35);
//        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//        categoryPlot23.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker38);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = valueMarker38.getLabelAnchor();
//        legendTitle22.setLegendItemGraphicLocation(rectangleAnchor40);
//        jFreeChart9.addLegend(legendTitle22);
//        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
//        textTitle43.setID("ClassContext");
//        jFreeChart9.setTitle(textTitle43);
//        java.awt.RenderingHints renderingHints47 = null;
//        try {
//            jFreeChart9.setRenderingHints(renderingHints47);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(collection7);
//        org.junit.Assert.assertNull(categoryAxis8);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(stroke14);
//        org.junit.Assert.assertNull(paint16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(color20);
//        org.junit.Assert.assertNotNull(projectInfo31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "3" + "'", str34.equals("3"));
//        org.junit.Assert.assertNotNull(image35);
//        org.junit.Assert.assertNotNull(rectangleAnchor40);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        java.util.List list4 = categoryPlot0.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = null;
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor9);
        categoryPlot0.zoomRangeAxes(0.0d, (double) 'a', plotRenderingInfo7, point2D10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            boolean boolean13 = categoryPlot0.removeAnnotation(categoryAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertNotNull(point2D10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color2 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_LEFT", 255);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        java.awt.Color color14 = java.awt.Color.BLUE;
        valueMarker1.setPaint((java.awt.Paint) color14);
        try {
            valueMarker1.setAlpha((float) (-16711681));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        blockContainer0.clear();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke5 = statisticalBarRenderer4.getBaseStroke();
        java.awt.Paint paint7 = statisticalBarRenderer4.getSeriesOutlinePaint((-1));
        boolean boolean8 = statisticalBarRenderer4.getAutoPopulateSeriesOutlineStroke();
        boolean boolean9 = statisticalBarRenderer4.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.white;
        statisticalBarRenderer4.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer4);
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block15 = null;
        blockContainer14.add(block15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.setWidth((double) '4');
        java.lang.Object obj20 = textTitle17.clone();
        double double21 = textTitle17.getContentYOffset();
        blockContainer14.add((org.jfree.chart.block.Block) textTitle17);
        legendTitle13.setWrapper(blockContainer14);
        java.util.List list24 = blockContainer14.getBlocks();
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer14);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = legendItemEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        legendItemEntity9.setSeriesKey((java.lang.Comparable) "");
        java.lang.String str15 = legendItemEntity9.toString();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator16 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator17 = null;
        java.lang.String str18 = legendItemEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator16, uRLTagFragmentGenerator17);
        java.lang.Comparable comparable19 = legendItemEntity9.getSeriesKey();
        org.jfree.data.general.Dataset dataset20 = legendItemEntity9.getDataset();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LegendItemEntity: seriesKey=, dataset=null" + "'", str15.equals("LegendItemEntity: seriesKey=, dataset=null"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + "" + "'", comparable19.equals(""));
        org.junit.Assert.assertNull(dataset20);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer2.setSeriesNegativeItemLabelPosition(10, itemLabelPosition7);
        java.awt.Stroke stroke10 = statisticalBarRenderer2.lookupSeriesOutlineStroke((int) (short) -1);
        statisticalBarRenderer0.setBaseStroke(stroke10);
        java.awt.Font font14 = statisticalBarRenderer0.getItemLabelFont(0, (int) (short) -1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) -1, (double) (byte) 1);
        boolean boolean5 = range2.intersects((double) 100, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.lang.String str9 = legendItem8.getLabel();
        int int10 = legendItem8.getSeriesIndex();
        boolean boolean11 = legendItem8.isShapeVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.title.Title title4 = titleChangeEvent3.getTitle();
        java.lang.String str5 = title4.getID();
        org.junit.Assert.assertNotNull(title4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ClassContext" + "'", str5.equals("ClassContext"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.SortOrder sortOrder5 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke2 = statisticalBarRenderer1.getBaseStroke();
        java.awt.Paint paint4 = statisticalBarRenderer1.getSeriesOutlinePaint((-1));
        boolean boolean5 = statisticalBarRenderer1.getAutoPopulateSeriesShape();
        java.awt.Font font6 = statisticalBarRenderer1.getBaseItemLabelFont();
        statisticalBarRenderer1.setSeriesVisible(4, (java.lang.Boolean) false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = statisticalBarRenderer1.getURLGenerator(64, (-16711681));
        boolean boolean13 = categoryAnchor0.equals((java.lang.Object) (-16711681));
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range5 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis7.setVisible(true);
        numberAxis7.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range13 = numberAxis7.getRange();
        double double14 = range13.getLength();
        org.jfree.data.Range range17 = org.jfree.data.Range.expand(range13, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint2.toRangeWidth(range17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint18.toFixedWidth(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 11.0d + "'", double14 == 11.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range7 = numberAxis1.getRange();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment8, verticalAlignment9, (double) ' ', (double) '4');
        boolean boolean13 = numberAxis1.equals((java.lang.Object) horizontalAlignment8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        double double3 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range5);
        double double7 = rectangleConstraint6.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.data.Range range9 = rectangleConstraint6.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setVisible(true);
        numberAxis11.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range17 = numberAxis11.getRange();
        double double18 = range17.getLength();
        org.jfree.data.Range range21 = org.jfree.data.Range.expand(range17, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint6.toRangeWidth(range21);
        numberAxis1.setRange(range21, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot26.setDomainAxisLocation(15, axisLocation28, true);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        textTitle31.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = textTitle31.getMargin();
        categoryPlot26.setInsets(rectangleInsets34, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = categoryPlot26.getInsets();
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot26);
        double double39 = numberAxis1.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 11.0d + "'", double18 == 11.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 21.0d + "'", double39 == 21.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        boolean boolean9 = legendItem8.isShapeFilled();
        java.awt.Paint paint10 = legendItem8.getFillPaint();
        boolean boolean11 = legendItem8.isLineVisible();
        legendItem8.setSeriesIndex(2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ItemLabelAnchor.OUTSIDE3");
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) -1, (double) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot4.setDomainAxisLocation(15, axisLocation6, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot4.getDomainMarkers(layer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot4);
        java.lang.Object obj13 = jFreeChart12.clone();
        boolean boolean14 = range2.equals(obj13);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot0.getOrientation();
        java.util.List list13 = categoryPlot0.getCategories();
        boolean boolean14 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = null;
        try {
            legendTitle19.setLegendItemGraphicPadding(rectangleInsets21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ClassContext", font4);
        labelBlock5.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock5.setToolTipText("");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) labelBlock5);
        java.lang.String str11 = labelBlock5.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock14 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape22 = textBlock14.calculateBounds(graphics2D15, 0.0f, (float) (-1), textBlockAnchor18, 0.0f, (float) 10, (double) 10);
        numberAxis13.setLeftArrow(shape22);
        java.text.NumberFormat numberFormat24 = numberAxis13.getNumberFormatOverride();
        blockContainer0.add((org.jfree.chart.block.Block) labelBlock5, (java.lang.Object) numberFormat24);
        boolean boolean26 = blockContainer0.isEmpty();
        java.lang.Object obj27 = blockContainer0.clone();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(numberFormat24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ClassContext", font5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str8 = color7.toString();
        boolean boolean10 = color7.equals((java.lang.Object) 'a');
        textBlock0.addLine("java.awt.Color[r=192,g=0,b=0]", font5, (java.awt.Paint) color7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textBlock0.getLineAlignment();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Font font15 = statisticalBarRenderer14.getBaseItemLabelFont();
        java.lang.Object obj17 = null;
        org.jfree.data.KeyedObject keyedObject18 = new org.jfree.data.KeyedObject((java.lang.Comparable) (byte) 100, obj17);
        java.awt.Paint paint19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        keyedObject18.setObject((java.lang.Object) paint19);
        textBlock0.addLine("", font15, paint19);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str8.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.setID("ClassContext");
        java.lang.Object obj13 = null;
        columnArrangement9.add((org.jfree.chart.block.Block) textTitle10, obj13);
        boolean boolean15 = textAnchor4.equals((java.lang.Object) textTitle10);
        textLine0.draw(graphics2D1, (float) '4', (float) (short) 10, textAnchor4, (float) (short) -1, (float) 0L, 0.0d);
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block21 = null;
        blockContainer20.add(block21);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle();
        textTitle23.setWidth((double) '4');
        java.lang.Object obj26 = textTitle23.clone();
        double double27 = textTitle23.getContentYOffset();
        blockContainer20.add((org.jfree.chart.block.Block) textTitle23);
        boolean boolean29 = textAnchor4.equals((java.lang.Object) blockContainer20);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke2 = statisticalBarRenderer1.getBaseStroke();
        java.awt.Paint paint4 = statisticalBarRenderer1.getSeriesOutlinePaint((-1));
        boolean boolean5 = statisticalBarRenderer1.getAutoPopulateSeriesShape();
        java.awt.Font font6 = statisticalBarRenderer1.getBaseItemLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot7.setDomainAxisLocation(15, axisLocation9, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke14 = statisticalBarRenderer13.getBaseStroke();
        java.awt.Paint paint16 = statisticalBarRenderer13.getSeriesOutlinePaint((-1));
        boolean boolean17 = statisticalBarRenderer13.getAutoPopulateSeriesOutlineStroke();
        categoryPlot7.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer13, true);
        java.awt.Paint paint20 = statisticalBarRenderer13.getBaseOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("", font6, paint20, (float) ' ');
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation1);
        int int3 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        textTitle0.setHeight((double) 0);
        textTitle0.setURLText("JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]");
        textTitle0.setNotify(false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (short) 100, (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke2 = statisticalBarRenderer1.getBaseStroke();
        java.awt.Paint paint4 = statisticalBarRenderer1.getSeriesOutlinePaint((-1));
        boolean boolean5 = statisticalBarRenderer1.getAutoPopulateSeriesShape();
        java.awt.Font font6 = statisticalBarRenderer1.getBaseItemLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer1.setSeriesFillPaint(100, paint8, true);
        boolean boolean11 = gradientPaintTransformType0.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        statisticalBarRenderer0.notifyListeners(rendererChangeEvent6);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle2.setFont(font3);
        java.awt.Paint paint5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint5);
        org.jfree.chart.text.TextBlock textBlock7 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape15 = textBlock7.calculateBounds(graphics2D8, 0.0f, (float) (-1), textBlockAnchor11, 0.0f, (float) 10, (double) 10);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        textBlock7.draw(graphics2D16, (float) 0L, (float) 0, textBlockAnchor20, (float) 0L, (float) (byte) 10, (double) 0.0f);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        int int28 = categoryPlot27.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot27.getRangeAxisEdge();
        java.awt.Paint paint30 = categoryPlot27.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot27.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot27.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot27.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo36, point2D37);
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = categoryPlot27.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation26, plotOrientation39);
        boolean boolean41 = textBlockAnchor20.equals((java.lang.Object) plotOrientation39);
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick44 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) ' ', textBlock6, textBlockAnchor20, textAnchor42, (double) 0.8f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(textAnchor42);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.setID("ClassContext");
        java.lang.Object obj13 = null;
        columnArrangement9.add((org.jfree.chart.block.Block) textTitle10, obj13);
        boolean boolean15 = textAnchor4.equals((java.lang.Object) textTitle10);
        textLine0.draw(graphics2D1, (float) '4', (float) (short) 10, textAnchor4, (float) (short) -1, (float) 0L, 0.0d);
        boolean boolean21 = textAnchor4.equals((java.lang.Object) 10.0d);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        java.awt.Paint paint5 = statisticalBarRenderer0.getSeriesItemLabelPaint(3);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        int int8 = categoryPlot7.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getRangeAxisEdge();
        java.awt.Paint paint10 = categoryPlot7.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot7.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot7.getDomainAxisEdge(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot14.setDomainAxisLocation(15, axisLocation16, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke21 = statisticalBarRenderer20.getBaseStroke();
        java.awt.Paint paint23 = statisticalBarRenderer20.getSeriesOutlinePaint((-1));
        boolean boolean24 = statisticalBarRenderer20.getAutoPopulateSeriesOutlineStroke();
        categoryPlot14.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer20, true);
        java.awt.Shape shape28 = statisticalBarRenderer20.lookupSeriesShape((int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation31 = null;
        categoryPlot29.setDomainAxisLocation(15, axisLocation31, true);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        textTitle34.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = textTitle34.getMargin();
        categoryPlot29.setInsets(rectangleInsets37, false);
        double double41 = rectangleInsets37.extendHeight((double) 100.0f);
        java.lang.String str42 = rectangleInsets37.toString();
        java.awt.Font font44 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("ClassContext", font44);
        labelBlock45.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle();
        boolean boolean49 = labelBlock45.equals((java.lang.Object) textTitle48);
        java.awt.geom.Rectangle2D rectangle2D50 = textTitle48.getBounds();
        rectangleInsets37.trim(rectangle2D50);
        boolean boolean52 = org.jfree.chart.util.ShapeUtilities.equal(shape28, (java.awt.Shape) rectangle2D50);
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D6, categoryPlot7, rectangle2D50, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.0d + "'", double41 == 100.0d);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str42.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setWidth((double) '4');
        java.lang.Object obj3 = textTitle0.clone();
        double double4 = textTitle0.getContentYOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("ClassContext", font14);
        labelBlock15.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        boolean boolean19 = labelBlock15.equals((java.lang.Object) textTitle18);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle18.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        int int22 = categoryPlot21.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getRangeAxisEdge();
        java.awt.Paint paint24 = categoryPlot21.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot21.getRangeAxisEdge();
        java.util.List list26 = categoryAxis5.refreshTicks(graphics2D11, axisState12, rectangle2D20, rectangleEdge25);
        textTitle0.setBounds(rectangle2D20);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D20, 50.0d, (float) 10L, (float) (-1));
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("3", "java.awt.Color[r=192,g=0,b=0]", "ThreadContext", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str5 = basicProjectInfo4.getVersion();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str5.equals("java.awt.Color[r=192,g=0,b=0]"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list6 = defaultStatisticalCategoryDataset5.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity9 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        java.lang.Number number12 = defaultStatisticalCategoryDataset5.getStdDevValue((java.lang.Comparable) "LegendItemEntity: seriesKey=, dataset=null", (java.lang.Comparable) 32.0f);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str14 = numberTickUnit13.toString();
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        boolean boolean16 = numberTickUnit13.equals((java.lang.Object) textAnchor15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double20 = categoryAxis17.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int22 = numberTickUnit21.getMinorTickCount();
        java.awt.Font font23 = categoryAxis17.getTickLabelFont((java.lang.Comparable) numberTickUnit21);
        java.lang.Number number24 = defaultStatisticalCategoryDataset5.getValue((java.lang.Comparable) numberTickUnit13, (java.lang.Comparable) numberTickUnit21);
        double double26 = defaultStatisticalCategoryDataset5.getRangeUpperBound(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "[size=1]" + "'", str14.equals("[size=1]"));
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double12 = rectangleInsets8.extendHeight((double) 100.0f);
        double double14 = rectangleInsets8.calculateTopOutset((double) 'a');
        java.awt.Font font16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ClassContext", font16);
        labelBlock17.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        boolean boolean21 = labelBlock17.equals((java.lang.Object) textTitle20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets8.createOutsetRectangle(rectangle2D22);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        java.awt.Paint paint30 = statisticalBarRenderer27.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke31 = statisticalBarRenderer27.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        statisticalBarRenderer27.setSeriesNegativeItemLabelPosition(255, itemLabelPosition33);
        boolean boolean35 = statisticalBarRenderer27.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = null;
        statisticalBarRenderer27.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator37, false);
        boolean boolean40 = defaultStatisticalCategoryDataset26.equals((java.lang.Object) statisticalBarRenderer27);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity44 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D22, "TextAnchor.CENTER_RIGHT", "TextBlockAnchor.TOP_LEFT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26, (java.lang.Comparable) 1, (java.lang.Comparable) numberTickUnit43);
        double double46 = defaultStatisticalCategoryDataset26.getRangeLowerBound(false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        boolean boolean31 = numberAxis11.isTickMarksVisible();
        java.awt.Paint paint32 = numberAxis11.getTickLabelPaint();
        numberAxis11.setLowerBound((double) ' ');
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        java.awt.Paint paint5 = statisticalBarRenderer0.getSeriesItemLabelPaint(3);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot7.setDomainAxisLocation(15, axisLocation9, true);
        categoryPlot7.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot7.getRendererForDataset(categoryDataset13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot7.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis17.setTickMarkOutsideLength((float) (short) 100);
        numberAxis17.setLabelAngle((double) '4');
        org.jfree.data.Range range22 = categoryPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis17);
        java.text.NumberFormat numberFormat23 = null;
        numberAxis17.setNumberFormatOverride(numberFormat23);
        java.awt.Shape shape25 = numberAxis17.getRightArrow();
        org.jfree.chart.text.TextBlock textBlock26 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = textBlock26.calculateDimensions(graphics2D27);
        java.awt.Font font31 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("ClassContext", font31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str34 = color33.toString();
        boolean boolean36 = color33.equals((java.lang.Object) 'a');
        textBlock26.addLine("java.awt.Color[r=192,g=0,b=0]", font31, (java.awt.Paint) color33);
        numberAxis17.setTickMarkPaint((java.awt.Paint) color33);
        java.awt.Color color39 = java.awt.Color.darkGray;
        float[] floatArray46 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray47 = color39.getRGBColorComponents(floatArray46);
        numberAxis17.setTickLabelPaint((java.awt.Paint) color39);
        try {
            statisticalBarRenderer0.setSeriesPaint((int) (short) -1, (java.awt.Paint) color39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str34.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot14.setDomainAxisLocation(15, axisLocation16, true);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        textTitle19.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle19.getMargin();
        categoryPlot14.setInsets(rectangleInsets22, false);
        double double26 = rectangleInsets22.extendHeight((double) 100.0f);
        double double28 = rectangleInsets22.calculateTopOutset((double) 'a');
        java.awt.Font font30 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("ClassContext", font30);
        labelBlock31.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        boolean boolean35 = labelBlock31.equals((java.lang.Object) textTitle34);
        java.awt.geom.Rectangle2D rectangle2D36 = textTitle34.getBounds();
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets22.createOutsetRectangle(rectangle2D36);
        valueMarker1.setLabelOffset(rectangleInsets22);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("hi!");
        boolean boolean3 = textTitle0.getExpandToFitSpace();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getPadding();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.LegendItem legendItem4 = statisticalBarRenderer0.getLegendItem((int) (short) 100, (int) (byte) 10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        statisticalBarRenderer5.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer5.setBaseSeriesVisible(false, false);
        java.awt.Font font14 = statisticalBarRenderer5.getItemLabelFont((int) (short) 1, (int) '4');
        statisticalBarRenderer0.setBaseItemLabelFont(font14, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(legendItem4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.event.TitleChangeListener titleChangeListener2 = null;
        textTitle1.addChangeListener(titleChangeListener2);
        java.awt.Paint paint4 = textTitle1.getPaint();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double11 = rectangleInsets8.getLeft();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        textTitle12.setURLText("hi!");
        boolean boolean15 = textTitle12.getExpandToFitSpace();
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle12.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets8.createOutsetRectangle(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray13, numberArray16, numberArray19, numberArray22, numberArray25, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray29);
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset30, 0.0d);
        legendItem8.setDataset((org.jfree.data.general.Dataset) categoryDataset30);
        java.awt.Stroke stroke35 = legendItem8.getOutlineStroke();
        java.awt.Paint paint36 = legendItem8.getOutlinePaint();
        legendItem8.setDatasetIndex(4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.3d + "'", number31.equals(0.3d));
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double12 = rectangleInsets8.extendHeight((double) 100.0f);
        double double14 = rectangleInsets8.extendWidth((double) 100);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("PlotOrientation.VERTICAL");
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        java.awt.Stroke stroke8 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        categoryItemRendererState1.setBarWidth(0.0d);
        org.jfree.chart.entity.EntityCollection entityCollection4 = categoryItemRendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list13 = defaultStatisticalCategoryDataset12.getColumnKeys();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot0.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot17.setDomainAxisLocation(15, axisLocation19, true);
        categoryPlot17.clearRangeAxes();
        categoryPlot17.setAnchorValue((double) (short) 0);
        categoryPlot17.setWeight((int) (byte) 10);
        categoryPlot17.setRangeCrosshairValue(1.0d, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator32 = null;
        statisticalBarRenderer31.setBaseToolTipGenerator(categoryToolTipGenerator32, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        statisticalBarRenderer31.setSeriesNegativeItemLabelPosition(10, itemLabelPosition36);
        java.awt.Stroke stroke39 = statisticalBarRenderer31.lookupSeriesOutlineStroke((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        int int41 = categoryPlot40.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        categoryPlot40.setFixedDomainAxisSpace(axisSpace42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis45.setVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent48 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis45);
        categoryPlot40.axisChanged(axisChangeEvent48);
        statisticalBarRenderer31.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot40);
        categoryPlot17.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer31, false);
        boolean boolean53 = defaultStatisticalCategoryDataset12.hasListener((java.util.EventListener) categoryPlot17);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setDomainAxisLocation(15, axisLocation15, true);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot13.getDomainMarkers(layer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot13.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot13);
        java.lang.Object obj22 = jFreeChart21.clone();
        jFreeChart21.setBackgroundImageAlignment((-4194304));
        java.awt.Paint paint25 = jFreeChart21.getBorderPaint();
        statisticalBarRenderer0.setBaseFillPaint(paint25);
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment28, verticalAlignment29, (double) ' ', (double) '4');
        columnArrangement32.clear();
        columnArrangement32.clear();
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement32);
        org.jfree.chart.ui.Licences licences36 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str37 = licences36.getGPL();
        java.lang.String str38 = licences36.getGPL();
        boolean boolean39 = columnArrangement27.equals((java.lang.Object) str38);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(licences36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis3.setTickLabelsVisible(true);
        boolean boolean8 = legendItemCollection1.equals((java.lang.Object) categoryAxis3);
        org.jfree.chart.text.TextBlock textBlock9 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape17 = textBlock9.calculateBounds(graphics2D10, 0.0f, (float) (-1), textBlockAnchor13, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        int int21 = categoryPlot20.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot20.getRangeAxisEdge();
        java.awt.Paint paint23 = categoryPlot20.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot20.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot20.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot20.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo29, point2D30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = categoryPlot20.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation32);
        boolean boolean34 = legendItemEntity18.equals((java.lang.Object) rectangleEdge33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setDomainAxisLocation(15, axisLocation37, true);
        categoryPlot35.clearRangeAxes();
        categoryPlot35.setAnchorValue((double) (short) 0);
        categoryPlot35.setWeight((int) (byte) 10);
        categoryPlot35.setRangeCrosshairVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list49 = defaultStatisticalCategoryDataset48.getColumnKeys();
        categoryPlot35.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset48);
        legendItemEntity18.setDataset((org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset48);
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset48, false);
        boolean boolean54 = legendItemCollection1.equals((java.lang.Object) defaultStatisticalCategoryDataset48);
        java.util.Iterator iterator55 = legendItemCollection1.iterator();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(iterator55);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((-1.0d), 0.3d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        categoryPlot0.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Plot plot11 = plotChangeEvent10.getPlot();
        java.awt.Paint paint12 = plot11.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle2.setFont(font3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("java.awt.Color[r=192,g=0,b=0]", font3);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot8.setDomainAxisLocation(15, axisLocation10, true);
        categoryPlot8.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot8.getRendererForDataset(categoryDataset14);
        java.awt.Stroke stroke16 = categoryPlot8.getOutlineStroke();
        valueMarker7.setStroke(stroke16);
        valueMarker7.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = valueMarker7.getLabelOffset();
        java.awt.Color color21 = java.awt.Color.white;
        int int22 = color21.getGreen();
        valueMarker7.setPaint((java.awt.Paint) color21);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=192,g=0,b=0]", font3, (java.awt.Paint) color21);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke26 = statisticalBarRenderer25.getBaseStroke();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = null;
        statisticalBarRenderer25.setSeriesURLGenerator((int) (byte) 1, categoryURLGenerator28);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator32 = statisticalBarRenderer31.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = null;
        statisticalBarRenderer33.setBaseToolTipGenerator(categoryToolTipGenerator34, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = null;
        statisticalBarRenderer33.setSeriesNegativeItemLabelPosition(10, itemLabelPosition38);
        java.awt.Stroke stroke41 = statisticalBarRenderer33.lookupSeriesOutlineStroke((int) (short) -1);
        statisticalBarRenderer31.setBaseStroke(stroke41);
        statisticalBarRenderer25.setSeriesOutlineStroke((int) (short) 100, stroke41, false);
        boolean boolean45 = textFragment24.equals((java.lang.Object) statisticalBarRenderer25);
        boolean boolean46 = statisticalBarRenderer25.getIncludeBaseInRange();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator32);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis3.setTickLabelsVisible(true);
        boolean boolean8 = legendItemCollection1.equals((java.lang.Object) categoryAxis3);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape15, (java.awt.Paint) color16);
        java.awt.Stroke stroke18 = legendItem17.getLineStroke();
        legendItemCollection1.add(legendItem17);
        java.awt.Stroke stroke20 = legendItem17.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("LengthConstraintType.FIXED", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot11 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(plot11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Font font5 = statisticalBarRenderer0.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesCreateEntities((int) ' ', (java.lang.Boolean) true, true);
        java.awt.Paint paint10 = statisticalBarRenderer0.getErrorIndicatorPaint();
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesOutlinePaint((-12));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        textTitle3.setURLText("hi!");
        boolean boolean6 = textTitle3.getExpandToFitSpace();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle3.getBounds();
        blockContainer0.add((org.jfree.chart.block.Block) textTitle3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        int int14 = categoryPlot0.getDatasetCount();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double22 = categoryAxis19.getLabelAngle();
        java.lang.String str24 = categoryAxis19.getCategoryLabelToolTip((java.lang.Comparable) 100);
        boolean boolean25 = categoryAxis19.isVisible();
        categoryPlot0.setDomainAxis((int) (short) 1, categoryAxis19, true);
        categoryAxis19.setUpperMargin((double) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle0.setFont(font1);
        textTitle0.setHeight((double) (short) -1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.JFreeChart jFreeChart6 = titleChangeEvent5.getChart();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double5 = categoryAxis2.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int7 = numberTickUnit6.getMinorTickCount();
        java.awt.Font font8 = categoryAxis2.getTickLabelFont((java.lang.Comparable) numberTickUnit6);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        statisticalBarRenderer10.setBaseToolTipGenerator(categoryToolTipGenerator11, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalBarRenderer10.setSeriesNegativeItemLabelPosition(10, itemLabelPosition15);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color24 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape23, (java.awt.Paint) color24);
        statisticalBarRenderer10.setBaseItemLabelPaint((java.awt.Paint) color24);
        categoryAxis2.setTickLabelPaint((java.lang.Comparable) 100L, (java.awt.Paint) color24);
        java.awt.Color color28 = java.awt.Color.getColor("3", color24);
        boolean boolean29 = textAnchor0.equals((java.lang.Object) "3");
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis0.setCategoryLabelPositionOffset((int) ' ');
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "RectangleEdge.RIGHT", font7);
        java.lang.Comparable comparable9 = null;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        try {
            categoryAxis0.setTickLabelPaint(comparable9, (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        numberAxis1.resizeRange((-1.0d));
        numberAxis1.setVerticalTickLabels(true);
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        java.awt.Stroke stroke11 = jFreeChart9.getBorderStroke();
        java.awt.Paint paint12 = jFreeChart9.getBorderPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = jFreeChart9.getCategoryPlot();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(categoryPlot13);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        numberAxis1.setInverted(false);
        double double9 = numberAxis1.getUpperMargin();
        numberAxis1.setFixedDimension(0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        numberAxis1.setAutoRange(false);
        boolean boolean11 = numberAxis1.isVerticalTickLabels();
        java.awt.Paint paint12 = numberAxis1.getTickMarkPaint();
        java.awt.Stroke stroke13 = numberAxis1.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isAutoRange();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        numberAxis1.removeChangeListener(axisChangeListener3);
        numberAxis1.resizeRange((double) ' ');
        boolean boolean7 = numberAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape7, (java.awt.Paint) color8);
        boolean boolean10 = legendItem9.isLineVisible();
        java.awt.Stroke stroke11 = legendItem9.getOutlineStroke();
        boolean boolean12 = lengthAdjustmentType0.equals((java.lang.Object) stroke11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("RectangleAnchor.CENTER");
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis2.setVisible(true);
        numberAxis2.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range8 = numberAxis2.getRange();
        double double9 = range8.getLength();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range8, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (-16711681), range12);
        org.jfree.data.Range range14 = rectangleConstraint13.getWidthRange();
        org.jfree.data.Range range15 = rectangleConstraint13.getWidthRange();
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11.0d + "'", double9 == 11.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setDomainAxisLocation(15, axisLocation5, true);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot3.getDomainMarkers(layer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot3.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) "ClassContext", jFreeChart11, (-4194304), (-4194304));
        org.jfree.chart.JFreeChart jFreeChart15 = chartProgressEvent14.getChart();
        jFreeChart15.setBackgroundImageAlpha((float) '4');
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(jFreeChart15);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double12 = rectangleInsets8.extendHeight((double) 100.0f);
        double double14 = rectangleInsets8.calculateTopOutset((double) 'a');
        java.awt.Font font16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ClassContext", font16);
        labelBlock17.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        boolean boolean21 = labelBlock17.equals((java.lang.Object) textTitle20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets8.createOutsetRectangle(rectangle2D22);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        java.awt.Paint paint30 = statisticalBarRenderer27.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke31 = statisticalBarRenderer27.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        statisticalBarRenderer27.setSeriesNegativeItemLabelPosition(255, itemLabelPosition33);
        boolean boolean35 = statisticalBarRenderer27.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = null;
        statisticalBarRenderer27.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator37, false);
        boolean boolean40 = defaultStatisticalCategoryDataset26.equals((java.lang.Object) statisticalBarRenderer27);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity44 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D22, "TextAnchor.CENTER_RIGHT", "TextBlockAnchor.TOP_LEFT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26, (java.lang.Comparable) 1, (java.lang.Comparable) numberTickUnit43);
        java.lang.Comparable comparable45 = categoryItemEntity44.getRowKey();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + comparable45 + "' != '" + 1 + "'", comparable45.equals(1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        java.awt.Stroke stroke10 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        java.util.List list2 = axisState1.getTicks();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list13 = defaultStatisticalCategoryDataset12.getColumnKeys();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot0.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str18 = numberTickUnit17.toString();
        java.lang.Number number20 = defaultStatisticalCategoryDataset12.getValue((java.lang.Comparable) numberTickUnit17, (java.lang.Comparable) "RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "[size=1]" + "'", str18.equals("[size=1]"));
        org.junit.Assert.assertNull(number20);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color2 = java.awt.Color.white;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font1, (java.awt.Paint) color2);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.cyan;
        int int7 = color6.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font5, (java.awt.Paint) color6);
        textLine3.removeFragment(textFragment9);
        java.awt.Graphics2D graphics2D11 = null;
        try {
            org.jfree.chart.util.Size2D size2D12 = textFragment9.calculateDimensions(graphics2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16711681) + "'", int7 == (-16711681));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot1.getRangeAxisEdge();
        categoryPlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        int int10 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6);
        java.awt.Stroke stroke12 = statisticalBarRenderer6.lookupSeriesStroke(1);
        boolean boolean13 = keyedObjects2D0.equals((java.lang.Object) stroke12);
        keyedObjects2D0.removeColumn((java.lang.Comparable) "ItemLabelAnchor.INSIDE7");
        int int17 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("hi!", font1, (java.awt.Paint) color2);
        double double4 = labelBlock3.getWidth();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range7);
        double double9 = rectangleConstraint8.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D11 = labelBlock3.arrange(graphics2D5, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) 'a', (double) 32.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis3.setTickLabelsVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis3.getCategoryLabelPositions();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        org.jfree.chart.text.TextAnchor textAnchor12 = categoryLabelPosition11.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions8, categoryLabelPosition11);
        boolean boolean14 = lengthAdjustmentType0.equals((java.lang.Object) categoryLabelPositions8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.util.SortOrder sortOrder14 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot0.setColumnRenderingOrder(sortOrder14);
        categoryPlot0.clearDomainMarkers(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(sortOrder14);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double12 = rectangleInsets8.extendHeight((double) 100.0f);
        double double14 = rectangleInsets8.calculateTopOutset((double) 'a');
        java.awt.Font font16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ClassContext", font16);
        labelBlock17.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        boolean boolean21 = labelBlock17.equals((java.lang.Object) textTitle20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets8.createOutsetRectangle(rectangle2D22);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        java.awt.Paint paint30 = statisticalBarRenderer27.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke31 = statisticalBarRenderer27.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        statisticalBarRenderer27.setSeriesNegativeItemLabelPosition(255, itemLabelPosition33);
        boolean boolean35 = statisticalBarRenderer27.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = null;
        statisticalBarRenderer27.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator37, false);
        boolean boolean40 = defaultStatisticalCategoryDataset26.equals((java.lang.Object) statisticalBarRenderer27);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity44 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D22, "TextAnchor.CENTER_RIGHT", "TextBlockAnchor.TOP_LEFT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26, (java.lang.Comparable) 1, (java.lang.Comparable) numberTickUnit43);
        org.jfree.data.general.DatasetGroup datasetGroup45 = defaultStatisticalCategoryDataset26.getGroup();
        java.lang.Number number48 = defaultStatisticalCategoryDataset26.getValue((java.lang.Comparable) 3, (java.lang.Comparable) "RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(datasetGroup45);
        org.junit.Assert.assertNull(number48);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        org.jfree.chart.plot.Plot plot11 = jFreeChart9.getPlot();
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        jFreeChart9.setNotify(true);
        jFreeChart9.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart9.createBufferedImage(10, 10, chartRenderingInfo19);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(bufferedImage20);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot10.setDomainAxisLocation(15, axisLocation12, true);
        categoryPlot10.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot10.getRendererForDataset(categoryDataset16);
        java.awt.Stroke stroke18 = categoryPlot10.getOutlineStroke();
        valueMarker9.setStroke(stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker9, layer20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setRangeCrosshairValue(3.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double12 = rectangleInsets8.extendHeight((double) 100.0f);
        java.lang.String str13 = rectangleInsets8.toString();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets8, (java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str13.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer2.setSeriesNegativeItemLabelPosition(10, itemLabelPosition7);
        java.awt.Stroke stroke10 = statisticalBarRenderer2.lookupSeriesOutlineStroke((int) (short) -1);
        statisticalBarRenderer0.setBaseStroke(stroke10);
        statisticalBarRenderer0.setSeriesCreateEntities(15, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str3 = color2.toString();
        statisticalBarRenderer0.setSeriesOutlinePaint(2, (java.awt.Paint) color2, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str3.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        java.awt.Color color14 = java.awt.Color.BLUE;
        valueMarker1.setPaint((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker1.setLabelAnchor(rectangleAnchor16);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor18);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color8, true);
        statisticalBarRenderer0.setBaseCreateEntities(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Stroke stroke16 = statisticalBarRenderer0.getBaseStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        categoryPlot1.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot1.getRendererForDataset(categoryDataset7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot1.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setTickMarkOutsideLength((float) (short) 100);
        numberAxis11.setLabelAngle((double) '4');
        org.jfree.data.Range range16 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.text.NumberFormat numberFormat17 = null;
        numberAxis11.setNumberFormatOverride(numberFormat17);
        java.awt.Shape shape19 = numberAxis11.getRightArrow();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) "RectangleEdge.RIGHT", shape19, "JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]", "AxisLocation.BOTTOM_OR_LEFT");
        java.lang.Object obj23 = categoryLabelEntity22.clone();
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.lang.Boolean boolean6 = statisticalBarRenderer0.getSeriesCreateEntities((-1));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color7);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer9);
        boolean boolean11 = statisticalBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint14 = statisticalBarRenderer0.getItemOutlinePaint(4, (-12));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = statisticalBarRenderer15.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator18 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer15.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        int int21 = categoryPlot20.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot20.getRangeAxisEdge();
        java.awt.Paint paint23 = categoryPlot20.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot20.getRangeAxisEdge();
        boolean boolean25 = categoryPlot20.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double29 = categoryAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int31 = numberTickUnit30.getMinorTickCount();
        java.awt.Font font32 = categoryAxis26.getTickLabelFont((java.lang.Comparable) numberTickUnit30);
        categoryPlot20.setNoDataMessageFont(font32);
        int int34 = categoryPlot20.getDatasetCount();
        java.awt.Stroke stroke35 = categoryPlot20.getRangeCrosshairStroke();
        statisticalBarRenderer15.setBaseStroke(stroke35);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = statisticalBarRenderer15.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator37);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(0, categoryURLGenerator12, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(itemLabelPosition15);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis8.setTickLabelsVisible(true);
        categoryAxis8.setLowerMargin((double) 100.0f);
        int int15 = categoryPlot0.getDomainAxisIndex(categoryAxis8);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setDomainAxisLocation(15, axisLocation5, true);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot3.getDomainMarkers(layer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot3.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) "ClassContext", jFreeChart11, (-4194304), (-4194304));
        org.jfree.chart.JFreeChart jFreeChart15 = chartProgressEvent14.getChart();
        chartProgressEvent14.setPercent(15);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(jFreeChart15);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        categoryPlot0.setAnchorValue((double) (byte) 100, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        statisticalBarRenderer11.setBaseToolTipGenerator(categoryToolTipGenerator12, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        statisticalBarRenderer11.setSeriesNegativeItemLabelPosition(10, itemLabelPosition16);
        java.awt.Stroke stroke19 = statisticalBarRenderer11.lookupSeriesOutlineStroke((int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = statisticalBarRenderer11.getBaseURLGenerator();
        categoryPlot0.setRenderer(255, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer11);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(categoryURLGenerator20);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle0.setFont(font1);
        textTitle0.setHeight((double) (short) -1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("ClassContext", font11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str14 = color13.toString();
        boolean boolean16 = color13.equals((java.lang.Object) 'a');
        textBlock6.addLine("java.awt.Color[r=192,g=0,b=0]", font11, (java.awt.Paint) color13);
        textTitle0.setFont(font11);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle21.setFont(font22);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font22);
        float float25 = textFragment24.getBaselineOffset();
        java.awt.Font font26 = textFragment24.getFont();
        java.awt.Color color27 = java.awt.Color.RED;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        textTitle28.setID("ClassContext");
        textTitle28.setHeight((double) 0);
        double double33 = textTitle28.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = textTitle28.getPosition();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke36 = statisticalBarRenderer35.getBaseStroke();
        java.awt.Paint paint38 = statisticalBarRenderer35.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke39 = statisticalBarRenderer35.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = null;
        statisticalBarRenderer35.setSeriesNegativeItemLabelPosition(255, itemLabelPosition41);
        java.lang.Boolean boolean44 = statisticalBarRenderer35.getSeriesVisible((int) (short) 0);
        boolean boolean45 = rectangleEdge34.equals((java.lang.Object) statisticalBarRenderer35);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement51 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment47, verticalAlignment48, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle();
        textTitle52.setID("ClassContext");
        java.lang.Object obj55 = null;
        columnArrangement51.add((org.jfree.chart.block.Block) textTitle52, obj55);
        boolean boolean57 = textAnchor46.equals((java.lang.Object) textTitle52);
        double double58 = textTitle52.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment59 = textTitle52.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment60 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = numberAxis62.getLabelInsets();
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("JFreeChart", font26, (java.awt.Paint) color27, rectangleEdge34, horizontalAlignment59, verticalAlignment60, rectangleInsets63);
        textTitle0.setVerticalAlignment(verticalAlignment60);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str14.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(boolean44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment59);
        org.junit.Assert.assertNotNull(verticalAlignment60);
        org.junit.Assert.assertNotNull(rectangleInsets63);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double10 = categoryAxis7.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int12 = numberTickUnit11.getMinorTickCount();
        java.awt.Font font13 = categoryAxis7.getTickLabelFont((java.lang.Comparable) numberTickUnit11);
        categoryPlot0.setDomainAxis(categoryAxis7);
        categoryAxis7.setTickLabelsVisible(true);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        java.awt.Stroke stroke14 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot15.setDomainAxisLocation(15, axisLocation17, true);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot15.getDomainMarkers(layer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot15.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis23.setTickLabelsVisible(true);
        categoryAxis23.setLowerMargin((double) 100.0f);
        int int30 = categoryPlot15.getDomainAxisIndex(categoryAxis23);
        categoryPlot0.setDomainAxis(categoryAxis23);
        categoryPlot0.clearRangeMarkers(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        boolean boolean10 = categoryPlot1.isRangeGridlinesVisible();
        int int11 = categoryPlot1.getWeight();
        try {
            categoryPlot1.setBackgroundImageAlpha((float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 64);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextStroke();
        java.lang.Object obj3 = defaultDrawingSupplier1.clone();
        java.awt.Shape shape4 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity7 = new org.jfree.chart.entity.CategoryLabelEntity(comparable0, shape4, "3", "ItemLabelAnchor.INSIDE7");
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        boolean boolean3 = numberAxis1.isInverted();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape14 = textBlock6.calculateBounds(graphics2D7, 0.0f, (float) (-1), textBlockAnchor10, 0.0f, (float) 10, (double) 10);
        numberAxis5.setLeftArrow(shape14);
        org.jfree.data.Range range16 = numberAxis5.getDefaultAutoRange();
        numberAxis1.setRangeWithMargins(range16, false, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) '#', (float) 192, (float) (-1));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color10 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape9, (java.awt.Paint) color10);
        java.lang.String str12 = legendItem11.getLabel();
        java.awt.Paint paint13 = legendItem11.getFillPaint();
        boolean boolean14 = legendItem11.isShapeFilled();
        legendItemCollection1.add(legendItem11);
        java.awt.Paint paint16 = legendItem11.getFillPaint();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ClassContext" + "'", str12.equals("ClassContext"));
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("CategoryLabelEntity: category=RectangleEdge.RIGHT, tooltip=JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0], url=AxisLocation.BOTTOM_OR_LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name CategoryLabelEntity: category=RectangleEdge.RIGHT, tooltip=JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0], url=AxisLocation.BOTTOM_OR_LEFT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color7);
        java.awt.Paint paint10 = null;
        try {
            statisticalBarRenderer0.setSeriesOutlinePaint((-12), paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        int int2 = numberTickUnit1.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        java.awt.Paint paint5 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("RectangleAnchor.CENTER");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("JFreeChart");
        try {
            java.lang.Object obj6 = jFreeChartResources0.getObject("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke2 = statisticalBarRenderer1.getBaseStroke();
        java.awt.Paint paint4 = statisticalBarRenderer1.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke5 = statisticalBarRenderer1.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer1.setSeriesNegativeItemLabelPosition(255, itemLabelPosition7);
        boolean boolean9 = statisticalBarRenderer1.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        statisticalBarRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator11, false);
        boolean boolean14 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) statisticalBarRenderer1);
        statisticalBarRenderer1.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("java.awt.Color[r=192,g=0,b=0]");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("hi!", font4, (java.awt.Paint) color5);
        textTitle0.setFont(font4);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str4 = projectInfo3.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo3.getLibraries();
//        java.lang.String str6 = projectInfo3.getLicenceText();
//        java.awt.Image image7 = projectInfo3.getLogo();
//        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("LegendItemEntity: seriesKey=, dataset=null", "RectangleEdge.RIGHT", "VerticalAlignment.CENTER", image7, "LengthConstraintType.FIXED", "TextAnchor.CENTER_RIGHT", "UnitType.RELATIVE");
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3" + "'", str6.equals("3"));
//        org.junit.Assert.assertNotNull(image7);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        statisticalBarRenderer0.setDrawBarOutline(true);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        java.awt.Color color14 = java.awt.Color.BLUE;
        valueMarker1.setPaint((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = valueMarker1.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        valueMarker1.setPaint((java.awt.Paint) color19);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.awt.Color color0 = java.awt.Color.cyan;
        int int1 = color0.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint3 = blockBorder2.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16711681) + "'", int1 == (-16711681));
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray5, numberArray8, numberArray11, numberArray14, numberArray17, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset22, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(0.0d, range25);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.3d + "'", number23.equals(0.3d));
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis10.setTickMarkOutsideLength((float) (short) 100);
        numberAxis10.setLabelAngle((double) '4');
        org.jfree.data.Range range15 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.text.NumberFormat numberFormat16 = null;
        numberAxis10.setNumberFormatOverride(numberFormat16);
        java.awt.Shape shape18 = numberAxis10.getRightArrow();
        org.jfree.chart.text.TextBlock textBlock19 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textBlock19.calculateDimensions(graphics2D20);
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("ClassContext", font24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str27 = color26.toString();
        boolean boolean29 = color26.equals((java.lang.Object) 'a');
        textBlock19.addLine("java.awt.Color[r=192,g=0,b=0]", font24, (java.awt.Paint) color26);
        numberAxis10.setTickMarkPaint((java.awt.Paint) color26);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean34 = numberAxis33.isNegativeArrowVisible();
        double double35 = numberAxis33.getAutoRangeMinimumSize();
        org.jfree.data.Range range37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range37);
        double double39 = rectangleConstraint38.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint38.toUnconstrainedWidth();
        org.jfree.data.Range range41 = rectangleConstraint38.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis43.setVisible(true);
        numberAxis43.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range49 = numberAxis43.getRange();
        double double50 = range49.getLength();
        org.jfree.data.Range range53 = org.jfree.data.Range.expand(range49, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = rectangleConstraint38.toRangeWidth(range53);
        numberAxis33.setRange(range53, false, true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit58 = numberAxis33.getTickUnit();
        numberAxis10.setTickUnit(numberTickUnit58, true, true);
        java.text.NumberFormat numberFormat62 = null;
        numberAxis10.setNumberFormatOverride(numberFormat62);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str27.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0E-8d + "'", double35 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.0d + "'", double39 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 11.0d + "'", double50 == 11.0d);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rectangleConstraint54);
        org.junit.Assert.assertNotNull(numberTickUnit58);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        categoryPlot1.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot1.getRendererForDataset(categoryDataset7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot1.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setTickMarkOutsideLength((float) (short) 100);
        numberAxis11.setLabelAngle((double) '4');
        org.jfree.data.Range range16 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.text.NumberFormat numberFormat17 = null;
        numberAxis11.setNumberFormatOverride(numberFormat17);
        java.awt.Shape shape19 = numberAxis11.getRightArrow();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) "RectangleEdge.RIGHT", shape19, "JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]", "AxisLocation.BOTTOM_OR_LEFT");
        java.lang.Comparable comparable23 = categoryLabelEntity22.getKey();
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "RectangleEdge.RIGHT" + "'", comparable23.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot10.setDomainAxisLocation(15, axisLocation12, true);
        categoryPlot10.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot10.getRendererForDataset(categoryDataset16);
        java.awt.Stroke stroke18 = categoryPlot10.getOutlineStroke();
        valueMarker9.setStroke(stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker9, layer20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = null;
        categoryPlot22.setDomainAxisLocation(15, axisLocation24, true);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        textTitle27.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle27.getMargin();
        categoryPlot22.setInsets(rectangleInsets30, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot22.getInsets();
        double double35 = rectangleInsets33.calculateLeftOutset((double) (byte) 10);
        valueMarker9.setLabelOffset(rectangleInsets33);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
        categoryPlot38.setDomainAxisLocation(15, axisLocation40, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke45 = statisticalBarRenderer44.getBaseStroke();
        java.awt.Paint paint47 = statisticalBarRenderer44.getSeriesOutlinePaint((-1));
        boolean boolean48 = statisticalBarRenderer44.getAutoPopulateSeriesOutlineStroke();
        categoryPlot38.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer44, true);
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.INSIDE7", (org.jfree.chart.plot.Plot) categoryPlot38);
        java.awt.Paint paint52 = categoryPlot38.getOutlinePaint();
        valueMarker9.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot38);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("LegendItemEntity: seriesKey=null, dataset=null", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        int int15 = categoryPlot14.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot14.getRangeAxisEdge();
        java.awt.Paint paint17 = categoryPlot14.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot14.getRangeAxisEdge();
        boolean boolean19 = categoryPlot14.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double23 = categoryAxis20.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int25 = numberTickUnit24.getMinorTickCount();
        java.awt.Font font26 = categoryAxis20.getTickLabelFont((java.lang.Comparable) numberTickUnit24);
        categoryPlot14.setNoDataMessageFont(font26);
        org.jfree.chart.util.SortOrder sortOrder28 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot14.setColumnRenderingOrder(sortOrder28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        float float31 = categoryAxis30.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = categoryAxis30.getCategoryJava2DCoordinate(categoryAnchor32, (int) '#', (int) (short) 10, rectangle2D35, rectangleEdge36);
        java.awt.Paint paint38 = categoryAxis30.getTickLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        categoryPlot39.setDomainAxisLocation(15, axisLocation41, true);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle();
        textTitle44.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = textTitle44.getMargin();
        categoryPlot39.setInsets(rectangleInsets47, false);
        double double50 = rectangleInsets47.getLeft();
        double double51 = rectangleInsets47.getTop();
        categoryAxis30.setTickLabelInsets(rectangleInsets47);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis53.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis53.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.axis.AxisState axisState60 = null;
        java.awt.Font font62 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock63 = new org.jfree.chart.block.LabelBlock("ClassContext", font62);
        labelBlock63.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle();
        boolean boolean67 = labelBlock63.equals((java.lang.Object) textTitle66);
        java.awt.geom.Rectangle2D rectangle2D68 = textTitle66.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot();
        int int70 = categoryPlot69.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = categoryPlot69.getRangeAxisEdge();
        java.awt.Paint paint72 = categoryPlot69.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = categoryPlot69.getRangeAxisEdge();
        java.util.List list74 = categoryAxis53.refreshTicks(graphics2D59, axisState60, rectangle2D68, rectangleEdge73);
        org.jfree.chart.entity.ChartEntity chartEntity77 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D68, "TextAnchor.CENTER_RIGHT", "ItemLabelAnchor.INSIDE7");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean80 = lengthAdjustmentType78.equals((java.lang.Object) 0L);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType81 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean83 = lengthAdjustmentType81.equals((java.lang.Object) 0L);
        java.awt.geom.Rectangle2D rectangle2D84 = rectangleInsets47.createAdjustedRectangle(rectangle2D68, lengthAdjustmentType78, lengthAdjustmentType81);
        java.awt.Shape shape85 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D84);
        try {
            statisticalBarRenderer0.drawBackground(graphics2D13, categoryPlot14, rectangle2D84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(list74);
        org.junit.Assert.assertNotNull(lengthAdjustmentType78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(shape85);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Shape shape5 = statisticalBarRenderer0.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer6);
        java.awt.Paint paint10 = statisticalBarRenderer0.getItemPaint((-1), 0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = itemLabelPosition2.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.awt.Paint paint3 = null;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) (short) 100, paint3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("3", graphics2D1, (float) (-12), (float) 'a', 1.0E-8d, (float) ' ', (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        numberAxis1.setAutoRange(false);
        boolean boolean11 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot14.setDomainAxisLocation(15, axisLocation16, true);
        categoryPlot14.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot14.getRendererForDataset(categoryDataset20);
        java.awt.Stroke stroke22 = categoryPlot14.getOutlineStroke();
        valueMarker13.setStroke(stroke22);
        valueMarker13.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = valueMarker13.getLabelOffset();
        double double28 = rectangleInsets26.calculateLeftOutset(3.0d);
        numberAxis1.setLabelInsets(rectangleInsets26);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = null;
        statisticalBarRenderer30.setBaseToolTipGenerator(categoryToolTipGenerator31, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = null;
        statisticalBarRenderer30.setSeriesNegativeItemLabelPosition(10, itemLabelPosition35);
        java.awt.Color color38 = java.awt.Color.MAGENTA;
        statisticalBarRenderer30.setSeriesFillPaint((int) '#', (java.awt.Paint) color38, false);
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder(rectangleInsets26, (java.awt.Paint) color38);
        double double43 = rectangleInsets26.calculateRightOutset((-1.0d));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 3.0d + "'", double43 == 3.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setDomainAxisLocation(15, axisLocation15, true);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot13.getDomainMarkers(layer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot13.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot13);
        java.lang.Object obj22 = jFreeChart21.clone();
        jFreeChart21.setBackgroundImageAlignment((-4194304));
        java.awt.Paint paint25 = jFreeChart21.getBorderPaint();
        statisticalBarRenderer0.setBaseFillPaint(paint25);
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment28, verticalAlignment29, (double) ' ', (double) '4');
        columnArrangement32.clear();
        columnArrangement32.clear();
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement32);
        columnArrangement32.clear();
        columnArrangement32.clear();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator39 = null;
        statisticalBarRenderer38.setBaseToolTipGenerator(categoryToolTipGenerator39, false);
        java.awt.Paint paint43 = statisticalBarRenderer38.lookupSeriesFillPaint(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator45 = null;
        statisticalBarRenderer38.setSeriesURLGenerator(192, categoryURLGenerator45, false);
        boolean boolean48 = columnArrangement32.equals((java.lang.Object) 192);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setID("ClassContext");
        java.lang.Object obj9 = null;
        columnArrangement5.add((org.jfree.chart.block.Block) textTitle6, obj9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = textTitle6.getVerticalAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        int int13 = categoryPlot12.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getRangeAxisEdge();
        categoryPlot12.setForegroundAlpha((float) 0);
        java.awt.Color color17 = java.awt.Color.darkGray;
        float[] floatArray24 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray25 = color17.getRGBColorComponents(floatArray24);
        categoryPlot12.setBackgroundPaint((java.awt.Paint) color17);
        boolean boolean27 = verticalAlignment11.equals((java.lang.Object) categoryPlot12);
        boolean boolean28 = unitType0.equals((java.lang.Object) boolean27);
        java.lang.Object obj29 = null;
        boolean boolean30 = unitType0.equals(obj29);
        java.lang.Object obj31 = null;
        boolean boolean32 = unitType0.equals(obj31);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.05d, 21.0d, Double.NaN, 3.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle1.setFont(font2);
        textTitle1.setHeight((double) (short) -1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.text.TextBlock textBlock7 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock7.calculateDimensions(graphics2D8);
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("ClassContext", font12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str15 = color14.toString();
        boolean boolean17 = color14.equals((java.lang.Object) 'a');
        textBlock7.addLine("java.awt.Color[r=192,g=0,b=0]", font12, (java.awt.Paint) color14);
        textTitle1.setFont(font12);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("UnitType.RELATIVE", font12);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str15.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis10.setTickMarkOutsideLength((float) (short) 100);
        numberAxis10.setLabelAngle((double) '4');
        org.jfree.data.Range range15 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.text.NumberFormat numberFormat16 = null;
        numberAxis10.setNumberFormatOverride(numberFormat16);
        java.awt.Shape shape18 = numberAxis10.getRightArrow();
        org.jfree.chart.text.TextBlock textBlock19 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textBlock19.calculateDimensions(graphics2D20);
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("ClassContext", font24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str27 = color26.toString();
        boolean boolean29 = color26.equals((java.lang.Object) 'a');
        textBlock19.addLine("java.awt.Color[r=192,g=0,b=0]", font24, (java.awt.Paint) color26);
        numberAxis10.setTickMarkPaint((java.awt.Paint) color26);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean34 = numberAxis33.isNegativeArrowVisible();
        double double35 = numberAxis33.getAutoRangeMinimumSize();
        org.jfree.data.Range range37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range37);
        double double39 = rectangleConstraint38.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint38.toUnconstrainedWidth();
        org.jfree.data.Range range41 = rectangleConstraint38.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis43.setVisible(true);
        numberAxis43.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range49 = numberAxis43.getRange();
        double double50 = range49.getLength();
        org.jfree.data.Range range53 = org.jfree.data.Range.expand(range49, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = rectangleConstraint38.toRangeWidth(range53);
        numberAxis33.setRange(range53, false, true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit58 = numberAxis33.getTickUnit();
        numberAxis10.setTickUnit(numberTickUnit58, true, true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand62 = null;
        numberAxis10.setMarkerBand(markerAxisBand62);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str27.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0E-8d + "'", double35 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.0d + "'", double39 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 11.0d + "'", double50 == 11.0d);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rectangleConstraint54);
        org.junit.Assert.assertNotNull(numberTickUnit58);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = null;
        plotChangeEvent10.setType(chartChangeEventType11);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (-1L));
        categoryAxis0.setCategoryMargin(0.0d);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot11.setRenderer((int) (byte) 100, categoryItemRenderer15);
        boolean boolean17 = categoryPlot11.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean20 = numberAxis19.isVerticalTickLabels();
        org.jfree.data.Range range21 = numberAxis19.getRange();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot24.setDomainAxisLocation(15, axisLocation26, true);
        categoryPlot24.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot24.getRendererForDataset(categoryDataset30);
        java.awt.Stroke stroke32 = categoryPlot24.getOutlineStroke();
        valueMarker23.setStroke(stroke32);
        valueMarker23.setLabel("ThreadContext");
        double double36 = valueMarker23.getValue();
        java.awt.Font font38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("ClassContext", font38);
        labelBlock39.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        boolean boolean43 = labelBlock39.equals((java.lang.Object) textTitle42);
        java.awt.geom.Rectangle2D rectangle2D44 = textTitle42.getBounds();
        statisticalBarRenderer8.drawRangeMarker(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.plot.Marker) valueMarker23, rectangle2D44);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        categoryPlot11.clearRangeAxes();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-1.0d) + "'", double36 == (-1.0d));
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangle2D44);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        java.lang.Object obj8 = null;
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle5.getVerticalAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        textTitle5.setPosition(rectangleEdge13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = textTitle5.getVerticalAlignment();
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(verticalAlignment15);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot4.setDomainAxisLocation(15, axisLocation6, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot4.getDomainMarkers(layer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot4);
        jFreeChart12.clearSubtitles();
        jFreeChart12.setBackgroundImageAlpha(0.5f);
        java.awt.Image image16 = jFreeChart12.getBackgroundImage();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart12);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        categoryPlot19.setDomainAxisLocation(15, axisLocation21, true);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        textTitle24.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = textTitle24.getMargin();
        categoryPlot19.setInsets(rectangleInsets27, false);
        double double31 = rectangleInsets27.extendHeight((double) 100.0f);
        double double33 = rectangleInsets27.calculateTopOutset((double) 'a');
        java.awt.Font font35 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("ClassContext", font35);
        labelBlock36.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        boolean boolean40 = labelBlock36.equals((java.lang.Object) textTitle39);
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle39.getBounds();
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets27.createOutsetRectangle(rectangle2D41);
        textTitle0.draw(graphics2D18, rectangle2D42);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.0d + "'", double31 == 100.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D42);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        java.awt.Paint paint13 = jFreeChart9.getBorderPaint();
        jFreeChart9.setBackgroundImageAlpha((float) 100);
        java.awt.Paint paint16 = jFreeChart9.getBackgroundPaint();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        org.jfree.chart.LegendItem legendItem6 = statisticalBarRenderer0.getLegendItem((-4194304), 100);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list19 = defaultStatisticalCategoryDataset18.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity22 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        int int23 = defaultStatisticalCategoryDataset18.getColumnCount();
        int int24 = defaultStatisticalCategoryDataset18.getColumnCount();
        org.jfree.data.Range range25 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18);
        org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, 2);
        boolean boolean28 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset27);
        double double29 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset27);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(pieDataset27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        java.lang.Class class1 = null;
//        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("LegendItemEntity: seriesKey=, dataset=null", class1);
//        org.junit.Assert.assertNull(inputStream2);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        boolean boolean13 = categoryPlot0.isOutlineVisible();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list15 = defaultStatisticalCategoryDataset14.getColumnKeys();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset14, true);
        categoryPlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset14);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset14, (double) 3);
        java.lang.Comparable comparable21 = null;
        java.lang.Number number23 = defaultStatisticalCategoryDataset14.getValue(comparable21, (java.lang.Comparable) "UnitType.RELATIVE");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(number23);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        numberAxis1.setInverted(false);
        numberAxis1.setUpperBound((double) 'a');
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setWidth((double) '4');
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape11 = textBlock3.calculateBounds(graphics2D4, 0.0f, (float) (-1), textBlockAnchor7, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity12 = new org.jfree.chart.entity.LegendItemEntity(shape11);
        boolean boolean13 = textTitle0.equals((java.lang.Object) shape11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        float float15 = categoryAxis14.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis14.getCategoryJava2DCoordinate(categoryAnchor16, (int) '#', (int) (short) 10, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
        categoryAxis14.setCategoryLabelPositions(categoryLabelPositions23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean26 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge25);
        java.lang.String str27 = rectangleEdge25.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition28 = categoryLabelPositions23.getLabelPosition(rectangleEdge25);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor29 = categoryLabelPosition28.getLabelAnchor();
        boolean boolean30 = textTitle0.equals((java.lang.Object) categoryLabelPosition28);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleEdge.RIGHT" + "'", str27.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition28);
        org.junit.Assert.assertNotNull(textBlockAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        size2D2.setWidth((double) (short) 0);
        java.lang.String str5 = size2D2.toString();
        double double6 = size2D2.width;
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str5.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block11 = null;
        blockContainer10.add(block11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setWidth((double) '4');
        java.lang.Object obj16 = textTitle13.clone();
        double double17 = textTitle13.getContentYOffset();
        blockContainer10.add((org.jfree.chart.block.Block) textTitle13);
        legendTitle9.setWrapper(blockContainer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot20.setDomainAxisLocation(15, axisLocation22, true);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        textTitle25.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle25.getMargin();
        categoryPlot20.setInsets(rectangleInsets28, false);
        legendTitle9.setItemLabelPadding(rectangleInsets28);
        boolean boolean33 = legendTitle9.equals((java.lang.Object) 1.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle9.getItemLabelPadding();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str3 = color2.toString();
        statisticalBarRenderer0.setSeriesOutlinePaint(2, (java.awt.Paint) color2, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        boolean boolean10 = statisticalBarRenderer6.getAutoPopulateSeriesShape();
        java.awt.Font font11 = statisticalBarRenderer6.getBaseItemLabelFont();
        statisticalBarRenderer0.setBaseItemLabelFont(font11, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str3.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimWidth(100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 98.0d + "'", double2 == 98.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot1.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot1.setRenderer((int) (byte) 100, categoryItemRenderer5);
        boolean boolean7 = categoryPlot1.isDomainGridlinesVisible();
        boolean boolean8 = rectangleAnchor0.equals((java.lang.Object) boolean7);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        java.awt.GradientPaint gradientPaint3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.setID("ClassContext");
        java.lang.Object obj13 = null;
        columnArrangement9.add((org.jfree.chart.block.Block) textTitle10, obj13);
        boolean boolean15 = textAnchor4.equals((java.lang.Object) textTitle10);
        double double16 = textTitle10.getWidth();
        double double17 = textTitle10.getHeight();
        textTitle10.setExpandToFitSpace(true);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle10.getBounds();
        try {
            java.awt.GradientPaint gradientPaint21 = standardGradientPaintTransformer1.transform(gradientPaint3, (java.awt.Shape) rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("ThreadContext", (int) (byte) 1, 192);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Font font1 = statisticalBarRenderer0.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        java.awt.Paint paint6 = statisticalBarRenderer0.getSeriesPaint((int) (short) -1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color7);
        double double9 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot12.setDomainAxisLocation(15, axisLocation14, true);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = textTitle17.getMargin();
        categoryPlot12.setInsets(rectangleInsets20, false);
        double double24 = rectangleInsets20.extendHeight((double) 100.0f);
        double double26 = rectangleInsets20.calculateTopOutset((double) 'a');
        java.awt.Font font28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("ClassContext", font28);
        labelBlock29.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        boolean boolean33 = labelBlock29.equals((java.lang.Object) textTitle32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle32.getBounds();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets20.createOutsetRectangle(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke40 = statisticalBarRenderer39.getBaseStroke();
        java.awt.Paint paint42 = statisticalBarRenderer39.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke43 = statisticalBarRenderer39.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        statisticalBarRenderer39.setSeriesNegativeItemLabelPosition(255, itemLabelPosition45);
        boolean boolean47 = statisticalBarRenderer39.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator49 = null;
        statisticalBarRenderer39.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator49, false);
        boolean boolean52 = defaultStatisticalCategoryDataset38.equals((java.lang.Object) statisticalBarRenderer39);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit55 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity56 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D34, "TextAnchor.CENTER_RIGHT", "TextBlockAnchor.TOP_LEFT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, (java.lang.Comparable) 1, (java.lang.Comparable) numberTickUnit55);
        try {
            statisticalBarRenderer0.drawOutline(graphics2D10, categoryPlot11, rectangle2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape10 = textBlock2.calculateBounds(graphics2D3, 0.0f, (float) (-1), textBlockAnchor6, 0.0f, (float) 10, (double) 10);
        numberAxis1.setLeftArrow(shape10);
        org.jfree.data.Range range12 = numberAxis1.getDefaultAutoRange();
        java.awt.Shape shape13 = numberAxis1.getDownArrow();
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        org.jfree.chart.plot.Plot plot11 = jFreeChart9.getPlot();
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        jFreeChart9.setNotify(true);
        org.jfree.chart.axis.AxisCollection axisCollection15 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list16 = axisCollection15.getAxesAtLeft();
        java.util.List list17 = axisCollection15.getAxesAtRight();
        jFreeChart9.setSubtitles(list17);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("ClassContext", font3);
        labelBlock4.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        boolean boolean8 = labelBlock4.equals((java.lang.Object) textTitle7);
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        int int11 = categoryPlot10.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot10.getRangeAxisEdge();
        double double13 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D9, rectangleEdge12);
        lineBorder0.draw(graphics2D1, rectangle2D9);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            lineBorder0.draw(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition5);
        java.awt.Stroke stroke8 = statisticalBarRenderer0.lookupSeriesOutlineStroke((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        int int10 = categoryPlot9.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot9.setFixedDomainAxisSpace(axisSpace11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis14.setVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis14);
        categoryPlot9.axisChanged(axisChangeEvent17);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke21 = defaultDrawingSupplier20.getNextStroke();
        java.awt.Shape shape22 = defaultDrawingSupplier20.getNextShape();
        categoryPlot9.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier20);
        java.awt.Stroke stroke24 = defaultDrawingSupplier20.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) '#', (int) (short) 10, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions9);
        java.awt.Paint paint12 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement11 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer5, (org.jfree.chart.block.Arrangement) columnArrangement10, (org.jfree.chart.block.Arrangement) centerArrangement11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setDomainAxisLocation(15, axisLocation15, true);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot13.getDomainMarkers(layer18);
        java.awt.Paint paint20 = categoryPlot13.getNoDataMessagePaint();
        statisticalBarRenderer5.setBasePaint(paint20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 15);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = legendItemEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        legendItemEntity9.setSeriesKey((java.lang.Comparable) "");
        java.lang.String str15 = legendItemEntity9.toString();
        legendItemEntity9.setSeriesKey((java.lang.Comparable) 64);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LegendItemEntity: seriesKey=, dataset=null" + "'", str15.equals("LegendItemEntity: seriesKey=, dataset=null"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Font font5 = statisticalBarRenderer0.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesCreateEntities((int) ' ', (java.lang.Boolean) true, true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        statisticalBarRenderer0.setSeriesFillPaint((int) (byte) 1, (java.awt.Paint) color11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = statisticalBarRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = itemLabelPosition13.getItemLabelAnchor();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        int int16 = categoryPlot15.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot15.getRangeAxisEdge();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot15.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot15.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo24, point2D25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis27.setTickLabelsVisible(true);
        java.util.List list32 = categoryPlot15.getCategoriesForAxis(categoryAxis27);
        boolean boolean33 = itemLabelPosition13.equals((java.lang.Object) list32);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color7);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer9);
        boolean boolean11 = statisticalBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint14 = statisticalBarRenderer0.getItemOutlinePaint(4, (-12));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        boolean boolean3 = numberAxis1.equals((java.lang.Object) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        int int5 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getRangeAxisEdge();
        java.awt.Paint paint7 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo13, point2D14);
        boolean boolean16 = categoryPlot4.isDomainZoomable();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Font font19 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("ClassContext", font19);
        labelBlock20.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle();
        boolean boolean24 = labelBlock20.equals((java.lang.Object) textTitle23);
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle23.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        boolean boolean28 = categoryPlot4.render(graphics2D17, rectangle2D25, (int) (byte) 100, plotRenderingInfo27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot4.getRenderer((int) ' ');
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        int int33 = categoryPlot32.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot32.getRangeAxisEdge();
        java.awt.Paint paint35 = categoryPlot32.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot32.getRangeAxisEdge();
        boolean boolean37 = categoryPlot32.isDomainZoomable();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        categoryPlot2.setAnchorValue((double) (short) 0);
        categoryPlot2.setWeight((int) (byte) 10);
        categoryPlot2.setRangeCrosshairValue(1.0d, true);
        boolean boolean15 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) categoryPlot2);
        try {
            java.lang.Number number18 = defaultStatisticalCategoryDataset0.getStdDevValue(10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "ItemLabelAnchor.OUTSIDE3", "", "PlotOrientation.VERTICAL", "");
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        size2D2.setWidth((double) (short) 0);
        double double5 = size2D2.height;
        size2D2.setWidth((double) 0.0f);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = valueMarker1.getLabelOffset();
        java.awt.Color color15 = java.awt.Color.white;
        int int16 = color15.getGreen();
        valueMarker1.setPaint((java.awt.Paint) color15);
        valueMarker1.setAlpha(0.8f);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) (short) 10, 2.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
//        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
//        org.jfree.chart.util.Layer layer6 = null;
//        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
//        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
//        java.lang.Object obj10 = jFreeChart9.clone();
//        jFreeChart9.setBackgroundImageAlignment((-4194304));
//        java.awt.Paint paint13 = jFreeChart9.getBorderPaint();
//        org.jfree.chart.ui.ProjectInfo projectInfo14 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str15 = projectInfo14.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray16 = projectInfo14.getLibraries();
//        java.lang.String str17 = projectInfo14.getLicenceText();
//        projectInfo14.setLicenceText("3");
//        org.jfree.chart.axis.AxisCollection axisCollection20 = new org.jfree.chart.axis.AxisCollection();
//        java.util.List list21 = axisCollection20.getAxesAtLeft();
//        java.util.List list22 = axisCollection20.getAxesAtRight();
//        projectInfo14.setContributors(list22);
//        jFreeChart9.setSubtitles(list22);
//        org.junit.Assert.assertNull(collection7);
//        org.junit.Assert.assertNull(categoryAxis8);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertNotNull(projectInfo14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3" + "'", str17.equals("3"));
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertNotNull(list22);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) 'a');
        double double5 = statisticalBarRenderer0.getItemMargin();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot8.setDomainAxisLocation(15, axisLocation10, true);
        categoryPlot8.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot8.getRendererForDataset(categoryDataset14);
        java.awt.Stroke stroke16 = categoryPlot8.getOutlineStroke();
        valueMarker7.setStroke(stroke16);
        valueMarker7.setLabel("ThreadContext");
        java.awt.Color color20 = java.awt.Color.BLUE;
        valueMarker7.setPaint((java.awt.Paint) color20);
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color20, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range7 = numberAxis1.getRange();
        double double8 = range7.getLength();
        org.jfree.data.Range range11 = org.jfree.data.Range.expand(range7, (double) 1.0f, (double) 1L);
        boolean boolean13 = range7.contains((double) 1);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11.0d + "'", double8 == 11.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) '#', (int) (short) 10, rectangle2D5, rectangleEdge6);
        categoryAxis0.setLabelAngle(0.0d);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent14);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        categoryPlot19.setDomainAxisLocation(15, axisLocation21, true);
        categoryPlot19.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot19.getRendererForDataset(categoryDataset25);
        java.awt.Stroke stroke27 = categoryPlot19.getOutlineStroke();
        valueMarker18.setStroke(stroke27);
        valueMarker18.setLabel("ThreadContext");
        java.awt.Paint paint31 = null;
        valueMarker18.setOutlinePaint(paint31);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot11.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker18, layer33);
        categoryPlot0.addRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker10, layer33);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation36 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(categoryItemRenderer26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(layer33);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range7 = numberAxis1.getRange();
        numberAxis1.setVisible(true);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setTickMarkOutsideLength((float) (short) 100);
        numberAxis1.setLabelAngle((double) '4');
        numberAxis1.setLowerBound((double) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.Font font17 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("ClassContext", font17);
        labelBlock18.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        boolean boolean22 = labelBlock18.equals((java.lang.Object) textTitle21);
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle21.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        int int25 = categoryPlot24.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot24.getRangeAxisEdge();
        java.awt.Paint paint27 = categoryPlot24.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot24.getRangeAxisEdge();
        java.util.List list29 = categoryAxis8.refreshTicks(graphics2D14, axisState15, rectangle2D23, rectangleEdge28);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D23);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D23, (double) 15, (double) 32.0f);
        numberAxis1.setUpArrow(shape33);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double3 = categoryAxis0.getLabelAngle();
        java.lang.String str5 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 100);
        boolean boolean6 = categoryAxis0.isVisible();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font8, (java.awt.Paint) color9);
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot14.setDomainAxisLocation(15, axisLocation16, true);
        categoryPlot14.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot14.getRendererForDataset(categoryDataset20);
        java.awt.Stroke stroke22 = categoryPlot14.getOutlineStroke();
        valueMarker13.setStroke(stroke22);
        valueMarker13.setLabel("ThreadContext");
        java.awt.Color color26 = java.awt.Color.BLUE;
        valueMarker13.setPaint((java.awt.Paint) color26);
        java.lang.Object obj28 = valueMarker13.clone();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke30 = statisticalBarRenderer29.getBaseStroke();
        java.awt.Paint paint32 = statisticalBarRenderer29.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke33 = statisticalBarRenderer29.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = null;
        statisticalBarRenderer29.setSeriesNegativeItemLabelPosition(255, itemLabelPosition35);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke38 = statisticalBarRenderer37.getBaseStroke();
        java.awt.Paint paint40 = statisticalBarRenderer37.getSeriesOutlinePaint((-1));
        boolean boolean41 = statisticalBarRenderer37.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke42 = statisticalBarRenderer37.getBaseOutlineStroke();
        statisticalBarRenderer29.setBaseOutlineStroke(stroke42, false);
        valueMarker13.setOutlineStroke(stroke42);
        categoryAxis0.setAxisLineStroke(stroke42);
        java.lang.String str47 = categoryAxis0.getLabelURL();
        categoryAxis0.setTickMarkInsideLength(0.95f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(str47);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        textTitle0.setHeight((double) 0);
        double double5 = textTitle0.getContentYOffset();
        java.lang.String str6 = textTitle0.getToolTipText();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str4 = projectInfo3.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo3.getLibraries();
        java.lang.String str6 = projectInfo3.getLicenceText();
        java.awt.Image image7 = projectInfo3.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("VerticalAlignment.CENTER", "RectangleEdge.TOP", "SortOrder.ASCENDING", image7, "JFreeChart", "TextAnchor.CENTER_RIGHT", "JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.ui.ProjectInfo projectInfo12 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str13 = projectInfo12.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray14 = projectInfo12.getLibraries();
        java.lang.String str15 = projectInfo12.getLicenceText();
        java.awt.Image image16 = projectInfo12.getLogo();
        org.jfree.chart.text.TextBlock textBlock17 = new org.jfree.chart.text.TextBlock();
        java.util.List list18 = textBlock17.getLines();
        projectInfo12.setContributors(list18);
        projectInfo11.addLibrary((org.jfree.chart.ui.Library) projectInfo12);
        org.jfree.chart.ui.Library[] libraryArray21 = projectInfo11.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3" + "'", str6.equals("3"));
        org.junit.Assert.assertNotNull(image7);
        org.junit.Assert.assertNotNull(projectInfo12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(libraryArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3" + "'", str15.equals("3"));
        org.junit.Assert.assertNotNull(image16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(libraryArray21);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        java.awt.Paint paint12 = statisticalBarRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        boolean boolean31 = numberAxis11.isTickMarksVisible();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean36 = numberAxis35.isVerticalTickLabels();
        org.jfree.data.Range range37 = numberAxis35.getRange();
        org.jfree.data.Range range40 = org.jfree.data.Range.shift(range37, (double) 10.0f, false);
        org.jfree.data.Range range43 = org.jfree.data.Range.shift(range40, (double) (-4194304), false);
        numberAxis11.setRange(range43, false, true);
        double double47 = numberAxis11.getUpperBound();
        boolean boolean48 = numberAxis11.isNegativeArrowVisible();
        numberAxis11.configure();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(50.0d, 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        int int10 = categoryPlot9.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot9.getRangeAxisEdge();
        java.awt.Paint paint12 = categoryPlot9.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot9.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot9.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot9.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo18, point2D19);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot9.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation8, plotOrientation21);
        categoryPlot0.setRangeAxisLocation(axisLocation8, true);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        java.awt.Paint paint5 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType6 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer7 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType6);
        java.lang.Object obj8 = standardGradientPaintTransformer7.clone();
        statisticalBarRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer7);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType6);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-16711681), (double) 2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Font font1 = statisticalBarRenderer0.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation((int) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle9.setFont(font10);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("java.awt.Color[r=192,g=0,b=0]", font10);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot15.setDomainAxisLocation(15, axisLocation17, true);
        categoryPlot15.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot15.getRendererForDataset(categoryDataset21);
        java.awt.Stroke stroke23 = categoryPlot15.getOutlineStroke();
        valueMarker14.setStroke(stroke23);
        valueMarker14.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = valueMarker14.getLabelOffset();
        java.awt.Color color28 = java.awt.Color.white;
        int int29 = color28.getGreen();
        valueMarker14.setPaint((java.awt.Paint) color28);
        org.jfree.chart.text.TextFragment textFragment31 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=192,g=0,b=0]", font10, (java.awt.Paint) color28);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        int int33 = categoryPlot32.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot32.getRangeAxisEdge();
        java.awt.Paint paint35 = categoryPlot32.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot32.getRangeAxisEdge();
        boolean boolean37 = categoryPlot32.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot32.getDomainAxisEdge((int) (short) -1);
        boolean boolean40 = categoryPlot32.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str42 = datasetRenderingOrder41.toString();
        categoryPlot32.setDatasetRenderingOrder(datasetRenderingOrder41);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) categoryPlot32, false);
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart45);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection49 = categoryPlot0.getDomainMarkers(15, layer48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str42.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 0.8f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke8 = statisticalBarRenderer7.getBaseStroke();
        java.awt.Paint paint10 = statisticalBarRenderer7.getSeriesOutlinePaint((-1));
        boolean boolean11 = statisticalBarRenderer7.getAutoPopulateSeriesOutlineStroke();
        categoryPlot1.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer7, true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.INSIDE7", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        try {
            java.awt.image.BufferedImage bufferedImage20 = jFreeChart14.createBufferedImage(0, (int) 'a', 100.0d, (double) '4', chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (97) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setWeight((int) (byte) 10);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list14 = defaultStatisticalCategoryDataset13.getColumnKeys();
        categoryPlot0.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot0.getRangeAxisEdge((int) ' ');
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list6 = defaultStatisticalCategoryDataset5.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity9 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        categoryItemEntity9.setColumnKey((java.lang.Comparable) 3);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot10.setDomainAxisLocation(15, axisLocation12, true);
        categoryPlot10.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot10.getRendererForDataset(categoryDataset16);
        java.awt.Stroke stroke18 = categoryPlot10.getOutlineStroke();
        valueMarker9.setStroke(stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker9, layer20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        int int5 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getRangeAxisEdge();
        java.awt.Paint paint7 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot4.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation3, plotOrientation16);
        java.lang.String str18 = axisLocation3.toString();
        categoryPlot0.setDomainAxisLocation(axisLocation3, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str18.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0E-8d);
        float float2 = valueMarker1.getAlpha();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.8f + "'", float2 == 0.8f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent3);
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        int int6 = categoryPlot0.getDatasetCount();
        java.lang.Object obj7 = categoryPlot0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        java.awt.Paint paint9 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = statisticalBarRenderer0.getPlot();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        textTitle7.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle7.getMargin();
        categoryPlot2.setInsets(rectangleInsets10, false);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot0.getRenderer((int) (byte) -1);
        java.awt.Paint paint16 = categoryPlot0.getBackgroundPaint();
        java.awt.Stroke stroke17 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color8, true);
        statisticalBarRenderer0.setBaseCreateEntities(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Shape shape18 = statisticalBarRenderer0.getItemShape((int) (short) -1, (int) (short) 100);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (byte) 100);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis1.setCategoryLabelPositionOffset((int) ' ');
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) "RectangleEdge.RIGHT", font8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setVisible(true);
        numberAxis11.setRange((double) (short) -1, 10.0d);
        numberAxis11.setInverted(false);
        double double19 = numberAxis11.getUpperMargin();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke22 = statisticalBarRenderer21.getBaseStroke();
        java.awt.Paint paint24 = statisticalBarRenderer21.getSeriesOutlinePaint((-1));
        boolean boolean25 = statisticalBarRenderer21.getAutoPopulateSeriesShape();
        java.awt.Font font26 = statisticalBarRenderer21.getBaseItemLabelFont();
        java.awt.Color color27 = java.awt.Color.white;
        int int28 = color27.getGreen();
        int int29 = color27.getRed();
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("CategoryLabelEntity: category=RectangleEdge.RIGHT, tooltip=JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0], url=AxisLocation.BOTTOM_OR_LEFT", font26, (java.awt.Paint) color27);
        numberAxis11.setTickLabelPaint((java.awt.Paint) color27);
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("hi!", font36, (java.awt.Paint) color37);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer41 = new org.jfree.chart.text.G2TextMeasurer(graphics2D40);
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, (java.awt.Paint) color37, (float) 3, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer41);
        try {
            org.jfree.chart.text.TextBlock textBlock43 = org.jfree.chart.text.TextUtilities.createTextBlock("[size=1]", font8, (java.awt.Paint) color27, 0.0f, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(textBlock42);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot4.setDomainAxisLocation(15, axisLocation6, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot4.getDomainMarkers(layer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot4);
        jFreeChart12.clearSubtitles();
        jFreeChart12.setBackgroundImageAlpha(0.5f);
        java.awt.Image image16 = jFreeChart12.getBackgroundImage();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart12);
        java.lang.Object obj18 = textTitle0.clone();
        java.lang.String str19 = textTitle0.getText();
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        double double3 = categoryItemRendererState1.getBarWidth();
        double double4 = categoryItemRendererState1.getSeriesRunningTotal();
        double double5 = categoryItemRendererState1.getBarWidth();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis8.setTickLabelsVisible(true);
        categoryAxis8.setLowerMargin((double) 100.0f);
        int int15 = categoryPlot0.getDomainAxisIndex(categoryAxis8);
        categoryPlot0.setRangeGridlinesVisible(false);
        java.awt.Paint paint18 = categoryPlot0.getOutlinePaint();
        boolean boolean19 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle19.getLegendItemGraphicAnchor();
        java.awt.Font font22 = legendTitle19.getItemFont();
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color25 = java.awt.Color.white;
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font24, (java.awt.Paint) color25);
        legendTitle19.setItemPaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = legendTitle19.getLegendItemGraphicLocation();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot8.setDomainAxisLocation(15, axisLocation10, true);
        categoryPlot8.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot8.getRendererForDataset(categoryDataset14);
        java.awt.Stroke stroke16 = categoryPlot8.getOutlineStroke();
        valueMarker7.setStroke(stroke16);
        valueMarker7.setLabel("ThreadContext");
        java.awt.Paint paint20 = null;
        valueMarker7.setOutlinePaint(paint20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker7, layer22);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(layer22);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) 'a');
        double double5 = statisticalBarRenderer0.getItemMargin();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        int int8 = categoryPlot7.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getRangeAxisEdge();
        java.awt.Paint paint10 = categoryPlot7.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot7.getRangeAxisEdge();
        boolean boolean12 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot7.getDomainAxisEdge((int) (short) -1);
        boolean boolean15 = categoryPlot7.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str17 = datasetRenderingOrder16.toString();
        categoryPlot7.setDatasetRenderingOrder(datasetRenderingOrder16);
        java.awt.Stroke stroke19 = categoryPlot7.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke21 = statisticalBarRenderer20.getBaseStroke();
        java.awt.Paint paint23 = statisticalBarRenderer20.getSeriesOutlinePaint((-1));
        boolean boolean24 = statisticalBarRenderer20.getAutoPopulateSeriesOutlineStroke();
        boolean boolean25 = statisticalBarRenderer20.getBaseSeriesVisible();
        statisticalBarRenderer20.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis31.setPositiveArrowVisible(true);
        numberAxis31.setFixedAutoRange((double) (short) 0);
        numberAxis31.setRangeWithMargins((double) 0, (double) '#');
        numberAxis31.setAutoRange(false);
        java.awt.Font font42 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("ClassContext", font42);
        labelBlock43.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        boolean boolean47 = labelBlock43.equals((java.lang.Object) textTitle46);
        java.awt.geom.Rectangle2D rectangle2D48 = textTitle46.getBounds();
        statisticalBarRenderer20.drawRangeGridline(graphics2D28, categoryPlot29, (org.jfree.chart.axis.ValueAxis) numberAxis31, rectangle2D48, (double) (-16711681));
        try {
            statisticalBarRenderer0.drawOutline(graphics2D6, categoryPlot7, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str17.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangle2D48);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double11 = rectangleInsets8.getLeft();
        double double12 = rectangleInsets8.getTop();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("ClassContext", font24);
        labelBlock25.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        boolean boolean29 = labelBlock25.equals((java.lang.Object) textTitle28);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle28.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        int int32 = categoryPlot31.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot31.getRangeAxisEdge();
        java.awt.Paint paint34 = categoryPlot31.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot31.getRangeAxisEdge();
        java.util.List list36 = categoryAxis15.refreshTicks(graphics2D21, axisState22, rectangle2D30, rectangleEdge35);
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D30);
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (-4194304), (double) 1L, rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets8.createOutsetRectangle(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("RectangleAnchor.CENTER");
        java.util.Set<java.lang.String> strSet3 = jFreeChartResources0.keySet();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        categoryPlot2.setAnchorValue((double) (short) 0);
        categoryPlot2.setWeight((int) (byte) 10);
        categoryPlot2.setRangeCrosshairValue(1.0d, true);
        boolean boolean15 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) categoryPlot2);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (int) (byte) 1);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(pieDataset17);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        java.util.List list2 = projectInfo0.getContributors();
        java.util.List list3 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator5, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block11 = null;
        blockContainer10.add(block11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setWidth((double) '4');
        java.lang.Object obj16 = textTitle13.clone();
        double double17 = textTitle13.getContentYOffset();
        blockContainer10.add((org.jfree.chart.block.Block) textTitle13);
        legendTitle9.setWrapper(blockContainer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot20.setDomainAxisLocation(15, axisLocation22, true);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        textTitle25.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle25.getMargin();
        categoryPlot20.setInsets(rectangleInsets28, false);
        legendTitle9.setItemLabelPadding(rectangleInsets28);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation35 = null;
        categoryPlot33.setDomainAxisLocation(15, axisLocation35, true);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = categoryPlot33.getDomainMarkers(layer38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = categoryPlot33.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot33);
        jFreeChart41.clearSubtitles();
        java.awt.Stroke stroke43 = jFreeChart41.getBorderStroke();
        java.awt.Image image44 = jFreeChart41.getBackgroundImage();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = jFreeChart41.getPadding();
        legendTitle9.setItemLabelPadding(rectangleInsets45);
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block48 = null;
        blockContainer47.add(block48);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        textTitle50.setWidth((double) '4');
        java.lang.Object obj53 = textTitle50.clone();
        double double54 = textTitle50.getContentYOffset();
        blockContainer47.add((org.jfree.chart.block.Block) textTitle50);
        legendTitle9.setWrapper(blockContainer47);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.data.Range range59 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range59);
        double double61 = rectangleConstraint60.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = rectangleConstraint60.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = rectangleConstraint62.toUnconstrainedHeight();
        try {
            org.jfree.chart.util.Size2D size2D64 = blockContainer47.arrange(graphics2D57, rectangleConstraint62);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNull(categoryAxis40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(image44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.0d + "'", double61 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint62);
        org.junit.Assert.assertNotNull(rectangleConstraint63);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        double double4 = statisticalBarRenderer0.getBase();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        textTitle3.setWidth((double) '4');
        java.lang.Object obj6 = textTitle3.clone();
        double double7 = textTitle3.getContentYOffset();
        blockContainer0.add((org.jfree.chart.block.Block) textTitle3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle11.setFont(font12);
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("java.awt.Color[r=192,g=0,b=0]", font12);
        boolean boolean15 = verticalAlignment9.equals((java.lang.Object) font12);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown((double) (-1L));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color2 = java.awt.Color.getColor("TextAnchor.CENTER_RIGHT", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        jFreeChart9.setBackgroundImageAlpha(0.5f);
        jFreeChart9.setBackgroundImageAlpha((float) 10);
        boolean boolean15 = jFreeChart9.isNotify();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition5);
        java.awt.Stroke stroke8 = statisticalBarRenderer0.lookupSeriesOutlineStroke((int) (short) -1);
        java.awt.Shape shape10 = statisticalBarRenderer0.lookupSeriesShape((int) (byte) 10);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        categoryPlot2.setAnchorValue((double) (short) 0);
        categoryPlot2.setWeight((int) (byte) 10);
        categoryPlot2.setRangeCrosshairValue(1.0d, true);
        boolean boolean15 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) categoryPlot2);
        org.jfree.data.Range range17 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        org.jfree.chart.plot.Plot plot11 = jFreeChart9.getPlot();
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        org.jfree.chart.event.ChartChangeListener chartChangeListener13 = null;
        try {
            jFreeChart9.removeChangeListener(chartChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list6 = defaultStatisticalCategoryDataset5.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity9 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        java.lang.Comparable comparable10 = categoryItemEntity9.getRowKey();
        categoryItemEntity9.setColumnKey((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryItemEntity9.getDataset();
        java.lang.Comparable comparable14 = categoryItemEntity9.getRowKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", comparable10.equals("ItemLabelAnchor.INSIDE7"));
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", comparable14.equals("ItemLabelAnchor.INSIDE7"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke14 = statisticalBarRenderer13.getBaseStroke();
        java.awt.Paint paint16 = statisticalBarRenderer13.getSeriesOutlinePaint((-1));
        boolean boolean17 = statisticalBarRenderer13.getAutoPopulateSeriesOutlineStroke();
        boolean boolean18 = statisticalBarRenderer13.getBaseSeriesVisible();
        java.awt.Color color20 = java.awt.Color.white;
        statisticalBarRenderer13.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer13);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        categoryPlot23.setDomainAxisLocation(15, axisLocation25, true);
        categoryPlot23.clearRangeAxes();
        categoryPlot23.setAnchorValue((double) (short) 0);
        org.jfree.chart.ui.ProjectInfo projectInfo31 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str32 = projectInfo31.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray33 = projectInfo31.getLibraries();
        java.lang.String str34 = projectInfo31.getLicenceText();
        java.awt.Image image35 = projectInfo31.getLogo();
        categoryPlot23.setBackgroundImage(image35);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        categoryPlot23.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = valueMarker38.getLabelAnchor();
        legendTitle22.setLegendItemGraphicLocation(rectangleAnchor40);
        jFreeChart9.addLegend(legendTitle22);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        textTitle43.setID("ClassContext");
        jFreeChart9.setTitle(textTitle43);
        java.lang.Object obj47 = textTitle43.clone();
        java.lang.Object obj48 = textTitle43.clone();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(projectInfo31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(libraryArray33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "3" + "'", str34.equals("3"));
        org.junit.Assert.assertNotNull(image35);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(obj48);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) '#', (int) (short) 10, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean12 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge11);
        java.lang.String str13 = rectangleEdge11.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = categoryLabelPositions9.getLabelPosition(rectangleEdge11);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        int int16 = categoryPlot15.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot15.getRangeAxisEdge();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot15.getRangeAxisEdge();
        boolean boolean20 = categoryPlot15.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis21.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double24 = categoryAxis21.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int26 = numberTickUnit25.getMinorTickCount();
        java.awt.Font font27 = categoryAxis21.getTickLabelFont((java.lang.Comparable) numberTickUnit25);
        categoryPlot15.setNoDataMessageFont(font27);
        int int29 = categoryPlot15.getDatasetCount();
        categoryPlot15.mapDatasetToDomainAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double37 = categoryAxis34.getLabelAngle();
        java.lang.String str39 = categoryAxis34.getCategoryLabelToolTip((java.lang.Comparable) 100);
        boolean boolean40 = categoryAxis34.isVisible();
        categoryPlot15.setDomainAxis((int) (short) 1, categoryAxis34, true);
        boolean boolean43 = categoryLabelPosition14.equals((java.lang.Object) categoryAxis34);
        double double44 = categoryLabelPosition14.getAngle();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.RIGHT" + "'", str13.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 10.0d + "'", double44 == 10.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color2 = java.awt.Color.white;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font1, (java.awt.Paint) color2);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.cyan;
        int int7 = color6.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font5, (java.awt.Paint) color6);
        textLine3.removeFragment(textFragment9);
        java.lang.String str11 = textFragment9.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16711681) + "'", int7 == (-16711681));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ClassContext" + "'", str11.equals("ClassContext"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = jFreeChart9.getCategoryPlot();
        org.jfree.chart.event.ChartChangeListener chartChangeListener11 = null;
        try {
            jFreeChart9.addChangeListener(chartChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(categoryPlot10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10, numberArray13, numberArray16, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray20);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset21);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset21, 0.0d);
        double double25 = range24.getUpperBound();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.3d + "'", number22.equals(0.3d));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.3d + "'", double25 == 0.3d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("PlotOrientation.VERTICAL");
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        booleanList0.clear();
        java.lang.Boolean boolean4 = booleanList0.getBoolean(64);
        booleanList0.setBoolean(0, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "DatasetRenderingOrder.FORWARD", "TextAnchor.CENTER_RIGHT", "org.jfree.chart.event.ChartProgressEvent[source=ClassContext]");
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot2.rendererChanged(rendererChangeEvent6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        categoryPlot0.setAnchorValue((double) 10L, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot17.setDomainAxisLocation(15, axisLocation19, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke24 = statisticalBarRenderer23.getBaseStroke();
        java.awt.Paint paint26 = statisticalBarRenderer23.getSeriesOutlinePaint((-1));
        boolean boolean27 = statisticalBarRenderer23.getAutoPopulateSeriesOutlineStroke();
        categoryPlot17.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23, true);
        java.awt.Shape shape31 = statisticalBarRenderer23.lookupSeriesShape((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = statisticalBarRenderer23.getURLGenerator((int) (byte) 1, (-4194304));
        categoryPlot0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23);
        java.awt.Shape shape37 = null;
        statisticalBarRenderer23.setSeriesShape(0, shape37, false);
        boolean boolean40 = statisticalBarRenderer23.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(categoryURLGenerator34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TextBlockAnchor.TOP_LEFT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        java.lang.Boolean boolean6 = statisticalBarRenderer0.getSeriesItemLabelsVisible((int) ' ');
        java.awt.Stroke stroke7 = statisticalBarRenderer0.getBaseOutlineStroke();
        java.lang.Boolean boolean9 = statisticalBarRenderer0.getSeriesItemLabelsVisible(0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setDomainAxisLocation(15, axisLocation5, true);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot3.getDomainMarkers(layer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot3.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) "ClassContext", jFreeChart11, (-4194304), (-4194304));
        java.awt.Color color15 = java.awt.Color.green;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color15);
        jFreeChart11.setBorderPaint((java.awt.Paint) color15);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke19 = statisticalBarRenderer18.getBaseStroke();
        java.awt.Paint paint21 = statisticalBarRenderer18.getSeriesOutlinePaint((-1));
        boolean boolean22 = statisticalBarRenderer18.getAutoPopulateSeriesOutlineStroke();
        boolean boolean23 = statisticalBarRenderer18.getBaseSeriesVisible();
        java.awt.Color color25 = java.awt.Color.white;
        statisticalBarRenderer18.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color25);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer18);
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block29 = null;
        blockContainer28.add(block29);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        textTitle31.setWidth((double) '4');
        java.lang.Object obj34 = textTitle31.clone();
        double double35 = textTitle31.getContentYOffset();
        blockContainer28.add((org.jfree.chart.block.Block) textTitle31);
        legendTitle27.setWrapper(blockContainer28);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
        categoryPlot38.setDomainAxisLocation(15, axisLocation40, true);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        textTitle43.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = textTitle43.getMargin();
        categoryPlot38.setInsets(rectangleInsets46, false);
        legendTitle27.setItemLabelPadding(rectangleInsets46);
        jFreeChart11.setPadding(rectangleInsets46);
        int int51 = jFreeChart11.getSubtitleCount();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Font font15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ClassContext", font15);
        labelBlock16.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        boolean boolean20 = labelBlock16.equals((java.lang.Object) textTitle19);
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        boolean boolean24 = categoryPlot0.render(graphics2D13, rectangle2D21, (int) (byte) 100, plotRenderingInfo23);
        categoryPlot0.setBackgroundImageAlpha((float) (byte) 0);
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(axisSpace27);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        numberAxis1.setAutoRange(false);
        boolean boolean11 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot14.setDomainAxisLocation(15, axisLocation16, true);
        categoryPlot14.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot14.getRendererForDataset(categoryDataset20);
        java.awt.Stroke stroke22 = categoryPlot14.getOutlineStroke();
        valueMarker13.setStroke(stroke22);
        valueMarker13.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = valueMarker13.getLabelOffset();
        double double28 = rectangleInsets26.calculateLeftOutset(3.0d);
        numberAxis1.setLabelInsets(rectangleInsets26);
        boolean boolean30 = numberAxis1.isAutoRange();
        java.awt.Shape shape31 = null;
        try {
            numberAxis1.setLeftArrow(shape31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot1.getRangeAxisEdge();
        java.awt.Paint paint4 = categoryPlot1.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot1.getRangeAxisEdge();
        boolean boolean6 = categoryPlot1.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot1.getDomainAxisEdge((int) (short) -1);
        boolean boolean9 = categoryPlot1.isSubplot();
        categoryPlot1.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        java.awt.Paint paint14 = categoryPlot11.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot11.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo20, point2D21);
        boolean boolean23 = categoryPlot11.isDomainZoomable();
        boolean boolean24 = categoryPlot11.isOutlineVisible();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset25 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list26 = defaultStatisticalCategoryDataset25.getColumnKeys();
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset25, true);
        categoryPlot11.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset25);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("RectangleEdge.RIGHT");
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot32.setDomainAxisLocation(15, axisLocation34, true);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot32.getDomainMarkers(layer37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis39.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double42 = categoryAxis39.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int44 = numberTickUnit43.getMinorTickCount();
        java.awt.Font font45 = categoryAxis39.getTickLabelFont((java.lang.Comparable) numberTickUnit43);
        categoryPlot32.setDomainAxis(categoryAxis39);
        categoryAxis39.setTickLabelsVisible(true);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray49 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis31, categoryAxis39 };
        categoryPlot11.setDomainAxes(categoryAxisArray49);
        categoryPlot1.setDomainAxes(categoryAxisArray49);
        boolean boolean52 = rangeType0.equals((java.lang.Object) categoryPlot1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(categoryAxisArray49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke5 = statisticalBarRenderer0.getBaseOutlineStroke();
        boolean boolean6 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean8 = statisticalBarRenderer0.getIncludeBaseInRange();
        boolean boolean9 = statisticalBarRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Font font11 = statisticalBarRenderer0.getSeriesItemLabelFont(0);
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(font11);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Font font2 = statisticalBarRenderer1.getBaseItemLabelFont();
        boolean boolean3 = axisLocation0.equals((java.lang.Object) font2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation0.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation5 = axisLocation4.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator(255);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int5 = color4.getTransparency();
        statisticalBarRenderer0.setSeriesItemLabelPaint(3, (java.awt.Paint) color4, false);
        org.jfree.chart.LegendItem legendItem10 = statisticalBarRenderer0.getLegendItem((int) ' ', (int) (short) 0);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(legendItem10);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        java.awt.Shape shape19 = statisticalBarRenderer14.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        statisticalBarRenderer14.setGradientPaintTransformer(gradientPaintTransformer20);
        int int22 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot0.getRenderer((int) (byte) 1);
        categoryPlot0.mapDatasetToDomainAxis(1, 255);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer25);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint((int) '#', (java.awt.Paint) color8, false);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        jFreeChart9.setTitle("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.TickUnit tickUnit1 = null;
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit(tickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range5 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis7.setVisible(true);
        numberAxis7.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range13 = numberAxis7.getRange();
        double double14 = range13.getLength();
        org.jfree.data.Range range17 = org.jfree.data.Range.expand(range13, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint2.toRangeWidth(range17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint18.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 11.0d + "'", double14 == 11.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (short) 10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        textTitle2.setWidth((double) '4');
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape13 = textBlock5.calculateBounds(graphics2D6, 0.0f, (float) (-1), textBlockAnchor9, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        boolean boolean15 = textTitle2.equals((java.lang.Object) shape13);
        shapeList0.setShape(15, shape13);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot1.getRangeAxisEdge();
        categoryPlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        int int10 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6);
        java.awt.Stroke stroke12 = statisticalBarRenderer6.lookupSeriesStroke(1);
        boolean boolean13 = keyedObjects2D0.equals((java.lang.Object) stroke12);
        keyedObjects2D0.removeColumn((java.lang.Comparable) "ItemLabelAnchor.INSIDE7");
        int int17 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getPositiveItemLabelPosition(0, 15);
        java.awt.Color color9 = java.awt.Color.black;
        try {
            statisticalBarRenderer0.setSeriesItemLabelPaint((int) (byte) -1, (java.awt.Paint) color9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        blockParams0.setGenerateEntities(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis0.setCategoryLabelPositionOffset((int) ' ');
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot7.setDomainAxisLocation(15, axisLocation9, true);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot7.getDomainMarkers(layer12);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        double double17 = numberAxis16.getAutoRangeMinimumSize();
        numberAxis16.setVisible(true);
        categoryPlot7.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) numberAxis16);
        categoryPlot7.setOutlineVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot7.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis24.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        java.awt.Font font33 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("ClassContext", font33);
        labelBlock34.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle();
        boolean boolean38 = labelBlock34.equals((java.lang.Object) textTitle37);
        java.awt.geom.Rectangle2D rectangle2D39 = textTitle37.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        int int41 = categoryPlot40.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot40.getRangeAxisEdge();
        java.awt.Paint paint43 = categoryPlot40.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot40.getRangeAxisEdge();
        java.util.List list45 = categoryAxis24.refreshTicks(graphics2D30, axisState31, rectangle2D39, rectangleEdge44);
        org.jfree.chart.entity.ChartEntity chartEntity48 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D39, "TextAnchor.CENTER_RIGHT", "ItemLabelAnchor.INSIDE7");
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle();
        textTitle49.setID("ClassContext");
        textTitle49.setHeight((double) 0);
        double double54 = textTitle49.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = textTitle49.getPosition();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer56 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke57 = statisticalBarRenderer56.getBaseStroke();
        java.awt.Paint paint59 = statisticalBarRenderer56.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke60 = statisticalBarRenderer56.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition62 = null;
        statisticalBarRenderer56.setSeriesNegativeItemLabelPosition(255, itemLabelPosition62);
        java.lang.Boolean boolean65 = statisticalBarRenderer56.getSeriesVisible((int) (short) 0);
        boolean boolean66 = rectangleEdge55.equals((java.lang.Object) statisticalBarRenderer56);
        org.jfree.chart.axis.AxisSpace axisSpace67 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace68 = categoryAxis0.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) categoryPlot7, rectangle2D39, rectangleEdge55, axisSpace67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0E-8d + "'", double17 == 1.0E-8d);
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNull(paint59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNull(boolean65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean2 = layer0.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getUpArrow();
        java.awt.Shape shape2 = numberAxis0.getRightArrow();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list6 = defaultStatisticalCategoryDataset5.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity9 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        try {
            java.lang.Number number12 = defaultStatisticalCategoryDataset5.getValue((int) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke19 = statisticalBarRenderer18.getBaseStroke();
        statisticalBarRenderer14.setBaseStroke(stroke19, false);
        categoryPlot0.setRangeGridlineStroke(stroke19);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation23, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke8 = statisticalBarRenderer7.getBaseStroke();
        java.awt.Paint paint10 = statisticalBarRenderer7.getSeriesOutlinePaint((-1));
        boolean boolean11 = statisticalBarRenderer7.getAutoPopulateSeriesOutlineStroke();
        categoryPlot1.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer7, true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.INSIDE7", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.awt.Paint paint15 = categoryPlot1.getOutlinePaint();
        float float16 = categoryPlot1.getForegroundAlpha();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = legendItemEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        legendItemEntity9.setSeriesKey((java.lang.Comparable) "");
        java.lang.String str15 = legendItemEntity9.toString();
        legendItemEntity9.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LegendItemEntity: seriesKey=, dataset=null" + "'", str15.equals("LegendItemEntity: seriesKey=, dataset=null"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double8 = categoryAxis5.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int10 = numberTickUnit9.getMinorTickCount();
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) numberTickUnit9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        statisticalBarRenderer13.setBaseToolTipGenerator(categoryToolTipGenerator14, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        statisticalBarRenderer13.setSeriesNegativeItemLabelPosition(10, itemLabelPosition18);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color27 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape26, (java.awt.Paint) color27);
        statisticalBarRenderer13.setBaseItemLabelPaint((java.awt.Paint) color27);
        categoryAxis5.setTickLabelPaint((java.lang.Comparable) 100L, (java.awt.Paint) color27);
        java.awt.Color color31 = java.awt.Color.getColor("3", color27);
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder((double) 2, (double) 1, (double) 100, (double) '4', (java.awt.Paint) color31);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot4.setDomainAxisLocation(15, axisLocation6, true);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot4.getDomainMarkers(layer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot4);
        jFreeChart12.clearSubtitles();
        jFreeChart12.setBackgroundImageAlpha(0.5f);
        java.awt.Image image16 = jFreeChart12.getBackgroundImage();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart12);
        java.lang.Object obj18 = jFreeChart12.clone();
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        java.awt.Paint paint14 = valueMarker1.getLabelPaint();
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        numberAxis1.configure();
        numberAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block11 = null;
        blockContainer10.add(block11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setWidth((double) '4');
        java.lang.Object obj16 = textTitle13.clone();
        double double17 = textTitle13.getContentYOffset();
        blockContainer10.add((org.jfree.chart.block.Block) textTitle13);
        legendTitle9.setWrapper(blockContainer10);
        java.util.List list20 = blockContainer10.getBlocks();
        double double21 = blockContainer10.getContentYOffset();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.Range range24 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range24);
        double double26 = rectangleConstraint25.getWidth();
        try {
            org.jfree.chart.util.Size2D size2D27 = blockContainer10.arrange(graphics2D22, rectangleConstraint25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float4 = categoryLabelPosition3.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = categoryLabelPosition3.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment7, verticalAlignment8, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        textTitle12.setID("ClassContext");
        java.lang.Object obj15 = null;
        columnArrangement11.add((org.jfree.chart.block.Block) textTitle12, obj15);
        boolean boolean17 = categoryLabelPosition3.equals((java.lang.Object) textTitle12);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color2 = java.awt.Color.white;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font1, (java.awt.Paint) color2);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.cyan;
        int int7 = color6.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("ClassContext", font5, (java.awt.Paint) color6);
        textLine3.removeFragment(textFragment9);
        org.jfree.chart.text.TextFragment textFragment11 = textLine3.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-16711681) + "'", int7 == (-16711681));
        org.junit.Assert.assertNotNull(textFragment11);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent3);
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range7 = numberAxis1.getRange();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot8.setDomainAxisLocation(15, axisLocation10, true);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle13.getMargin();
        categoryPlot8.setInsets(rectangleInsets16, false);
        double double20 = rectangleInsets16.extendHeight((double) 100.0f);
        double double22 = rectangleInsets16.calculateTopOutset((double) 'a');
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("ClassContext", font24);
        labelBlock25.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        boolean boolean29 = labelBlock25.equals((java.lang.Object) textTitle28);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle28.getBounds();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets16.createOutsetRectangle(rectangle2D30);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset34 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke36 = statisticalBarRenderer35.getBaseStroke();
        java.awt.Paint paint38 = statisticalBarRenderer35.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke39 = statisticalBarRenderer35.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = null;
        statisticalBarRenderer35.setSeriesNegativeItemLabelPosition(255, itemLabelPosition41);
        boolean boolean43 = statisticalBarRenderer35.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator45 = null;
        statisticalBarRenderer35.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator45, false);
        boolean boolean48 = defaultStatisticalCategoryDataset34.equals((java.lang.Object) statisticalBarRenderer35);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit51 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity52 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D30, "TextAnchor.CENTER_RIGHT", "TextBlockAnchor.TOP_LEFT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset34, (java.lang.Comparable) 1, (java.lang.Comparable) numberTickUnit51);
        numberAxis1.setLeftArrow((java.awt.Shape) rectangle2D30);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.0d + "'", double20 == 100.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        double double3 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.Range range4 = numberAxis1.getRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setTickMarkOutsideLength((float) (short) 100);
        numberAxis1.setLabelAngle((double) '4');
        numberAxis1.setLowerBound((double) (byte) 100);
        double double8 = numberAxis1.getUpperMargin();
        numberAxis1.setInverted(false);
        java.awt.Font font11 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleEdge.RIGHT");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 0.05d);
        java.awt.Font font5 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        java.awt.Stroke stroke6 = categoryAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Font font5 = statisticalBarRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setSeriesFillPaint(100, paint7, true);
        java.awt.Stroke stroke11 = statisticalBarRenderer0.getSeriesOutlineStroke((int) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator12);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(stroke11);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10, numberArray13, numberArray16, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray20);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset21);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset21, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range24, (double) 0.95f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint(range24, 100.0d);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.3d + "'", number22.equals(0.3d));
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean2 = axisLocation0.equals((java.lang.Object) rectangleEdge1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = axisLocation0.getOpposite();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation3, plotOrientation4);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        chartEntity1.setURLText("3");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke5 = statisticalBarRenderer4.getBaseStroke();
        java.awt.Paint paint7 = statisticalBarRenderer4.getSeriesOutlinePaint((-1));
        boolean boolean8 = statisticalBarRenderer4.getAutoPopulateSeriesOutlineStroke();
        boolean boolean9 = statisticalBarRenderer4.getBaseSeriesVisible();
        java.awt.Color color11 = java.awt.Color.white;
        statisticalBarRenderer4.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer4);
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block15 = null;
        blockContainer14.add(block15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.setWidth((double) '4');
        java.lang.Object obj20 = textTitle17.clone();
        double double21 = textTitle17.getContentYOffset();
        blockContainer14.add((org.jfree.chart.block.Block) textTitle17);
        legendTitle13.setWrapper(blockContainer14);
        java.util.List list24 = blockContainer14.getBlocks();
        double double25 = blockContainer14.getContentYOffset();
        boolean boolean26 = chartEntity1.equals((java.lang.Object) double25);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 15.0d, (double) (-16711681), (-12), (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        double double7 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        try {
            valueMarker1.setAlpha((float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        java.util.List list4 = categoryPlot0.getCategories();
        java.awt.Color color5 = java.awt.Color.BLUE;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Paint paint2 = labelBlock1.getPaint();
        java.awt.Paint paint3 = labelBlock1.getPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis12.setTickLabelsVisible(true);
        java.util.List list17 = categoryPlot0.getCategoriesForAxis(categoryAxis12);
        categoryPlot0.setWeight((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke2 = statisticalBarRenderer1.getBaseStroke();
        java.awt.Paint paint4 = statisticalBarRenderer1.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke5 = statisticalBarRenderer1.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer1.setSeriesNegativeItemLabelPosition(255, itemLabelPosition7);
        boolean boolean9 = statisticalBarRenderer1.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        statisticalBarRenderer1.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator11, false);
        boolean boolean14 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) statisticalBarRenderer1);
        java.lang.Object obj15 = null;
        boolean boolean16 = defaultStatisticalCategoryDataset0.equals(obj15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke4 = statisticalBarRenderer3.getBaseStroke();
        java.awt.Paint paint6 = statisticalBarRenderer3.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke7 = statisticalBarRenderer3.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        statisticalBarRenderer3.setSeriesNegativeItemLabelPosition(255, itemLabelPosition9);
        boolean boolean11 = statisticalBarRenderer3.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer3.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        categoryPlot16.setDomainAxisLocation(15, axisLocation18, true);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot16.getDomainMarkers(layer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot16.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot16);
        java.lang.Object obj25 = jFreeChart24.clone();
        jFreeChart24.setBackgroundImageAlignment((-4194304));
        java.awt.Paint paint28 = jFreeChart24.getBorderPaint();
        statisticalBarRenderer3.setBaseFillPaint(paint28);
        org.jfree.chart.block.ColumnArrangement columnArrangement30 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement35 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment31, verticalAlignment32, (double) ' ', (double) '4');
        columnArrangement35.clear();
        columnArrangement35.clear();
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer3, (org.jfree.chart.block.Arrangement) columnArrangement30, (org.jfree.chart.block.Arrangement) columnArrangement35);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement30);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.data.Range range42 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range42);
        double double44 = rectangleConstraint43.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toUnconstrainedWidth();
        double double46 = rectangleConstraint43.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D47 = blockContainer0.arrange(graphics2D40, rectangleConstraint43);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.0d + "'", double44 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        boolean boolean10 = statisticalBarRenderer6.getAutoPopulateSeriesOutlineStroke();
        categoryPlot0.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6, true);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean15 = numberAxis14.isVerticalTickLabels();
        org.jfree.data.Range range16 = numberAxis14.getRange();
        numberAxis14.configure();
        int int18 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean11 = axisLocation9.equals((java.lang.Object) rectangleEdge10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation9.getOpposite();
        boolean boolean13 = legendItem8.equals((java.lang.Object) axisLocation9);
        java.awt.Paint paint14 = legendItem8.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        boolean boolean9 = legendItem8.isShapeFilled();
        java.lang.String str10 = legendItem8.getURLText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ThreadContext" + "'", str10.equals("ThreadContext"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis1.setCategoryLabelPositionOffset((int) ' ');
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) "RectangleEdge.RIGHT", font8);
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("java.awt.Color[r=192,g=0,b=0]", font8);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int int3 = java.awt.Color.HSBtoRGB((float) 'a', (float) (byte) 0, (float) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-35) + "'", int3 == (-35));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ItemLabelAnchor.OUTSIDE3", graphics2D1, (double) 15, 0.0f, (float) (-35));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getPositiveItemLabelPosition(0, 15);
        java.awt.Paint paint9 = statisticalBarRenderer0.lookupSeriesOutlinePaint(1);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment11, verticalAlignment12, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        textTitle16.setID("ClassContext");
        java.lang.Object obj19 = null;
        columnArrangement15.add((org.jfree.chart.block.Block) textTitle16, obj19);
        boolean boolean21 = textAnchor10.equals((java.lang.Object) textTitle16);
        double double22 = textTitle16.getWidth();
        double double23 = textTitle16.getHeight();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.Font font26 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("ClassContext", font26);
        labelBlock27.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        boolean boolean31 = labelBlock27.equals((java.lang.Object) textTitle30);
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle30.getBounds();
        textTitle16.draw(graphics2D24, rectangle2D32);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis35.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double38 = categoryAxis35.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int40 = numberTickUnit39.getMinorTickCount();
        java.awt.Font font41 = categoryAxis35.getTickLabelFont((java.lang.Comparable) numberTickUnit39);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer43 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = null;
        statisticalBarRenderer43.setBaseToolTipGenerator(categoryToolTipGenerator44, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition48 = null;
        statisticalBarRenderer43.setSeriesNegativeItemLabelPosition(10, itemLabelPosition48);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color57 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape56, (java.awt.Paint) color57);
        statisticalBarRenderer43.setBaseItemLabelPaint((java.awt.Paint) color57);
        categoryAxis35.setTickLabelPaint((java.lang.Comparable) 100L, (java.awt.Paint) color57);
        java.awt.Color color61 = java.awt.Color.getColor("3", color57);
        textTitle16.setPaint((java.awt.Paint) color57);
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color57, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color61);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 15);
        axisState1.cursorUp((double) 15);
        axisState1.cursorDown((double) 1L);
        java.util.List list6 = null;
        axisState1.setTicks(list6);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double12 = rectangleInsets8.extendHeight((double) 100.0f);
        double double14 = rectangleInsets8.calculateTopOutset((double) 'a');
        java.awt.Font font16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ClassContext", font16);
        labelBlock17.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        boolean boolean21 = labelBlock17.equals((java.lang.Object) textTitle20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets8.createOutsetRectangle(rectangle2D22);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        java.awt.Paint paint30 = statisticalBarRenderer27.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke31 = statisticalBarRenderer27.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        statisticalBarRenderer27.setSeriesNegativeItemLabelPosition(255, itemLabelPosition33);
        boolean boolean35 = statisticalBarRenderer27.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = null;
        statisticalBarRenderer27.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator37, false);
        boolean boolean40 = defaultStatisticalCategoryDataset26.equals((java.lang.Object) statisticalBarRenderer27);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity44 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D22, "TextAnchor.CENTER_RIGHT", "TextBlockAnchor.TOP_LEFT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26, (java.lang.Comparable) 1, (java.lang.Comparable) numberTickUnit43);
        double double45 = numberTickUnit43.getSize();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        java.awt.Color color14 = java.awt.Color.BLUE;
        valueMarker1.setPaint((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = valueMarker1.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType17);
        java.awt.Paint paint19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        valueMarker1.setOutlinePaint(paint19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker1.getLabelOffset();
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection10 = categoryPlot0.getDomainMarkers((int) '#', layer9);
        double double11 = categoryPlot0.getRangeCrosshairValue();
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.CENTER");
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setBaseItemLabelsVisible(false, false);
        java.awt.Paint paint6 = null;
        statisticalBarRenderer0.setSeriesPaint(0, paint6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        statisticalBarRenderer0.notifyListeners(rendererChangeEvent8);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        double double7 = numberAxis1.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str9 = numberTickUnit8.toString();
        boolean boolean11 = numberTickUnit8.equals((java.lang.Object) 0L);
        numberAxis1.setTickUnit(numberTickUnit8, true, false);
        int int15 = numberTickUnit8.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[size=1]" + "'", str9.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        categoryPlot0.setAnchorValue((double) 10L, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot17.setDomainAxisLocation(15, axisLocation19, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke24 = statisticalBarRenderer23.getBaseStroke();
        java.awt.Paint paint26 = statisticalBarRenderer23.getSeriesOutlinePaint((-1));
        boolean boolean27 = statisticalBarRenderer23.getAutoPopulateSeriesOutlineStroke();
        categoryPlot17.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23, true);
        java.awt.Shape shape31 = statisticalBarRenderer23.lookupSeriesShape((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = statisticalBarRenderer23.getURLGenerator((int) (byte) 1, (-4194304));
        categoryPlot0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font39 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle38.setFont(font39);
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("java.awt.Color[r=192,g=0,b=0]", font39);
        try {
            statisticalBarRenderer23.setSeriesItemLabelFont((-4194304), font39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(categoryURLGenerator34);
        org.junit.Assert.assertNotNull(font39);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double4 = categoryAxis1.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int6 = numberTickUnit5.getMinorTickCount();
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) numberTickUnit5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        statisticalBarRenderer9.setBaseToolTipGenerator(categoryToolTipGenerator10, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        statisticalBarRenderer9.setSeriesNegativeItemLabelPosition(10, itemLabelPosition14);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color23 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape22, (java.awt.Paint) color23);
        statisticalBarRenderer9.setBaseItemLabelPaint((java.awt.Paint) color23);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 100L, (java.awt.Paint) color23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        java.awt.Paint paint30 = statisticalBarRenderer27.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke31 = statisticalBarRenderer27.getBaseStroke();
        java.lang.Boolean boolean33 = statisticalBarRenderer27.getSeriesItemLabelsVisible((int) ' ');
        java.awt.Stroke stroke34 = statisticalBarRenderer27.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color23, stroke34);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        textTitle0.setHeight((double) 0);
        double double5 = textTitle0.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle0.getPosition();
        boolean boolean7 = textTitle0.getNotify();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = legendTitle19.getHorizontalAlignment();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        textTitle21.setID("ClassContext");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent24 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        org.jfree.chart.title.Title title25 = titleChangeEvent24.getTitle();
        org.jfree.chart.title.Title title26 = titleChangeEvent24.getTitle();
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = title26.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment20, verticalAlignment27, (double) 100, (double) 255);
        flowArrangement30.clear();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke33 = statisticalBarRenderer32.getBaseStroke();
        java.awt.Paint paint35 = statisticalBarRenderer32.getSeriesOutlinePaint((-1));
        boolean boolean36 = statisticalBarRenderer32.getAutoPopulateSeriesOutlineStroke();
        boolean boolean37 = statisticalBarRenderer32.getBaseSeriesVisible();
        java.awt.Color color39 = java.awt.Color.white;
        statisticalBarRenderer32.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color39);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer32);
        org.jfree.chart.block.BlockContainer blockContainer42 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block43 = null;
        blockContainer42.add(block43);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        textTitle45.setWidth((double) '4');
        java.lang.Object obj48 = textTitle45.clone();
        double double49 = textTitle45.getContentYOffset();
        blockContainer42.add((org.jfree.chart.block.Block) textTitle45);
        legendTitle41.setWrapper(blockContainer42);
        java.util.List list52 = blockContainer42.getBlocks();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment53 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement57 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment53, verticalAlignment54, (double) ' ', (double) '4');
        columnArrangement57.clear();
        columnArrangement57.clear();
        blockContainer42.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement57);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = null;
        try {
            org.jfree.chart.util.Size2D size2D63 = flowArrangement30.arrange(blockContainer42, graphics2D61, rectangleConstraint62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(title25);
        org.junit.Assert.assertNotNull(title26);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertNotNull(list52);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        java.lang.Boolean boolean6 = statisticalBarRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        boolean boolean9 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 0, (int) (short) -1);
        statisticalBarRenderer0.setBaseCreateEntities(false, false);
        statisticalBarRenderer0.setSeriesVisibleInLegend(15, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        double double3 = numberAxis1.getAutoRangeMinimumSize();
        boolean boolean4 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setFixedDimension(0.3d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) '#', (int) (short) 10, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        org.jfree.chart.text.TextAnchor textAnchor14 = categoryLabelPosition13.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions9, categoryLabelPosition13);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape8, (java.awt.Paint) color9);
        boolean boolean11 = legendItem10.isLineVisible();
        boolean boolean12 = legendItem10.isLineVisible();
        int int13 = objectList1.indexOf((java.lang.Object) boolean12);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        double double3 = size2D2.width;
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(0, categoryURLGenerator6);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape7, (java.awt.Paint) color8);
        java.awt.Stroke stroke10 = legendItem9.getLineStroke();
        java.awt.Shape shape11 = legendItem9.getShape();
        boolean boolean12 = gradientPaintTransformType0.equals((java.lang.Object) shape11);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }
}

