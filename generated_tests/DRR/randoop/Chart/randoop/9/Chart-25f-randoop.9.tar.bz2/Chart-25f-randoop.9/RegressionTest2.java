import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        double double3 = categoryItemRendererState1.getBarWidth();
        double double4 = categoryItemRendererState1.getSeriesRunningTotal();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = categoryItemRendererState1.getInfo();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, range4);
        double double7 = range3.constrain((double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = statisticalBarRenderer0.getToolTipGenerator((int) (byte) -1, (-1));
        java.awt.Paint paint10 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        textTitle11.setID("ClassContext");
        java.lang.Object obj14 = null;
        columnArrangement10.add((org.jfree.chart.block.Block) textTitle11, obj14);
        boolean boolean16 = textAnchor5.equals((java.lang.Object) textTitle11);
        textLine1.draw(graphics2D2, (float) '4', (float) (short) 10, textAnchor5, (float) (short) -1, (float) 0L, 0.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        categoryPlot21.setDomainAxisLocation(15, axisLocation23, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        java.awt.Paint paint30 = statisticalBarRenderer27.getSeriesOutlinePaint((-1));
        boolean boolean31 = statisticalBarRenderer27.getAutoPopulateSeriesOutlineStroke();
        categoryPlot21.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer27, true);
        java.awt.Paint paint34 = statisticalBarRenderer27.getBaseOutlinePaint();
        boolean boolean35 = textLine1.equals((java.lang.Object) paint34);
        textBlock0.addLine(textLine1);
        org.jfree.chart.text.TextFragment textFragment37 = textLine1.getFirstTextFragment();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.Size2D size2D39 = textLine1.calculateDimensions(graphics2D38);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(textFragment37);
        org.junit.Assert.assertNotNull(size2D39);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("ClassContext", font2);
        labelBlock3.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        java.awt.Font font7 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ClassContext", font7);
        labelBlock8.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        boolean boolean12 = labelBlock8.equals((java.lang.Object) textTitle11);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle11.getBounds();
        labelBlock3.setBounds(rectangle2D13);
        boolean boolean15 = axisLocation0.equals((java.lang.Object) labelBlock3);
        java.awt.Paint paint16 = labelBlock3.getPaint();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        int int6 = categoryPlot5.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getRangeAxisEdge();
        java.awt.Paint paint8 = categoryPlot5.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot5.getRangeAxisEdge();
        boolean boolean10 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double14 = categoryAxis11.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int16 = numberTickUnit15.getMinorTickCount();
        java.awt.Font font17 = categoryAxis11.getTickLabelFont((java.lang.Comparable) numberTickUnit15);
        categoryPlot5.setNoDataMessageFont(font17);
        org.jfree.chart.util.SortOrder sortOrder19 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot5.setColumnRenderingOrder(sortOrder19);
        categoryPlot0.setRowRenderingOrder(sortOrder19);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(sortOrder19);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis11.setMarkerBand(markerAxisBand31);
        boolean boolean33 = numberAxis11.isInverted();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis5.setVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis5);
        categoryPlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation11 = axisLocation10.getOpposite();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateLeftInset((double) 0.5f);
        double double4 = rectangleInsets0.extendWidth(21.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 23.0d + "'", double4 == 23.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.setID("ClassContext");
        java.lang.Object obj13 = null;
        columnArrangement9.add((org.jfree.chart.block.Block) textTitle10, obj13);
        boolean boolean15 = textAnchor4.equals((java.lang.Object) textTitle10);
        textLine0.draw(graphics2D1, (float) '4', (float) (short) 10, textAnchor4, (float) (short) -1, (float) 0L, 0.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot20.setDomainAxisLocation(15, axisLocation22, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke27 = statisticalBarRenderer26.getBaseStroke();
        java.awt.Paint paint29 = statisticalBarRenderer26.getSeriesOutlinePaint((-1));
        boolean boolean30 = statisticalBarRenderer26.getAutoPopulateSeriesOutlineStroke();
        categoryPlot20.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26, true);
        java.awt.Paint paint33 = statisticalBarRenderer26.getBaseOutlinePaint();
        boolean boolean34 = textLine0.equals((java.lang.Object) paint33);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.util.Size2D size2D36 = textLine0.calculateDimensions(graphics2D35);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(size2D36);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        numberAxis1.setInverted(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource9);
        java.text.NumberFormat numberFormat11 = null;
        numberAxis1.setNumberFormatOverride(numberFormat11);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke19 = statisticalBarRenderer18.getBaseStroke();
        statisticalBarRenderer14.setBaseStroke(stroke19, false);
        categoryPlot0.setRangeGridlineStroke(stroke19);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation23, true);
        int int26 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        java.util.Locale locale1 = null;
//        java.lang.Class class2 = null;
//        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
//        try {
//            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader3);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        org.jfree.chart.plot.Plot plot11 = jFreeChart9.getPlot();
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        jFreeChart9.setNotify(true);
        jFreeChart9.setTextAntiAlias(true);
        java.awt.Paint paint17 = jFreeChart9.getBorderPaint();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        shapeList0.clear();
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (-4194304));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot1.getRangeAxisEdge();
        java.awt.Paint paint4 = categoryPlot1.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot1.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot1.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot1.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo10, point2D11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot1.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent3);
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.mapDatasetToRangeAxis(255, 64);
        java.lang.String str10 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        java.util.List list3 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Font font5 = statisticalBarRenderer0.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesCreateEntities((int) ' ', (java.lang.Boolean) true, true);
        java.awt.Paint paint10 = statisticalBarRenderer0.getErrorIndicatorPaint();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color14 = java.awt.Color.cyan;
        int int15 = color14.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color14);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("ClassContext", font13, (java.awt.Paint) color14);
        statisticalBarRenderer0.setSeriesOutlinePaint(64, (java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-16711681) + "'", int15 == (-16711681));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        numberAxis1.setInverted(false);
        numberAxis1.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double14 = categoryAxis11.getLabelAngle();
        boolean boolean15 = numberAxis1.equals((java.lang.Object) categoryAxis11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot0.getOrientation();
        java.lang.String str13 = plotOrientation12.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.VERTICAL" + "'", str13.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 15);
        axisState1.cursorUp((double) 15);
        axisState1.setMax((double) 15);
        axisState1.cursorUp(10.0d);
        double double8 = axisState1.getMax();
        double double9 = axisState1.getMax();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 15.0d + "'", double8 == 15.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 15.0d + "'", double9 == 15.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        categoryPlot0.setAnchorValue((double) 10L, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot17.setDomainAxisLocation(15, axisLocation19, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke24 = statisticalBarRenderer23.getBaseStroke();
        java.awt.Paint paint26 = statisticalBarRenderer23.getSeriesOutlinePaint((-1));
        boolean boolean27 = statisticalBarRenderer23.getAutoPopulateSeriesOutlineStroke();
        categoryPlot17.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23, true);
        java.awt.Shape shape31 = statisticalBarRenderer23.lookupSeriesShape((int) 'a');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = statisticalBarRenderer23.getURLGenerator((int) (byte) 1, (-4194304));
        categoryPlot0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23);
        java.awt.Shape shape37 = null;
        statisticalBarRenderer23.setSeriesShape(0, shape37, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke41 = statisticalBarRenderer40.getBaseStroke();
        java.awt.Paint paint43 = statisticalBarRenderer40.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer44 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke45 = statisticalBarRenderer44.getBaseStroke();
        statisticalBarRenderer40.setBaseStroke(stroke45, false);
        boolean boolean48 = statisticalBarRenderer40.getAutoPopulateSeriesFillPaint();
        statisticalBarRenderer40.setBaseItemLabelsVisible(false, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator53 = statisticalBarRenderer52.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator55 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer52.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator55);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        int int58 = categoryPlot57.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = categoryPlot57.getRangeAxisEdge();
        java.awt.Paint paint60 = categoryPlot57.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot57.getRangeAxisEdge();
        boolean boolean62 = categoryPlot57.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis63.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double66 = categoryAxis63.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit67 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int68 = numberTickUnit67.getMinorTickCount();
        java.awt.Font font69 = categoryAxis63.getTickLabelFont((java.lang.Comparable) numberTickUnit67);
        categoryPlot57.setNoDataMessageFont(font69);
        int int71 = categoryPlot57.getDatasetCount();
        java.awt.Stroke stroke72 = categoryPlot57.getRangeCrosshairStroke();
        statisticalBarRenderer52.setBaseStroke(stroke72);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator74 = statisticalBarRenderer52.getLegendItemLabelGenerator();
        statisticalBarRenderer40.setLegendItemToolTipGenerator(categorySeriesLabelGenerator74);
        statisticalBarRenderer23.setLegendItemURLGenerator(categorySeriesLabelGenerator74);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNull(categoryURLGenerator34);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator53);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator74);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        statisticalBarRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer2.setSeriesNegativeItemLabelPosition(10, itemLabelPosition7);
        java.awt.Stroke stroke10 = statisticalBarRenderer2.lookupSeriesOutlineStroke((int) (short) -1);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        numberAxis1.setVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        int int6 = categoryPlot5.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setDomainAxisLocation(15, axisLocation15, true);
        categoryPlot13.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot13.getRendererForDataset(categoryDataset19);
        java.awt.Stroke stroke21 = categoryPlot13.getOutlineStroke();
        valueMarker12.setStroke(stroke21);
        valueMarker12.setLabel("ThreadContext");
        java.awt.Paint paint25 = null;
        valueMarker12.setOutlinePaint(paint25);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot5.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker12, layer27);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 10L, (double) (byte) 1, 0.0d);
        double double35 = rectangleInsets33.calculateRightInset(0.3d);
        valueMarker12.setLabelOffset(rectangleInsets33);
        numberAxis1.setLabelInsets(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        java.awt.Shape shape6 = numberAxis1.getLeftArrow();
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        jFreeChart9.setBackgroundImageAlpha(0.5f);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        jFreeChart9.setBorderStroke(stroke13);
        java.awt.RenderingHints renderingHints15 = null;
        try {
            jFreeChart9.setRenderingHints(renderingHints15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        org.jfree.data.Range range9 = numberAxis1.getRange();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        numberAxis1.setTickMarkPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke13 = statisticalBarRenderer12.getBaseStroke();
        java.awt.Paint paint15 = statisticalBarRenderer12.getSeriesOutlinePaint((-1));
        boolean boolean16 = statisticalBarRenderer12.getAutoPopulateSeriesOutlineStroke();
        boolean boolean17 = statisticalBarRenderer12.getBaseSeriesVisible();
        statisticalBarRenderer12.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis23.setPositiveArrowVisible(true);
        numberAxis23.setFixedAutoRange((double) (short) 0);
        numberAxis23.setRangeWithMargins((double) 0, (double) '#');
        numberAxis23.setAutoRange(false);
        java.awt.Font font34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("ClassContext", font34);
        labelBlock35.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        boolean boolean39 = labelBlock35.equals((java.lang.Object) textTitle38);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle38.getBounds();
        statisticalBarRenderer12.drawRangeGridline(graphics2D20, categoryPlot21, (org.jfree.chart.axis.ValueAxis) numberAxis23, rectangle2D40, (double) (-16711681));
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D40);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        textTitle0.setHeight((double) 0);
        double double5 = textTitle0.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle0.getPosition();
        double double7 = textTitle0.getContentYOffset();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray13, numberArray16, numberArray19, numberArray22, numberArray25, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray29);
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset30, 0.0d);
        legendItem8.setDataset((org.jfree.data.general.Dataset) categoryDataset30);
        boolean boolean35 = legendItem8.isShapeFilled();
        int int36 = legendItem8.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.3d + "'", number31.equals(0.3d));
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke5 = statisticalBarRenderer4.getBaseStroke();
        statisticalBarRenderer0.setBaseStroke(stroke5, false);
        boolean boolean8 = statisticalBarRenderer0.getAutoPopulateSeriesFillPaint();
        statisticalBarRenderer0.setBaseItemLabelsVisible(false, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator15 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer12.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        int int18 = categoryPlot17.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot17.getRangeAxisEdge();
        java.awt.Paint paint20 = categoryPlot17.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot17.getRangeAxisEdge();
        boolean boolean22 = categoryPlot17.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double26 = categoryAxis23.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int28 = numberTickUnit27.getMinorTickCount();
        java.awt.Font font29 = categoryAxis23.getTickLabelFont((java.lang.Comparable) numberTickUnit27);
        categoryPlot17.setNoDataMessageFont(font29);
        int int31 = categoryPlot17.getDatasetCount();
        java.awt.Stroke stroke32 = categoryPlot17.getRangeCrosshairStroke();
        statisticalBarRenderer12.setBaseStroke(stroke32);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator34 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator34);
        java.awt.Paint paint37 = statisticalBarRenderer0.getSeriesOutlinePaint((-35));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator34);
        org.junit.Assert.assertNull(paint37);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.lang.String str9 = legendItem8.getLabel();
        java.awt.Font font11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font11, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        boolean boolean15 = legendItem8.equals((java.lang.Object) font11);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setWidth((double) '4');
        textTitle0.setNotify(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.setID("ClassContext");
        java.lang.Object obj13 = null;
        columnArrangement9.add((org.jfree.chart.block.Block) textTitle10, obj13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = textTitle10.getVerticalAlignment();
        boolean boolean17 = verticalAlignment15.equals((java.lang.Object) '4');
        textTitle0.setVerticalAlignment(verticalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        numberAxis1.setDownArrow(shape11);
        numberAxis1.setPositiveArrowVisible(false);
        numberAxis1.setAutoRangeMinimumSize((double) (short) 1, true);
        boolean boolean19 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) (short) -1, 10.0d);
        numberAxis1.setInverted(false);
        double double9 = numberAxis1.getUpperMargin();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke12 = statisticalBarRenderer11.getBaseStroke();
        java.awt.Paint paint14 = statisticalBarRenderer11.getSeriesOutlinePaint((-1));
        boolean boolean15 = statisticalBarRenderer11.getAutoPopulateSeriesShape();
        java.awt.Font font16 = statisticalBarRenderer11.getBaseItemLabelFont();
        java.awt.Color color17 = java.awt.Color.white;
        int int18 = color17.getGreen();
        int int19 = color17.getRed();
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("CategoryLabelEntity: category=RectangleEdge.RIGHT, tooltip=JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0], url=AxisLocation.BOTTOM_OR_LEFT", font16, (java.awt.Paint) color17);
        numberAxis1.setTickLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        int int23 = categoryPlot22.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot22.getRangeAxisEdge();
        java.awt.Paint paint25 = categoryPlot22.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot22.getRangeAxisEdge();
        boolean boolean27 = categoryPlot22.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot22.getDomainAxisEdge((int) (short) -1);
        categoryPlot22.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot22);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, (double) 10.0f, false);
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range3, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        org.jfree.data.Range range4 = numberAxis1.getRange();
        double double6 = range4.constrain((double) 0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        boolean boolean8 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str10 = datasetRenderingOrder9.toString();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder9);
        java.awt.Stroke stroke12 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot15.setDomainAxisLocation(15, axisLocation17, true);
        categoryPlot15.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot15.getRendererForDataset(categoryDataset21);
        java.awt.Stroke stroke23 = categoryPlot15.getOutlineStroke();
        valueMarker14.setStroke(stroke23);
        valueMarker14.setLabel("ThreadContext");
        java.awt.Color color27 = java.awt.Color.BLUE;
        valueMarker14.setPaint((java.awt.Paint) color27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = valueMarker14.getLabelAnchor();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str10.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 100.0f, (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        double double6 = blockContainer5.getHeight();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getGreen();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot4.setDomainAxisLocation(15, axisLocation6, true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        textTitle9.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle9.getMargin();
        categoryPlot4.setInsets(rectangleInsets12, false);
        double double16 = rectangleInsets12.extendHeight((double) 100.0f);
        double double18 = rectangleInsets12.calculateTopOutset((double) 'a');
        java.awt.Font font20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("ClassContext", font20);
        labelBlock21.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        boolean boolean25 = labelBlock21.equals((java.lang.Object) textTitle24);
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets12.createOutsetRectangle(rectangle2D26);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset30 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke32 = statisticalBarRenderer31.getBaseStroke();
        java.awt.Paint paint34 = statisticalBarRenderer31.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke35 = statisticalBarRenderer31.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = null;
        statisticalBarRenderer31.setSeriesNegativeItemLabelPosition(255, itemLabelPosition37);
        boolean boolean39 = statisticalBarRenderer31.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        statisticalBarRenderer31.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator41, false);
        boolean boolean44 = defaultStatisticalCategoryDataset30.equals((java.lang.Object) statisticalBarRenderer31);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit47 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity48 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D26, "TextAnchor.CENTER_RIGHT", "TextBlockAnchor.TOP_LEFT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset30, (java.lang.Comparable) 1, (java.lang.Comparable) numberTickUnit47);
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color56 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape55, (java.awt.Paint) color56);
        boolean boolean58 = legendItem57.isLineVisible();
        java.awt.Stroke stroke59 = legendItem57.getOutlineStroke();
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem(attributedString0, "RectangleEdge.TOP", "TextBlockAnchor.TOP_LEFT", "LegendItemEntity: seriesKey=, dataset=null", (java.awt.Shape) rectangle2D26, stroke59, (java.awt.Paint) color60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(color60);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis11.setMarkerBand(markerAxisBand31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double36 = categoryAxis33.getLabelAngle();
        java.lang.String str38 = categoryAxis33.getCategoryLabelToolTip((java.lang.Comparable) 100);
        boolean boolean39 = categoryAxis33.isVisible();
        java.awt.Font font41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("hi!", font41, (java.awt.Paint) color42);
        categoryAxis33.setAxisLinePaint((java.awt.Paint) color42);
        numberAxis11.setTickLabelPaint((java.awt.Paint) color42);
        java.awt.Paint paint46 = numberAxis11.getTickMarkPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.PINK;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("AxisLocation.BOTTOM_OR_LEFT", font1, (java.awt.Paint) color2, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        statisticalBarRenderer0.setMinimumBarLength(0.0d);
        java.awt.Paint paint13 = statisticalBarRenderer0.getItemOutlinePaint(64, (int) (short) 100);
        statisticalBarRenderer0.setMinimumBarLength((-1.0d));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        java.lang.Boolean boolean6 = statisticalBarRenderer0.getSeriesItemLabelsVisible((int) ' ');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator7);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.event.TitleChangeListener titleChangeListener8 = null;
        textTitle7.addChangeListener(titleChangeListener8);
        java.awt.Paint paint10 = textTitle7.getPaint();
        try {
            org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem(attributedString0, "DatasetRenderingOrder.FORWARD", "Category Plot", "java.awt.Color[r=192,g=0,b=0]", shape4, stroke5, paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) '#', (int) (short) 10, rectangle2D5, rectangleEdge6);
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot9.setDomainAxisLocation(15, axisLocation11, true);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        textTitle14.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = textTitle14.getMargin();
        categoryPlot9.setInsets(rectangleInsets17, false);
        double double20 = rectangleInsets17.getLeft();
        double double21 = rectangleInsets17.getTop();
        categoryAxis0.setTickLabelInsets(rectangleInsets17);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis23.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.axis.AxisState axisState30 = null;
        java.awt.Font font32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("ClassContext", font32);
        labelBlock33.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        boolean boolean37 = labelBlock33.equals((java.lang.Object) textTitle36);
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle36.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        int int40 = categoryPlot39.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot39.getRangeAxisEdge();
        java.awt.Paint paint42 = categoryPlot39.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot39.getRangeAxisEdge();
        java.util.List list44 = categoryAxis23.refreshTicks(graphics2D29, axisState30, rectangle2D38, rectangleEdge43);
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D38, "TextAnchor.CENTER_RIGHT", "ItemLabelAnchor.INSIDE7");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean50 = lengthAdjustmentType48.equals((java.lang.Object) 0L);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType51 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean53 = lengthAdjustmentType51.equals((java.lang.Object) 0L);
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets17.createAdjustedRectangle(rectangle2D38, lengthAdjustmentType48, lengthAdjustmentType51);
        double double56 = rectangleInsets17.calculateRightOutset((double) 100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNotNull(lengthAdjustmentType48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        float float4 = categoryLabelPosition3.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = categoryLabelPosition3.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition3);
        float float7 = categoryLabelPosition3.getWidthRatio();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.95f + "'", float7 == 0.95f);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test055");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getCopyright();
//        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
//        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
//        categoryPlot2.clearRangeAxes();
//        categoryPlot2.setAnchorValue((double) (short) 0);
//        categoryPlot2.setWeight((int) (byte) 10);
//        categoryPlot2.setRangeCrosshairVisible(true);
//        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//        java.util.List list16 = defaultStatisticalCategoryDataset15.getColumnKeys();
//        categoryPlot2.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset15);
//        boolean boolean18 = projectInfo0.equals((java.lang.Object) defaultStatisticalCategoryDataset15);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
        blockParams0.setTranslateY((double) (short) 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getItemLabelPadding();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = lineBorder11.getInsets();
        legendTitle9.setFrame((org.jfree.chart.block.BlockFrame) lineBorder11);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block11 = null;
        blockContainer10.add(block11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setWidth((double) '4');
        java.lang.Object obj16 = textTitle13.clone();
        double double17 = textTitle13.getContentYOffset();
        blockContainer10.add((org.jfree.chart.block.Block) textTitle13);
        legendTitle9.setWrapper(blockContainer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot20.setDomainAxisLocation(15, axisLocation22, true);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        textTitle25.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle25.getMargin();
        categoryPlot20.setInsets(rectangleInsets28, false);
        legendTitle9.setItemLabelPadding(rectangleInsets28);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation35 = null;
        categoryPlot33.setDomainAxisLocation(15, axisLocation35, true);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = categoryPlot33.getDomainMarkers(layer38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = categoryPlot33.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot33);
        jFreeChart41.clearSubtitles();
        java.awt.Stroke stroke43 = jFreeChart41.getBorderStroke();
        java.awt.Image image44 = jFreeChart41.getBackgroundImage();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = jFreeChart41.getPadding();
        legendTitle9.setItemLabelPadding(rectangleInsets45);
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        try {
            rectangleInsets45.trim(rectangle2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNull(categoryAxis40);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(image44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        statisticalBarRenderer0.setItemMargin(98.0d);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        java.awt.Paint paint14 = categoryPlot11.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot11.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot11.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation23);
        boolean boolean25 = legendItemEntity9.equals((java.lang.Object) rectangleEdge24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot26.setDomainAxisLocation(15, axisLocation28, true);
        categoryPlot26.clearRangeAxes();
        categoryPlot26.setAnchorValue((double) (short) 0);
        categoryPlot26.setWeight((int) (byte) 10);
        categoryPlot26.setRangeCrosshairVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset39 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list40 = defaultStatisticalCategoryDataset39.getColumnKeys();
        categoryPlot26.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset39);
        legendItemEntity9.setDataset((org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset39);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset39, false);
        java.lang.Object obj45 = null;
        boolean boolean46 = defaultStatisticalCategoryDataset39.equals(obj45);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot5.setDomainAxisLocation(15, axisLocation7, true);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot5.getDomainMarkers(layer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot5.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.Object obj14 = jFreeChart13.clone();
        jFreeChart13.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle17.setFont(font18);
        textTitle17.setHeight((double) (short) -1);
        jFreeChart13.setTitle(textTitle17);
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart13.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = legendTitle23.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = legendTitle23.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = legendTitle23.getLegendItemGraphicEdge();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleEdge26);
        boolean boolean28 = range3.equals((java.lang.Object) rectangleEdge26);
        double double30 = range3.constrain((double) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(legendTitle23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE3", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        java.awt.Paint paint14 = null;
        valueMarker1.setOutlinePaint(paint14);
        valueMarker1.setLabel("hi!");
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke2 = statisticalBarRenderer1.getBaseStroke();
        java.awt.Paint paint4 = statisticalBarRenderer1.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke5 = statisticalBarRenderer1.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        statisticalBarRenderer1.setSeriesNegativeItemLabelPosition(255, itemLabelPosition7);
        boolean boolean9 = statisticalBarRenderer1.getBaseItemLabelsVisible();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer1.setBaseOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        statisticalBarRenderer1.setBaseToolTipGenerator(categoryToolTipGenerator12);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list20 = defaultStatisticalCategoryDataset19.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity23 = new org.jfree.chart.entity.CategoryItemEntity(shape16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset19, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        int int24 = defaultStatisticalCategoryDataset19.getColumnCount();
        int int25 = defaultStatisticalCategoryDataset19.getColumnCount();
        org.jfree.data.Range range26 = statisticalBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset19);
        org.jfree.data.general.PieDataset pieDataset28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset19, 2);
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset28);
        org.jfree.data.general.PieDataset pieDataset32 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset28, (java.lang.Comparable) 0.3d, 0.0d);
        boolean boolean33 = chartChangeEventType0.equals((java.lang.Object) 0.3d);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(pieDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(pieDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setDomainAxisLocation(15, axisLocation5, true);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot3.getDomainMarkers(layer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot3.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) "ClassContext", jFreeChart11, (-4194304), (-4194304));
        java.awt.Color color15 = java.awt.Color.green;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color15);
        jFreeChart11.setBorderPaint((java.awt.Paint) color15);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke19 = statisticalBarRenderer18.getBaseStroke();
        java.awt.Paint paint21 = statisticalBarRenderer18.getSeriesOutlinePaint((-1));
        boolean boolean22 = statisticalBarRenderer18.getAutoPopulateSeriesOutlineStroke();
        boolean boolean23 = statisticalBarRenderer18.getBaseSeriesVisible();
        java.awt.Color color25 = java.awt.Color.white;
        statisticalBarRenderer18.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color25);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer18);
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block29 = null;
        blockContainer28.add(block29);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        textTitle31.setWidth((double) '4');
        java.lang.Object obj34 = textTitle31.clone();
        double double35 = textTitle31.getContentYOffset();
        blockContainer28.add((org.jfree.chart.block.Block) textTitle31);
        legendTitle27.setWrapper(blockContainer28);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
        categoryPlot38.setDomainAxisLocation(15, axisLocation40, true);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        textTitle43.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = textTitle43.getMargin();
        categoryPlot38.setInsets(rectangleInsets46, false);
        legendTitle27.setItemLabelPadding(rectangleInsets46);
        jFreeChart11.setPadding(rectangleInsets46);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo53 = null;
        try {
            jFreeChart11.handleClick(255, 100, chartRenderingInfo53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator5, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = statisticalBarRenderer0.getSeriesToolTipGenerator((-16711681));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        textTitle3.setWidth((double) '4');
        java.lang.Object obj6 = textTitle3.clone();
        double double7 = textTitle3.getContentYOffset();
        blockContainer0.add((org.jfree.chart.block.Block) textTitle3);
        org.jfree.chart.block.Arrangement arrangement9 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(arrangement9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        categoryPlot2.setAnchorValue((double) (short) 0);
        categoryPlot2.setWeight((int) (byte) 10);
        categoryPlot2.setRangeCrosshairValue(1.0d, true);
        boolean boolean15 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) categoryPlot2);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        int int17 = categoryPlot16.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getRangeAxisEdge();
        categoryPlot16.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke22 = statisticalBarRenderer21.getBaseStroke();
        java.awt.Paint paint24 = statisticalBarRenderer21.getSeriesOutlinePaint((-1));
        int int25 = categoryPlot16.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer21);
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot16.getDataset();
        categoryPlot16.setDrawSharedDomainAxis(true);
        java.awt.Font font29 = categoryPlot16.getNoDataMessageFont();
        categoryPlot2.setParent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        numberAxis1.setDownArrow(shape11);
        numberAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis1.setMarkerBand(markerAxisBand16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis18.setTickLabelsVisible(true);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.AxisState axisState24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis25.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.AxisState axisState32 = null;
        java.awt.Font font34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("ClassContext", font34);
        labelBlock35.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        boolean boolean39 = labelBlock35.equals((java.lang.Object) textTitle38);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle38.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        int int42 = categoryPlot41.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot41.getRangeAxisEdge();
        java.awt.Paint paint44 = categoryPlot41.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot41.getRangeAxisEdge();
        java.util.List list46 = categoryAxis25.refreshTicks(graphics2D31, axisState32, rectangle2D40, rectangleEdge45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean48 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge47);
        java.lang.String str49 = rectangleEdge47.toString();
        java.util.List list50 = categoryAxis18.refreshTicks(graphics2D23, axisState24, rectangle2D40, rectangleEdge47);
        numberAxis1.setLeftArrow((java.awt.Shape) rectangle2D40);
        numberAxis1.setTickLabelsVisible(false);
        numberAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "RectangleEdge.RIGHT" + "'", str49.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(list50);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement11 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer5, (org.jfree.chart.block.Arrangement) columnArrangement10, (org.jfree.chart.block.Arrangement) centerArrangement11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis14.setPositiveArrowVisible(true);
        numberAxis14.setFixedAutoRange((double) (short) 0);
        numberAxis14.setRangeWithMargins((double) 0, (double) '#');
        numberAxis14.setAutoRange(false);
        boolean boolean24 = numberAxis14.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis14.getTickLabelInsets();
        boolean boolean26 = legendTitle12.equals((java.lang.Object) rectangleInsets25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        legendTitle12.setItemPaint((java.awt.Paint) color27);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.setID("ClassContext");
        java.lang.Object obj13 = null;
        columnArrangement9.add((org.jfree.chart.block.Block) textTitle10, obj13);
        boolean boolean15 = textAnchor4.equals((java.lang.Object) textTitle10);
        textLine0.draw(graphics2D1, (float) '4', (float) (short) 10, textAnchor4, (float) (short) -1, (float) 0L, 0.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot20.setDomainAxisLocation(15, axisLocation22, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke27 = statisticalBarRenderer26.getBaseStroke();
        java.awt.Paint paint29 = statisticalBarRenderer26.getSeriesOutlinePaint((-1));
        boolean boolean30 = statisticalBarRenderer26.getAutoPopulateSeriesOutlineStroke();
        categoryPlot20.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26, true);
        java.awt.Paint paint33 = statisticalBarRenderer26.getBaseOutlinePaint();
        boolean boolean34 = textLine0.equals((java.lang.Object) paint33);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine();
        boolean boolean37 = textLine35.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font40 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle39.setFont(font40);
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font40);
        textLine35.addFragment(textFragment42);
        textLine0.removeFragment(textFragment42);
        float float45 = textFragment42.getBaselineOffset();
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.0f + "'", float45 == 0.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection10 = categoryPlot0.getDomainMarkers((int) '#', layer9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot12.setDomainAxisLocation(15, axisLocation14, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke19 = statisticalBarRenderer18.getBaseStroke();
        java.awt.Paint paint21 = statisticalBarRenderer18.getSeriesOutlinePaint((-1));
        boolean boolean22 = statisticalBarRenderer18.getAutoPopulateSeriesOutlineStroke();
        categoryPlot12.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer18, true);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.INSIDE7", (org.jfree.chart.plot.Plot) categoryPlot12);
        java.awt.Paint paint26 = categoryPlot12.getOutlinePaint();
        boolean boolean27 = layer9.equals((java.lang.Object) categoryPlot12);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Font font15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ClassContext", font15);
        labelBlock16.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        boolean boolean20 = labelBlock16.equals((java.lang.Object) textTitle19);
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        boolean boolean24 = categoryPlot0.render(graphics2D13, rectangle2D21, (int) (byte) 100, plotRenderingInfo23);
        categoryPlot0.setBackgroundImageAlpha((float) (byte) 0);
        categoryPlot0.setAnchorValue((double) (short) 10, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = null;
        statisticalBarRenderer30.setBaseToolTipGenerator(categoryToolTipGenerator31, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = null;
        statisticalBarRenderer30.setSeriesNegativeItemLabelPosition(10, itemLabelPosition35);
        java.awt.Stroke stroke38 = statisticalBarRenderer30.lookupSeriesOutlineStroke((int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator39 = statisticalBarRenderer30.getBaseURLGenerator();
        int int40 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(categoryURLGenerator39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "JFreeChart version ClassContext.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\n3", "Size2D[width=0.0, height=0.0]", "ItemLabelAnchor.INSIDE7", "UnitType.RELATIVE");
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke32 = statisticalBarRenderer31.getBaseStroke();
        java.awt.Paint paint34 = statisticalBarRenderer31.getSeriesOutlinePaint((-1));
        java.awt.Shape shape36 = statisticalBarRenderer31.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer37 = null;
        statisticalBarRenderer31.setGradientPaintTransformer(gradientPaintTransformer37);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke41 = statisticalBarRenderer40.getBaseStroke();
        java.awt.Paint paint43 = statisticalBarRenderer40.getSeriesOutlinePaint((-1));
        boolean boolean44 = statisticalBarRenderer40.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = statisticalBarRenderer40.getPositiveItemLabelPosition(0, 15);
        statisticalBarRenderer31.setSeriesPositiveItemLabelPosition(0, itemLabelPosition47, true);
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition47);
        java.awt.Stroke stroke51 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNull(shape36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle0.setFont(font1);
        textTitle0.setHeight((double) (short) -1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("ClassContext", font11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str14 = color13.toString();
        boolean boolean16 = color13.equals((java.lang.Object) 'a');
        textBlock6.addLine("java.awt.Color[r=192,g=0,b=0]", font11, (java.awt.Paint) color13);
        textTitle0.setFont(font11);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        categoryPlot19.setDomainAxisLocation(15, axisLocation21, true);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        textTitle24.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = textTitle24.getMargin();
        categoryPlot19.setInsets(rectangleInsets27, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryPlot19.getInsets();
        textTitle0.setPadding(rectangleInsets30);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str14.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement11 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer5, (org.jfree.chart.block.Arrangement) columnArrangement10, (org.jfree.chart.block.Arrangement) centerArrangement11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setID("ClassContext");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent16 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle13);
        org.jfree.chart.title.Title title17 = titleChangeEvent16.getTitle();
        org.jfree.chart.title.Title title18 = titleChangeEvent16.getTitle();
        org.jfree.chart.block.BlockFrame blockFrame19 = title18.getFrame();
        legendTitle12.setFrame(blockFrame19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.data.Range range24 = new org.jfree.data.Range((double) (byte) -1, (double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range24, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D27 = legendTitle12.arrange(graphics2D21, rectangleConstraint26);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(title17);
        org.junit.Assert.assertNotNull(title18);
        org.junit.Assert.assertNotNull(blockFrame19);
        org.junit.Assert.assertNotNull(size2D27);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 15);
        axisState1.cursorUp((double) 15);
        java.util.List list4 = axisState1.getTicks();
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle0.setFont(font1);
        textTitle0.setHeight((double) (short) -1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("ClassContext", font11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str14 = color13.toString();
        boolean boolean16 = color13.equals((java.lang.Object) 'a');
        textBlock6.addLine("java.awt.Color[r=192,g=0,b=0]", font11, (java.awt.Paint) color13);
        textTitle0.setFont(font11);
        double double19 = textTitle0.getHeight();
        java.awt.Paint paint20 = textTitle0.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = null;
        try {
            textTitle0.setTextAlignment(horizontalAlignment21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str14.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setDomainAxisLocation(15, axisLocation5, true);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot3.getDomainMarkers(layer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot3.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) "ClassContext", jFreeChart11, (-4194304), (-4194304));
        java.lang.Object obj15 = chartProgressEvent14.getSource();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + obj15 + "' != '" + "ClassContext" + "'", obj15.equals("ClassContext"));
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
//        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
//        categoryPlot0.clearRangeAxes();
//        categoryPlot0.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str9 = projectInfo8.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getLibraries();
//        java.lang.String str11 = projectInfo8.getLicenceText();
//        java.awt.Image image12 = projectInfo8.getLogo();
//        categoryPlot0.setBackgroundImage(image12);
//        java.awt.Paint paint14 = categoryPlot0.getDomainGridlinePaint();
//        int int15 = categoryPlot0.getDatasetCount();
//        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis16.setMaximumCategoryLabelWidthRatio((float) ' ');
//        double double19 = categoryAxis16.getLabelAngle();
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
//        int int21 = numberTickUnit20.getMinorTickCount();
//        java.awt.Font font22 = categoryAxis16.getTickLabelFont((java.lang.Comparable) numberTickUnit20);
//        java.awt.Paint paint24 = categoryAxis16.getTickLabelPaint((java.lang.Comparable) (byte) 10);
//        categoryAxis16.removeCategoryLabelToolTip((java.lang.Comparable) '#');
//        double double27 = categoryAxis16.getLowerMargin();
//        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
//        float float29 = categoryAxis28.getMaximumCategoryLabelWidthRatio();
//        org.jfree.chart.axis.CategoryAnchor categoryAnchor30 = null;
//        java.awt.geom.Rectangle2D rectangle2D33 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
//        double double35 = categoryAxis28.getCategoryJava2DCoordinate(categoryAnchor30, (int) '#', (int) (short) 10, rectangle2D33, rectangleEdge34);
//        double double36 = categoryAxis28.getCategoryMargin();
//        java.awt.Font font37 = categoryAxis28.getLabelFont();
//        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("RectangleEdge.RIGHT");
//        categoryAxis39.removeCategoryLabelToolTip((java.lang.Comparable) 0.05d);
//        java.awt.Font font43 = categoryAxis39.getTickLabelFont((java.lang.Comparable) 1);
//        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis44.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
//        categoryAxis44.setCategoryLabelPositionOffset((int) ' ');
//        java.awt.Font font51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        categoryAxis44.setTickLabelFont((java.lang.Comparable) "RectangleEdge.RIGHT", font51);
//        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis53.setMaximumCategoryLabelWidthRatio((float) ' ');
//        double double56 = categoryAxis53.getLabelAngle();
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit57 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
//        int int58 = numberTickUnit57.getMinorTickCount();
//        java.awt.Font font59 = categoryAxis53.getTickLabelFont((java.lang.Comparable) numberTickUnit57);
//        java.awt.Paint paint61 = categoryAxis53.getTickLabelPaint((java.lang.Comparable) (byte) 10);
//        categoryAxis53.removeCategoryLabelToolTip((java.lang.Comparable) '#');
//        float float64 = categoryAxis53.getMaximumCategoryLabelWidthRatio();
//        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis65.setMaximumCategoryLabelWidthRatio((float) ' ');
//        double double68 = categoryAxis65.getLabelAngle();
//        double double69 = categoryAxis65.getLowerMargin();
//        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray70 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis16, categoryAxis28, categoryAxis39, categoryAxis44, categoryAxis53, categoryAxis65 };
//        categoryPlot0.setDomainAxes(categoryAxisArray70);
//        org.junit.Assert.assertNotNull(projectInfo8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3" + "'", str11.equals("3"));
//        org.junit.Assert.assertNotNull(image12);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//        org.junit.Assert.assertNotNull(numberTickUnit20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(font22);
//        org.junit.Assert.assertNotNull(paint24);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.2d + "'", double36 == 0.2d);
//        org.junit.Assert.assertNotNull(font37);
//        org.junit.Assert.assertNotNull(font43);
//        org.junit.Assert.assertNotNull(font51);
//        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
//        org.junit.Assert.assertNotNull(numberTickUnit57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(font59);
//        org.junit.Assert.assertNotNull(paint61);
//        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 32.0f + "'", float64 == 32.0f);
//        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.05d + "'", double69 == 0.05d);
//        org.junit.Assert.assertNotNull(categoryAxisArray70);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.setID("ClassContext");
        java.lang.Object obj13 = null;
        columnArrangement9.add((org.jfree.chart.block.Block) textTitle10, obj13);
        boolean boolean15 = textAnchor4.equals((java.lang.Object) textTitle10);
        textLine0.draw(graphics2D1, (float) '4', (float) (short) 10, textAnchor4, (float) (short) -1, (float) 0L, 0.0d);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("VerticalAlignment.CENTER");
        textLine0.removeFragment(textFragment21);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor9 = itemLabelPosition8.getTextAnchor();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        numberAxis1.setAutoRange(true);
        boolean boolean11 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//        numberAxis1.setVisible(true);
//        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
//        org.jfree.chart.axis.Axis axis5 = axisChangeEvent4.getAxis();
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
//        categoryPlot6.setDomainAxisLocation(15, axisLocation8, true);
//        categoryPlot6.clearRangeAxes();
//        categoryPlot6.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo14 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str15 = projectInfo14.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray16 = projectInfo14.getLibraries();
//        java.lang.String str17 = projectInfo14.getLicenceText();
//        java.awt.Image image18 = projectInfo14.getLogo();
//        categoryPlot6.setBackgroundImage(image18);
//        java.awt.Paint paint20 = categoryPlot6.getDomainGridlinePaint();
//        axis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
//        org.junit.Assert.assertNotNull(axis5);
//        org.junit.Assert.assertNotNull(projectInfo14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3" + "'", str17.equals("3"));
//        org.junit.Assert.assertNotNull(image18);
//        org.junit.Assert.assertNotNull(paint20);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        java.awt.Paint paint5 = statisticalBarRenderer0.lookupSeriesFillPaint(0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(192, categoryURLGenerator7, false);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle0.setFont(font1);
        textTitle0.setHeight((double) (short) -1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textBlock6.calculateDimensions(graphics2D7);
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("ClassContext", font11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str14 = color13.toString();
        boolean boolean16 = color13.equals((java.lang.Object) 'a');
        textBlock6.addLine("java.awt.Color[r=192,g=0,b=0]", font11, (java.awt.Paint) color13);
        textTitle0.setFont(font11);
        double double19 = textTitle0.getHeight();
        java.awt.Paint paint20 = textTitle0.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle0.getMargin();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str14.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        java.awt.Shape shape19 = statisticalBarRenderer14.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        statisticalBarRenderer14.setGradientPaintTransformer(gradientPaintTransformer20);
        int int22 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double26 = categoryAxis23.getLabelAngle();
        java.lang.String str28 = categoryAxis23.getCategoryLabelToolTip((java.lang.Comparable) 100);
        java.util.List list29 = categoryPlot0.getCategoriesForAxis(categoryAxis23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke31 = statisticalBarRenderer30.getBaseStroke();
        java.awt.Paint paint33 = statisticalBarRenderer30.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke34 = statisticalBarRenderer30.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        statisticalBarRenderer30.setSeriesNegativeItemLabelPosition(255, itemLabelPosition36);
        boolean boolean38 = statisticalBarRenderer30.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator40 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer30.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator40);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation45 = null;
        categoryPlot43.setDomainAxisLocation(15, axisLocation45, true);
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = categoryPlot43.getDomainMarkers(layer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = categoryPlot43.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot43);
        java.lang.Object obj52 = jFreeChart51.clone();
        jFreeChart51.setBackgroundImageAlignment((-4194304));
        java.awt.Paint paint55 = jFreeChart51.getBorderPaint();
        statisticalBarRenderer30.setBaseFillPaint(paint55);
        java.awt.Paint paint58 = null;
        statisticalBarRenderer30.setSeriesFillPaint((int) (byte) 10, paint58);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent61 = null;
        categoryPlot0.markerChanged(markerChangeEvent61);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNull(categoryAxis50);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = legendItemEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        legendItemEntity9.setSeriesKey((java.lang.Comparable) "");
        java.lang.Object obj15 = legendItemEntity9.clone();
        java.lang.String str16 = legendItemEntity9.getToolTipText();
        java.lang.Object obj17 = legendItemEntity9.clone();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        java.awt.Paint paint13 = jFreeChart9.getBorderPaint();
        int int14 = jFreeChart9.getSubtitleCount();
        boolean boolean16 = jFreeChart9.equals((java.lang.Object) 0.3d);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double12 = rectangleInsets8.extendHeight((double) 100.0f);
        double double14 = rectangleInsets8.calculateTopOutset((double) 'a');
        java.awt.Font font16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ClassContext", font16);
        labelBlock17.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        boolean boolean21 = labelBlock17.equals((java.lang.Object) textTitle20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets8.createOutsetRectangle(rectangle2D22);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        java.awt.Paint paint30 = statisticalBarRenderer27.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke31 = statisticalBarRenderer27.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        statisticalBarRenderer27.setSeriesNegativeItemLabelPosition(255, itemLabelPosition33);
        boolean boolean35 = statisticalBarRenderer27.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = null;
        statisticalBarRenderer27.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator37, false);
        boolean boolean40 = defaultStatisticalCategoryDataset26.equals((java.lang.Object) statisticalBarRenderer27);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity44 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D22, "TextAnchor.CENTER_RIGHT", "TextBlockAnchor.TOP_LEFT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26, (java.lang.Comparable) 1, (java.lang.Comparable) numberTickUnit43);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit47 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str48 = numberTickUnit47.toString();
        defaultStatisticalCategoryDataset26.add(0.0d, (double) 0.95f, (java.lang.Comparable) numberTickUnit47, (java.lang.Comparable) "ItemLabelAnchor.OUTSIDE3");
        try {
            java.lang.Number number53 = defaultStatisticalCategoryDataset26.getStdDevValue(3, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(numberTickUnit47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "[size=1]" + "'", str48.equals("[size=1]"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        categoryPlot1.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot1.getRendererForDataset(categoryDataset7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot1.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setTickMarkOutsideLength((float) (short) 100);
        numberAxis11.setLabelAngle((double) '4');
        org.jfree.data.Range range16 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis11);
        java.text.NumberFormat numberFormat17 = null;
        numberAxis11.setNumberFormatOverride(numberFormat17);
        java.awt.Shape shape19 = numberAxis11.getRightArrow();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) "RectangleEdge.RIGHT", shape19, "JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]", "AxisLocation.BOTTOM_OR_LEFT");
        java.lang.String str23 = categoryLabelEntity22.toString();
        categoryLabelEntity22.setToolTipText("UnitType.RELATIVE");
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "CategoryLabelEntity: category=RectangleEdge.RIGHT, tooltip=JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0], url=AxisLocation.BOTTOM_OR_LEFT" + "'", str23.equals("CategoryLabelEntity: category=RectangleEdge.RIGHT, tooltip=JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0], url=AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.TickUnit tickUnit1 = null;
        try {
            tickUnits0.add(tickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'unit' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.awt.Stroke stroke9 = legendItem8.getLineStroke();
        int int10 = legendItem8.getDatasetIndex();
        java.lang.String str11 = legendItem8.getDescription();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 15);
        axisState1.cursorUp((double) 15);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        int int5 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getRangeAxisEdge();
        java.awt.Paint paint7 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo13, point2D14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis16.setTickLabelsVisible(true);
        java.util.List list21 = categoryPlot4.getCategoriesForAxis(categoryAxis16);
        axisState1.setTicks(list21);
        java.util.List list23 = axisState1.getTicks();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        numberAxis1.resizeRange((-1.0d));
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setUpperMargin(0.2d);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape15, (java.awt.Paint) color16);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity20 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape15, "", "ChartChangeEventType.GENERAL");
        org.jfree.data.Range range21 = numberAxis1.getRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int1 = color0.getGreen();
        java.awt.Color color2 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "JFreeChart", "hi!", "ClassContext");
        basicProjectInfo4.setVersion("{0}");
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double4 = categoryAxis1.getLabelAngle();
        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 100);
        boolean boolean7 = categoryAxis1.isVisible();
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("hi!", font9, (java.awt.Paint) color10);
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color10);
        org.jfree.data.KeyedObject keyedObject13 = new org.jfree.data.KeyedObject((java.lang.Comparable) 1L, (java.lang.Object) categoryAxis1);
        double double14 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        double double5 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot1.getRangeAxisEdge();
        categoryPlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        int int10 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6);
        java.awt.Stroke stroke12 = statisticalBarRenderer6.lookupSeriesStroke(1);
        boolean boolean13 = keyedObjects2D0.equals((java.lang.Object) stroke12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean16 = numberAxis15.isNegativeArrowVisible();
        double double17 = numberAxis15.getAutoRangeMinimumSize();
        org.jfree.data.Range range19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range19);
        double double21 = rectangleConstraint20.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint20.toUnconstrainedWidth();
        org.jfree.data.Range range23 = rectangleConstraint20.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis25.setVisible(true);
        numberAxis25.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range31 = numberAxis25.getRange();
        double double32 = range31.getLength();
        org.jfree.data.Range range35 = org.jfree.data.Range.expand(range31, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint20.toRangeWidth(range35);
        numberAxis15.setRange(range35, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot40.setDomainAxisLocation(15, axisLocation42, true);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        textTitle45.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = textTitle45.getMargin();
        categoryPlot40.setInsets(rectangleInsets48, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryPlot40.getInsets();
        numberAxis15.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot40);
        keyedObjects2D0.addObject((java.lang.Object) numberAxis15, (java.lang.Comparable) 11.0d, (java.lang.Comparable) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis56.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double59 = categoryAxis56.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit60 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int61 = numberTickUnit60.getMinorTickCount();
        java.awt.Font font62 = categoryAxis56.getTickLabelFont((java.lang.Comparable) numberTickUnit60);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer64 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator65 = null;
        statisticalBarRenderer64.setBaseToolTipGenerator(categoryToolTipGenerator65, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition69 = null;
        statisticalBarRenderer64.setSeriesNegativeItemLabelPosition(10, itemLabelPosition69);
        java.awt.Shape shape77 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color78 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem79 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape77, (java.awt.Paint) color78);
        statisticalBarRenderer64.setBaseItemLabelPaint((java.awt.Paint) color78);
        categoryAxis56.setTickLabelPaint((java.lang.Comparable) 100L, (java.awt.Paint) color78);
        keyedObjects2D0.addObject((java.lang.Object) color78, (java.lang.Comparable) Double.NaN, (java.lang.Comparable) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0E-8d + "'", double17 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 11.0d + "'", double32 == 11.0d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(color78);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke5 = statisticalBarRenderer4.getBaseStroke();
        statisticalBarRenderer0.setBaseStroke(stroke5, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke9 = statisticalBarRenderer8.getBaseStroke();
        java.awt.Paint paint11 = statisticalBarRenderer8.getSeriesOutlinePaint((-1));
        boolean boolean12 = statisticalBarRenderer8.getAutoPopulateSeriesOutlineStroke();
        boolean boolean13 = statisticalBarRenderer8.getBaseSeriesVisible();
        statisticalBarRenderer8.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis19.setPositiveArrowVisible(true);
        numberAxis19.setFixedAutoRange((double) (short) 0);
        numberAxis19.setRangeWithMargins((double) 0, (double) '#');
        numberAxis19.setAutoRange(false);
        java.awt.Font font30 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("ClassContext", font30);
        labelBlock31.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        boolean boolean35 = labelBlock31.equals((java.lang.Object) textTitle34);
        java.awt.geom.Rectangle2D rectangle2D36 = textTitle34.getBounds();
        statisticalBarRenderer8.drawRangeGridline(graphics2D16, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis19, rectangle2D36, (double) (-16711681));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke40 = statisticalBarRenderer39.getBaseStroke();
        java.awt.Paint paint42 = statisticalBarRenderer39.getSeriesOutlinePaint((-1));
        java.awt.Shape shape44 = statisticalBarRenderer39.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer45 = null;
        statisticalBarRenderer39.setGradientPaintTransformer(gradientPaintTransformer45);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke49 = statisticalBarRenderer48.getBaseStroke();
        java.awt.Paint paint51 = statisticalBarRenderer48.getSeriesOutlinePaint((-1));
        boolean boolean52 = statisticalBarRenderer48.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = statisticalBarRenderer48.getPositiveItemLabelPosition(0, 15);
        statisticalBarRenderer39.setSeriesPositiveItemLabelPosition(0, itemLabelPosition55, true);
        statisticalBarRenderer8.setNegativeItemLabelPositionFallback(itemLabelPosition55);
        statisticalBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition55);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNull(shape44);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition55);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        boolean boolean31 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Paint paint32 = statisticalBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        int int34 = categoryPlot33.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot33.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent36 = null;
        categoryPlot33.rendererChanged(rendererChangeEvent36);
        java.awt.Paint paint38 = categoryPlot33.getRangeCrosshairPaint();
        statisticalBarRenderer0.setBaseFillPaint(paint38, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (-1L));
        double double6 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator10, false);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        statisticalBarRenderer5.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer5.setAutoPopulateSeriesOutlinePaint(false);
        boolean boolean11 = statisticalBarRenderer5.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = statisticalBarRenderer5.getBaseItemLabelGenerator();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list19 = defaultStatisticalCategoryDataset18.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity22 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        java.lang.Comparable comparable23 = categoryItemEntity22.getRowKey();
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryItemEntity22.getDataset();
        org.jfree.data.Range range25 = statisticalBarRenderer5.findRangeBounds(categoryDataset24);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset24, false);
        org.jfree.data.Range range28 = statisticalBarRenderer0.findRangeBounds(categoryDataset24);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", comparable23.equals("ItemLabelAnchor.INSIDE7"));
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(range28);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        boolean boolean3 = numberAxis1.equals((java.lang.Object) '#');
        float float4 = numberAxis1.getTickMarkOutsideLength();
        boolean boolean5 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        boolean boolean8 = categoryPlot0.isSubplot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        org.jfree.chart.text.TextAnchor textAnchor14 = categoryLabelPosition13.getRotationAnchor();
        boolean boolean15 = sortOrder10.equals((java.lang.Object) textAnchor14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        boolean boolean3 = numberAxis1.equals((java.lang.Object) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        int int5 = categoryPlot4.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot4.getRangeAxisEdge();
        java.awt.Paint paint7 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo13, point2D14);
        boolean boolean16 = categoryPlot4.isDomainZoomable();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Font font19 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("ClassContext", font19);
        labelBlock20.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle();
        boolean boolean24 = labelBlock20.equals((java.lang.Object) textTitle23);
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle23.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        boolean boolean28 = categoryPlot4.render(graphics2D17, rectangle2D25, (int) (byte) 100, plotRenderingInfo27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot4.getRenderer((int) ' ');
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categoryItemRenderer30);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape13 = textBlock5.calculateBounds(graphics2D6, 0.0f, (float) (-1), textBlockAnchor9, 0.0f, (float) 10, (double) 10);
        numberAxis4.setLeftArrow(shape13);
        java.text.NumberFormat numberFormat15 = numberAxis4.getNumberFormatOverride();
        numberAxis4.setTickMarksVisible(false);
        boolean boolean18 = categoryPlot0.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double3 = categoryAxis0.getLabelAngle();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        int int7 = categoryPlot6.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot8.setDomainAxisLocation(15, axisLocation10, true);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle13.getMargin();
        categoryPlot8.setInsets(rectangleInsets16, false);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot8);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        textTitle21.setID("ClassContext");
        textTitle21.setHeight((double) 0);
        double double26 = textTitle21.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = textTitle21.getPosition();
        boolean boolean28 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace30 = categoryAxis0.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot6, rectangle2D20, rectangleEdge27, axisSpace29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color7);
        int int9 = color7.getAlpha();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double4 = categoryAxis1.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int6 = numberTickUnit5.getMinorTickCount();
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) numberTickUnit5);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("LengthConstraintType.NONE", font7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        statisticalBarRenderer0.notifyListeners(rendererChangeEvent6);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke9 = statisticalBarRenderer8.getBaseStroke();
        java.awt.Paint paint11 = statisticalBarRenderer8.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke13 = statisticalBarRenderer12.getBaseStroke();
        statisticalBarRenderer8.setBaseStroke(stroke13, false);
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke13);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0L, 1, (short) 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0L, 1, (short) 0 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0L, 1, (short) 0 };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 0L, 1, (short) 0 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0L, 1, (short) 0 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0L, 1, (short) 0 };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13, numberArray17, numberArray21, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "LengthConstraintType.FIXED", numberArray26);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis2.setVisible(true);
        numberAxis2.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range8 = numberAxis2.getRange();
        double double9 = range8.getLength();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range8, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) (-16711681), range12);
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray18, numberArray21, numberArray24, numberArray27, numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset35);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset35, 0.0d);
        org.jfree.data.Range range39 = org.jfree.data.Range.combine(range12, range38);
        java.lang.Object obj40 = null;
        boolean boolean41 = range38.equals(obj40);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 11.0d + "'", double9 == 11.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.3d + "'", number36.equals(0.3d));
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        double double3 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range5);
        double double7 = rectangleConstraint6.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.data.Range range9 = rectangleConstraint6.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setVisible(true);
        numberAxis11.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range17 = numberAxis11.getRange();
        double double18 = range17.getLength();
        org.jfree.data.Range range21 = org.jfree.data.Range.expand(range17, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint6.toRangeWidth(range21);
        numberAxis1.setRange(range21, false, true);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        textTitle26.setURLText("hi!");
        boolean boolean29 = textTitle26.getExpandToFitSpace();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle26.getBounds();
        numberAxis1.setRightArrow((java.awt.Shape) rectangle2D30);
        boolean boolean32 = numberAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 11.0d + "'", double18 == 11.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        booleanList0.clear();
        java.lang.Boolean boolean4 = booleanList0.getBoolean((int) (short) 1);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = legendTitle19.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle19.getLegendItemGraphicEdge();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis5.setVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis5);
        categoryPlot0.axisChanged(axisChangeEvent8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot0.getRenderer(3);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("VerticalAlignment.CENTER");
        float float2 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape10 = textBlock2.calculateBounds(graphics2D3, 0.0f, (float) (-1), textBlockAnchor6, 0.0f, (float) 10, (double) 10);
        numberAxis1.setLeftArrow(shape10);
        java.text.NumberFormat numberFormat12 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(numberFormat12);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesPaint(false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        textTitle4.setURLText("hi!");
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle4.getPosition();
        boolean boolean8 = unitType3.equals((java.lang.Object) rectangleEdge7);
        boolean boolean9 = defaultDrawingSupplier0.equals((java.lang.Object) unitType3);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        int int11 = categoryPlot10.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot10.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent13);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot18.setDomainAxisLocation(15, axisLocation20, true);
        categoryPlot18.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot18.getRendererForDataset(categoryDataset24);
        java.awt.Stroke stroke26 = categoryPlot18.getOutlineStroke();
        valueMarker17.setStroke(stroke26);
        valueMarker17.setLabel("ThreadContext");
        java.awt.Paint paint30 = null;
        valueMarker17.setOutlinePaint(paint30);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot10.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker17, layer32);
        boolean boolean34 = defaultDrawingSupplier0.equals((java.lang.Object) layer32);
        java.awt.Paint paint35 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Stroke stroke36 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1L), (double) (-4194304), (double) (-16711681), 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double12 = rectangleInsets8.extendHeight((double) 100.0f);
        double double14 = rectangleInsets8.calculateTopOutset((double) 'a');
        java.awt.Font font16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ClassContext", font16);
        labelBlock17.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        boolean boolean21 = labelBlock17.equals((java.lang.Object) textTitle20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets8.createOutsetRectangle(rectangle2D22);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke28 = statisticalBarRenderer27.getBaseStroke();
        java.awt.Paint paint30 = statisticalBarRenderer27.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke31 = statisticalBarRenderer27.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        statisticalBarRenderer27.setSeriesNegativeItemLabelPosition(255, itemLabelPosition33);
        boolean boolean35 = statisticalBarRenderer27.getBaseItemLabelsVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = null;
        statisticalBarRenderer27.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator37, false);
        boolean boolean40 = defaultStatisticalCategoryDataset26.equals((java.lang.Object) statisticalBarRenderer27);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity44 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D22, "TextAnchor.CENTER_RIGHT", "TextBlockAnchor.TOP_LEFT", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset26, (java.lang.Comparable) 1, (java.lang.Comparable) numberTickUnit43);
        org.jfree.data.general.DatasetGroup datasetGroup45 = defaultStatisticalCategoryDataset26.getGroup();
        java.lang.String str46 = datasetGroup45.getID();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(datasetGroup45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "NOID" + "'", str46.equals("NOID"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.event.ChartChangeListener chartChangeListener20 = null;
        try {
            jFreeChart9.addChangeListener(chartChangeListener20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle0.setFont(font1);
        textTitle0.setHeight((double) (short) -1);
        java.lang.String str5 = textTitle0.getToolTipText();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = textTitle0.getPosition();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer3.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer3.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        objectList1.set(3, (java.lang.Object) statisticalBarRenderer3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis3.setTickLabelsVisible(true);
        boolean boolean8 = legendItemCollection1.equals((java.lang.Object) categoryAxis3);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape15, (java.awt.Paint) color16);
        java.awt.Stroke stroke18 = legendItem17.getLineStroke();
        legendItemCollection1.add(legendItem17);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color27 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape26, (java.awt.Paint) color27);
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray42 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray49 = new java.lang.Number[][] { numberArray33, numberArray36, numberArray39, numberArray42, numberArray45, numberArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray49);
        java.lang.Number number51 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset50);
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset50, 0.0d);
        legendItem28.setDataset((org.jfree.data.general.Dataset) categoryDataset50);
        java.awt.Stroke stroke55 = legendItem28.getOutlineStroke();
        java.awt.Paint paint56 = legendItem28.getOutlinePaint();
        legendItemCollection1.add(legendItem28);
        legendItem28.setSeriesIndex(0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 0.3d + "'", number51.equals(0.3d));
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator1, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition5);
        java.awt.Stroke stroke8 = statisticalBarRenderer0.lookupSeriesOutlineStroke((int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = statisticalBarRenderer0.getBaseURLGenerator();
        statisticalBarRenderer0.setMinimumBarLength((double) (short) 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(categoryURLGenerator9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        jFreeChart9.setBackgroundImageAlpha(0.5f);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        jFreeChart9.setBorderStroke(stroke13);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart9.getLegend();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(legendTitle15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot11.setDomainAxisLocation(15, axisLocation13, true);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot11.getDomainMarkers(layer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot11.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot11);
        categoryPlot0.notifyListeners(plotChangeEvent20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset27 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list28 = defaultStatisticalCategoryDataset27.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity31 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset27, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        java.lang.Comparable comparable32 = categoryItemEntity31.getRowKey();
        categoryItemEntity31.setColumnKey((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.category.CategoryDataset categoryDataset35 = categoryItemEntity31.getDataset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot0.getRendererForDataset(categoryDataset35);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", comparable32.equals("ItemLabelAnchor.INSIDE7"));
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertNull(categoryItemRenderer36);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement11 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer5, (org.jfree.chart.block.Arrangement) columnArrangement10, (org.jfree.chart.block.Arrangement) centerArrangement11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setID("ClassContext");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent16 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle13);
        org.jfree.chart.title.Title title17 = titleChangeEvent16.getTitle();
        org.jfree.chart.title.Title title18 = titleChangeEvent16.getTitle();
        org.jfree.chart.block.BlockFrame blockFrame19 = title18.getFrame();
        legendTitle12.setFrame(blockFrame19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle12.getLegendItemGraphicLocation();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(title17);
        org.junit.Assert.assertNotNull(title18);
        org.junit.Assert.assertNotNull(blockFrame19);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10, numberArray13, numberArray16, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray20);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset21);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.3d + "'", number22.equals(0.3d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        double double3 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        double double5 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test146");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo3.setLicenceName("");
//        org.jfree.chart.ui.Library[] libraryArray6 = projectInfo3.getLibraries();
//        projectInfo3.setVersion("ClassContext");
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
//        java.lang.String str10 = projectInfo3.getLicenceName();
//        projectInfo3.setName("[size=1]");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray2);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertNotNull(libraryArray6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setToolTipText("");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) labelBlock2);
        java.lang.String str8 = labelBlock2.getURLText();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot9.setDomainAxisLocation(15, axisLocation11, true);
        categoryPlot9.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot9.getRendererForDataset(categoryDataset15);
        java.awt.Stroke stroke17 = categoryPlot9.getOutlineStroke();
        boolean boolean18 = labelBlock2.equals((java.lang.Object) stroke17);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        double double9 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-8d + "'", double9 == 1.0E-8d);
        org.junit.Assert.assertNull(markerAxisBand10);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
//        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
//        org.jfree.chart.util.Layer layer5 = null;
//        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis();
//        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
//        int int12 = categoryPlot11.getWeight();
//        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
//        categoryPlot11.rendererChanged(rendererChangeEvent14);
//        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
//        categoryPlot19.setDomainAxisLocation(15, axisLocation21, true);
//        categoryPlot19.clearRangeAxes();
//        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot19.getRendererForDataset(categoryDataset25);
//        java.awt.Stroke stroke27 = categoryPlot19.getOutlineStroke();
//        valueMarker18.setStroke(stroke27);
//        valueMarker18.setLabel("ThreadContext");
//        java.awt.Paint paint31 = null;
//        valueMarker18.setOutlinePaint(paint31);
//        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
//        categoryPlot11.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker18, layer33);
//        categoryPlot0.addRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker10, layer33);
//        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
//        categoryPlot36.setDomainAxisLocation(15, axisLocation38, true);
//        categoryPlot36.clearRangeAxes();
//        categoryPlot36.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo44 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str45 = projectInfo44.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray46 = projectInfo44.getLibraries();
//        java.lang.String str47 = projectInfo44.getLicenceText();
//        java.awt.Image image48 = projectInfo44.getLogo();
//        categoryPlot36.setBackgroundImage(image48);
//        categoryPlot0.setBackgroundImage(image48);
//        org.junit.Assert.assertNull(collection6);
//        org.junit.Assert.assertNull(categoryAxis7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(rectangleEdge13);
//        org.junit.Assert.assertNull(categoryItemRenderer26);
//        org.junit.Assert.assertNotNull(stroke27);
//        org.junit.Assert.assertNotNull(layer33);
//        org.junit.Assert.assertNotNull(projectInfo44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "3" + "'", str47.equals("3"));
//        org.junit.Assert.assertNotNull(image48);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double4 = categoryAxis1.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int6 = numberTickUnit5.getMinorTickCount();
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) numberTickUnit5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        statisticalBarRenderer9.setBaseToolTipGenerator(categoryToolTipGenerator10, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        statisticalBarRenderer9.setSeriesNegativeItemLabelPosition(10, itemLabelPosition14);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color23 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape22, (java.awt.Paint) color23);
        statisticalBarRenderer9.setBaseItemLabelPaint((java.awt.Paint) color23);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 100L, (java.awt.Paint) color23);
        java.awt.Color color27 = java.awt.Color.getColor("3", color23);
        java.awt.Color color28 = color23.darker();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX(21.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray13, numberArray16, numberArray19, numberArray22, numberArray25, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray29);
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset30, 0.0d);
        legendItem8.setDataset((org.jfree.data.general.Dataset) categoryDataset30);
        java.awt.Stroke stroke35 = legendItem8.getOutlineStroke();
        java.awt.Paint paint36 = legendItem8.getOutlinePaint();
        legendItem8.setSeriesKey((java.lang.Comparable) "JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]");
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.3d + "'", number31.equals(0.3d));
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = jFreeChart9.getPadding();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape9 = numberAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.0E-8d, "PlotOrientation.VERTICAL", textAnchor2, textAnchor3, (double) ' ');
        org.jfree.chart.text.TextAnchor textAnchor6 = numberTick5.getTextAnchor();
        org.jfree.chart.axis.TickType tickType7 = numberTick5.getTickType();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick5.getRotationAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(tickType7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        statisticalBarRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke5 = statisticalBarRenderer4.getBaseStroke();
        statisticalBarRenderer0.setBaseStroke(stroke5, false);
        boolean boolean8 = statisticalBarRenderer0.getAutoPopulateSeriesFillPaint();
        statisticalBarRenderer0.setSeriesVisible(2, (java.lang.Boolean) true, true);
        int int13 = statisticalBarRenderer0.getColumnCount();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke2 = statisticalBarRenderer1.getBaseStroke();
        java.awt.Paint paint4 = statisticalBarRenderer1.getSeriesOutlinePaint((-1));
        boolean boolean5 = statisticalBarRenderer1.getAutoPopulateSeriesOutlineStroke();
        boolean boolean6 = statisticalBarRenderer1.getBaseSeriesVisible();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer1.setSeriesItemLabelPaint(0, (java.awt.Paint) color8);
        java.awt.Color color10 = java.awt.Color.CYAN;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setDomainAxisLocation(15, axisLocation15, true);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot13.getDomainMarkers(layer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot13.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot13);
        java.lang.Object obj22 = jFreeChart21.clone();
        org.jfree.chart.plot.Plot plot23 = jFreeChart21.getPlot();
        java.awt.Stroke stroke24 = jFreeChart21.getBorderStroke();
        org.jfree.chart.text.TextBlock textBlock25 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = textBlock25.calculateDimensions(graphics2D26);
        java.awt.Font font30 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("ClassContext", font30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str33 = color32.toString();
        boolean boolean35 = color32.equals((java.lang.Object) 'a');
        textBlock25.addLine("java.awt.Color[r=192,g=0,b=0]", font30, (java.awt.Paint) color32);
        jFreeChart21.setBorderPaint((java.awt.Paint) color32);
        java.awt.Color color38 = java.awt.Color.darkGray;
        float[] floatArray45 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray46 = color38.getRGBColorComponents(floatArray45);
        float[] floatArray47 = color32.getRGBColorComponents(floatArray46);
        float[] floatArray48 = color8.getComponents(colorSpace11, floatArray46);
        float[] floatArray49 = color0.getColorComponents(floatArray48);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(plot23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str33.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape10 = textBlock2.calculateBounds(graphics2D3, 0.0f, (float) (-1), textBlockAnchor6, 0.0f, (float) 10, (double) 10);
        numberAxis1.setLeftArrow(shape10);
        float float12 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.awt.Stroke stroke9 = legendItem8.getLineStroke();
        java.lang.Comparable comparable10 = legendItem8.getSeriesKey();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray15, numberArray18, numberArray21, numberArray24, numberArray27, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray31);
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset32);
        legendItem8.setDataset((org.jfree.data.general.Dataset) categoryDataset32);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset32);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 0.0d + "'", number33.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 0.3d + "'", number35.equals(0.3d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis10.setTickMarkOutsideLength((float) (short) 100);
        numberAxis10.setLabelAngle((double) '4');
        org.jfree.data.Range range15 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str17 = datasetRenderingOrder16.toString();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder16);
        java.lang.String str19 = datasetRenderingOrder16.toString();
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str17.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str19.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setToolTipText("");
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("RectangleEdge.RIGHT");
        java.awt.Font font10 = categoryAxis8.getTickLabelFont((java.lang.Comparable) "RectangleEdge.RIGHT");
        labelBlock2.setFont(font10);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font14);
        labelBlock2.setFont(font14);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.Font font28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("ClassContext", font28);
        labelBlock29.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        boolean boolean33 = labelBlock29.equals((java.lang.Object) textTitle32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle32.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        int int36 = categoryPlot35.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot35.getRangeAxisEdge();
        java.awt.Paint paint38 = categoryPlot35.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot35.getRangeAxisEdge();
        java.util.List list40 = categoryAxis19.refreshTicks(graphics2D25, axisState26, rectangle2D34, rectangleEdge39);
        try {
            labelBlock2.draw(graphics2D18, rectangle2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(list40);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("hi!", font2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = null;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer9 = new org.jfree.chart.text.G2TextMeasurer(graphics2D8);
        try {
            org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("org.jfree.chart.event.ChartProgressEvent[source=ClassContext]", font2, paint5, (float) 100, 192, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        double double3 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range5);
        double double7 = rectangleConstraint6.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toUnconstrainedWidth();
        org.jfree.data.Range range9 = rectangleConstraint6.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setVisible(true);
        numberAxis11.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range17 = numberAxis11.getRange();
        double double18 = range17.getLength();
        org.jfree.data.Range range21 = org.jfree.data.Range.expand(range17, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint6.toRangeWidth(range21);
        numberAxis1.setRange(range21, false, true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = numberAxis1.getTickUnit();
        numberAxis1.setTickMarkInsideLength((float) (byte) 100);
        numberAxis1.setLabel("");
        java.lang.Class<?> wildcardClass31 = numberAxis1.getClass();
        numberAxis1.configure();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 11.0d + "'", double18 == 11.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(numberTickUnit26);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        boolean boolean31 = numberAxis11.isTickMarksVisible();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean36 = numberAxis35.isVerticalTickLabels();
        org.jfree.data.Range range37 = numberAxis35.getRange();
        org.jfree.data.Range range40 = org.jfree.data.Range.shift(range37, (double) 10.0f, false);
        org.jfree.data.Range range43 = org.jfree.data.Range.shift(range40, (double) (-4194304), false);
        numberAxis11.setRange(range43, false, true);
        boolean boolean47 = numberAxis11.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = numberAxis11.getMarkerBand();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(markerAxisBand48);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) '#', (int) (short) 10, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        float float9 = categoryAxis8.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis8.getCategoryJava2DCoordinate(categoryAnchor10, (int) '#', (int) (short) 10, rectangle2D13, rectangleEdge14);
        java.awt.Paint paint16 = categoryAxis8.getTickLabelPaint();
        categoryAxis0.setAxisLinePaint(paint16);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis1.getLabelInsets();
        numberAxis1.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke5 = statisticalBarRenderer0.getBaseOutlineStroke();
        boolean boolean6 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean8 = statisticalBarRenderer0.getIncludeBaseInRange();
        double double9 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        java.awt.Paint paint14 = categoryPlot11.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot11.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot11.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation23);
        boolean boolean25 = legendItemEntity9.equals((java.lang.Object) rectangleEdge24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot26.setDomainAxisLocation(15, axisLocation28, true);
        categoryPlot26.clearRangeAxes();
        categoryPlot26.setAnchorValue((double) (short) 0);
        categoryPlot26.setWeight((int) (byte) 10);
        categoryPlot26.setRangeCrosshairVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset39 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list40 = defaultStatisticalCategoryDataset39.getColumnKeys();
        categoryPlot26.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset39);
        legendItemEntity9.setDataset((org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset39);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset39, false);
        try {
            java.lang.Comparable comparable46 = defaultStatisticalCategoryDataset39.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNull(range44);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke5 = statisticalBarRenderer0.getBaseOutlineStroke();
        boolean boolean6 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean8 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke10 = statisticalBarRenderer9.getBaseStroke();
        java.awt.Paint paint12 = statisticalBarRenderer9.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke13 = statisticalBarRenderer9.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalBarRenderer9.setSeriesNegativeItemLabelPosition(255, itemLabelPosition15);
        boolean boolean17 = statisticalBarRenderer9.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer9.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        statisticalBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        statisticalBarRenderer0.setSeriesVisible(0, (java.lang.Boolean) false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        int int27 = categoryPlot26.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot26.getRangeAxisEdge();
        java.awt.Paint paint29 = categoryPlot26.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot26.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot26.getDomainAxisEdge(0);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot36.setDomainAxisLocation(15, axisLocation38, true);
        categoryPlot36.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = categoryPlot36.getRendererForDataset(categoryDataset42);
        java.awt.Stroke stroke44 = categoryPlot36.getOutlineStroke();
        valueMarker35.setStroke(stroke44);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot26.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker35, layer46);
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation25, layer46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNull(categoryItemRenderer43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(layer46);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot1.getRangeAxisEdge();
        categoryPlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        int int10 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6);
        java.awt.Stroke stroke12 = statisticalBarRenderer6.lookupSeriesStroke(1);
        boolean boolean13 = keyedObjects2D0.equals((java.lang.Object) stroke12);
        keyedObjects2D0.removeColumn((java.lang.Comparable) "ItemLabelAnchor.INSIDE7");
        int int16 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = statisticalBarRenderer0.getSeriesURLGenerator(255);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle5.setFont(font6);
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font6);
        float float9 = textFragment8.getBaselineOffset();
        java.awt.Font font10 = textFragment8.getFont();
        java.awt.Font font11 = textFragment8.getFont();
        statisticalBarRenderer0.setSeriesItemLabelFont((int) 'a', font11, true);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list20 = defaultStatisticalCategoryDataset19.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity23 = new org.jfree.chart.entity.CategoryItemEntity(shape16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset19, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        java.lang.Comparable comparable24 = categoryItemEntity23.getRowKey();
        categoryItemEntity23.setColumnKey((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.category.CategoryDataset categoryDataset27 = categoryItemEntity23.getDataset();
        org.jfree.data.Range range28 = statisticalBarRenderer0.findRangeBounds(categoryDataset27);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", comparable24.equals("ItemLabelAnchor.INSIDE7"));
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNull(range28);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot1.getRangeAxisEdge();
        categoryPlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        int int10 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6);
        java.awt.Stroke stroke12 = statisticalBarRenderer6.lookupSeriesStroke(1);
        boolean boolean13 = keyedObjects2D0.equals((java.lang.Object) stroke12);
        keyedObjects2D0.removeColumn((java.lang.Comparable) "ItemLabelAnchor.INSIDE7");
        try {
            java.lang.Comparable comparable17 = keyedObjects2D0.getRowKey((-16711681));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        int int2 = categoryPlot1.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot1.getRangeAxisEdge();
        categoryPlot1.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        int int10 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6);
        java.awt.Stroke stroke12 = statisticalBarRenderer6.lookupSeriesStroke(1);
        boolean boolean13 = keyedObjects2D0.equals((java.lang.Object) stroke12);
        java.lang.Object obj14 = keyedObjects2D0.clone();
        try {
            java.lang.Object obj17 = keyedObjects2D0.getObject((int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test178");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
//        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
//        categoryPlot0.clearRangeAxes();
//        categoryPlot0.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str9 = projectInfo8.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getLibraries();
//        java.lang.String str11 = projectInfo8.getLicenceText();
//        java.awt.Image image12 = projectInfo8.getLogo();
//        categoryPlot0.setBackgroundImage(image12);
//        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker15);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = valueMarker15.getLabelAnchor();
//        java.awt.Paint paint18 = valueMarker15.getOutlinePaint();
//        org.junit.Assert.assertNotNull(projectInfo8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3" + "'", str11.equals("3"));
//        org.junit.Assert.assertNotNull(image12);
//        org.junit.Assert.assertNotNull(rectangleAnchor17);
//        org.junit.Assert.assertNotNull(paint18);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = valueMarker1.getLabelOffset();
        double double16 = rectangleInsets14.calculateLeftOutset(3.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot17.setDomainAxisLocation(15, axisLocation19, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke24 = statisticalBarRenderer23.getBaseStroke();
        java.awt.Paint paint26 = statisticalBarRenderer23.getSeriesOutlinePaint((-1));
        boolean boolean27 = statisticalBarRenderer23.getAutoPopulateSeriesOutlineStroke();
        categoryPlot17.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23, true);
        java.awt.Shape shape31 = statisticalBarRenderer23.lookupSeriesShape((int) 'a');
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot32.setDomainAxisLocation(15, axisLocation34, true);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle();
        textTitle37.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle37.getMargin();
        categoryPlot32.setInsets(rectangleInsets40, false);
        double double44 = rectangleInsets40.extendHeight((double) 100.0f);
        java.lang.String str45 = rectangleInsets40.toString();
        java.awt.Font font47 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("ClassContext", font47);
        labelBlock48.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        boolean boolean52 = labelBlock48.equals((java.lang.Object) textTitle51);
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle51.getBounds();
        rectangleInsets40.trim(rectangle2D53);
        boolean boolean55 = org.jfree.chart.util.ShapeUtilities.equal(shape31, (java.awt.Shape) rectangle2D53);
        rectangleInsets14.trim(rectangle2D53);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.0d + "'", double44 == 100.0d);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str45.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Object obj2 = defaultStatisticalCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor8);
        org.jfree.chart.text.TextAnchor textAnchor10 = categoryLabelPosition9.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions6, categoryLabelPosition9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        float float15 = categoryLabelPosition14.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor16, textBlockAnchor17);
        float float19 = categoryLabelPosition18.getWidthRatio();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition9, categoryLabelPosition14, categoryLabelPosition18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.95f + "'", float15 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.95f + "'", float19 == 0.95f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement11 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer5, (org.jfree.chart.block.Arrangement) columnArrangement10, (org.jfree.chart.block.Arrangement) centerArrangement11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis14.setPositiveArrowVisible(true);
        numberAxis14.setFixedAutoRange((double) (short) 0);
        numberAxis14.setRangeWithMargins((double) 0, (double) '#');
        numberAxis14.setAutoRange(false);
        boolean boolean24 = numberAxis14.isVerticalTickLabels();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = numberAxis14.getTickLabelInsets();
        boolean boolean26 = legendTitle12.equals((java.lang.Object) rectangleInsets25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        int int28 = categoryPlot27.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot27.getRangeAxisEdge();
        categoryPlot27.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke33 = statisticalBarRenderer32.getBaseStroke();
        java.awt.Paint paint35 = statisticalBarRenderer32.getSeriesOutlinePaint((-1));
        int int36 = categoryPlot27.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer32);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = categoryPlot27.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        int int39 = categoryPlot38.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot38.getRangeAxisEdge();
        java.awt.Paint paint41 = categoryPlot38.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot38.getRangeAxisEdge();
        boolean boolean43 = categoryPlot38.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis44.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double47 = categoryAxis44.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit48 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int49 = numberTickUnit48.getMinorTickCount();
        java.awt.Font font50 = categoryAxis44.getTickLabelFont((java.lang.Comparable) numberTickUnit48);
        categoryPlot38.setNoDataMessageFont(font50);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke53 = statisticalBarRenderer52.getBaseStroke();
        java.awt.Paint paint55 = statisticalBarRenderer52.getSeriesOutlinePaint((-1));
        java.awt.Shape shape57 = statisticalBarRenderer52.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer58 = null;
        statisticalBarRenderer52.setGradientPaintTransformer(gradientPaintTransformer58);
        int int60 = categoryPlot38.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer52);
        double double61 = statisticalBarRenderer52.getMinimumBarLength();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer62 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke63 = statisticalBarRenderer62.getBaseStroke();
        org.jfree.chart.LegendItem legendItem66 = statisticalBarRenderer62.getLegendItem((int) (short) 100, (int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition68 = null;
        statisticalBarRenderer62.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition68, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer71 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke72 = statisticalBarRenderer71.getBaseStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator73 = statisticalBarRenderer71.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer74 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke75 = statisticalBarRenderer74.getBaseStroke();
        java.awt.Paint paint77 = statisticalBarRenderer74.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer78 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke79 = statisticalBarRenderer78.getBaseStroke();
        statisticalBarRenderer74.setBaseStroke(stroke79, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray82 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { statisticalBarRenderer52, statisticalBarRenderer62, statisticalBarRenderer71, statisticalBarRenderer74 };
        categoryPlot27.setRenderers(categoryItemRendererArray82);
        legendTitle12.setSources((org.jfree.chart.LegendItemSource[]) categoryItemRendererArray82);
        java.awt.Paint paint85 = legendTitle12.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(drawingSupplier37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(paint55);
        org.junit.Assert.assertNull(shape57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNull(legendItem66);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator73);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNull(paint77);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(categoryItemRendererArray82);
        org.junit.Assert.assertNull(paint85);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range5 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis7.setVisible(true);
        numberAxis7.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range13 = numberAxis7.getRange();
        double double14 = range13.getLength();
        org.jfree.data.Range range17 = org.jfree.data.Range.expand(range13, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint2.toRangeWidth(range17);
        java.lang.String str19 = rectangleConstraint2.toString();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 11.0d + "'", double14 == 11.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]" + "'", str19.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement11 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer5, (org.jfree.chart.block.Arrangement) columnArrangement10, (org.jfree.chart.block.Arrangement) centerArrangement11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setID("ClassContext");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent16 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle13);
        org.jfree.chart.title.Title title17 = titleChangeEvent16.getTitle();
        org.jfree.chart.title.Title title18 = titleChangeEvent16.getTitle();
        org.jfree.chart.block.BlockFrame blockFrame19 = title18.getFrame();
        legendTitle12.setFrame(blockFrame19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis21.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis21.setTickLabelsVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = categoryAxis21.getCategoryLabelPositions();
        java.awt.Font font28 = categoryAxis21.getTickLabelFont((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE3");
        legendTitle12.setItemFont(font28);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(title17);
        org.junit.Assert.assertNotNull(title18);
        org.junit.Assert.assertNotNull(blockFrame19);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list6 = defaultStatisticalCategoryDataset5.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity9 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        java.util.List list11 = defaultStatisticalCategoryDataset5.getRowKeys();
        java.lang.Object obj12 = defaultStatisticalCategoryDataset5.clone();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(range13);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test186");
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str4 = projectInfo3.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo3.getLibraries();
//        java.lang.String str6 = projectInfo3.getLicenceText();
//        java.awt.Image image7 = projectInfo3.getLogo();
//        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("VerticalAlignment.CENTER", "RectangleEdge.TOP", "SortOrder.ASCENDING", image7, "JFreeChart", "TextAnchor.CENTER_RIGHT", "JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]");
//        projectInfo11.addOptionalLibrary("LegendItemEntity: seriesKey=, dataset=null");
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3" + "'", str6.equals("3"));
//        org.junit.Assert.assertNotNull(image7);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        boolean boolean7 = statisticalBarRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list19 = defaultStatisticalCategoryDataset18.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity22 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        int int23 = defaultStatisticalCategoryDataset18.getColumnCount();
        int int24 = defaultStatisticalCategoryDataset18.getColumnCount();
        org.jfree.data.Range range25 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18);
        org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, 2);
        boolean boolean28 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset27);
        org.jfree.data.general.PieDataset pieDataset31 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset27, (java.lang.Comparable) 0.3d, 0.0d);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset31, (java.lang.Comparable) 0.2d, (double) 2, 0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(pieDataset27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(pieDataset31);
        org.junit.Assert.assertNotNull(pieDataset35);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAJOR" + "'", str1.equals("MAJOR"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0E-8d);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker1.setStroke(stroke2);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor8);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = categoryLabelPosition9.getWidthType();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor4, textAnchor5, 0.3d, categoryLabelWidthType10, 0.0f);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = categoryLabelPosition12.getLabelAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        jFreeChart9.setBackgroundImageAlpha(0.5f);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart9.removeProgressListener(chartProgressListener13);
        java.lang.Object obj15 = jFreeChart9.getTextAntiAlias();
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart9.addProgressListener(chartProgressListener16);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range5 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        double double3 = numberAxis2.getAutoRangeMinimumSize();
        java.awt.Shape shape4 = numberAxis2.getUpArrow();
        java.awt.Font font5 = numberAxis2.getTickLabelFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        boolean boolean10 = statisticalBarRenderer6.getAutoPopulateSeriesOutlineStroke();
        boolean boolean11 = statisticalBarRenderer6.getBaseSeriesVisible();
        statisticalBarRenderer6.setMinimumBarLength((double) 10);
        java.awt.Color color14 = java.awt.Color.darkGray;
        float[] floatArray21 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray22 = color14.getRGBColorComponents(floatArray21);
        statisticalBarRenderer6.setBaseItemLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, (java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(textBlock24);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test197");
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str4 = projectInfo3.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo3.getLibraries();
//        java.lang.String str6 = projectInfo3.getLicenceText();
//        java.awt.Image image7 = projectInfo3.getLogo();
//        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo("VerticalAlignment.CENTER", "RectangleEdge.TOP", "SortOrder.ASCENDING", image7, "JFreeChart", "TextAnchor.CENTER_RIGHT", "JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]");
//        org.jfree.chart.ui.ProjectInfo projectInfo12 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str13 = projectInfo12.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray14 = projectInfo12.getLibraries();
//        java.lang.String str15 = projectInfo12.getLicenceText();
//        java.awt.Image image16 = projectInfo12.getLogo();
//        org.jfree.chart.text.TextBlock textBlock17 = new org.jfree.chart.text.TextBlock();
//        java.util.List list18 = textBlock17.getLines();
//        projectInfo12.setContributors(list18);
//        projectInfo11.addLibrary((org.jfree.chart.ui.Library) projectInfo12);
//        java.lang.String str21 = projectInfo11.getInfo();
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3" + "'", str6.equals("3"));
//        org.junit.Assert.assertNotNull(image7);
//        org.junit.Assert.assertNotNull(projectInfo12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(libraryArray14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3" + "'", str15.equals("3"));
//        org.junit.Assert.assertNotNull(image16);
//        org.junit.Assert.assertNotNull(list18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "SortOrder.ASCENDING" + "'", str21.equals("SortOrder.ASCENDING"));
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = legendTitle19.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = legendTitle19.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ClassContext", font5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str8 = color7.toString();
        boolean boolean10 = color7.equals((java.lang.Object) 'a');
        textBlock0.addLine("java.awt.Color[r=192,g=0,b=0]", font5, (java.awt.Paint) color7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textBlock0.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, 0.0d, 21.0d);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        boolean boolean18 = flowArrangement16.equals((java.lang.Object) itemLabelAnchor17);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str8.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke4 = statisticalBarRenderer3.getBaseStroke();
        java.awt.Paint paint6 = statisticalBarRenderer3.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke7 = statisticalBarRenderer3.getBaseStroke();
        java.lang.Boolean boolean9 = statisticalBarRenderer3.getSeriesItemLabelsVisible((int) ' ');
        boolean boolean10 = datasetRenderingOrder0.equals((java.lang.Object) statisticalBarRenderer3);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot12.setDomainAxisLocation(15, axisLocation14, true);
        categoryPlot12.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot12.getRendererForDataset(categoryDataset18);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = categoryPlot12.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis22.setTickMarkOutsideLength((float) (short) 100);
        numberAxis22.setLabelAngle((double) '4');
        org.jfree.data.Range range27 = categoryPlot12.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis22);
        java.text.NumberFormat numberFormat28 = null;
        numberAxis22.setNumberFormatOverride(numberFormat28);
        java.awt.Shape shape30 = numberAxis22.getRightArrow();
        org.jfree.chart.text.TextBlock textBlock31 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.util.Size2D size2D33 = textBlock31.calculateDimensions(graphics2D32);
        java.awt.Font font36 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("ClassContext", font36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str39 = color38.toString();
        boolean boolean41 = color38.equals((java.lang.Object) 'a');
        textBlock31.addLine("java.awt.Color[r=192,g=0,b=0]", font36, (java.awt.Paint) color38);
        numberAxis22.setTickMarkPaint((java.awt.Paint) color38);
        statisticalBarRenderer3.setSeriesFillPaint(10, (java.awt.Paint) color38);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(size2D33);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str39.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setWeight((int) (byte) 10);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Stroke stroke12 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        int int14 = categoryPlot13.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getRangeAxisEdge();
        java.awt.Paint paint16 = categoryPlot13.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot13.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot13.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot13.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo22, point2D23);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = categoryPlot13.getOrientation();
        java.util.List list26 = categoryPlot13.getCategories();
        boolean boolean27 = categoryPlot13.isRangeZoomable();
        java.awt.Stroke stroke28 = categoryPlot13.getDomainGridlineStroke();
        categoryPlot0.setOutlineStroke(stroke28);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray13, numberArray16, numberArray19, numberArray22, numberArray25, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray29);
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset30, 0.0d);
        legendItem8.setDataset((org.jfree.data.general.Dataset) categoryDataset30);
        boolean boolean35 = legendItem8.isShapeFilled();
        java.lang.String str36 = legendItem8.getToolTipText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.3d + "'", number31.equals(0.3d));
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ClassContext" + "'", str36.equals("ClassContext"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Shape shape5 = statisticalBarRenderer0.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo9);
        double double11 = categoryItemRendererState10.getSeriesRunningTotal();
        double double12 = categoryItemRendererState10.getBarWidth();
        org.jfree.chart.text.TextBlock textBlock13 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = textBlock13.calculateDimensions(graphics2D14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, 0.3d, (double) (short) 100, rectangleAnchor18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot20.setDomainAxisLocation(15, axisLocation22, true);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot20.getDomainMarkers(layer25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot20.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis28.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis28.setTickLabelsVisible(true);
        categoryAxis28.setLowerMargin((double) 100.0f);
        int int35 = categoryPlot20.getDomainAxisIndex(categoryAxis28);
        categoryPlot20.setRangeGridlinesVisible(false);
        java.awt.Paint paint38 = categoryPlot20.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis39.setMaximumCategoryLabelWidthRatio((float) ' ');
        int int42 = categoryAxis39.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis44.setPositiveArrowVisible(true);
        numberAxis44.setFixedAutoRange((double) (short) 0);
        numberAxis44.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset57 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list58 = defaultStatisticalCategoryDataset57.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity61 = new org.jfree.chart.entity.CategoryItemEntity(shape54, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset57, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        int int62 = defaultStatisticalCategoryDataset57.getColumnCount();
        int int63 = defaultStatisticalCategoryDataset57.getColumnCount();
        try {
            statisticalBarRenderer0.drawItem(graphics2D8, categoryItemRendererState10, rectangle2D19, categoryPlot20, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis44, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset57, (int) (byte) 1, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis10.setTickMarkOutsideLength((float) (short) 100);
        numberAxis10.setLabelAngle((double) '4');
        org.jfree.data.Range range15 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.text.NumberFormat numberFormat16 = null;
        numberAxis10.setNumberFormatOverride(numberFormat16);
        java.awt.Shape shape18 = numberAxis10.getRightArrow();
        org.jfree.chart.text.TextBlock textBlock19 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textBlock19.calculateDimensions(graphics2D20);
        java.awt.Font font24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("ClassContext", font24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str27 = color26.toString();
        boolean boolean29 = color26.equals((java.lang.Object) 'a');
        textBlock19.addLine("java.awt.Color[r=192,g=0,b=0]", font24, (java.awt.Paint) color26);
        numberAxis10.setTickMarkPaint((java.awt.Paint) color26);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean34 = numberAxis33.isNegativeArrowVisible();
        double double35 = numberAxis33.getAutoRangeMinimumSize();
        org.jfree.data.Range range37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range37);
        double double39 = rectangleConstraint38.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint38.toUnconstrainedWidth();
        org.jfree.data.Range range41 = rectangleConstraint38.getHeightRange();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis43.setVisible(true);
        numberAxis43.setRange((double) (short) -1, 10.0d);
        org.jfree.data.Range range49 = numberAxis43.getRange();
        double double50 = range49.getLength();
        org.jfree.data.Range range53 = org.jfree.data.Range.expand(range49, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = rectangleConstraint38.toRangeWidth(range53);
        numberAxis33.setRange(range53, false, true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit58 = numberAxis33.getTickUnit();
        numberAxis10.setTickUnit(numberTickUnit58, true, true);
        numberAxis10.setFixedAutoRange((double) (-16711681));
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str27.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0E-8d + "'", double35 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.0d + "'", double39 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 11.0d + "'", double50 == 11.0d);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rectangleConstraint54);
        org.junit.Assert.assertNotNull(numberTickUnit58);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list6 = defaultStatisticalCategoryDataset5.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity9 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        java.lang.Comparable comparable10 = categoryItemEntity9.getRowKey();
        categoryItemEntity9.setColumnKey((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str13 = categoryItemEntity9.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", comparable10.equals("ItemLabelAnchor.INSIDE7"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str13.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        numberAxis1.resizeRange((-1.0d));
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setUpperMargin(0.2d);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle10.setFont(font11);
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("java.awt.Color[r=192,g=0,b=0]", font11);
        numberAxis1.setLabelFont(font11);
        float float15 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test207");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getCopyright();
//        java.util.List list2 = projectInfo0.getContributors();
//        projectInfo0.setLicenceText("ThreadContext");
//        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo0.getOptionalLibraries();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertNotNull(libraryArray5);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str3 = color2.toString();
        statisticalBarRenderer0.setSeriesOutlinePaint(2, (java.awt.Paint) color2, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        int int7 = categoryPlot6.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot6.getRangeAxisEdge();
        categoryPlot6.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke12 = statisticalBarRenderer11.getBaseStroke();
        java.awt.Paint paint14 = statisticalBarRenderer11.getSeriesOutlinePaint((-1));
        int int15 = categoryPlot6.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer11);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke17 = statisticalBarRenderer16.getBaseStroke();
        java.awt.Paint paint19 = statisticalBarRenderer16.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke20 = statisticalBarRenderer16.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        statisticalBarRenderer16.setSeriesNegativeItemLabelPosition(255, itemLabelPosition22);
        java.lang.Boolean boolean25 = statisticalBarRenderer16.getSeriesVisible((int) (short) 0);
        statisticalBarRenderer16.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = statisticalBarRenderer16.getDrawingSupplier();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke31 = statisticalBarRenderer30.getBaseStroke();
        java.awt.Paint paint33 = statisticalBarRenderer30.getSeriesOutlinePaint((-1));
        boolean boolean34 = statisticalBarRenderer30.getAutoPopulateSeriesOutlineStroke();
        statisticalBarRenderer30.setDrawBarOutline(true);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font40 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle39.setFont(font40);
        java.awt.Paint paint42 = null;
        org.jfree.chart.text.TextBlock textBlock43 = org.jfree.chart.text.TextUtilities.createTextBlock("", font40, paint42);
        statisticalBarRenderer30.setSeriesItemLabelFont((int) (short) 100, font40);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer45 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke46 = statisticalBarRenderer45.getBaseStroke();
        java.awt.Paint paint48 = statisticalBarRenderer45.getSeriesOutlinePaint((-1));
        boolean boolean49 = statisticalBarRenderer45.getAutoPopulateSeriesOutlineStroke();
        boolean boolean50 = statisticalBarRenderer45.getBaseSeriesVisible();
        java.awt.Color color52 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer45.setSeriesItemLabelPaint(0, (java.awt.Paint) color52);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer54 = null;
        statisticalBarRenderer45.setGradientPaintTransformer(gradientPaintTransformer54);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer56 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke57 = statisticalBarRenderer56.getBaseStroke();
        statisticalBarRenderer56.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator61 = null;
        statisticalBarRenderer56.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator61, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray64 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { statisticalBarRenderer16, statisticalBarRenderer30, statisticalBarRenderer45, statisticalBarRenderer56 };
        categoryPlot6.setRenderers(categoryItemRendererArray64);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer66 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Font font67 = statisticalBarRenderer66.getBaseItemLabelFont();
        boolean boolean70 = statisticalBarRenderer66.getItemVisible(2, (int) (short) 10);
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer66, false);
        statisticalBarRenderer0.setPlot(categoryPlot6);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str3.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(boolean25);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(textBlock43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(categoryItemRendererArray64);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }
}

