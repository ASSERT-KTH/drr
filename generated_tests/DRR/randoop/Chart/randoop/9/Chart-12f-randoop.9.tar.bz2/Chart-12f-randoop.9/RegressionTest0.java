import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateBottomInset((double) (byte) -1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Shape shape0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 100, 0, (java.lang.Comparable) 'a', "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray3 = new float[] { (byte) -1 };
        try {
            float[] floatArray4 = color0.getComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color0 = java.awt.Color.BLUE;
        boolean boolean2 = color0.equals((java.lang.Object) 0);
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = color0.getRGBComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Comparable comparable1 = null;
        try {
            int int2 = defaultKeyedValues2D0.getColumnIndex(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.awt.Stroke stroke1 = null;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        double double9 = rectangleInsets7.calculateTopInset((double) '#');
        try {
            org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset((double) '#');
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets5.createAdjustedRectangle(rectangle2D8, lengthAdjustmentType9, lengthAdjustmentType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray5 = null;
        float[] floatArray6 = java.awt.Color.RGBtoHSB(3, 0, 15, floatArray5);
        try {
            float[] floatArray7 = color0.getComponents(colorSpace1, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int3 = java.awt.Color.HSBtoRGB((float) 1L, (float) 15, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-15728654) + "'", int3 == (-15728654));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.Comparable comparable3 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset2, comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle1.setPosition(rectangleEdge20);
        java.awt.Font font22 = null;
        try {
            legendTitle1.setItemFont(font22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int3 = java.awt.Color.HSBtoRGB((float) 10, (float) (short) 10, (float) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-555) + "'", int3 == (-555));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        double double9 = rectangleInsets7.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        java.awt.geom.Rectangle2D rectangle2D12 = legendTitle11.getBounds();
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets7.createInsetRectangle(rectangle2D12, false, true);
        try {
            blockBorder0.draw(graphics2D1, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        java.awt.Stroke stroke3 = null;
        strokeMap0.put((java.lang.Comparable) 100.0f, stroke3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        java.awt.geom.Rectangle2D rectangle2D19 = legendTitle18.getBounds();
        java.lang.Object obj20 = null;
        try {
            java.lang.Object obj21 = legendTitle1.draw(graphics2D16, rectangle2D19, obj20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets5.createInsetRectangle(rectangle2D10, false, true);
        double double15 = rectangleInsets5.calculateTopOutset(0.08d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        try {
            textTitle2.setTextAlignment(horizontalAlignment3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = java.awt.Color.BLUE;
        java.awt.Color color4 = java.awt.Color.BLUE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        int int6 = color5.getBlue();
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, color1, color2, color3, color4, color5 };
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color12 = java.awt.Color.BLUE;
        boolean boolean14 = color12.equals((java.lang.Object) 0);
        java.awt.Color color17 = java.awt.Color.getColor("", (int) (byte) 10);
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor11, color12, color17 };
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color27 = java.awt.Color.BLUE;
        java.awt.Color color28 = java.awt.Color.green;
        java.awt.Color color29 = java.awt.Color.WHITE;
        int int30 = color29.getBlue();
        java.awt.Color color31 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { chartColor22, chartColor26, color27, color28, color29, color31 };
        java.awt.Stroke stroke33 = null;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke33 };
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = null;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray18, paintArray32, strokeArray34, strokeArray35, shapeArray37);
        try {
            java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shapeArray37);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.plot.Plot plot4 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]", font2, plot4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        boolean boolean4 = chartChangeEventType2.equals((java.lang.Object) color3);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        projectInfo0.addLibrary(library5);
        projectInfo0.setLicenceName("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.lang.Class<?> wildcardClass1 = rectangleAnchor0.getClass();
        java.lang.String str2 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str2.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeRow(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Number number3 = defaultKeyedValues2D0.getValue((java.lang.Comparable) (short) 100, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.addValue((java.lang.Number) 100L, (java.lang.Comparable) 255, (java.lang.Comparable) 100L);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", 0);
        int int3 = color2.getRed();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        projectInfo0.addLibrary(library5);
        org.jfree.chart.ui.Library library11 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor15 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean16 = library11.equals((java.lang.Object) chartColor15);
        projectInfo0.addOptionalLibrary(library11);
        org.jfree.chart.ui.Library library22 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        java.lang.String str23 = library22.getLicenceName();
        projectInfo0.addLibrary(library22);
        java.lang.String str25 = library22.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        try {
            defaultKeyedValues2D0.removeRow((java.lang.Comparable) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("");
        projectInfo0.setLicenceText("hi!");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        try {
            defaultKeyedValues2D0.removeColumn((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.trimWidth((double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-15.0d) + "'", double7 == (-15.0d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = legendTitle1.arrange(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        boolean boolean11 = legendTitle1.getNotify();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        legendTitle13.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer16 = null;
        legendTitle13.setWrapper(blockContainer16);
        legendTitle13.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        boolean boolean23 = legendTitle13.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle13.setPosition(rectangleEdge24);
        legendTitle1.setPosition(rectangleEdge24);
        java.lang.String str27 = rectangleEdge24.toString();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleEdge.TOP" + "'", str27.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray8 = new float[] { (byte) -1, (byte) -1, (-1) };
        float[] floatArray9 = java.awt.Color.RGBtoHSB(2, (int) (byte) -1, (int) 'a', floatArray8);
        try {
            float[] floatArray10 = color0.getColorComponents(colorSpace1, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray6 = new float[] { 3, 0L, 3, 1.0f };
        try {
            float[] floatArray7 = color0.getColorComponents(colorSpace1, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        legendTitle1.setWidth(0.0d);
        legendTitle1.setID("Rotation.CLOCKWISE");
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = null;
        try {
            org.jfree.chart.util.Size2D size2D24 = legendTitle1.arrange(graphics2D22, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset((double) '#');
        java.lang.String str8 = rectangleInsets5.toString();
        double double10 = rectangleInsets5.calculateLeftInset(15.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str8.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        legendTitle1.setWidth(0.0d);
        legendTitle1.setID("Rotation.CLOCKWISE");
        java.awt.Font font22 = null;
        try {
            legendTitle1.setItemFont(font22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Rotation.CLOCKWISE", "ChartEntity: tooltip = Rotation.CLOCKWISE", "RectangleEdge.TOP", "");
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        double double6 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor7);
        java.lang.Class<?> wildcardClass9 = rectangleAnchor7.getClass();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color8 = java.awt.Color.WHITE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = java.awt.Color.BLUE;
        java.awt.Color color11 = java.awt.Color.BLUE;
        java.awt.Color color12 = java.awt.Color.WHITE;
        int int13 = color12.getBlue();
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color7, color8, color9, color10, color11, color12 };
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color19 = java.awt.Color.BLUE;
        boolean boolean21 = color19.equals((java.lang.Object) 0);
        java.awt.Color color24 = java.awt.Color.getColor("", (int) (byte) 10);
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { chartColor18, color19, color24 };
        org.jfree.chart.ChartColor chartColor29 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        org.jfree.chart.ChartColor chartColor33 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color34 = java.awt.Color.BLUE;
        java.awt.Color color35 = java.awt.Color.green;
        java.awt.Color color36 = java.awt.Color.WHITE;
        int int37 = color36.getBlue();
        java.awt.Color color38 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray39 = new java.awt.Paint[] { chartColor29, chartColor33, color34, color35, color36, color38 };
        java.awt.Stroke stroke40 = null;
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] { stroke40 };
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] {};
        java.awt.Shape shape43 = null;
        java.awt.Shape[] shapeArray44 = new java.awt.Shape[] { shape43 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray25, paintArray39, strokeArray41, strokeArray42, shapeArray44);
        try {
            java.lang.Object obj46 = legendTitle1.draw(graphics2D5, rectangle2D6, (java.lang.Object) paintArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paintArray39);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shapeArray44);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.Color color7 = java.awt.Color.YELLOW;
        try {
            java.lang.Object obj8 = legendTitle1.draw(graphics2D5, rectangle2D6, (java.lang.Object) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.Object obj1 = null;
        boolean boolean2 = pieLabelLinkStyle0.equals(obj1);
        java.lang.String str3 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str3.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.block.BlockContainer blockContainer2 = null;
        legendTitle1.setWrapper(blockContainer2);
        org.jfree.chart.block.BlockFrame blockFrame4 = null;
        try {
            legendTitle1.setFrame(blockFrame4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        double double21 = rectangleInsets16.calculateBottomOutset((double) 0);
        double double22 = rectangleInsets16.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets5.createInsetRectangle(rectangle2D10, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D13);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator15 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator16 = null;
        java.lang.String str17 = chartEntity14.getImageMapAreaTag(toolTipTagFragmentGenerator15, uRLTagFragmentGenerator16);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("UnitType.RELATIVE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Block block2 = null;
        org.jfree.chart.ui.Library library7 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean12 = library7.equals((java.lang.Object) chartColor11);
        blockContainer1.add(block2, (java.lang.Object) boolean12);
        org.jfree.chart.block.Arrangement arrangement14 = blockContainer1.getArrangement();
        boolean boolean15 = blockContainer1.isEmpty();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = blockBorder27.getInsets();
        double double30 = rectangleInsets28.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        java.awt.geom.Rectangle2D rectangle2D33 = legendTitle32.getBounds();
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets28.createInsetRectangle(rectangle2D33, false, true);
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets22.createOutsetRectangle(rectangle2D36, true, false);
        try {
            blockContainer1.draw(graphics2D16, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(arrangement14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        boolean boolean3 = legendTitle1.equals((java.lang.Object) (-1.0d));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = legendTitle1.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("PieLabelLinkStyle.STANDARD", "PieLabelLinkStyle.STANDARD");
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        piePlot1.setOutlineVisible(false);
        java.awt.Paint paint7 = null;
        try {
            piePlot1.setBaseSectionPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Image image2 = piePlot1.getBackgroundImage();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        legendTitle4.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        legendTitle4.setWrapper(blockContainer7);
        legendTitle4.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        double double21 = rectangleInsets19.calculateTopInset((double) '#');
        legendTitle4.setLegendItemGraphicPadding(rectangleInsets19);
        double double24 = rectangleInsets19.calculateBottomOutset((double) 0);
        java.awt.Color color25 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder(rectangleInsets19, (java.awt.Paint) color25);
        piePlot1.setNoDataMessagePaint((java.awt.Paint) color25);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator28 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(pieURLGenerator28);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeColumn((java.lang.Comparable) 0.5f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 0.5");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets5.createInsetRectangle(rectangle2D10, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D13);
        java.lang.String str15 = chartEntity14.getShapeType();
        chartEntity14.setToolTipText("hi!");
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "rect" + "'", str15.equals("rect"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder4.getInsets();
        double double7 = rectangleInsets6.getRight();
        double double8 = rectangleInsets6.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 15.0d + "'", double7 == 15.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = java.awt.Color.BLUE;
        java.awt.Color color4 = java.awt.Color.BLUE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        int int6 = color5.getBlue();
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, color1, color2, color3, color4, color5 };
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color12 = java.awt.Color.BLUE;
        boolean boolean14 = color12.equals((java.lang.Object) 0);
        java.awt.Color color17 = java.awt.Color.getColor("", (int) (byte) 10);
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor11, color12, color17 };
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color27 = java.awt.Color.BLUE;
        java.awt.Color color28 = java.awt.Color.green;
        java.awt.Color color29 = java.awt.Color.WHITE;
        int int30 = color29.getBlue();
        java.awt.Color color31 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { chartColor22, chartColor26, color27, color28, color29, color31 };
        java.awt.Stroke stroke33 = null;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke33 };
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = null;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray18, paintArray32, strokeArray34, strokeArray35, shapeArray37);
        java.awt.Paint paint39 = defaultDrawingSupplier38.getNextPaint();
        java.awt.Paint paint40 = defaultDrawingSupplier38.getNextFillPaint();
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder(paint40);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray4 = new float[] { '#', 0 };
        try {
            float[] floatArray5 = color0.getColorComponents(colorSpace1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        legendTitle5.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer8 = null;
        legendTitle5.setWrapper(blockContainer8);
        legendTitle5.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle5.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = legendTitle5.getVerticalAlignment();
        java.lang.String str21 = verticalAlignment20.toString();
        legendTitle1.setVerticalAlignment(verticalAlignment20);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockBorder28.getInsets();
        double double31 = rectangleInsets29.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        java.awt.geom.Rectangle2D rectangle2D34 = legendTitle33.getBounds();
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets29.createInsetRectangle(rectangle2D34, false, true);
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        legendTitle39.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer42 = null;
        legendTitle39.setWrapper(blockContainer42);
        double double44 = legendTitle39.getHeight();
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        legendTitle46.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer49 = null;
        legendTitle46.setWrapper(blockContainer49);
        legendTitle46.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        boolean boolean56 = legendTitle46.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle46.setPosition(rectangleEdge57);
        legendTitle39.setPosition(rectangleEdge57);
        try {
            java.lang.Object obj60 = legendTitle1.draw(graphics2D23, rectangle2D34, (java.lang.Object) rectangleEdge57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "VerticalAlignment.CENTER" + "'", str21.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot5.setLabelOutlineStroke(stroke6);
        piePlot5.setIgnoreNullValues(false);
        java.awt.Paint paint10 = piePlot5.getLabelLinkPaint();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(1.0d, (double) (byte) 0, (double) (short) 100, (double) 0.0f, paint10);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.setInfo("");
//        projectInfo0.setName("UnitType.RELATIVE");
//        java.lang.String str5 = projectInfo0.getCopyright();
//        java.util.List list6 = projectInfo0.getContributors();
//        java.lang.String str7 = projectInfo0.getInfo();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str5.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets5.createInsetRectangle(rectangle2D10, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10, "Rotation.CLOCKWISE");
        java.lang.String str16 = chartEntity15.toString();
        java.lang.String str17 = chartEntity15.toString();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ChartEntity: tooltip = Rotation.CLOCKWISE" + "'", str16.equals("ChartEntity: tooltip = Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ChartEntity: tooltip = Rotation.CLOCKWISE" + "'", str17.equals("ChartEntity: tooltip = Rotation.CLOCKWISE"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues2D0.getColumnKey((-555));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = java.awt.Color.BLUE;
        java.awt.Color color4 = java.awt.Color.BLUE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        int int6 = color5.getBlue();
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, color1, color2, color3, color4, color5 };
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color12 = java.awt.Color.BLUE;
        boolean boolean14 = color12.equals((java.lang.Object) 0);
        java.awt.Color color17 = java.awt.Color.getColor("", (int) (byte) 10);
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor11, color12, color17 };
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color27 = java.awt.Color.BLUE;
        java.awt.Color color28 = java.awt.Color.green;
        java.awt.Color color29 = java.awt.Color.WHITE;
        int int30 = color29.getBlue();
        java.awt.Color color31 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { chartColor22, chartColor26, color27, color28, color29, color31 };
        java.awt.Stroke stroke33 = null;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke33 };
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = null;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray18, paintArray32, strokeArray34, strokeArray35, shapeArray37);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator40 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset41 = null;
        java.lang.String str43 = standardPieSectionLabelGenerator40.generateSectionLabel(pieDataset41, (java.lang.Comparable) (short) 0);
        boolean boolean44 = defaultDrawingSupplier38.equals((java.lang.Object) standardPieSectionLabelGenerator40);
        org.jfree.data.general.PieDataset pieDataset45 = null;
        java.lang.Comparable comparable46 = null;
        try {
            java.text.AttributedString attributedString47 = standardPieSectionLabelGenerator40.generateAttributedSectionLabel(pieDataset45, comparable46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.setValue((java.lang.Number) 15, (java.lang.Comparable) 100, (java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean7 = defaultKeyedValues2D0.equals((java.lang.Object) (short) 0);
        int int9 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) 0.5f);
        try {
            defaultKeyedValues2D0.removeRow((java.lang.Comparable) (-15728654));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.lang.Object obj4 = textTitle2.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getTextAlignment();
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle2.setFont(font7);
        textTitle2.setURLText("VerticalAlignment.CENTER");
        textTitle2.setText("");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.lang.Object obj4 = textTitle2.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getTextAlignment();
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle2.setFont(font7);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        legendTitle11.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer14 = null;
        legendTitle11.setWrapper(blockContainer14);
        legendTitle11.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockBorder25.getInsets();
        double double28 = rectangleInsets26.calculateTopInset((double) '#');
        legendTitle11.setLegendItemGraphicPadding(rectangleInsets26);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle11.setPosition(rectangleEdge30);
        textTitle2.setPosition(rectangleEdge30);
        java.lang.String str33 = rectangleEdge30.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "RectangleEdge.TOP" + "'", str33.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("VerticalAlignment.CENTER", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color1 = color0.darker();
        int int2 = color1.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 178 + "'", int2 == 178);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.setIgnoreNullValues(false);
        java.awt.Paint paint6 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        projectInfo0.addLibrary(library5);
        org.jfree.chart.ui.Library library11 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor15 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean16 = library11.equals((java.lang.Object) chartColor15);
        projectInfo0.addOptionalLibrary(library11);
        org.jfree.chart.ui.Library library22 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        java.lang.String str23 = library22.getLicenceName();
        projectInfo0.addLibrary(library22);
        org.jfree.chart.ui.Library[] libraryArray25 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(libraryArray25);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        boolean boolean11 = legendTitle1.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle1.setPosition(rectangleEdge12);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        legendTitle15.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer18 = null;
        legendTitle15.setWrapper(blockContainer18);
        double double20 = legendTitle15.getHeight();
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        legendTitle22.setWrapper(blockContainer25);
        legendTitle22.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        boolean boolean32 = legendTitle22.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle22.setPosition(rectangleEdge33);
        legendTitle15.setPosition(rectangleEdge33);
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        double double21 = rectangleInsets16.calculateBottomOutset((double) 0);
        java.awt.Color color22 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(rectangleInsets16, (java.awt.Paint) color22);
        float[] floatArray27 = null;
        float[] floatArray28 = java.awt.Color.RGBtoHSB(3, 0, 15, floatArray27);
        try {
            float[] floatArray29 = color22.getRGBComponents(floatArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        double double4 = piePlot1.getStartAngle();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("TableOrder.BY_COLUMN", "RectangleEdge.TOP", "TableOrder.BY_COLUMN", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle2.getPosition();
        textTitle2.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.ChartColor chartColor4 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean5 = strokeMap0.equals((java.lang.Object) 3);
        strokeMap0.clear();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean7 = piePlot1.equals((java.lang.Object) rectangleAnchor6);
        piePlot1.setShadowYOffset(0.0d);
        double double10 = piePlot1.getShadowYOffset();
        java.awt.Stroke stroke11 = null;
        try {
            piePlot1.setLabelLinkStroke(stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        double double10 = rectangleInsets8.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle12.getBounds();
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets8.createInsetRectangle(rectangle2D13, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D13, "Rotation.CLOCKWISE");
        try {
            objectList1.set((-15728654), (java.lang.Object) rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart9.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart9.createBufferedImage(178, 2, 1, chartRenderingInfo15);
        java.awt.RenderingHints renderingHints17 = jFreeChart9.getRenderingHints();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = blockBorder23.getInsets();
        double double26 = rectangleInsets24.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle28.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets24.createInsetRectangle(rectangle2D29, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D29, "Rotation.CLOCKWISE");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        try {
            jFreeChart9.draw(graphics2D18, rectangle2D29, chartRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertNotNull(renderingHints17);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.setValue((java.lang.Number) 15, (java.lang.Comparable) 100, (java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean7 = defaultKeyedValues2D0.equals((java.lang.Object) (short) 0);
        int int9 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) 0.5f);
        try {
            java.lang.Comparable comparable11 = defaultKeyedValues2D0.getColumnKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        java.awt.geom.Rectangle2D rectangle2D5 = legendTitle4.getBounds();
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            multiplePiePlot0.draw(graphics2D2, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNotNull(rectangle2D5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder8.getInsets();
        double double11 = rectangleInsets9.calculateTopInset((double) (byte) -1);
        legendTitle1.setItemLabelPadding(rectangleInsets9);
        double double13 = rectangleInsets9.getBottom();
        double double15 = rectangleInsets9.calculateBottomInset((double) 100);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart9.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart9.createBufferedImage(178, 2, 1, chartRenderingInfo15);
        java.awt.RenderingHints renderingHints17 = jFreeChart9.getRenderingHints();
        org.jfree.chart.event.ChartChangeListener chartChangeListener18 = null;
        try {
            jFreeChart9.removeChangeListener(chartChangeListener18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertNotNull(renderingHints17);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Rotation.CLOCKWISE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle3.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle3.setWidth((double) '4');
        legendTitle3.setWidth(0.0d);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle3.setItemPaint((java.awt.Paint) color22);
        boolean boolean24 = piePlot1.equals((java.lang.Object) legendTitle3);
        float float25 = piePlot1.getForegroundAlpha();
        java.awt.Font font26 = piePlot1.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.setValue((java.lang.Number) 15, (java.lang.Comparable) 100, (java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean7 = defaultKeyedValues2D0.equals((java.lang.Object) (short) 0);
        try {
            defaultKeyedValues2D0.removeRow((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = null;
        boolean boolean2 = defaultDrawingSupplier0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        double double6 = legendTitle1.getHeight();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.block.BlockFrame blockFrame9 = null;
        try {
            legendTitle1.setFrame(blockFrame9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 100L, (float) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.awt.Paint paint10 = piePlot3.getLabelOutlinePaint();
        float float11 = piePlot3.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.geom.Rectangle2D rectangle2D2 = legendTitle1.getBounds();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        legendTitle4.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        legendTitle4.setWrapper(blockContainer7);
        legendTitle4.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        double double21 = rectangleInsets19.calculateTopInset((double) '#');
        legendTitle4.setLegendItemGraphicPadding(rectangleInsets19);
        double double24 = rectangleInsets19.calculateRightOutset(15.0d);
        legendTitle1.setPadding(rectangleInsets19);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle1.getSources();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 15.0d + "'", double24 == 15.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        legendTitle1.setWidth(0.0d);
        legendTitle1.setNotify(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle1.getLegendItemGraphicPadding();
        double double24 = rectangleInsets22.trimWidth((double) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 96.0d + "'", double24 == 96.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart9.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart9.createBufferedImage(178, 2, 1, chartRenderingInfo15);
        java.awt.RenderingHints renderingHints17 = jFreeChart9.getRenderingHints();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot18 = jFreeChart9.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertNotNull(renderingHints17);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Shape shape0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        try {
            org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, (int) (short) 0, (int) '4', (java.lang.Comparable) 90.0d, "Pie Plot", "Rotation.CLOCKWISE");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset((double) '#');
        java.lang.String str8 = rectangleInsets5.toString();
        double double10 = rectangleInsets5.calculateLeftOutset((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str8.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle1.setPosition(rectangleEdge20);
        legendTitle1.setPadding((double) 10.0f, 0.0d, (double) 1.0f, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle1.getLegendItemGraphicPadding();
        double double29 = rectangleInsets27.trimWidth((double) 255);
        double double31 = rectangleInsets27.extendWidth((double) 15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 230.0d + "'", double29 == 230.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 40.0d + "'", double31 == 40.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle2.getTextAlignment();
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        legendTitle6.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer9 = null;
        legendTitle6.setWrapper(blockContainer9);
        legendTitle6.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle6.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle6.setWidth((double) '4');
        legendTitle6.setWidth(0.0d);
        java.awt.Font font25 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        legendTitle6.setItemFont(font25);
        org.jfree.chart.event.TitleChangeListener titleChangeListener27 = null;
        legendTitle6.removeChangeListener(titleChangeListener27);
        boolean boolean29 = horizontalAlignment4.equals((java.lang.Object) legendTitle6);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.lang.Object obj2 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        piePlot1.handleClick(0, (int) '4', plotRenderingInfo6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle2.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot11.setLabelOutlineStroke(stroke12);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        double double21 = rectangleInsets19.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle23.getBounds();
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets19.createInsetRectangle(rectangle2D24, false, true);
        double double29 = rectangleInsets19.calculateBottomOutset((double) 100);
        org.jfree.chart.util.UnitType unitType30 = rectangleInsets19.getUnitType();
        double double31 = rectangleInsets19.getRight();
        piePlot11.setInsets(rectangleInsets19, true);
        jFreeChart9.setPadding(rectangleInsets19);
        jFreeChart9.fireChartChanged();
        jFreeChart9.setBorderVisible(false);
        jFreeChart9.clearSubtitles();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 15.0d + "'", double31 == 15.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle1.getVerticalAlignment();
        java.awt.geom.Rectangle2D rectangle2D5 = legendTitle1.getBounds();
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        legendTitle7.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer10 = null;
        legendTitle7.setWrapper(blockContainer10);
        legendTitle7.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.calculateTopInset((double) '#');
        legendTitle7.setLegendItemGraphicPadding(rectangleInsets22);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle7.setPosition(rectangleEdge26);
        legendTitle1.setPosition(rectangleEdge26);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.lang.Object obj1 = null;
        boolean boolean2 = lineBorder0.equals(obj1);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        double double10 = rectangleInsets8.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle12.getBounds();
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets8.createInsetRectangle(rectangle2D13, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D13, "Rotation.CLOCKWISE");
        java.lang.String str19 = chartEntity18.toString();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        chartEntity18.setArea(shape20);
        boolean boolean22 = lineBorder0.equals((java.lang.Object) shape20);
        java.awt.Stroke stroke23 = lineBorder0.getStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ChartEntity: tooltip = Rotation.CLOCKWISE" + "'", str19.equals("ChartEntity: tooltip = Rotation.CLOCKWISE"));
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.setValue((java.lang.Number) 15, (java.lang.Comparable) 100, (java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean7 = defaultKeyedValues2D0.equals((java.lang.Object) (short) 0);
        int int9 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) 0.5f);
        java.util.List list10 = defaultKeyedValues2D0.getRowKeys();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        pieLabelDistributor1.distributeLabels(100.0d, (double) (byte) 0);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord5 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart9.setTextAntiAlias(true);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint14 = textTitle13.getBackgroundPaint();
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart9.removeChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 0, (double) 100.0f, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.setInfo("");
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
//        java.lang.String str5 = projectInfo3.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Rotation.CLOCKWISE" + "'", str5.equals("Rotation.CLOCKWISE"));
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.setValue((java.lang.Number) 15, (java.lang.Comparable) 100, (java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean7 = defaultKeyedValues2D0.equals((java.lang.Object) (short) 0);
        try {
            defaultKeyedValues2D0.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean7 = piePlot1.equals((java.lang.Object) rectangleAnchor6);
        java.awt.Paint paint9 = piePlot1.getSectionPaint((java.lang.Comparable) 15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = piePlot1.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor12 = new org.jfree.chart.plot.PieLabelDistributor(0);
        pieLabelDistributor12.clear();
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor12);
        org.jfree.chart.plot.Plot plot15 = piePlot1.getParent();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNull(plot15);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        org.jfree.data.general.DatasetGroup datasetGroup5 = piePlot1.getDatasetGroup();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(datasetGroup5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.CENTER", "ChartEntity: tooltip = Rotation.CLOCKWISE", "RectangleAnchor.BOTTOM_RIGHT", "Rotation.CLOCKWISE", "rect");
        basicProjectInfo5.addOptionalLibrary("UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        piePlot1.setBackgroundAlpha(1.0f);
        try {
            piePlot1.setBackgroundImageAlpha((float) (-49088));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        int int10 = jFreeChart9.getSubtitleCount();
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font12);
        java.awt.Paint paint14 = textTitle13.getPaint();
        java.lang.Object obj15 = textTitle13.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getTextAlignment();
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        textTitle13.setFont(font18);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        legendTitle22.setWrapper(blockContainer25);
        legendTitle22.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockBorder36.getInsets();
        double double39 = rectangleInsets37.calculateTopInset((double) '#');
        legendTitle22.setLegendItemGraphicPadding(rectangleInsets37);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle22.setPosition(rectangleEdge41);
        textTitle13.setPosition(rectangleEdge41);
        java.awt.Paint paint44 = null;
        textTitle13.setBackgroundPaint(paint44);
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle13);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        legendTitle49.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment52 = legendTitle49.getVerticalAlignment();
        java.awt.geom.Rectangle2D rectangle2D53 = legendTitle49.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = null;
        try {
            jFreeChart9.draw(graphics2D47, rectangle2D53, chartRenderingInfo54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(verticalAlignment52);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray2 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle6.getBounds();
        java.awt.Shape[] shapeArray8 = new java.awt.Shape[] { rectangle2D7 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray4, shapeArray8);
        java.awt.Paint paint10 = defaultDrawingSupplier9.getNextFillPaint();
        java.awt.Paint paint11 = defaultDrawingSupplier9.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(shapeArray8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        piePlot1.setOutlineVisible(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot1.removeChangeListener(plotChangeListener9);
        piePlot1.setCircular(true);
        piePlot1.setPieIndex(0);
        piePlot1.setForegroundAlpha(0.0f);
        boolean boolean17 = piePlot1.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        int int10 = jFreeChart9.getSubtitleCount();
        int int11 = jFreeChart9.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot14.setLabelOutlineStroke(stroke15);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets22.createInsetRectangle(rectangle2D27, false, true);
        double double32 = rectangleInsets22.calculateBottomOutset((double) 100);
        org.jfree.chart.util.UnitType unitType33 = rectangleInsets22.getUnitType();
        double double34 = rectangleInsets22.getRight();
        piePlot14.setInsets(rectangleInsets22, true);
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle38.getBounds();
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets22.createInsetRectangle(rectangle2D39);
        try {
            jFreeChart9.draw(graphics2D12, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(unitType33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 15.0d + "'", double34 == 15.0d);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ChartEntity: tooltip = Rotation.CLOCKWISE", "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartEntity: tooltip = Rotation.CLOCKWISE" + "'", str3.equals("ChartEntity: tooltip = Rotation.CLOCKWISE"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        java.awt.Font font5 = piePlot1.getLabelFont();
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) (byte) -1);
        legendTitle8.setItemLabelPadding(rectangleInsets16);
        java.lang.Object obj20 = null;
        columnArrangement6.add((org.jfree.chart.block.Block) legendTitle8, obj20);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment23, verticalAlignment24, (double) 100L, (double) (short) -1);
        columnArrangement27.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource22, (org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement6, (org.jfree.chart.block.Arrangement) columnArrangement29);
        java.awt.Color color32 = java.awt.Color.orange;
        java.awt.Color color33 = color32.darker();
        boolean boolean34 = columnArrangement29.equals((java.lang.Object) color32);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        boolean boolean3 = strokeMap0.containsKey((java.lang.Comparable) 100.0f);
        java.lang.Object obj4 = strokeMap0.clone();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent(obj4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.setValue((java.lang.Number) 15, (java.lang.Comparable) 100, (java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        defaultKeyedValues2D0.removeColumn((int) (short) 0);
        try {
            java.lang.Comparable comparable9 = defaultKeyedValues2D0.getColumnKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        legendTitle9.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        legendTitle9.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle9.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle9.setWidth((double) '4');
        legendTitle9.setWidth(0.0d);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle9.setItemPaint((java.awt.Paint) color28);
        boolean boolean30 = piePlot7.equals((java.lang.Object) legendTitle9);
        piePlot7.zoom((double) 100L);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle33 = piePlot7.getLabelLinkStyle();
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle33);
        java.awt.Paint paint35 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle33);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets11.createInsetRectangle(rectangle2D16, false, true);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createOutsetRectangle(rectangle2D19, true, false);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity29 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D22, pieDataset23, (int) (short) 10, 0, (java.lang.Comparable) 100.0d, "", "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!");
        int int30 = pieSectionEntity29.getPieIndex();
        pieSectionEntity29.setPieIndex((int) '#');
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color1 = color0.darker();
        java.awt.Color color2 = color1.darker();
        float[] floatArray6 = null;
        float[] floatArray7 = java.awt.Color.RGBtoHSB(3, 0, 15, floatArray6);
        try {
            float[] floatArray8 = color2.getRGBComponents(floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        multiplePiePlot0.setBackgroundAlpha((float) (byte) -1);
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("UnitType.RELATIVE");
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle1.arrange(graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder8.getInsets();
        double double11 = rectangleInsets9.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        java.awt.geom.Rectangle2D rectangle2D14 = legendTitle13.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets9.createInsetRectangle(rectangle2D14, false, true);
        double double19 = rectangleInsets9.calculateBottomOutset((double) 100);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets9.getUnitType();
        double double21 = rectangleInsets9.getRight();
        piePlot1.setInsets(rectangleInsets9, true);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot25.setLabelOutlineStroke(stroke26);
        piePlot25.setIgnoreNullValues(false);
        java.awt.Paint paint30 = piePlot25.getLabelLinkPaint();
        piePlot1.setBaseSectionOutlinePaint(paint30);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 15.0d + "'", double21 == 15.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean10 = library5.equals((java.lang.Object) chartColor9);
        float[] floatArray17 = new float[] { (byte) -1, (byte) -1, (-1) };
        float[] floatArray18 = java.awt.Color.RGBtoHSB(2, (int) (byte) -1, (int) 'a', floatArray17);
        float[] floatArray19 = chartColor9.getRGBColorComponents(floatArray17);
        float[] floatArray20 = color0.getColorComponents(floatArray19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        legendTitle4.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        legendTitle4.setWrapper(blockContainer7);
        legendTitle4.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle4.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle4.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockBorder25.getInsets();
        double double28 = rectangleInsets26.calculateTopInset((double) '#');
        java.lang.String str29 = rectangleInsets26.toString();
        legendTitle4.setLegendItemGraphicPadding(rectangleInsets26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendTitle4.getLegendItemGraphicAnchor();
        try {
            java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 15, (double) 10.0f, rectangleAnchor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str29.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor31);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets11.createInsetRectangle(rectangle2D16, false, true);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createOutsetRectangle(rectangle2D19, true, false);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity29 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D22, pieDataset23, (int) (short) 10, 0, (java.lang.Comparable) 100.0d, "", "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!");
        java.lang.Comparable comparable30 = null;
        pieSectionEntity29.setSectionKey(comparable30);
        pieSectionEntity29.setSectionKey((java.lang.Comparable) (short) 100);
        pieSectionEntity29.setPieIndex(0);
        pieSectionEntity29.setSectionIndex((int) (byte) 100);
        pieSectionEntity29.setPieIndex(2);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        legendTitle4.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        legendTitle4.setWrapper(blockContainer7);
        legendTitle4.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle4.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle4.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockBorder25.getInsets();
        double double28 = rectangleInsets26.calculateTopInset((double) '#');
        java.lang.String str29 = rectangleInsets26.toString();
        legendTitle4.setLegendItemGraphicPadding(rectangleInsets26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendTitle4.getLegendItemGraphicAnchor();
        try {
            java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (short) 10, (double) 15, rectangleAnchor31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str29.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor31);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double15 = rectangleInsets13.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle17.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createInsetRectangle(rectangle2D18, false, true);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createOutsetRectangle(rectangle2D21, true, false);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24, "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!", "");
        try {
            blockBorder0.draw(graphics2D1, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        boolean boolean3 = jFreeChartResources0.containsKey("PieLabelLinkStyle.STANDARD");
        try {
            java.lang.String[] strArray5 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        piePlot1.setOutlineVisible(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot1.removeChangeListener(plotChangeListener9);
        piePlot1.setCircular(true);
        piePlot1.setPieIndex(0);
        piePlot1.setForegroundAlpha(0.0f);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = piePlot1.getLegendLabelURLGenerator();
        java.lang.Object obj18 = null;
        boolean boolean19 = piePlot1.equals(obj18);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(pieURLGenerator17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Color color4 = java.awt.Color.darkGray;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) (short) 1, (double) 0L, 230.0d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int3 = java.awt.Color.HSBtoRGB((float) 178, 0.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle2.getTextAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textTitle2.arrange(graphics2D5, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setVersion("RectangleAnchor.BOTTOM_RIGHT");
        basicProjectInfo0.setName("{0}");
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.QUAD_CURVE" + "'", str1.equals("PieLabelLinkStyle.QUAD_CURVE"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.setIgnoreNullValues(false);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.plot.Plot plot7 = piePlot1.getParent();
        try {
            float float8 = plot7.getForegroundAlpha();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.Object obj0 = null;
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        double double8 = legendTitle3.getHeight();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle3.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Font font11 = legendTitle3.getItemFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.removeChangeListener(plotChangeListener14);
        java.awt.Font font16 = piePlot13.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean19 = piePlot13.equals((java.lang.Object) rectangleAnchor18);
        piePlot13.setShadowYOffset(0.0d);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("Rotation.CLOCKWISE", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        java.awt.Paint paint24 = jFreeChart23.getBorderPaint();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int3 = java.awt.Color.HSBtoRGB((float) (-49088), (float) (-16777216), (float) (-1L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16646144) + "'", int3 == (-16646144));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.geom.Rectangle2D rectangle2D2 = legendTitle1.getBounds();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        legendTitle4.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer7 = null;
        legendTitle4.setWrapper(blockContainer7);
        legendTitle4.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        double double21 = rectangleInsets19.calculateTopInset((double) '#');
        legendTitle4.setLegendItemGraphicPadding(rectangleInsets19);
        double double24 = rectangleInsets19.calculateRightOutset(15.0d);
        legendTitle1.setPadding(rectangleInsets19);
        double double27 = rectangleInsets19.calculateBottomInset(0.08d);
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 15.0d + "'", double24 == 15.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.lang.Object obj4 = textTitle2.clone();
        java.lang.Object obj5 = textTitle2.clone();
        java.lang.String str6 = textTitle2.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) 1L);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        int int10 = jFreeChart9.getSubtitleCount();
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font12);
        java.awt.Paint paint14 = textTitle13.getPaint();
        java.lang.Object obj15 = textTitle13.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getTextAlignment();
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        textTitle13.setFont(font18);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        legendTitle22.setWrapper(blockContainer25);
        legendTitle22.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockBorder36.getInsets();
        double double39 = rectangleInsets37.calculateTopInset((double) '#');
        legendTitle22.setLegendItemGraphicPadding(rectangleInsets37);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle22.setPosition(rectangleEdge41);
        textTitle13.setPosition(rectangleEdge41);
        java.awt.Paint paint44 = null;
        textTitle13.setBackgroundPaint(paint44);
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle13);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        legendTitle48.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer51 = null;
        legendTitle48.setWrapper(blockContainer51);
        double double53 = legendTitle48.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle48.setLegendItemGraphicLocation(rectangleAnchor54);
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle48);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        legendTitle59.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment62 = legendTitle59.getVerticalAlignment();
        java.awt.geom.Rectangle2D rectangle2D63 = legendTitle59.getBounds();
        try {
            jFreeChart9.draw(graphics2D57, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(verticalAlignment62);
        org.junit.Assert.assertNotNull(rectangle2D63);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.Color color1 = color0.darker();
        int int2 = color1.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-5075968) + "'", int2 == (-5075968));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        piePlot1.setOutlineVisible(false);
        java.awt.Paint paint7 = piePlot1.getOutlinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        java.awt.Font font1 = null;
//        org.jfree.data.general.PieDataset pieDataset2 = null;
//        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
//        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
//        piePlot3.removeChangeListener(plotChangeListener4);
//        piePlot3.setBackgroundAlpha(1.0f);
//        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
//        org.jfree.data.general.PieDataset pieDataset10 = null;
//        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
//        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        piePlot11.setLabelOutlineStroke(stroke12);
//        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
//        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
//        double double21 = rectangleInsets19.calculateTopInset((double) (byte) -1);
//        org.jfree.chart.LegendItemSource legendItemSource22 = null;
//        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
//        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle23.getBounds();
//        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets19.createInsetRectangle(rectangle2D24, false, true);
//        double double29 = rectangleInsets19.calculateBottomOutset((double) 100);
//        org.jfree.chart.util.UnitType unitType30 = rectangleInsets19.getUnitType();
//        double double31 = rectangleInsets19.getRight();
//        piePlot11.setInsets(rectangleInsets19, true);
//        jFreeChart9.setPadding(rectangleInsets19);
//        org.jfree.chart.ui.ProjectInfo projectInfo35 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo35.setInfo("");
//        projectInfo35.setName("UnitType.RELATIVE");
//        java.lang.String str40 = projectInfo35.getCopyright();
//        java.util.List list41 = projectInfo35.getContributors();
//        try {
//            jFreeChart9.setSubtitles(list41);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.ui.Contributor cannot be cast to org.jfree.chart.title.Title");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(stroke12);
//        org.junit.Assert.assertNotNull(rectangleInsets19);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
//        org.junit.Assert.assertNotNull(rectangle2D24);
//        org.junit.Assert.assertNotNull(rectangle2D27);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
//        org.junit.Assert.assertNotNull(unitType30);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 15.0d + "'", double31 == 15.0d);
//        org.junit.Assert.assertNotNull(projectInfo35);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str40.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertNotNull(list41);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        float[] floatArray7 = null;
        float[] floatArray8 = java.awt.Color.RGBtoHSB(3, 0, 15, floatArray7);
        float[] floatArray9 = color3.getRGBColorComponents(floatArray8);
        float[] floatArray10 = java.awt.Color.RGBtoHSB(3, (int) (short) 100, 2, floatArray9);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 0, (-1), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.setInfo("");
//        java.lang.String str3 = projectInfo0.getLicenceText();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        java.awt.Font font6 = piePlot3.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean9 = piePlot3.equals((java.lang.Object) rectangleAnchor8);
        piePlot3.setShadowYOffset(0.0d);
        boolean boolean12 = blockBorder1.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets5.createInsetRectangle(rectangle2D10, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D13);
        java.lang.String str15 = chartEntity14.getShapeType();
        java.awt.Color color16 = java.awt.Color.orange;
        java.awt.Color color17 = color16.darker();
        boolean boolean18 = chartEntity14.equals((java.lang.Object) color16);
        java.lang.String str19 = chartEntity14.getShapeCoords();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "rect" + "'", str15.equals("rect"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0,1,1,-1" + "'", str19.equals("0,1,1,-1"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        legendTitle1.setWidth(0.0d);
        legendTitle1.setNotify(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = legendTitle1.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D23 = null;
        try {
            org.jfree.chart.util.Size2D size2D24 = legendTitle1.arrange(graphics2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment22);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double15 = rectangleInsets13.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle17.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createInsetRectangle(rectangle2D18, false, true);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createOutsetRectangle(rectangle2D21, true, false);
        int int25 = objectList1.indexOf((java.lang.Object) true);
        org.jfree.chart.ui.ProjectInfo projectInfo26 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library31 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        projectInfo26.addLibrary(library31);
        org.jfree.chart.ui.Library library37 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor41 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean42 = library37.equals((java.lang.Object) chartColor41);
        projectInfo26.addOptionalLibrary(library37);
        org.jfree.chart.ui.Library library48 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        java.lang.String str49 = library48.getLicenceName();
        projectInfo26.addLibrary(library48);
        boolean boolean51 = objectList1.equals((java.lang.Object) library48);
        java.lang.Object obj53 = objectList1.get((int) (byte) 0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot55 = new org.jfree.chart.plot.MultiplePiePlot();
        try {
            objectList1.set(0, (java.lang.Object) multiplePiePlot55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(projectInfo26);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(obj53);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.TableOrder tableOrder1 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot2.getPieChart();
        multiplePiePlot0.setPieChart(jFreeChart3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.UnitType unitType6 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        double double19 = rectangleInsets17.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle21.getBounds();
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets17.createInsetRectangle(rectangle2D22, false, true);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets11.createOutsetRectangle(rectangle2D25, true, false);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity35 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D28, pieDataset29, (int) (short) 10, 0, (java.lang.Comparable) 100.0d, "", "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!");
        try {
            jFreeChart3.draw(graphics2D5, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        java.awt.Paint paint13 = defaultDrawingSupplier10.getNextOutlinePaint();
        java.awt.Paint[] paintArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray15 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke17 };
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        java.awt.geom.Rectangle2D rectangle2D21 = legendTitle20.getBounds();
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] { rectangle2D21 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray15, strokeArray16, strokeArray18, shapeArray22);
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextFillPaint();
        boolean boolean25 = defaultDrawingSupplier10.equals((java.lang.Object) defaultDrawingSupplier23);
        java.awt.Paint paint26 = defaultDrawingSupplier10.getNextFillPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str1 = tableOrder0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = tableOrder0.equals(obj2);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_COLUMN" + "'", str1.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.geom.Rectangle2D rectangle2D2 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D2);
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle2.getPosition();
        java.lang.String str5 = textTitle2.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        piePlot1.setOutlineVisible(false);
        java.awt.Paint paint7 = piePlot1.getOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset8 = piePlot1.getDataset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(pieDataset8);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((-1.0d), (double) (byte) 100, 96.0d, (double) 10.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        boolean boolean2 = blockContainer1.isEmpty();
        java.util.List list3 = blockContainer1.getBlocks();
        blockContainer1.clear();
        boolean boolean5 = blockContainer1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (short) 0);
        java.lang.Object obj5 = standardPieSectionLabelGenerator1.clone();
        java.text.AttributedString attributedString7 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel(178, attributedString7);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        int int10 = jFreeChart9.getSubtitleCount();
        int int11 = jFreeChart9.getBackgroundImageAlignment();
        java.awt.Paint paint12 = jFreeChart9.getBackgroundPaint();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = blockBorder24.getInsets();
        double double27 = rectangleInsets25.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets25.createInsetRectangle(rectangle2D30, false, true);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets19.createOutsetRectangle(rectangle2D33, true, false);
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity43 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D36, pieDataset37, (int) (short) 10, 0, (java.lang.Comparable) 100.0d, "", "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!");
        try {
            jFreeChart9.draw(graphics2D13, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D36);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.geom.Rectangle2D rectangle2D2 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D2, "");
        java.lang.String str5 = chartEntity4.getShapeType();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator6 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator7 = null;
        java.lang.String str8 = chartEntity4.getImageMapAreaTag(toolTipTagFragmentGenerator6, uRLTagFragmentGenerator7);
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "rect" + "'", str5.equals("rect"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("rect", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.awt.Paint paint10 = piePlot3.getLabelLinkPaint();
        java.awt.Stroke stroke11 = null;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot13.setLabelOutlineStroke(stroke14);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        double double23 = rectangleInsets21.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle25.getBounds();
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets21.createInsetRectangle(rectangle2D26, false, true);
        double double31 = rectangleInsets21.calculateBottomOutset((double) 100);
        org.jfree.chart.util.UnitType unitType32 = rectangleInsets21.getUnitType();
        double double33 = rectangleInsets21.getRight();
        piePlot13.setInsets(rectangleInsets21, true);
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle37.getBounds();
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets21.createInsetRectangle(rectangle2D38);
        try {
            org.jfree.chart.block.LineBorder lineBorder40 = new org.jfree.chart.block.LineBorder(paint10, stroke11, rectangleInsets21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 15.0d + "'", double33 == 15.0d);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        double double25 = rectangleInsets23.calculateTopInset((double) '#');
        java.lang.String str26 = rectangleInsets23.toString();
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets23);
        java.awt.Paint paint28 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str26.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        double double20 = rectangleInsets18.calculateTopInset((double) '#');
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets18);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = legendTitle3.getSources();
        boolean boolean23 = strokeMap0.equals((java.lang.Object) legendItemSourceArray22);
        strokeMap0.clear();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        java.awt.Stroke stroke28 = piePlot27.getOutlineStroke();
        strokeMap0.put((java.lang.Comparable) 4.0d, stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.geom.Rectangle2D rectangle2D2 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D2, "");
        java.lang.String str5 = chartEntity4.getShapeType();
        chartEntity4.setToolTipText("ChartEntity: tooltip = Rotation.CLOCKWISE");
        java.lang.Object obj8 = chartEntity4.clone();
        java.lang.String str9 = chartEntity4.getURLText();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "rect" + "'", str5.equals("rect"));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (byte) 10);
        java.awt.Color color3 = color2.darker();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.CENTER", "ChartEntity: tooltip = Rotation.CLOCKWISE", "RectangleAnchor.BOTTOM_RIGHT", "Rotation.CLOCKWISE", "rect");
        java.lang.String str6 = basicProjectInfo5.getInfo();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str6.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Image image2 = piePlot1.getBackgroundImage();
        java.awt.Paint paint3 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator4);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.setInfo("");
//        projectInfo0.setName("UnitType.RELATIVE");
//        java.lang.String str5 = projectInfo0.getCopyright();
//        java.util.List list6 = projectInfo0.getContributors();
//        java.awt.Image image7 = projectInfo0.getLogo();
//        java.awt.Image image8 = projectInfo0.getLogo();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str5.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertNotNull(image7);
//        org.junit.Assert.assertNotNull(image8);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.setValue((java.lang.Number) 15, (java.lang.Comparable) 100, (java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        defaultKeyedValues2D0.removeColumn((int) (short) 0);
        defaultKeyedValues2D0.addValue((java.lang.Number) 90.0d, (java.lang.Comparable) "PieLabelLinkStyle.STANDARD", (java.lang.Comparable) (-555));
        defaultKeyedValues2D0.addValue((java.lang.Number) 178, (java.lang.Comparable) (short) -1, (java.lang.Comparable) 10.0d);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue((java.lang.Comparable) "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n", (java.lang.Comparable) "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.geom.Rectangle2D rectangle2D2 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D2, "");
        java.lang.String str5 = chartEntity4.toString();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartEntity: tooltip = " + "'", str5.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = blockContainer1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.lang.Object obj4 = textTitle2.clone();
        java.lang.Object obj5 = textTitle2.clone();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Font font8 = piePlot7.getLabelFont();
        textTitle2.setFont(font8);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.CENTER", "ChartEntity: tooltip = Rotation.CLOCKWISE", "RectangleAnchor.BOTTOM_RIGHT", "Rotation.CLOCKWISE", "rect");
        projectInfo3.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        java.lang.String str12 = projectInfo3.getName();
        projectInfo3.setVersion("0,1,1,-1");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnitType.RELATIVE" + "'", str12.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        legendTitle1.setWidth(0.0d);
        legendTitle1.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(rectangleAnchor22);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.incrementValue((double) (byte) 0, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 100");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) "{0}");
        java.lang.Comparable comparable5 = null;
        try {
            defaultCategoryDataset0.setValue((java.lang.Number) (byte) 100, (java.lang.Comparable) (-1.0d), comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.Font font4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.removeChangeListener(plotChangeListener7);
        piePlot6.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) piePlot6, false);
        jFreeChart12.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        java.awt.image.BufferedImage bufferedImage19 = jFreeChart12.createBufferedImage(178, 2, 1, chartRenderingInfo18);
        org.jfree.chart.ui.ProjectInfo projectInfo23 = new org.jfree.chart.ui.ProjectInfo("Rotation.CLOCKWISE", "PieLabelLinkStyle.STANDARD", "Multiple Pie Plot", (java.awt.Image) bufferedImage19, "RectangleEdge.TOP", "TableOrder.BY_COLUMN", "Pie Plot");
        org.junit.Assert.assertNotNull(bufferedImage19);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceText();
//        java.util.List list2 = projectInfo0.getContributors();
//        projectInfo0.addOptionalLibrary("ChartEntity: tooltip = ");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
//        org.junit.Assert.assertNotNull(list2);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        java.awt.Font font18 = legendTitle1.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.TOP;
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge19);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        multiplePiePlot0.setBackgroundImageAlignment((int) (byte) 1);
        java.awt.Image image5 = multiplePiePlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNull(image5);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Font font6 = null;
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.removeChangeListener(plotChangeListener9);
        piePlot8.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font6, (org.jfree.chart.plot.Plot) piePlot8, false);
        jFreeChart14.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage(178, 2, 1, chartRenderingInfo20);
        java.awt.Paint paint22 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        jFreeChart14.setBorderPaint(paint22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart14, chartChangeEventType24);
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((double) 2, (double) 8, (double) 255, 90.0d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        piePlot1.setOutlineVisible(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.UnitType unitType10 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType10, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        double double23 = rectangleInsets21.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle25.getBounds();
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets21.createInsetRectangle(rectangle2D26, false, true);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets15.createOutsetRectangle(rectangle2D29, true, false);
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = blockBorder37.getInsets();
        double double40 = rectangleInsets38.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource41 = null;
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle(legendItemSource41);
        java.awt.geom.Rectangle2D rectangle2D43 = legendTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets38.createInsetRectangle(rectangle2D43, false, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D43, rectangleAnchor47);
        org.jfree.chart.plot.PlotState plotState49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        try {
            piePlot1.draw(graphics2D9, rectangle2D29, point2D48, plotState49, plotRenderingInfo50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(point2D48);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        java.awt.Font font18 = legendTitle1.getItemFont();
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        legendTitle20.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer23 = null;
        legendTitle20.setWrapper(blockContainer23);
        legendTitle20.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle20.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle20.setWidth((double) '4');
        java.awt.Font font37 = legendTitle20.getItemFont();
        legendTitle1.setItemFont(font37);
        legendTitle1.setHeight(15.0d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(font37);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        int int10 = jFreeChart9.getSubtitleCount();
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font12);
        java.awt.Paint paint14 = textTitle13.getPaint();
        java.lang.Object obj15 = textTitle13.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getTextAlignment();
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        textTitle13.setFont(font18);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        legendTitle22.setWrapper(blockContainer25);
        legendTitle22.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockBorder36.getInsets();
        double double39 = rectangleInsets37.calculateTopInset((double) '#');
        legendTitle22.setLegendItemGraphicPadding(rectangleInsets37);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle22.setPosition(rectangleEdge41);
        textTitle13.setPosition(rectangleEdge41);
        java.awt.Paint paint44 = null;
        textTitle13.setBackgroundPaint(paint44);
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle13);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        legendTitle48.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer51 = null;
        legendTitle48.setWrapper(blockContainer51);
        double double53 = legendTitle48.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle48.setLegendItemGraphicLocation(rectangleAnchor54);
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle48);
        jFreeChart9.setTitle("rect");
        try {
            java.awt.image.BufferedImage bufferedImage61 = jFreeChart9.createBufferedImage((-1), (-49088));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (-49088) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        java.util.List list5 = projectInfo3.getContributors();
        java.awt.Image image6 = projectInfo3.getLogo();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer11 = null;
        legendTitle8.setWrapper(blockContainer11);
        legendTitle8.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle8.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = legendTitle8.getVerticalAlignment();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray24 = legendTitle8.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle8.getLegendItemGraphicPadding();
        java.awt.Paint paint26 = legendTitle8.getBackgroundPaint();
        org.jfree.chart.ui.ProjectInfo projectInfo27 = org.jfree.chart.JFreeChart.INFO;
        projectInfo27.setInfo("");
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint32 = textTitle31.getBackgroundPaint();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.util.UnitType unitType34 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType34, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder44 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = blockBorder44.getInsets();
        double double47 = rectangleInsets45.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        java.awt.geom.Rectangle2D rectangle2D50 = legendTitle49.getBounds();
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets45.createInsetRectangle(rectangle2D50, false, true);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets39.createOutsetRectangle(rectangle2D53, true, false);
        org.jfree.chart.entity.ChartEntity chartEntity59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D56, "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!", "");
        org.jfree.chart.ui.ProjectInfo projectInfo60 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library65 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        projectInfo60.addLibrary(library65);
        java.lang.Object obj67 = textTitle31.draw(graphics2D33, rectangle2D56, (java.lang.Object) projectInfo60);
        projectInfo27.addLibrary((org.jfree.chart.ui.Library) projectInfo60);
        boolean boolean69 = legendTitle8.equals((java.lang.Object) projectInfo60);
        projectInfo3.addLibrary((org.jfree.chart.ui.Library) projectInfo60);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(image6);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(legendItemSourceArray24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(projectInfo27);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(projectInfo60);
        org.junit.Assert.assertNull(obj67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets11.createInsetRectangle(rectangle2D16, false, true);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createOutsetRectangle(rectangle2D19, true, false);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity29 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D22, pieDataset23, (int) (short) 10, 0, (java.lang.Comparable) 100.0d, "", "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!");
        java.lang.Comparable comparable30 = null;
        pieSectionEntity29.setSectionKey(comparable30);
        try {
            java.lang.String str32 = pieSectionEntity29.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ChartEntity: tooltip = Rotation.CLOCKWISE", "0,1,1,-1", "", "ChartEntity: tooltip = ", "{0}");
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        java.awt.Font font5 = piePlot1.getLabelFont();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Stroke stroke11 = piePlot10.getOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 52.0d, stroke11);
        piePlot1.setBackgroundImageAlignment(8);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = java.awt.Color.BLUE;
        java.awt.Color color4 = java.awt.Color.BLUE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        int int6 = color5.getBlue();
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, color1, color2, color3, color4, color5 };
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color12 = java.awt.Color.BLUE;
        boolean boolean14 = color12.equals((java.lang.Object) 0);
        java.awt.Color color17 = java.awt.Color.getColor("", (int) (byte) 10);
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor11, color12, color17 };
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color27 = java.awt.Color.BLUE;
        java.awt.Color color28 = java.awt.Color.green;
        java.awt.Color color29 = java.awt.Color.WHITE;
        int int30 = color29.getBlue();
        java.awt.Color color31 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { chartColor22, chartColor26, color27, color28, color29, color31 };
        java.awt.Stroke stroke33 = null;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke33 };
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = null;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray18, paintArray32, strokeArray34, strokeArray35, shapeArray37);
        java.awt.Paint paint39 = defaultDrawingSupplier38.getNextPaint();
        boolean boolean41 = defaultDrawingSupplier38.equals((java.lang.Object) (-555));
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.Plot plot6 = plotChangeEvent5.getPlot();
        org.jfree.chart.plot.Plot plot7 = plot6.getRootPlot();
        java.awt.Image image8 = null;
        plot7.setBackgroundImage(image8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) plot7);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle10);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        titleChangeEvent11.setChart(jFreeChart12);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(plot7);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 1, (float) (short) 0, (float) (byte) 10);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setBackgroundImageAlignment((int) (short) 0);
        float float15 = piePlot1.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Block block2 = null;
        org.jfree.chart.ui.Library library7 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean12 = library7.equals((java.lang.Object) chartColor11);
        blockContainer1.add(block2, (java.lang.Object) boolean12);
        java.lang.Object obj14 = blockContainer1.clone();
        org.jfree.chart.block.Arrangement arrangement15 = null;
        try {
            blockContainer1.setArrangement(arrangement15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        projectInfo5.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        projectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo8);
        java.util.List list10 = projectInfo8.getContributors();
        java.awt.Image image11 = projectInfo8.getLogo();
        projectInfo0.setLogo(image11);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(image11);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        double double6 = legendTitle1.getHeight();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle1.setBackgroundPaint((java.awt.Paint) color7);
        int int9 = color7.getRed();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 128 + "'", int9 == 128);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.removeChangeListener(plotChangeListener5);
        java.awt.Font font7 = piePlot4.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean10 = piePlot4.equals((java.lang.Object) rectangleAnchor9);
        java.awt.Paint paint12 = piePlot4.getSectionPaint((java.lang.Comparable) 15);
        piePlot4.setPieIndex((int) (byte) 1);
        java.awt.Paint paint15 = piePlot4.getNoDataMessagePaint();
        boolean boolean16 = multiplePiePlot0.equals((java.lang.Object) paint15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        double double25 = rectangleInsets23.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        java.awt.geom.Rectangle2D rectangle2D28 = legendTitle27.getBounds();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets23.createInsetRectangle(rectangle2D28, false, true);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockBorder36.getInsets();
        double double39 = rectangleInsets37.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        java.awt.geom.Rectangle2D rectangle2D42 = legendTitle41.getBounds();
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets37.createInsetRectangle(rectangle2D42, false, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Point2D point2D47 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor46);
        org.jfree.chart.plot.PlotState plotState48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            multiplePiePlot0.draw(graphics2D17, rectangle2D28, point2D47, plotState48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.setIgnoreNullValues(false);
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        java.awt.Paint paint7 = piePlot1.getBaseSectionOutlinePaint();
        double double8 = piePlot1.getStartAngle();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        pieLabelDistributor1.clear();
        int int3 = pieLabelDistributor1.getItemCount();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord5 = pieLabelDistributor1.getPieLabelRecord((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        double double25 = rectangleInsets23.calculateTopInset((double) '#');
        java.lang.String str26 = rectangleInsets23.toString();
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets23);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        legendTitle29.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        legendTitle33.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer36 = null;
        legendTitle33.setWrapper(blockContainer36);
        legendTitle33.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle33.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = legendTitle33.getVerticalAlignment();
        java.lang.String str49 = verticalAlignment48.toString();
        legendTitle29.setVerticalAlignment(verticalAlignment48);
        legendTitle1.setVerticalAlignment(verticalAlignment48);
        java.lang.String str52 = verticalAlignment48.toString();
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str26.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "VerticalAlignment.CENTER" + "'", str49.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "VerticalAlignment.CENTER" + "'", str52.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        int int10 = jFreeChart9.getSubtitleCount();
        int int11 = jFreeChart9.getBackgroundImageAlignment();
        java.awt.Paint paint12 = jFreeChart9.getBackgroundPaint();
        jFreeChart9.setTitle("UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE 1.2.0-pre ().  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n");
        jFreeChart9.setAntiAlias(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        try {
            jFreeChart9.handleClick(15, (-16777216), chartRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Comparable comparable4 = null;
        try {
            java.awt.Paint paint5 = piePlot1.getSectionPaint(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        projectInfo0.setVersion("Rotation.CLOCKWISE");
//        projectInfo0.setVersion("TableOrder.BY_COLUMN");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE version 0,1,1,-1.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE 0,1,1,-1 ().  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE 0,1,1,-1 ().  (hi!).UnitType.RELATIVE 0,1,1,-1 ().VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).UnitType.RELATIVE 0,1,1,-1 ().UnitType.RELATIVE 0,1,1,-1 ().\nUnitType.RELATIVE LICENCE TERMS:\n" + "'", str1.equals("UnitType.RELATIVE version 0,1,1,-1.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE 0,1,1,-1 ().  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE 0,1,1,-1 ().  (hi!).UnitType.RELATIVE 0,1,1,-1 ().VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).UnitType.RELATIVE 0,1,1,-1 ().UnitType.RELATIVE 0,1,1,-1 ().\nUnitType.RELATIVE LICENCE TERMS:\n"));
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.setIgnoreNullValues(false);
        java.awt.Stroke stroke6 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean7 = piePlot1.isOutlineVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.setIgnoreNullValues(false);
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        org.jfree.chart.block.Arrangement arrangement7 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment8, verticalAlignment9, (double) 100L, (double) (short) -1);
        try {
            org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, arrangement7, (org.jfree.chart.block.Arrangement) columnArrangement12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-16646144));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "rect");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rect" + "'", str3.equals("rect"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        try {
            defaultCategoryDataset0.removeColumn((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        int int2 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.clear();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle3.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle3.setWidth((double) '4');
        legendTitle3.setWidth(0.0d);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle3.setItemPaint((java.awt.Paint) color22);
        boolean boolean24 = piePlot1.equals((java.lang.Object) legendTitle3);
        piePlot1.zoom((double) 100L);
        piePlot1.setForegroundAlpha((float) (-15728654));
        java.awt.Paint paint29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder(paint29);
        java.awt.Paint paint31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean32 = blockBorder30.equals((java.lang.Object) paint31);
        piePlot1.setLabelOutlinePaint(paint31);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        legendTitle1.setItemFont(font3);
        org.jfree.chart.block.BlockFrame blockFrame6 = legendTitle1.getFrame();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(blockFrame6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.removeChangeListener(plotChangeListener5);
        java.awt.Font font7 = piePlot4.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean10 = piePlot4.equals((java.lang.Object) rectangleAnchor9);
        java.awt.Paint paint12 = piePlot4.getSectionPaint((java.lang.Comparable) 15);
        piePlot4.setPieIndex((int) (byte) 1);
        java.awt.Paint paint15 = piePlot4.getNoDataMessagePaint();
        boolean boolean16 = multiplePiePlot0.equals((java.lang.Object) paint15);
        multiplePiePlot0.setLimit((double) (short) 1);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.Color color20 = java.awt.Color.DARK_GRAY;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        org.jfree.chart.util.UnitType unitType23 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets(unitType23, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = blockBorder33.getInsets();
        double double36 = rectangleInsets34.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle38.getBounds();
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets34.createInsetRectangle(rectangle2D39, false, true);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets28.createOutsetRectangle(rectangle2D42, true, false);
        org.jfree.data.general.PieDataset pieDataset46 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity52 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D45, pieDataset46, (int) (short) 10, 0, (java.lang.Comparable) 100.0d, "", "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!");
        java.awt.geom.AffineTransform affineTransform53 = null;
        java.awt.Font font55 = null;
        org.jfree.data.general.PieDataset pieDataset56 = null;
        org.jfree.chart.plot.PiePlot piePlot57 = new org.jfree.chart.plot.PiePlot(pieDataset56);
        org.jfree.chart.event.PlotChangeListener plotChangeListener58 = null;
        piePlot57.removeChangeListener(plotChangeListener58);
        piePlot57.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart63 = new org.jfree.chart.JFreeChart("", font55, (org.jfree.chart.plot.Plot) piePlot57, false);
        jFreeChart63.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo69 = null;
        java.awt.image.BufferedImage bufferedImage70 = jFreeChart63.createBufferedImage(178, 2, 1, chartRenderingInfo69);
        java.awt.RenderingHints renderingHints71 = jFreeChart63.getRenderingHints();
        java.awt.PaintContext paintContext72 = color20.createContext(colorModel21, rectangle22, rectangle2D45, affineTransform53, renderingHints71);
        try {
            multiplePiePlot0.drawBackground(graphics2D19, (java.awt.geom.Rectangle2D) rectangle22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(unitType23);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(bufferedImage70);
        org.junit.Assert.assertNotNull(renderingHints71);
        org.junit.Assert.assertNotNull(paintContext72);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj1 = blockContainer0.clone();
        boolean boolean2 = blockContainer0.isEmpty();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot5.setLabelOutlineStroke(stroke6);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double15 = rectangleInsets13.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle17.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createInsetRectangle(rectangle2D18, false, true);
        double double23 = rectangleInsets13.calculateBottomOutset((double) 100);
        org.jfree.chart.util.UnitType unitType24 = rectangleInsets13.getUnitType();
        double double25 = rectangleInsets13.getRight();
        piePlot5.setInsets(rectangleInsets13, true);
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets13.createInsetRectangle(rectangle2D30);
        java.lang.Object obj32 = null;
        try {
            java.lang.Object obj33 = blockContainer0.draw(graphics2D3, rectangle2D31, obj32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(unitType24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 15.0d + "'", double25 == 15.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        boolean boolean3 = legendTitle1.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        try {
            legendTitle1.setPosition(rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultCategoryDataset0.getColumnKey(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        java.lang.Object obj6 = null;
        boolean boolean7 = rectangleInsets5.equals(obj6);
        double double9 = rectangleInsets5.calculateRightOutset((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 15.0d + "'", double9 == 15.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        java.awt.Font font6 = piePlot3.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean9 = piePlot3.equals((java.lang.Object) rectangleAnchor8);
        java.awt.Paint paint11 = piePlot3.getSectionPaint((java.lang.Comparable) 15);
        piePlot3.setPieIndex((int) (byte) 1);
        java.awt.Paint paint14 = piePlot3.getNoDataMessagePaint();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        legendTitle16.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer19 = null;
        legendTitle16.setWrapper(blockContainer19);
        legendTitle16.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        boolean boolean26 = legendTitle16.getNotify();
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        legendTitle28.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer31 = null;
        legendTitle28.setWrapper(blockContainer31);
        legendTitle28.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        boolean boolean38 = legendTitle28.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle28.setPosition(rectangleEdge39);
        legendTitle16.setPosition(rectangleEdge39);
        boolean boolean42 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge39);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = null;
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        legendTitle45.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        legendTitle49.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer52 = null;
        legendTitle49.setWrapper(blockContainer52);
        legendTitle49.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle49.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment64 = legendTitle49.getVerticalAlignment();
        java.lang.String str65 = verticalAlignment64.toString();
        legendTitle45.setVerticalAlignment(verticalAlignment64);
        org.jfree.chart.block.BlockBorder blockBorder71 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = blockBorder71.getInsets();
        double double74 = rectangleInsets72.calculateLeftOutset(0.0d);
        double double76 = rectangleInsets72.calculateTopInset((double) (-1L));
        try {
            org.jfree.chart.title.TextTitle textTitle77 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ", font1, paint14, rectangleEdge39, horizontalAlignment43, verticalAlignment64, rectangleInsets72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(verticalAlignment64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "VerticalAlignment.CENTER" + "'", str65.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 10.0d + "'", double74 == 10.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue((java.lang.Comparable) (-16777216), (java.lang.Comparable) 255);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 255");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo3.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        projectInfo3.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo6);
        projectInfo3.setLicenceText("");
        java.awt.Font font11 = null;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.removeChangeListener(plotChangeListener14);
        piePlot13.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", font11, (org.jfree.chart.plot.Plot) piePlot13, false);
        jFreeChart19.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart19.createBufferedImage(178, 2, 1, chartRenderingInfo25);
        projectInfo3.setLogo((java.awt.Image) bufferedImage26);
        org.jfree.chart.ui.ProjectInfo projectInfo31 = new org.jfree.chart.ui.ProjectInfo("", "", "PieLabelLinkStyle.STANDARD", (java.awt.Image) bufferedImage26, "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n", "ChartEntity: tooltip = ", "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]");
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(bufferedImage26);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        legendTitle2.setWrapper(blockContainer5);
        double double7 = legendTitle2.getHeight();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle2.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Font font10 = legendTitle2.getItemFont();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.removeChangeListener(plotChangeListener13);
        java.awt.Font font15 = piePlot12.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean18 = piePlot12.equals((java.lang.Object) rectangleAnchor17);
        piePlot12.setShadowYOffset(0.0d);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("Rotation.CLOCKWISE", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        try {
            org.jfree.chart.title.Title title24 = jFreeChart22.getSubtitle((-5075968));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.geom.Rectangle2D rectangle2D2 = legendTitle1.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D2, "");
        java.lang.Object obj5 = chartEntity4.clone();
        java.awt.Shape shape6 = chartEntity4.getArea();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        java.lang.String str1 = tableOrder0.toString();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot3.setLabelOutlineStroke(stroke4);
        piePlot3.setIgnoreNullValues(false);
        java.awt.Paint paint8 = piePlot3.getLabelLinkPaint();
        boolean boolean9 = tableOrder0.equals((java.lang.Object) paint8);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_COLUMN" + "'", str1.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.lang.Object obj4 = textTitle2.clone();
        java.lang.String str5 = textTitle2.getURLText();
        java.lang.String str6 = textTitle2.getToolTipText();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle2.arrange(graphics2D7, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        piePlot1.setCircular(false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint8 = textTitle7.getBackgroundPaint();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.UnitType unitType10 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType10, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        double double23 = rectangleInsets21.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle25.getBounds();
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets21.createInsetRectangle(rectangle2D26, false, true);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets15.createOutsetRectangle(rectangle2D29, true, false);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D32, "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!", "");
        org.jfree.chart.ui.ProjectInfo projectInfo36 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library41 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        projectInfo36.addLibrary(library41);
        java.lang.Object obj43 = textTitle7.draw(graphics2D9, rectangle2D32, (java.lang.Object) projectInfo36);
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot(pieDataset44);
        java.awt.Image image46 = piePlot45.getBackgroundImage();
        java.awt.Paint paint47 = piePlot45.getLabelLinkPaint();
        java.lang.String str48 = piePlot45.getPlotType();
        java.lang.Object obj49 = piePlot45.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        org.jfree.chart.plot.PiePlotState piePlotState52 = piePlot1.initialise(graphics2D5, rectangle2D32, piePlot45, (java.lang.Integer) 100, plotRenderingInfo51);
        int int53 = piePlot45.getPieIndex();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(projectInfo36);
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertNull(image46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Pie Plot" + "'", str48.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(piePlotState52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) "{0}");
        org.jfree.data.general.DatasetGroup datasetGroup3 = defaultCategoryDataset0.getGroup();
        try {
            defaultCategoryDataset0.removeColumn((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(datasetGroup3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, 0.0d, (double) 0.0f, (-15.0d));
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle3.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle3.setWidth((double) '4');
        legendTitle3.setWidth(0.0d);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle3.setItemPaint((java.awt.Paint) color22);
        boolean boolean24 = piePlot1.equals((java.lang.Object) legendTitle3);
        piePlot1.zoom((double) 100L);
        try {
            piePlot1.setInteriorGap(100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (100.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle3.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle3.setWidth((double) '4');
        legendTitle3.setWidth(0.0d);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle3.setItemPaint((java.awt.Paint) color22);
        boolean boolean24 = piePlot1.equals((java.lang.Object) legendTitle3);
        piePlot1.zoom((double) 100L);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle27 = piePlot1.getLabelLinkStyle();
        java.lang.Object obj28 = null;
        boolean boolean29 = pieLabelLinkStyle27.equals(obj28);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.awt.Paint paint5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        piePlot1.setSectionPaint((java.lang.Comparable) "RectangleAnchor.BOTTOM_RIGHT", paint5);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Comparable comparable1 = null;
        boolean boolean2 = paintMap0.containsKey(comparable1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.removeChangeListener(plotChangeListener5);
        java.awt.Font font7 = piePlot4.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean10 = piePlot4.equals((java.lang.Object) rectangleAnchor9);
        piePlot4.setShadowYOffset(0.0d);
        double double13 = piePlot4.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot4.getLabelPadding();
        java.awt.Color color17 = java.awt.Color.white;
        java.awt.Color color18 = java.awt.Color.getColor("", color17);
        piePlot4.setSectionPaint((java.lang.Comparable) 2, (java.awt.Paint) color18);
        piePlot4.setIgnoreNullValues(false);
        boolean boolean22 = paintMap0.equals((java.lang.Object) false);
        java.lang.Object obj23 = paintMap0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets11.createInsetRectangle(rectangle2D16, false, true);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createOutsetRectangle(rectangle2D19, true, false);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity29 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D22, pieDataset23, (int) (short) 10, 0, (java.lang.Comparable) 100.0d, "", "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!");
        java.lang.Comparable comparable30 = null;
        pieSectionEntity29.setSectionKey(comparable30);
        org.jfree.data.general.PieDataset pieDataset32 = pieSectionEntity29.getDataset();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator33 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator34 = null;
        try {
            java.lang.String str35 = pieSectionEntity29.getImageMapAreaTag(toolTipTagFragmentGenerator33, uRLTagFragmentGenerator34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNull(pieDataset32);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        legendTitle1.setWidth(0.0d);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle1.setItemPaint((java.awt.Paint) color20);
        java.lang.String str22 = color20.toString();
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "java.awt.Color[r=64,g=64,b=255]" + "'", str22.equals("java.awt.Color[r=64,g=64,b=255]"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "Rotation.CLOCKWISE");
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        java.awt.Font font18 = legendTitle1.getItemFont();
        java.awt.Paint paint19 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        legendTitle1.setItemPaint(paint19);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.awt.Paint paint10 = piePlot3.getLabelLinkPaint();
        org.jfree.chart.ui.Library library15 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean20 = library15.equals((java.lang.Object) chartColor19);
        piePlot3.setBaseSectionPaint((java.awt.Paint) chartColor19);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        legendTitle23.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer26 = null;
        legendTitle23.setWrapper(blockContainer26);
        double double28 = legendTitle23.getHeight();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle23.setBackgroundPaint((java.awt.Paint) color29);
        java.awt.Font font31 = legendTitle23.getItemFont();
        piePlot3.setLabelFont(font31);
        float float33 = piePlot3.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.5f + "'", float33 == 0.5f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n");
        try {
            java.lang.Object obj4 = jFreeChartResources0.getObject("TableOrder.BY_COLUMN");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key TableOrder.BY_COLUMN");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement1);
        org.jfree.chart.block.Block block3 = null;
        org.jfree.chart.ui.Library library8 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean13 = library8.equals((java.lang.Object) chartColor12);
        blockContainer2.add(block3, (java.lang.Object) boolean13);
        org.jfree.chart.block.Arrangement arrangement15 = blockContainer2.getArrangement();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = flowArrangement0.arrange(blockContainer2, graphics2D16, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(arrangement15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        legendTitle1.setItemFont(font7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        lineBorder12.draw(graphics2D13, rectangle2D16);
        boolean boolean18 = rectangleAnchor11.equals((java.lang.Object) rectangle2D16);
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor11);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle1.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle2.getMargin();
        java.awt.Font font5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.awt.Paint paint7 = textTitle6.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = textTitle6.getPosition();
        textTitle2.setPosition(rectangleEdge8);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor11 = new org.jfree.chart.plot.PieLabelDistributor((-16646144));
        boolean boolean12 = textTitle2.equals((java.lang.Object) (-16646144));
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Class<?> wildcardClass1 = multiplePiePlot0.getClass();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder2);
        multiplePiePlot0.setLimit((double) (byte) -1);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(tableOrder2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Color color1 = java.awt.Color.getColor("rect");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        java.lang.String str3 = tableOrder2.toString();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TableOrder.BY_COLUMN" + "'", str3.equals("TableOrder.BY_COLUMN"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        legendTitle2.setWrapper(blockContainer5);
        double double7 = legendTitle2.getHeight();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle2.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Font font10 = legendTitle2.getItemFont();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.removeChangeListener(plotChangeListener13);
        java.awt.Font font15 = piePlot12.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean18 = piePlot12.equals((java.lang.Object) rectangleAnchor17);
        piePlot12.setShadowYOffset(0.0d);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("Rotation.CLOCKWISE", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        try {
            org.jfree.chart.plot.XYPlot xYPlot23 = jFreeChart22.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.setValue((java.lang.Number) 15, (java.lang.Comparable) 100, (java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        defaultKeyedValues2D0.removeColumn((int) (short) 0);
        int int8 = defaultKeyedValues2D0.getColumnCount();
        try {
            defaultKeyedValues2D0.removeRow((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        boolean boolean7 = unitType0.equals((java.lang.Object) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1.0f, (double) 178, (double) (-1), 10.0d);
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets12.getUnitType();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(unitType13);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.geom.Rectangle2D rectangle2D2 = legendTitle1.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle1.getItemLabelPadding();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("0,1,1,-1", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = plotChangeEvent5.getType();
        org.jfree.chart.util.UnitType unitType7 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType7, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        boolean boolean14 = unitType7.equals((java.lang.Object) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType7, (double) 1.0f, (double) 178, (double) (-1), 10.0d);
        boolean boolean20 = chartChangeEventType6.equals((java.lang.Object) 10.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        float float5 = piePlot1.getForegroundAlpha();
        java.awt.Paint paint7 = piePlot1.getSectionPaint((java.lang.Comparable) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        java.awt.Paint paint3 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot11.setLabelOutlineStroke(stroke12);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        double double21 = rectangleInsets19.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle23.getBounds();
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets19.createInsetRectangle(rectangle2D24, false, true);
        double double29 = rectangleInsets19.calculateBottomOutset((double) 100);
        org.jfree.chart.util.UnitType unitType30 = rectangleInsets19.getUnitType();
        double double31 = rectangleInsets19.getRight();
        piePlot11.setInsets(rectangleInsets19, true);
        jFreeChart9.setPadding(rectangleInsets19);
        jFreeChart9.fireChartChanged();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.LegendItemSource legendItemSource39 = null;
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle(legendItemSource39);
        java.awt.geom.Rectangle2D rectangle2D41 = legendTitle40.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity43 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D41, "");
        textTitle37.draw(graphics2D38, rectangle2D41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = null;
        try {
            jFreeChart9.draw(graphics2D36, rectangle2D41, chartRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 15.0d + "'", double31 == 15.0d);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int1 = color0.getRGB();
        int int2 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-49088) + "'", int1 == (-49088));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = plotChangeEvent5.getType();
        java.lang.String str7 = plotChangeEvent5.toString();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        java.awt.geom.Rectangle2D rectangle2D10 = legendTitle9.getBounds();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets5.createInsetRectangle(rectangle2D10, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D13);
        chartEntity14.setURLText("Pie Plot");
        java.lang.String str17 = chartEntity14.getURLText();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pie Plot" + "'", str17.equals("Pie Plot"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder8.getInsets();
        double double11 = rectangleInsets9.calculateTopInset((double) (byte) -1);
        legendTitle1.setItemLabelPadding(rectangleInsets9);
        double double13 = rectangleInsets9.getBottom();
        double double15 = rectangleInsets9.calculateLeftInset(52.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        piePlot1.setOutlineVisible(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot1.removeChangeListener(plotChangeListener9);
        boolean boolean11 = piePlot1.isSubplot();
        piePlot1.setNoDataMessage("VerticalAlignment.CENTER");
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator14);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Image image2 = piePlot1.getBackgroundImage();
        java.awt.Paint paint3 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelGenerator();
        piePlot1.setMinimumArcAngleToDraw((double) 255);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        java.awt.Paint paint6 = defaultDrawingSupplier4.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean7 = piePlot1.equals((java.lang.Object) rectangleAnchor6);
        boolean boolean8 = piePlot1.getSimpleLabels();
        piePlot1.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = java.awt.Color.BLUE;
        java.awt.Color color4 = java.awt.Color.BLUE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        int int6 = color5.getBlue();
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, color1, color2, color3, color4, color5 };
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color12 = java.awt.Color.BLUE;
        boolean boolean14 = color12.equals((java.lang.Object) 0);
        java.awt.Color color17 = java.awt.Color.getColor("", (int) (byte) 10);
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor11, color12, color17 };
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color27 = java.awt.Color.BLUE;
        java.awt.Color color28 = java.awt.Color.green;
        java.awt.Color color29 = java.awt.Color.WHITE;
        int int30 = color29.getBlue();
        java.awt.Color color31 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { chartColor22, chartColor26, color27, color28, color29, color31 };
        java.awt.Stroke stroke33 = null;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke33 };
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = null;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray18, paintArray32, strokeArray34, strokeArray35, shapeArray37);
        java.awt.Paint paint39 = defaultDrawingSupplier38.getNextPaint();
        java.awt.Paint paint40 = defaultDrawingSupplier38.getNextFillPaint();
        java.lang.Object obj41 = defaultDrawingSupplier38.clone();
        java.lang.Object obj42 = defaultDrawingSupplier38.clone();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = color2.darker();
        java.awt.Color color4 = color3.darker();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint8 = textTitle7.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle7.getTextAlignment();
        java.awt.Font font11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("hi!", font11);
        java.awt.Paint paint13 = textTitle12.getPaint();
        java.lang.Object obj14 = textTitle12.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle12.getTextAlignment();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        legendTitle17.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer20 = null;
        legendTitle17.setWrapper(blockContainer20);
        legendTitle17.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle17.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle17.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = blockBorder38.getInsets();
        double double41 = rectangleInsets39.calculateTopInset((double) '#');
        java.lang.String str42 = rectangleInsets39.toString();
        legendTitle17.setLegendItemGraphicPadding(rectangleInsets39);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        legendTitle45.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        legendTitle49.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer52 = null;
        legendTitle49.setWrapper(blockContainer52);
        legendTitle49.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle49.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment64 = legendTitle49.getVerticalAlignment();
        java.lang.String str65 = verticalAlignment64.toString();
        legendTitle45.setVerticalAlignment(verticalAlignment64);
        legendTitle17.setVerticalAlignment(verticalAlignment64);
        org.jfree.chart.block.FlowArrangement flowArrangement70 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment64, (double) (short) 0, (double) (-1L));
        org.jfree.data.general.PieDataset pieDataset71 = null;
        org.jfree.chart.plot.PiePlot piePlot72 = new org.jfree.chart.plot.PiePlot(pieDataset71);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot72.setLabelOutlineStroke(stroke73);
        java.lang.Object obj75 = piePlot72.clone();
        piePlot72.setOutlineVisible(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator78 = null;
        piePlot72.setToolTipGenerator(pieToolTipGenerator78);
        org.jfree.chart.event.PlotChangeListener plotChangeListener80 = null;
        piePlot72.removeChangeListener(plotChangeListener80);
        boolean boolean82 = piePlot72.isSubplot();
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = piePlot72.getLabelPadding();
        org.jfree.chart.title.TextTitle textTitle84 = new org.jfree.chart.title.TextTitle("", font1, (java.awt.Paint) color3, rectangleEdge5, horizontalAlignment9, verticalAlignment64, rectangleInsets83);
        textTitle84.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str42.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertNotNull(verticalAlignment64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "VerticalAlignment.CENTER" + "'", str65.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(rectangleInsets83);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        legendTitle2.setWrapper(blockContainer5);
        double double7 = legendTitle2.getHeight();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle2.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Font font10 = legendTitle2.getItemFont();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.removeChangeListener(plotChangeListener13);
        java.awt.Font font15 = piePlot12.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean18 = piePlot12.equals((java.lang.Object) rectangleAnchor17);
        piePlot12.setShadowYOffset(0.0d);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("Rotation.CLOCKWISE", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart22.getTitle();
        org.jfree.chart.event.ChartChangeListener chartChangeListener24 = null;
        try {
            jFreeChart22.removeChangeListener(chartChangeListener24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(textTitle23);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean7 = piePlot1.equals((java.lang.Object) rectangleAnchor6);
        piePlot1.setShadowYOffset(0.0d);
        double double10 = piePlot1.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot1.getLabelPadding();
        java.awt.Color color14 = java.awt.Color.white;
        java.awt.Color color15 = java.awt.Color.getColor("", color14);
        piePlot1.setSectionPaint((java.lang.Comparable) 2, (java.awt.Paint) color15);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = piePlot1.getURLGenerator();
        java.awt.Stroke stroke19 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 96.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(pieURLGenerator17);
        org.junit.Assert.assertNull(stroke19);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Block block2 = null;
        org.jfree.chart.ui.Library library7 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean12 = library7.equals((java.lang.Object) chartColor11);
        blockContainer1.add(block2, (java.lang.Object) boolean12);
        org.jfree.chart.block.Arrangement arrangement14 = blockContainer1.getArrangement();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        legendTitle16.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer19 = null;
        legendTitle16.setWrapper(blockContainer19);
        double double21 = legendTitle16.getHeight();
        blockContainer1.add((org.jfree.chart.block.Block) legendTitle16);
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        legendTitle24.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer27 = null;
        legendTitle24.setWrapper(blockContainer27);
        legendTitle24.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = blockBorder38.getInsets();
        double double41 = rectangleInsets39.calculateTopInset((double) '#');
        legendTitle24.setLegendItemGraphicPadding(rectangleInsets39);
        double double44 = rectangleInsets39.calculateBottomOutset((double) 0);
        java.awt.Color color45 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder46 = new org.jfree.chart.block.BlockBorder(rectangleInsets39, (java.awt.Paint) color45);
        blockContainer1.setMargin(rectangleInsets39);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.data.general.PieDataset pieDataset49 = null;
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset49);
        java.awt.Stroke stroke51 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot50.setLabelOutlineStroke(stroke51);
        org.jfree.chart.block.BlockBorder blockBorder57 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = blockBorder57.getInsets();
        double double60 = rectangleInsets58.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource61 = null;
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle(legendItemSource61);
        java.awt.geom.Rectangle2D rectangle2D63 = legendTitle62.getBounds();
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets58.createInsetRectangle(rectangle2D63, false, true);
        double double68 = rectangleInsets58.calculateBottomOutset((double) 100);
        org.jfree.chart.util.UnitType unitType69 = rectangleInsets58.getUnitType();
        double double70 = rectangleInsets58.getRight();
        piePlot50.setInsets(rectangleInsets58, true);
        org.jfree.chart.LegendItemSource legendItemSource73 = null;
        org.jfree.chart.title.LegendTitle legendTitle74 = new org.jfree.chart.title.LegendTitle(legendItemSource73);
        java.awt.geom.Rectangle2D rectangle2D75 = legendTitle74.getBounds();
        java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets58.createInsetRectangle(rectangle2D75);
        try {
            blockContainer1.draw(graphics2D48, rectangle2D75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(arrangement14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertNotNull(unitType69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 15.0d + "'", double70 == 15.0d);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangle2D76);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        strokeMap0.clear();
        boolean boolean4 = strokeMap0.containsKey((java.lang.Comparable) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        boolean boolean2 = textTitle1.getExpandToFitSpace();
        java.lang.Object obj3 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Color color0 = java.awt.Color.CYAN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getAlpha();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        float[] floatArray10 = null;
        float[] floatArray11 = java.awt.Color.RGBtoHSB(3, 0, 15, floatArray10);
        float[] floatArray12 = color6.getRGBColorComponents(floatArray11);
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) (byte) 10, (int) '4', (-555), floatArray12);
        try {
            float[] floatArray14 = color0.getRGBComponents(floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle3.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle3.setWidth((double) '4');
        legendTitle3.setWidth(0.0d);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle3.setItemPaint((java.awt.Paint) color22);
        boolean boolean24 = piePlot1.equals((java.lang.Object) legendTitle3);
        float float25 = piePlot1.getForegroundAlpha();
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        legendTitle27.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer30 = null;
        legendTitle27.setWrapper(blockContainer30);
        legendTitle27.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle27.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle27.setWidth((double) '4');
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean45 = legendTitle27.equals((java.lang.Object) color44);
        piePlot1.setShadowPaint((java.awt.Paint) color44);
        int int47 = color44.getBlue();
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 255 + "'", int47 == 255);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Font font2 = piePlot1.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.setValue((java.lang.Number) 15, (java.lang.Comparable) 100, (java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean7 = defaultKeyedValues2D0.equals((java.lang.Object) (short) 0);
        try {
            defaultKeyedValues2D0.removeColumn((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '#', (int) (short) 1, 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean7 = piePlot1.equals((java.lang.Object) rectangleAnchor6);
        java.awt.Paint paint9 = piePlot1.getSectionPaint((java.lang.Comparable) 15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = piePlot1.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor12 = new org.jfree.chart.plot.PieLabelDistributor(0);
        pieLabelDistributor12.clear();
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor12);
        pieLabelDistributor12.distributeLabels(90.0d, (double) (byte) 10);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(drawingSupplier10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Image image2 = piePlot1.getBackgroundImage();
        piePlot1.setBackgroundImageAlignment(10);
        float float5 = piePlot1.getBackgroundAlpha();
        int int6 = piePlot1.getPieIndex();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        legendTitle8.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer11 = null;
        legendTitle8.setWrapper(blockContainer11);
        legendTitle8.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        double double25 = rectangleInsets23.calculateTopInset((double) '#');
        legendTitle8.setLegendItemGraphicPadding(rectangleInsets23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = legendTitle8.getPosition();
        org.jfree.chart.LegendItemSource legendItemSource28 = null;
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle(legendItemSource28);
        java.awt.Font font31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("hi!", font31);
        legendTitle29.setItemFont(font31);
        legendTitle8.setItemFont(font31);
        piePlot1.setNoDataMessageFont(font31);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean7 = piePlot1.equals((java.lang.Object) rectangleAnchor6);
        java.awt.Paint paint9 = piePlot1.getSectionPaint((java.lang.Comparable) 15);
        piePlot1.setPieIndex((int) (byte) 1);
        java.awt.Stroke stroke12 = null;
        piePlot1.setOutlineStroke(stroke12);
        piePlot1.setPieIndex((-555));
        java.awt.Paint paint16 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = legendTitle1.getVerticalAlignment();
        java.lang.Object obj17 = legendTitle1.clone();
        java.lang.Class<?> wildcardClass18 = obj17.getClass();
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        float float5 = piePlot1.getForegroundAlpha();
        boolean boolean6 = piePlot1.isCircular();
        boolean boolean7 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = java.awt.Color.BLUE;
        java.awt.Color color4 = java.awt.Color.BLUE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        int int6 = color5.getBlue();
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color0, color1, color2, color3, color4, color5 };
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color12 = java.awt.Color.BLUE;
        boolean boolean14 = color12.equals((java.lang.Object) 0);
        java.awt.Color color17 = java.awt.Color.getColor("", (int) (byte) 10);
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { chartColor11, color12, color17 };
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        java.awt.Color color27 = java.awt.Color.BLUE;
        java.awt.Color color28 = java.awt.Color.green;
        java.awt.Color color29 = java.awt.Color.WHITE;
        int int30 = color29.getBlue();
        java.awt.Color color31 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { chartColor22, chartColor26, color27, color28, color29, color31 };
        java.awt.Stroke stroke33 = null;
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] { stroke33 };
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = null;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray18, paintArray32, strokeArray34, strokeArray35, shapeArray37);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator40 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset41 = null;
        java.lang.String str43 = standardPieSectionLabelGenerator40.generateSectionLabel(pieDataset41, (java.lang.Comparable) (short) 0);
        boolean boolean44 = defaultDrawingSupplier38.equals((java.lang.Object) standardPieSectionLabelGenerator40);
        java.lang.String str45 = standardPieSectionLabelGenerator40.getLabelFormat();
        org.jfree.chart.block.ColumnArrangement columnArrangement46 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement46);
        org.jfree.chart.block.Block block48 = null;
        org.jfree.chart.ui.Library library53 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor57 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean58 = library53.equals((java.lang.Object) chartColor57);
        blockContainer47.add(block48, (java.lang.Object) boolean58);
        org.jfree.chart.block.Arrangement arrangement60 = blockContainer47.getArrangement();
        org.jfree.chart.LegendItemSource legendItemSource61 = null;
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle(legendItemSource61);
        legendTitle62.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer65 = null;
        legendTitle62.setWrapper(blockContainer65);
        double double67 = legendTitle62.getHeight();
        blockContainer47.add((org.jfree.chart.block.Block) legendTitle62);
        boolean boolean69 = standardPieSectionLabelGenerator40.equals((java.lang.Object) blockContainer47);
        org.jfree.chart.block.Arrangement arrangement70 = blockContainer47.getArrangement();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(arrangement60);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(arrangement70);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Stroke stroke3 = piePlot2.getOutlineStroke();
        float float4 = piePlot2.getForegroundAlpha();
        java.awt.Color color5 = java.awt.Color.cyan;
        piePlot2.setLabelOutlinePaint((java.awt.Paint) color5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("TableOrder.BY_COLUMN", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = piePlot2.getLegendItems();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        legendTitle1.setWidth(0.0d);
        legendTitle1.setNotify(true);
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer();
        boolean boolean23 = blockContainer22.isEmpty();
        legendTitle1.setWrapper(blockContainer22);
        java.awt.Font font26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("hi!", font26);
        java.awt.Paint paint28 = textTitle27.getPaint();
        java.lang.Object obj29 = textTitle27.clone();
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = blockBorder34.getInsets();
        double double37 = rectangleInsets35.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        java.awt.geom.Rectangle2D rectangle2D40 = legendTitle39.getBounds();
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets35.createInsetRectangle(rectangle2D40, false, true);
        textTitle27.setMargin(rectangleInsets35);
        double double46 = rectangleInsets35.calculateTopInset((double) (byte) 0);
        legendTitle1.setItemLabelPadding(rectangleInsets35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = legendTitle1.getLegendItemGraphicAnchor();
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable2 = null;
        try {
            defaultCategoryDataset0.removeValue((java.lang.Comparable) 10, comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        legendTitle2.setWrapper(blockContainer5);
        double double7 = legendTitle2.getHeight();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle2.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Font font10 = legendTitle2.getItemFont();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.removeChangeListener(plotChangeListener13);
        java.awt.Font font15 = piePlot12.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean18 = piePlot12.equals((java.lang.Object) rectangleAnchor17);
        piePlot12.setShadowYOffset(0.0d);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("Rotation.CLOCKWISE", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart22.getTitle();
        org.jfree.chart.plot.Plot plot24 = jFreeChart22.getPlot();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(plot24);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = blockBorder8.getInsets();
        double double11 = rectangleInsets9.calculateTopInset((double) (byte) -1);
        legendTitle1.setItemLabelPadding(rectangleInsets9);
        java.lang.String str13 = rectangleInsets9.toString();
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str13.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean9 = library4.equals((java.lang.Object) chartColor8);
        float[] floatArray16 = new float[] { (byte) -1, (byte) -1, (-1) };
        float[] floatArray17 = java.awt.Color.RGBtoHSB(2, (int) (byte) -1, (int) 'a', floatArray16);
        float[] floatArray18 = chartColor8.getRGBColorComponents(floatArray16);
        int int19 = chartColor8.getBlue();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        java.awt.Color color7 = java.awt.Color.GREEN;
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        java.lang.String str13 = piePlot1.getPlotType();
        boolean boolean14 = piePlot1.getIgnoreNullValues();
        double double16 = piePlot1.getExplodePercent((java.lang.Comparable) 100);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        java.awt.Stroke stroke6 = defaultDrawingSupplier4.getNextStroke();
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double15 = rectangleInsets13.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle17.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createInsetRectangle(rectangle2D18, false, true);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createOutsetRectangle(rectangle2D21, true, false);
        int int25 = objectList1.indexOf((java.lang.Object) true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot26 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart27 = multiplePiePlot26.getPieChart();
        int int28 = objectList1.indexOf((java.lang.Object) jFreeChart27);
        java.awt.Color color29 = java.awt.Color.WHITE;
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        legendTitle33.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer36 = null;
        legendTitle33.setWrapper(blockContainer36);
        legendTitle33.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle33.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle33.setWidth((double) '4');
        legendTitle33.setWidth(0.0d);
        java.awt.Color color52 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle33.setItemPaint((java.awt.Paint) color52);
        boolean boolean54 = piePlot31.equals((java.lang.Object) legendTitle33);
        piePlot31.zoom((double) 100L);
        piePlot31.setForegroundAlpha((float) (-15728654));
        org.jfree.data.general.PieDataset pieDataset59 = null;
        org.jfree.chart.plot.PiePlot piePlot60 = new org.jfree.chart.plot.PiePlot(pieDataset59);
        java.awt.Stroke stroke61 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot60.setLabelOutlineStroke(stroke61);
        piePlot60.setIgnoreNullValues(false);
        java.awt.Stroke stroke65 = piePlot60.getBaseSectionOutlineStroke();
        piePlot31.setLabelLinkStroke(stroke65);
        boolean boolean67 = color29.equals((java.lang.Object) piePlot31);
        boolean boolean68 = objectList1.equals((java.lang.Object) piePlot31);
        double double69 = piePlot31.getInteriorGap();
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(jFreeChart27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.08d + "'", double69 == 0.08d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Image image2 = piePlot1.getBackgroundImage();
        piePlot1.setBackgroundImageAlignment(10);
        float float5 = piePlot1.getBackgroundAlpha();
        java.awt.Paint paint6 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setBackgroundImageAlignment((int) (short) 0);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        piePlot1.setLabelPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        java.util.List list2 = jFreeChart1.getSubtitles();
        boolean boolean3 = jFreeChart1.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle4 = jFreeChart1.getTitle();
        try {
            org.jfree.chart.plot.XYPlot xYPlot5 = jFreeChart1.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(textTitle4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray2 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke3 = null;
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        java.awt.geom.Rectangle2D rectangle2D7 = legendTitle6.getBounds();
        java.awt.Shape[] shapeArray8 = new java.awt.Shape[] { rectangle2D7 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray4, shapeArray8);
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(shapeArray8);
        org.junit.Assert.assertNull(stroke10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        java.awt.Paint paint13 = piePlot1.getNoDataMessagePaint();
        boolean boolean14 = piePlot1.isCircular();
        java.awt.Font font15 = piePlot1.getLabelFont();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle1.setPosition(rectangleEdge20);
        legendTitle1.setPadding((double) 10.0f, 0.0d, (double) 1.0f, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle1.getLegendItemGraphicPadding();
        double double29 = rectangleInsets27.calculateLeftOutset((double) 1.0f);
        double double30 = rectangleInsets27.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.0d + "'", double29 == 10.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("UnitType.RELATIVE");
        java.awt.Paint paint2 = null;
        try {
            textTitle1.setPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("PieLabelLinkStyle.STANDARD");
        java.util.Set<java.lang.String> strSet5 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle3.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle3.setWidth((double) '4');
        legendTitle3.setWidth(0.0d);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle3.setItemPaint((java.awt.Paint) color22);
        boolean boolean24 = piePlot1.equals((java.lang.Object) legendTitle3);
        piePlot1.zoom((double) 100L);
        piePlot1.setForegroundAlpha((float) (-15728654));
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot30.setLabelOutlineStroke(stroke31);
        piePlot30.setIgnoreNullValues(false);
        java.awt.Stroke stroke35 = piePlot30.getBaseSectionOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke35);
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke38 = lineBorder37.getStroke();
        piePlot1.setLabelLinkStroke(stroke38);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator40 = piePlot1.getToolTipGenerator();
        try {
            piePlot1.setInteriorGap((double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (52.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(pieToolTipGenerator40);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        legendTitle2.setWrapper(blockContainer5);
        double double7 = legendTitle2.getHeight();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle2.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Font font10 = legendTitle2.getItemFont();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.removeChangeListener(plotChangeListener13);
        java.awt.Font font15 = piePlot12.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean18 = piePlot12.equals((java.lang.Object) rectangleAnchor17);
        piePlot12.setShadowYOffset(0.0d);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("Rotation.CLOCKWISE", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        java.awt.Paint paint23 = jFreeChart22.getBorderPaint();
        boolean boolean24 = jFreeChart22.isBorderVisible();
        org.jfree.chart.LegendItemSource legendItemSource26 = null;
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle(legendItemSource26);
        java.awt.geom.Rectangle2D rectangle2D28 = legendTitle27.getBounds();
        try {
            jFreeChart22.addSubtitle((-49088), (org.jfree.chart.title.Title) legendTitle27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        java.awt.Font font6 = piePlot3.getLabelFont();
        java.awt.Font font7 = piePlot3.getLabelFont();
        boolean boolean8 = datasetGroup1.equals((java.lang.Object) piePlot3);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        piePlot3.setDataset(pieDataset9);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        double double2 = blockContainer0.getWidth();
        java.lang.Object obj3 = blockContainer0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        java.lang.String str6 = unitType0.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 0, 52.0d, (double) 1L, (double) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, (double) (byte) 10, (double) 100L, 0.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.RELATIVE" + "'", str6.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets11.createInsetRectangle(rectangle2D16, false, true);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createOutsetRectangle(rectangle2D19, true, false);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity29 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D22, pieDataset23, (int) (short) 10, 0, (java.lang.Comparable) 100.0d, "", "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!");
        java.lang.Comparable comparable30 = null;
        pieSectionEntity29.setSectionKey(comparable30);
        java.lang.Comparable comparable32 = pieSectionEntity29.getSectionKey();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNull(comparable32);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        java.awt.Font font4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.removeChangeListener(plotChangeListener7);
        piePlot6.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) piePlot6, false);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot14.setLabelOutlineStroke(stroke15);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource25 = null;
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle(legendItemSource25);
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets22.createInsetRectangle(rectangle2D27, false, true);
        double double32 = rectangleInsets22.calculateBottomOutset((double) 100);
        org.jfree.chart.util.UnitType unitType33 = rectangleInsets22.getUnitType();
        double double34 = rectangleInsets22.getRight();
        piePlot14.setInsets(rectangleInsets22, true);
        jFreeChart12.setPadding(rectangleInsets22);
        jFreeChart12.fireChartChanged();
        jFreeChart12.setBorderVisible(false);
        multiplePiePlot0.setPieChart(jFreeChart12);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.LegendItemSource legendItemSource43 = null;
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle(legendItemSource43);
        java.awt.geom.Rectangle2D rectangle2D45 = legendTitle44.getBounds();
        try {
            jFreeChart12.draw(graphics2D42, rectangle2D45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(unitType33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 15.0d + "'", double34 == 15.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.util.List list2 = projectInfo0.getContributors();
        java.lang.String str3 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean7 = piePlot1.equals((java.lang.Object) rectangleAnchor6);
        piePlot1.setShadowYOffset(0.0d);
        double double10 = piePlot1.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot1.getLabelPadding();
        java.awt.Color color14 = java.awt.Color.white;
        java.awt.Color color15 = java.awt.Color.getColor("", color14);
        piePlot1.setSectionPaint((java.lang.Comparable) 2, (java.awt.Paint) color15);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = piePlot1.getURLGenerator();
        boolean boolean18 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(pieURLGenerator17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        int int2 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) (short) 0, (java.lang.Comparable) 255, (java.lang.Comparable) 100.0d);
        try {
            defaultKeyedValues2D0.removeColumn(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font4);
        legendTitle2.setItemFont(font4);
        java.awt.Paint paint7 = null;
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        legendTitle9.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle9.setWrapper(blockContainer12);
        legendTitle9.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = blockBorder23.getInsets();
        double double26 = rectangleInsets24.calculateTopInset((double) '#');
        legendTitle9.setLegendItemGraphicPadding(rectangleInsets24);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle9.setPosition(rectangleEdge28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge28);
        java.awt.Font font32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("hi!", font32);
        java.awt.Paint paint34 = textTitle33.getPaint();
        java.lang.Object obj35 = textTitle33.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = textTitle33.getTextAlignment();
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        legendTitle38.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer41 = null;
        legendTitle38.setWrapper(blockContainer41);
        legendTitle38.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle38.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle38.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder59 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = blockBorder59.getInsets();
        double double62 = rectangleInsets60.calculateTopInset((double) '#');
        java.lang.String str63 = rectangleInsets60.toString();
        legendTitle38.setLegendItemGraphicPadding(rectangleInsets60);
        org.jfree.chart.LegendItemSource legendItemSource65 = null;
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle(legendItemSource65);
        legendTitle66.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource69 = null;
        org.jfree.chart.title.LegendTitle legendTitle70 = new org.jfree.chart.title.LegendTitle(legendItemSource69);
        legendTitle70.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer73 = null;
        legendTitle70.setWrapper(blockContainer73);
        legendTitle70.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle70.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment85 = legendTitle70.getVerticalAlignment();
        java.lang.String str86 = verticalAlignment85.toString();
        legendTitle66.setVerticalAlignment(verticalAlignment85);
        legendTitle38.setVerticalAlignment(verticalAlignment85);
        org.jfree.chart.block.FlowArrangement flowArrangement91 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment36, verticalAlignment85, (double) (short) 0, (double) (-1L));
        org.jfree.chart.util.VerticalAlignment verticalAlignment92 = null;
        org.jfree.chart.block.BlockBorder blockBorder97 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets98 = blockBorder97.getInsets();
        try {
            org.jfree.chart.title.TextTitle textTitle99 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ", font4, paint7, rectangleEdge30, horizontalAlignment36, verticalAlignment92, rectangleInsets98);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'verticalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str63.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertNotNull(verticalAlignment85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "VerticalAlignment.CENTER" + "'", str86.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(rectangleInsets98);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle3.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle3.setWidth((double) '4');
        legendTitle3.setWidth(0.0d);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle3.setItemPaint((java.awt.Paint) color22);
        boolean boolean24 = piePlot1.equals((java.lang.Object) legendTitle3);
        piePlot1.zoom((double) 100L);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle27 = piePlot1.getLabelLinkStyle();
        java.awt.Stroke stroke28 = piePlot1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = plotChangeEvent5.getType();
        java.lang.Object obj7 = null;
        boolean boolean8 = chartChangeEventType6.equals(obj7);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean7 = piePlot1.equals((java.lang.Object) rectangleAnchor6);
        java.awt.Paint paint9 = piePlot1.getSectionPaint((java.lang.Comparable) 15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = piePlot1.getDrawingSupplier();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor12 = new org.jfree.chart.plot.PieLabelDistributor(0);
        pieLabelDistributor12.clear();
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor12);
        int int15 = pieLabelDistributor12.getItemCount();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord17 = pieLabelDistributor12.getPieLabelRecord((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) "{0}");
        int int3 = defaultCategoryDataset0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        boolean boolean3 = legendTitle1.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        legendTitle1.removeChangeListener(titleChangeListener4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        double double5 = piePlot1.getExplodePercent((java.lang.Comparable) (-5075968));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.setIgnoreNullValues(false);
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        double double7 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Class<?> wildcardClass1 = multiplePiePlot0.getClass();
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(tableOrder2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Block block2 = null;
        org.jfree.chart.ui.Library library7 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean12 = library7.equals((java.lang.Object) chartColor11);
        blockContainer1.add(block2, (java.lang.Object) boolean12);
        org.jfree.chart.block.Arrangement arrangement14 = blockContainer1.getArrangement();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        legendTitle16.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer19 = null;
        legendTitle16.setWrapper(blockContainer19);
        double double21 = legendTitle16.getHeight();
        blockContainer1.add((org.jfree.chart.block.Block) legendTitle16);
        legendTitle16.setID("hi!");
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(arrangement14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.setIgnoreNullValues(false);
        java.awt.Stroke stroke6 = piePlot1.getBaseSectionOutlineStroke();
        piePlot1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        org.jfree.chart.block.BlockFrame blockFrame20 = legendTitle1.getFrame();
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame20);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = multiplePiePlot0.getPieChart();
        java.util.List list2 = jFreeChart1.getSubtitles();
        boolean boolean3 = jFreeChart1.getAntiAlias();
        org.jfree.chart.title.TextTitle textTitle4 = jFreeChart1.getTitle();
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart1.getLegend();
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart1.getTitle();
        org.junit.Assert.assertNotNull(jFreeChart1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(textTitle4);
        org.junit.Assert.assertNull(legendTitle5);
        org.junit.Assert.assertNotNull(textTitle6);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.removeChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        legendTitle7.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer10 = null;
        legendTitle7.setWrapper(blockContainer10);
        legendTitle7.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle7.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle7.setWidth((double) '4');
        legendTitle7.setWidth(0.0d);
        java.awt.Font font26 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        legendTitle7.setItemFont(font26);
        piePlot2.setLabelFont(font26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font26);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = blockContainer1.isEmpty();
        double double3 = blockContainer1.getWidth();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = flowArrangement0.arrange(blockContainer1, graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        java.awt.geom.Rectangle2D rectangle2D4 = legendTitle3.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D4, "");
        textTitle0.draw(graphics2D1, rectangle2D4);
        textTitle0.setText("");
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Rotation.CLOCKWISE", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        double double25 = rectangleInsets23.calculateTopInset((double) '#');
        java.lang.String str26 = rectangleInsets23.toString();
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = legendTitle1.getLegendItemGraphicAnchor();
        java.awt.Font font29 = legendTitle1.getItemFont();
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str26.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle2.getPosition();
        boolean boolean5 = textTitle2.getExpandToFitSpace();
        textTitle2.setText("0,1,1,-1");
        java.lang.String str8 = textTitle2.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = blockBorder10.getInsets();
        double double13 = rectangleInsets11.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets11.createInsetRectangle(rectangle2D16, false, true);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets5.createOutsetRectangle(rectangle2D19, true, false);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D22, "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!", "");
        java.lang.Object obj26 = chartEntity25.clone();
        java.awt.Shape shape27 = chartEntity25.getArea();
        java.lang.String str28 = chartEntity25.getToolTipText();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!" + "'", str28.equals("UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!"));
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo2);
//        java.awt.Image image4 = null;
//        projectInfo2.setLogo(image4);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE version TableOrder.BY_COLUMN.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n" + "'", str1.equals("UnitType.RELATIVE version TableOrder.BY_COLUMN.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n"));
//        org.junit.Assert.assertNotNull(projectInfo2);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4145152) + "'", int1 == (-4145152));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        double double2 = blockContainer0.getWidth();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        boolean boolean11 = unitType4.equals((java.lang.Object) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) 1.0f, (double) 178, (double) (-1), 10.0d);
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        boolean boolean20 = legendTitle18.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.event.TitleChangeListener titleChangeListener21 = null;
        legendTitle18.removeChangeListener(titleChangeListener21);
        org.jfree.chart.util.UnitType unitType23 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets(unitType23, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = blockBorder33.getInsets();
        double double36 = rectangleInsets34.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource37 = null;
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle(legendItemSource37);
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle38.getBounds();
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets34.createInsetRectangle(rectangle2D39, false, true);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets28.createOutsetRectangle(rectangle2D42, true, false);
        legendTitle18.setBounds(rectangle2D45);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets16.createOutsetRectangle(rectangle2D45, true, false);
        org.jfree.chart.LegendItemSource legendItemSource50 = null;
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle(legendItemSource50);
        legendTitle51.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer54 = null;
        legendTitle51.setWrapper(blockContainer54);
        java.awt.Font font57 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle58 = new org.jfree.chart.title.TextTitle("hi!", font57);
        legendTitle51.setItemFont(font57);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = legendTitle51.getItemLabelPadding();
        org.jfree.chart.LegendItemSource legendItemSource61 = null;
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle(legendItemSource61);
        legendTitle62.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer65 = null;
        legendTitle62.setWrapper(blockContainer65);
        legendTitle62.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder76 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = blockBorder76.getInsets();
        double double79 = rectangleInsets77.calculateTopInset((double) '#');
        legendTitle62.setLegendItemGraphicPadding(rectangleInsets77);
        org.jfree.chart.event.TitleChangeListener titleChangeListener81 = null;
        legendTitle62.removeChangeListener(titleChangeListener81);
        org.jfree.chart.LegendItemSource legendItemSource83 = null;
        org.jfree.chart.title.LegendTitle legendTitle84 = new org.jfree.chart.title.LegendTitle(legendItemSource83);
        legendTitle84.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer87 = null;
        legendTitle84.setWrapper(blockContainer87);
        double double89 = legendTitle84.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor90 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle84.setLegendItemGraphicLocation(rectangleAnchor90);
        java.lang.String str92 = rectangleAnchor90.toString();
        legendTitle62.setLegendItemGraphicLocation(rectangleAnchor90);
        legendTitle51.setLegendItemGraphicLocation(rectangleAnchor90);
        try {
            java.lang.Object obj95 = blockContainer0.draw(graphics2D3, rectangle2D45, (java.lang.Object) legendTitle51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(unitType23);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor90);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "RectangleAnchor.BOTTOM_RIGHT" + "'", str92.equals("RectangleAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.awt.Paint paint10 = piePlot3.getLabelLinkPaint();
        org.jfree.chart.ui.Library library15 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean20 = library15.equals((java.lang.Object) chartColor19);
        piePlot3.setBaseSectionPaint((java.awt.Paint) chartColor19);
        java.awt.Paint paint22 = piePlot3.getShadowPaint();
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle3.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle3.setWidth((double) '4');
        legendTitle3.setWidth(0.0d);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle3.setItemPaint((java.awt.Paint) color22);
        boolean boolean24 = piePlot1.equals((java.lang.Object) legendTitle3);
        java.awt.Paint paint25 = piePlot1.getShadowPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        piePlot1.datasetChanged(datasetChangeEvent26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        piePlot1.setDataset(pieDataset28);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        java.awt.Paint paint13 = defaultDrawingSupplier10.getNextOutlinePaint();
        java.awt.Paint paint14 = defaultDrawingSupplier10.getNextPaint();
        java.awt.Stroke stroke15 = defaultDrawingSupplier10.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.lang.Object obj4 = textTitle2.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle2.getTextAlignment();
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        legendTitle7.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer10 = null;
        legendTitle7.setWrapper(blockContainer10);
        legendTitle7.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle7.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle7.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = blockBorder28.getInsets();
        double double31 = rectangleInsets29.calculateTopInset((double) '#');
        java.lang.String str32 = rectangleInsets29.toString();
        legendTitle7.setLegendItemGraphicPadding(rectangleInsets29);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        legendTitle35.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource38 = null;
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle(legendItemSource38);
        legendTitle39.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer42 = null;
        legendTitle39.setWrapper(blockContainer42);
        legendTitle39.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle39.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = legendTitle39.getVerticalAlignment();
        java.lang.String str55 = verticalAlignment54.toString();
        legendTitle35.setVerticalAlignment(verticalAlignment54);
        legendTitle7.setVerticalAlignment(verticalAlignment54);
        org.jfree.chart.block.FlowArrangement flowArrangement60 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment54, (double) (short) 0, (double) (-1L));
        org.jfree.chart.LegendItemSource legendItemSource61 = null;
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle(legendItemSource61);
        legendTitle62.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer65 = null;
        legendTitle62.setWrapper(blockContainer65);
        legendTitle62.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle62.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle62.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder83 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets84 = blockBorder83.getInsets();
        double double86 = rectangleInsets84.calculateTopInset((double) '#');
        java.lang.String str87 = rectangleInsets84.toString();
        legendTitle62.setLegendItemGraphicPadding(rectangleInsets84);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor89 = legendTitle62.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = legendTitle62.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockContainer blockContainer91 = new org.jfree.chart.block.BlockContainer();
        legendTitle62.setWrapper(blockContainer91);
        java.awt.Graphics2D graphics2D93 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint94 = null;
        try {
            org.jfree.chart.util.Size2D size2D95 = flowArrangement60.arrange(blockContainer91, graphics2D93, rectangleConstraint94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str32.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "VerticalAlignment.CENTER" + "'", str55.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(rectangleInsets84);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.0d + "'", double86 == 1.0d);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str87.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor89);
        org.junit.Assert.assertNotNull(rectangleEdge90);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockBorder14.getInsets();
        double double17 = rectangleInsets15.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle(legendItemSource18);
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets15.createInsetRectangle(rectangle2D20, false, true);
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets9.createOutsetRectangle(rectangle2D23, true, false);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\nhi!", "");
        org.jfree.chart.ui.ProjectInfo projectInfo30 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library35 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        projectInfo30.addLibrary(library35);
        java.lang.Object obj37 = textTitle1.draw(graphics2D3, rectangle2D26, (java.lang.Object) projectInfo30);
        textTitle1.setText("TableOrder.BY_COLUMN");
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(projectInfo30);
        org.junit.Assert.assertNull(obj37);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean7 = piePlot1.equals((java.lang.Object) rectangleAnchor6);
        java.awt.Paint paint9 = piePlot1.getSectionPaint((java.lang.Comparable) 15);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Stroke stroke12 = piePlot11.getOutlineStroke();
        piePlot1.setLabelOutlineStroke(stroke12);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle1.setPosition(rectangleEdge20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        java.lang.String str24 = rectangleEdge23.toString();
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleEdge.TOP" + "'", str24.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        legendTitle2.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        legendTitle2.setWrapper(blockContainer5);
        double double7 = legendTitle2.getHeight();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle2.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Font font10 = legendTitle2.getItemFont();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.removeChangeListener(plotChangeListener13);
        java.awt.Font font15 = piePlot12.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean18 = piePlot12.equals((java.lang.Object) rectangleAnchor17);
        piePlot12.setShadowYOffset(0.0d);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("Rotation.CLOCKWISE", font10, (org.jfree.chart.plot.Plot) piePlot12, false);
        java.awt.Paint paint23 = jFreeChart22.getBorderPaint();
        boolean boolean24 = jFreeChart22.isBorderVisible();
        org.jfree.chart.title.LegendTitle legendTitle25 = jFreeChart22.getLegend();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(legendTitle25);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("rect", "RectangleEdge.TOP", "ChartEntity: tooltip = Rotation.CLOCKWISE", image3, "UnitType.RELATIVE", "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n", "PieLabelLinkStyle.STANDARD");
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        defaultKeyedValues2D0.setValue((java.lang.Number) 15, (java.lang.Comparable) 100, (java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        defaultKeyedValues2D0.removeColumn((int) (short) 0);
        java.lang.Comparable comparable9 = defaultKeyedValues2D0.getRowKey((int) (short) 0);
        java.lang.Comparable comparable10 = null;
        try {
            defaultKeyedValues2D0.removeValue(comparable10, (java.lang.Comparable) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        double double20 = rectangleInsets18.calculateTopInset((double) '#');
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets18);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = legendTitle3.getSources();
        boolean boolean23 = strokeMap0.equals((java.lang.Object) legendItemSourceArray22);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        legendTitle25.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer28 = null;
        legendTitle25.setWrapper(blockContainer28);
        legendTitle25.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle25.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle25.setWidth((double) '4');
        boolean boolean42 = strokeMap0.equals((java.lang.Object) legendTitle25);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.ui.Contributor contributor3 = new org.jfree.chart.ui.Contributor("", "");
        java.lang.String str4 = contributor3.getEmail();
        boolean boolean5 = unitType0.equals((java.lang.Object) str4);
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.RELATIVE" + "'", str6.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.zoom((double) (byte) 100);
        java.awt.Stroke stroke6 = piePlot1.getOutlineStroke();
        java.awt.Paint paint8 = piePlot1.getSectionPaint((java.lang.Comparable) 10.0f);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        java.awt.Font font5 = piePlot1.getLabelFont();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        piePlot1.setOutlinePaint((java.awt.Paint) color6);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Stroke stroke11 = piePlot10.getOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 52.0d, stroke11);
        double double13 = piePlot1.getInteriorGap();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = color2.darker();
        java.awt.Color color4 = color3.darker();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint8 = textTitle7.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textTitle7.getTextAlignment();
        java.awt.Font font11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("hi!", font11);
        java.awt.Paint paint13 = textTitle12.getPaint();
        java.lang.Object obj14 = textTitle12.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle12.getTextAlignment();
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        legendTitle17.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer20 = null;
        legendTitle17.setWrapper(blockContainer20);
        legendTitle17.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle17.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle17.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = blockBorder38.getInsets();
        double double41 = rectangleInsets39.calculateTopInset((double) '#');
        java.lang.String str42 = rectangleInsets39.toString();
        legendTitle17.setLegendItemGraphicPadding(rectangleInsets39);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        legendTitle45.setWidth((double) 0L);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        legendTitle49.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer52 = null;
        legendTitle49.setWrapper(blockContainer52);
        legendTitle49.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle49.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment64 = legendTitle49.getVerticalAlignment();
        java.lang.String str65 = verticalAlignment64.toString();
        legendTitle45.setVerticalAlignment(verticalAlignment64);
        legendTitle17.setVerticalAlignment(verticalAlignment64);
        org.jfree.chart.block.FlowArrangement flowArrangement70 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment64, (double) (short) 0, (double) (-1L));
        org.jfree.data.general.PieDataset pieDataset71 = null;
        org.jfree.chart.plot.PiePlot piePlot72 = new org.jfree.chart.plot.PiePlot(pieDataset71);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot72.setLabelOutlineStroke(stroke73);
        java.lang.Object obj75 = piePlot72.clone();
        piePlot72.setOutlineVisible(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator78 = null;
        piePlot72.setToolTipGenerator(pieToolTipGenerator78);
        org.jfree.chart.event.PlotChangeListener plotChangeListener80 = null;
        piePlot72.removeChangeListener(plotChangeListener80);
        boolean boolean82 = piePlot72.isSubplot();
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = piePlot72.getLabelPadding();
        org.jfree.chart.title.TextTitle textTitle84 = new org.jfree.chart.title.TextTitle("", font1, (java.awt.Paint) color3, rectangleEdge5, horizontalAlignment9, verticalAlignment64, rectangleInsets83);
        org.jfree.chart.util.VerticalAlignment verticalAlignment85 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement88 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment85, 230.0d, 0.08d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str42.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
        org.junit.Assert.assertNotNull(verticalAlignment64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "VerticalAlignment.CENTER" + "'", str65.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(rectangleInsets83);
        org.junit.Assert.assertNotNull(verticalAlignment85);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.CENTER", "ChartEntity: tooltip = Rotation.CLOCKWISE", "RectangleAnchor.BOTTOM_RIGHT", "Rotation.CLOCKWISE", "rect");
        projectInfo3.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        java.awt.Font font13 = null;
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.removeChangeListener(plotChangeListener16);
        piePlot15.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("", font13, (org.jfree.chart.plot.Plot) piePlot15, false);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        java.awt.image.BufferedImage bufferedImage28 = jFreeChart21.createBufferedImage(178, 2, 1, chartRenderingInfo27);
        projectInfo3.setLogo((java.awt.Image) bufferedImage28);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(bufferedImage28);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        java.lang.String str13 = piePlot1.getPlotType();
        java.awt.Shape shape14 = piePlot1.getLegendItemShape();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        java.lang.Object obj4 = textTitle2.clone();
        java.lang.String str5 = textTitle2.getURLText();
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle2.getVerticalAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle1.getVerticalAlignment();
        legendTitle1.setWidth(90.0d);
        org.junit.Assert.assertNotNull(verticalAlignment4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        java.lang.Object obj4 = piePlot1.clone();
        piePlot1.setOutlineVisible(false);
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        piePlot1.setCircular(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle3.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle3.setWidth((double) '4');
        legendTitle3.setWidth(0.0d);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle3.setItemPaint((java.awt.Paint) color22);
        boolean boolean24 = piePlot1.equals((java.lang.Object) legendTitle3);
        piePlot1.zoom((double) 100L);
        piePlot1.setForegroundAlpha((float) (-15728654));
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot30.setLabelOutlineStroke(stroke31);
        piePlot30.setIgnoreNullValues(false);
        java.awt.Stroke stroke35 = piePlot30.getBaseSectionOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke35);
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke38 = lineBorder37.getStroke();
        piePlot1.setLabelLinkStroke(stroke38);
        java.awt.Paint paint40 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint40);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo2);
//        java.lang.String str4 = projectInfo0.getVersion();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE version TableOrder.BY_COLUMN.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).  (hi!).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).\nUnitType.RELATIVE LICENCE TERMS:\n" + "'", str1.equals("UnitType.RELATIVE version TableOrder.BY_COLUMN.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).  (hi!).  (hi!).UnitType.RELATIVE TableOrder.BY_COLUMN ().  (hi!).  (hi!).VerticalAlignment.CENTER ChartEntity: tooltip = Rotation.CLOCKWISE (RectangleAnchor.BOTTOM_RIGHT).\nUnitType.RELATIVE LICENCE TERMS:\n"));
//        org.junit.Assert.assertNotNull(projectInfo2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TableOrder.BY_COLUMN" + "'", str4.equals("TableOrder.BY_COLUMN"));
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.Plot plot6 = plotChangeEvent5.getPlot();
        org.jfree.chart.plot.Plot plot7 = plot6.getRootPlot();
        java.awt.Image image8 = null;
        plot7.setBackgroundImage(image8);
        java.awt.Stroke stroke10 = plot7.getOutlineStroke();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle2.getPosition();
        boolean boolean5 = textTitle2.getExpandToFitSpace();
        textTitle2.setExpandToFitSpace(false);
        textTitle2.setText("hi!");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Class<?> wildcardClass1 = multiplePiePlot0.getClass();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder2);
        java.awt.Font font5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.removeChangeListener(plotChangeListener8);
        piePlot7.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font5, (org.jfree.chart.plot.Plot) piePlot7, false);
        int int14 = jFreeChart13.getSubtitleCount();
        int int15 = jFreeChart13.getBackgroundImageAlignment();
        java.awt.Paint paint16 = jFreeChart13.getBackgroundPaint();
        jFreeChart13.setTitle("UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).UnitType.RELATIVE 1.2.0-pre ().  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n");
        jFreeChart13.setAntiAlias(false);
        org.jfree.chart.plot.Plot plot21 = jFreeChart13.getPlot();
        multiplePiePlot0.setPieChart(jFreeChart13);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(plot21);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library5 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        projectInfo0.addLibrary(library5);
        org.jfree.chart.ui.Library library11 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor15 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean16 = library11.equals((java.lang.Object) chartColor15);
        projectInfo0.addOptionalLibrary(library11);
        org.jfree.chart.ui.Library library22 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        java.lang.String str23 = library22.getLicenceName();
        projectInfo0.addLibrary(library22);
        projectInfo0.addOptionalLibrary("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color2 = java.awt.Color.getColor("ChartEntity: tooltip = ", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle1.setPosition(rectangleEdge20);
        legendTitle1.setPadding((double) 10.0f, 0.0d, (double) 1.0f, (double) (-1.0f));
        java.awt.Font font28 = null;
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        piePlot30.removeChangeListener(plotChangeListener31);
        piePlot30.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", font28, (org.jfree.chart.plot.Plot) piePlot30, false);
        jFreeChart36.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        java.awt.image.BufferedImage bufferedImage43 = jFreeChart36.createBufferedImage(178, 2, 1, chartRenderingInfo42);
        java.awt.RenderingHints renderingHints44 = jFreeChart36.getRenderingHints();
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart36);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendTitle1.getLegendItemGraphicPadding();
        double double48 = rectangleInsets46.extendWidth(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(bufferedImage43);
        org.junit.Assert.assertNotNull(renderingHints44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 26.0d + "'", double48 == 26.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        java.lang.String str2 = unitType0.toString();
        java.lang.String str3 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.RELATIVE" + "'", str2.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UnitType.RELATIVE" + "'", str3.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        double double4 = piePlot1.getShadowYOffset();
        boolean boolean5 = piePlot1.isCircular();
        org.jfree.chart.util.Rotation rotation6 = null;
        try {
            piePlot1.setDirection(rotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Font font2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.removeChangeListener(plotChangeListener5);
        piePlot4.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) piePlot4, false);
        jFreeChart10.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart10.createBufferedImage(178, 2, 1, chartRenderingInfo16);
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        jFreeChart10.setBorderPaint(paint18);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart10, chartChangeEventType20);
        boolean boolean23 = chartChangeEventType20.equals((java.lang.Object) 96.0d);
        java.lang.String str24 = chartChangeEventType20.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str24.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Block block2 = null;
        org.jfree.chart.ui.Library library7 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean12 = library7.equals((java.lang.Object) chartColor11);
        blockContainer1.add(block2, (java.lang.Object) boolean12);
        org.jfree.chart.block.Arrangement arrangement14 = blockContainer1.getArrangement();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        legendTitle16.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer19 = null;
        legendTitle16.setWrapper(blockContainer19);
        double double21 = legendTitle16.getHeight();
        blockContainer1.add((org.jfree.chart.block.Block) legendTitle16);
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        legendTitle25.setWidth((double) 0L);
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = blockBorder32.getInsets();
        double double35 = rectangleInsets33.calculateTopInset((double) (byte) -1);
        legendTitle25.setItemLabelPadding(rectangleInsets33);
        java.lang.Object obj37 = null;
        columnArrangement23.add((org.jfree.chart.block.Block) legendTitle25, obj37);
        blockContainer1.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement23);
        columnArrangement23.clear();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(arrangement14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        boolean boolean11 = legendTitle1.getNotify();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.LegendItemSource legendItemSource14 = null;
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource14);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle15.getBounds();
        lineBorder12.draw(graphics2D13, rectangle2D16);
        legendTitle1.setBounds(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "PieLabelLinkStyle.QUAD_CURVE", "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]");
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        legendTitle23.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer26 = null;
        legendTitle23.setWrapper(blockContainer26);
        double double28 = legendTitle23.getHeight();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle23.setBackgroundPaint((java.awt.Paint) color29);
        java.awt.Font font31 = legendTitle23.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendTitle23.getMargin();
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(rectangleInsets32, (java.awt.Paint) color33);
        org.jfree.chart.LegendItemSource legendItemSource35 = null;
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle(legendItemSource35);
        legendTitle36.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = legendTitle36.getVerticalAlignment();
        java.awt.geom.Rectangle2D rectangle2D40 = legendTitle36.getBounds();
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets32.createInsetRectangle(rectangle2D40, false, true);
        chartEntity21.setArea((java.awt.Shape) rectangle2D40);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D43);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.UnitType unitType11 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType11, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        boolean boolean18 = unitType11.equals((java.lang.Object) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(unitType11, (double) 1.0f, (double) 178, (double) (-1), 10.0d);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        boolean boolean27 = legendTitle25.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.event.TitleChangeListener titleChangeListener28 = null;
        legendTitle25.removeChangeListener(titleChangeListener28);
        org.jfree.chart.util.UnitType unitType30 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = new org.jfree.chart.util.RectangleInsets(unitType30, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder40 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = blockBorder40.getInsets();
        double double43 = rectangleInsets41.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        java.awt.geom.Rectangle2D rectangle2D46 = legendTitle45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets41.createInsetRectangle(rectangle2D46, false, true);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets35.createOutsetRectangle(rectangle2D49, true, false);
        legendTitle25.setBounds(rectangle2D52);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets23.createOutsetRectangle(rectangle2D52, true, false);
        org.jfree.chart.block.BlockBorder blockBorder61 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = blockBorder61.getInsets();
        double double64 = rectangleInsets62.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource65 = null;
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle(legendItemSource65);
        java.awt.geom.Rectangle2D rectangle2D67 = legendTitle66.getBounds();
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets62.createInsetRectangle(rectangle2D67, false, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Point2D point2D72 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D67, rectangleAnchor71);
        java.lang.Class<?> wildcardClass73 = point2D72.getClass();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo74 = null;
        try {
            jFreeChart9.draw(graphics2D10, rectangle2D52, point2D72, chartRenderingInfo74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(point2D72);
        org.junit.Assert.assertNotNull(wildcardClass73);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        jFreeChart9.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        java.awt.image.BufferedImage bufferedImage16 = jFreeChart9.createBufferedImage(178, 2, 1, chartRenderingInfo15);
        java.awt.RenderingHints renderingHints17 = jFreeChart9.getRenderingHints();
        java.awt.Paint paint18 = jFreeChart9.getBorderPaint();
        org.junit.Assert.assertNotNull(bufferedImage16);
        org.junit.Assert.assertNotNull(renderingHints17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        double double18 = rectangleInsets16.calculateTopInset((double) '#');
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets16);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle1.setPosition(rectangleEdge20);
        legendTitle1.setPadding((double) 10.0f, 0.0d, (double) 1.0f, (double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle1.getLegendItemGraphicPadding();
        double double29 = rectangleInsets27.calculateLeftInset((double) (byte) 10);
        double double31 = rectangleInsets27.calculateTopInset(0.4d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.0d + "'", double29 == 10.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle3.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle3.setWidth((double) '4');
        legendTitle3.setWidth(0.0d);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        legendTitle3.setItemPaint((java.awt.Paint) color22);
        boolean boolean24 = piePlot1.equals((java.lang.Object) legendTitle3);
        java.awt.Paint paint25 = piePlot1.getShadowPaint();
        java.awt.Paint paint26 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        try {
            defaultCategoryDataset0.removeRow(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Font font2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.removeChangeListener(plotChangeListener5);
        piePlot4.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) piePlot4, false);
        jFreeChart10.setTextAntiAlias(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart10.createBufferedImage(178, 2, 1, chartRenderingInfo16);
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        jFreeChart10.setBorderPaint(paint18);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart10, chartChangeEventType20);
        jFreeChart10.removeLegend();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.setIgnoreNullValues(false);
        java.awt.Stroke stroke6 = piePlot1.getBaseSectionOutlineStroke();
        piePlot1.setStartAngle(100.0d);
        piePlot1.setMaximumLabelWidth((-15.0d));
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        piePlot1.axisChanged(axisChangeEvent11);
        java.awt.Paint paint14 = piePlot1.getSectionPaint((java.lang.Comparable) "UnitType.RELATIVE");
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = piePlot1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        java.lang.Object obj6 = null;
        boolean boolean7 = rectangleInsets5.equals(obj6);
        double double9 = rectangleInsets5.extendHeight(15.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 17.0d + "'", double9 == 17.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean7 = piePlot1.equals((java.lang.Object) rectangleAnchor6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        piePlot1.markerChanged(markerChangeEvent8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int11 = color10.getBlue();
        piePlot1.setBaseSectionPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        double double25 = rectangleInsets23.calculateTopInset((double) '#');
        java.lang.String str26 = rectangleInsets23.toString();
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets23);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = null;
        try {
            org.jfree.chart.util.Size2D size2D30 = legendTitle1.arrange(graphics2D28, rectangleConstraint29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]" + "'", str26.equals("RectangleInsets[t=1.0,l=10.0,b=1.0,r=15.0]"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        java.awt.Font font3 = piePlot1.getLabelFont();
        piePlot1.setCircular(false, false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        double double20 = rectangleInsets18.calculateTopInset((double) '#');
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets18);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = legendTitle3.getSources();
        boolean boolean23 = strokeMap0.equals((java.lang.Object) legendItemSourceArray22);
        strokeMap0.clear();
        java.lang.Object obj25 = strokeMap0.clone();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        piePlot28.removeChangeListener(plotChangeListener29);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier31);
        java.awt.Paint paint33 = piePlot28.getLabelLinkPaint();
        java.awt.Stroke stroke34 = piePlot28.getLabelOutlineStroke();
        strokeMap0.put((java.lang.Comparable) "", stroke34);
        strokeMap0.clear();
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        int int10 = jFreeChart9.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        double double19 = rectangleInsets17.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle21.getBounds();
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets17.createInsetRectangle(rectangle2D22, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D22, "Rotation.CLOCKWISE");
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = blockBorder32.getInsets();
        double double35 = rectangleInsets33.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle37.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets33.createInsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Point2D point2D43 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor42);
        java.lang.Class<?> wildcardClass44 = point2D43.getClass();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = null;
        try {
            jFreeChart9.draw(graphics2D11, rectangle2D22, point2D43, chartRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(point2D43);
        org.junit.Assert.assertNotNull(wildcardClass44);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.lang.Object obj10 = jFreeChart9.clone();
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        java.lang.String str13 = piePlot1.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot1.getLabelPadding();
        org.jfree.data.general.PieDataset pieDataset15 = piePlot1.getDataset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pie Plot" + "'", str13.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(pieDataset15);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        double double20 = rectangleInsets18.calculateTopInset((double) '#');
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets18);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = legendTitle3.getSources();
        boolean boolean23 = strokeMap0.equals((java.lang.Object) legendItemSourceArray22);
        strokeMap0.clear();
        java.lang.Object obj25 = strokeMap0.clone();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        piePlot28.removeChangeListener(plotChangeListener29);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier31);
        java.awt.Paint paint33 = piePlot28.getLabelLinkPaint();
        java.awt.Stroke stroke34 = piePlot28.getLabelOutlineStroke();
        strokeMap0.put((java.lang.Comparable) "", stroke34);
        java.lang.Object obj36 = null;
        boolean boolean37 = strokeMap0.equals(obj36);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("Multiple Pie Plot");
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        float[] floatArray9 = new float[] { (byte) -1, (byte) -1, (-1) };
        float[] floatArray10 = java.awt.Color.RGBtoHSB(2, (int) (byte) -1, (int) 'a', floatArray9);
        float[] floatArray11 = java.awt.Color.RGBtoHSB(10, (-1), (int) (short) 1, floatArray9);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.removeChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.plot.Plot plot7 = plotChangeEvent6.getPlot();
        boolean boolean8 = horizontalAlignment0.equals((java.lang.Object) plot7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("UnitType.RELATIVE");
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = textTitle10.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment11, (double) 1L, (double) 10.0f);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        legendTitle1.setWidth((double) '4');
        legendTitle1.setWidth(0.0d);
        legendTitle1.setNotify(true);
        double double22 = legendTitle1.getContentYOffset();
        org.jfree.chart.LegendItemSource legendItemSource23 = null;
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle(legendItemSource23);
        legendTitle24.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer27 = null;
        legendTitle24.setWrapper(blockContainer27);
        double double29 = legendTitle24.getHeight();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle24.setBackgroundPaint((java.awt.Paint) color30);
        java.awt.Font font32 = legendTitle24.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle24.getMargin();
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder(rectangleInsets33, (java.awt.Paint) color34);
        org.jfree.chart.LegendItemSource legendItemSource36 = null;
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle(legendItemSource36);
        legendTitle37.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = legendTitle37.getVerticalAlignment();
        java.awt.geom.Rectangle2D rectangle2D41 = legendTitle37.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets33.createInsetRectangle(rectangle2D41, false, true);
        legendTitle1.setBounds(rectangle2D44);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(verticalAlignment40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D44);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("{0}", "UnitType.RELATIVE version 1.2.0-pre.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY UnitType.RELATIVE:  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).  (hi!).\nUnitType.RELATIVE LICENCE TERMS:\n", "ChartEntity: tooltip = Rotation.CLOCKWISE", "");
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendHeight(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.0d + "'", double2 == 9.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 1, 0.0d, (double) 10.0f, 4.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.setIgnoreNullValues(false);
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        float float7 = piePlot1.getForegroundAlpha();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle10.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D11, "");
        java.lang.String str14 = chartEntity13.getToolTipText();
        org.jfree.chart.util.UnitType unitType15 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets(unitType15, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockBorder25.getInsets();
        double double28 = rectangleInsets26.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle30.getBounds();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets26.createInsetRectangle(rectangle2D31, false, true);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets20.createOutsetRectangle(rectangle2D34, true, false);
        chartEntity13.setArea((java.awt.Shape) rectangle2D37);
        java.awt.Font font40 = null;
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        piePlot42.removeChangeListener(plotChangeListener43);
        piePlot42.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart("", font40, (org.jfree.chart.plot.Plot) piePlot42, false);
        java.awt.Paint paint49 = piePlot42.getLabelLinkPaint();
        org.jfree.chart.ui.Library library54 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor58 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean59 = library54.equals((java.lang.Object) chartColor58);
        piePlot42.setBaseSectionPaint((java.awt.Paint) chartColor58);
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = piePlot42.getSimpleLabelOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        org.jfree.chart.plot.PiePlotState piePlotState64 = piePlot1.initialise(graphics2D8, rectangle2D37, piePlot42, (java.lang.Integer) (-15728654), plotRenderingInfo63);
        int int65 = piePlot1.getPieIndex();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertNotNull(piePlotState64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        legendTitle3.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle3.setWrapper(blockContainer6);
        legendTitle3.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        double double20 = rectangleInsets18.calculateTopInset((double) '#');
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets18);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = legendTitle3.getSources();
        boolean boolean23 = strokeMap0.equals((java.lang.Object) legendItemSourceArray22);
        java.lang.Object obj24 = strokeMap0.clone();
        strokeMap0.clear();
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray17 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle1.getLegendItemGraphicPadding();
        java.awt.Paint paint19 = legendTitle1.getBackgroundPaint();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(legendItemSourceArray17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.cyan;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.removeChangeListener(plotChangeListener8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        java.awt.Paint paint13 = defaultDrawingSupplier10.getNextOutlinePaint();
        java.lang.Object obj14 = defaultDrawingSupplier10.clone();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color1 = color0.darker();
        int int2 = color1.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-16731648) + "'", int2 == (-16731648));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot1.setLabelOutlineStroke(stroke2);
        piePlot1.setIgnoreNullValues(false);
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        float float7 = piePlot1.getForegroundAlpha();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        java.awt.geom.Rectangle2D rectangle2D11 = legendTitle10.getBounds();
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D11, "");
        java.lang.String str14 = chartEntity13.getToolTipText();
        org.jfree.chart.util.UnitType unitType15 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets(unitType15, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockBorder25.getInsets();
        double double28 = rectangleInsets26.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource29 = null;
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle(legendItemSource29);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle30.getBounds();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets26.createInsetRectangle(rectangle2D31, false, true);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets20.createOutsetRectangle(rectangle2D34, true, false);
        chartEntity13.setArea((java.awt.Shape) rectangle2D37);
        java.awt.Font font40 = null;
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        piePlot42.removeChangeListener(plotChangeListener43);
        piePlot42.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart("", font40, (org.jfree.chart.plot.Plot) piePlot42, false);
        java.awt.Paint paint49 = piePlot42.getLabelLinkPaint();
        org.jfree.chart.ui.Library library54 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor58 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean59 = library54.equals((java.lang.Object) chartColor58);
        piePlot42.setBaseSectionPaint((java.awt.Paint) chartColor58);
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = piePlot42.getSimpleLabelOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        org.jfree.chart.plot.PiePlotState piePlotState64 = piePlot1.initialise(graphics2D8, rectangle2D37, piePlot42, (java.lang.Integer) (-15728654), plotRenderingInfo63);
        org.jfree.chart.entity.ChartEntity chartEntity65 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D37);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertNotNull(piePlotState64);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Image image2 = piePlot1.getBackgroundImage();
        double double3 = piePlot1.getShadowYOffset();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        projectInfo7.setInfo("");
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo10);
        java.util.List list12 = projectInfo10.getContributors();
        java.awt.Image image13 = projectInfo10.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("0,1,1,-1", "hi!", "ChartEntity: tooltip = ", image13, "TableOrder.BY_COLUMN", "java.awt.Color[r=64,g=64,b=255]", "ChartEntity: tooltip = Rotation.CLOCKWISE");
        piePlot1.setBackgroundImage(image13);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(image13);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Color color1 = color0.darker();
        float[] floatArray2 = null;
        float[] floatArray3 = color0.getRGBComponents(floatArray2);
        java.awt.Color color4 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.removeChangeListener(plotChangeListener4);
        piePlot3.setBackgroundAlpha(1.0f);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        int int10 = jFreeChart9.getSubtitleCount();
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font12);
        java.awt.Paint paint14 = textTitle13.getPaint();
        java.lang.Object obj15 = textTitle13.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle13.getTextAlignment();
        java.awt.Font font18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        textTitle13.setFont(font18);
        org.jfree.chart.LegendItemSource legendItemSource21 = null;
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle(legendItemSource21);
        legendTitle22.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer25 = null;
        legendTitle22.setWrapper(blockContainer25);
        legendTitle22.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = blockBorder36.getInsets();
        double double39 = rectangleInsets37.calculateTopInset((double) '#');
        legendTitle22.setLegendItemGraphicPadding(rectangleInsets37);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle22.setPosition(rectangleEdge41);
        textTitle13.setPosition(rectangleEdge41);
        java.awt.Paint paint44 = null;
        textTitle13.setBackgroundPaint(paint44);
        jFreeChart9.removeSubtitle((org.jfree.chart.title.Title) textTitle13);
        boolean boolean47 = jFreeChart9.getAntiAlias();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = null;
        try {
            java.awt.image.BufferedImage bufferedImage51 = jFreeChart9.createBufferedImage((-1), 0, chartRenderingInfo50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("ChartEntity: tooltip = ");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Class<?> wildcardClass1 = multiplePiePlot0.getClass();
        org.jfree.chart.util.TableOrder tableOrder2 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder2);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        multiplePiePlot0.setAggregatedItemsPaint(paint4);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.removeChangeListener(plotChangeListener2);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        double double7 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getLabelPadding();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        legendTitle10.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer13 = null;
        legendTitle10.setWrapper(blockContainer13);
        double double15 = legendTitle10.getHeight();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle10.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Font font18 = legendTitle10.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle10.getMargin();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets19, (java.awt.Paint) color20);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        legendTitle23.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = legendTitle23.getVerticalAlignment();
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle23.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets19.createInsetRectangle(rectangle2D27, false, true);
        rectangleInsets8.trim(rectangle2D30);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        java.awt.Paint paint3 = textTitle2.getPaint();
        double double4 = textTitle2.getWidth();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getBlue();
        org.jfree.chart.block.BlockBorder blockBorder2 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color4 = color3.darker();
        boolean boolean5 = blockBorder2.equals((java.lang.Object) color3);
        java.awt.color.ColorSpace colorSpace6 = color3.getColorSpace();
        java.awt.Color color10 = java.awt.Color.getHSBColor((float) '#', (float) '#', 10.0f);
        org.jfree.chart.ui.Library library15 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean20 = library15.equals((java.lang.Object) chartColor19);
        float[] floatArray27 = new float[] { (byte) -1, (byte) -1, (-1) };
        float[] floatArray28 = java.awt.Color.RGBtoHSB(2, (int) (byte) -1, (int) 'a', floatArray27);
        float[] floatArray29 = chartColor19.getRGBColorComponents(floatArray27);
        float[] floatArray30 = color10.getColorComponents(floatArray29);
        java.awt.Color color31 = java.awt.Color.green;
        java.awt.Color color32 = color31.darker();
        float[] floatArray33 = null;
        float[] floatArray34 = color31.getRGBComponents(floatArray33);
        float[] floatArray41 = new float[] { (byte) -1, (byte) -1, (-1) };
        float[] floatArray42 = java.awt.Color.RGBtoHSB(2, (int) (byte) -1, (int) 'a', floatArray41);
        float[] floatArray43 = color31.getRGBColorComponents(floatArray42);
        float[] floatArray44 = color10.getRGBColorComponents(floatArray42);
        float[] floatArray45 = color0.getColorComponents(colorSpace6, floatArray42);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(blockBorder2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(178);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Class<?> wildcardClass1 = multiplePiePlot0.getClass();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = multiplePiePlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset3 = multiplePiePlot0.getDataset();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        legendTitle5.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer8 = null;
        legendTitle5.setWrapper(blockContainer8);
        double double10 = legendTitle5.getHeight();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        legendTitle5.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Font font13 = legendTitle5.getItemFont();
        multiplePiePlot0.setNoDataMessageFont(font13);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(legendItemCollection2);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        legendTitle1.setPadding((double) (-1L), 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = legendTitle1.getVerticalAlignment();
        java.lang.Object obj17 = legendTitle1.clone();
        legendTitle1.setNotify(true);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getColumnIndex((java.lang.Comparable) "{0}");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        java.util.List list5 = jFreeChart4.getSubtitles();
        boolean boolean6 = jFreeChart4.getAntiAlias();
        java.awt.Color color7 = java.awt.Color.CYAN;
        jFreeChart4.setBorderPaint((java.awt.Paint) color7);
        boolean boolean9 = defaultCategoryDataset0.equals((java.lang.Object) jFreeChart4);
        defaultCategoryDataset0.validateObject();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        legendTitle1.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        boolean boolean11 = legendTitle1.getNotify();
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource12);
        legendTitle13.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer16 = null;
        legendTitle13.setWrapper(blockContainer16);
        legendTitle13.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        boolean boolean23 = legendTitle13.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        legendTitle13.setPosition(rectangleEdge24);
        legendTitle1.setPosition(rectangleEdge24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = legendTitle1.getPosition();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent28 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getOutlineStroke();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        java.awt.geom.Rectangle2D rectangle2D5 = legendTitle4.getBounds();
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        legendTitle7.setWidth((double) 0L);
        org.jfree.chart.block.BlockContainer blockContainer10 = null;
        legendTitle7.setWrapper(blockContainer10);
        legendTitle7.setMargin((double) 0L, (double) ' ', (double) 'a', 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = blockBorder21.getInsets();
        double double24 = rectangleInsets22.calculateTopInset((double) '#');
        legendTitle7.setLegendItemGraphicPadding(rectangleInsets22);
        double double27 = rectangleInsets22.calculateRightOutset(15.0d);
        legendTitle4.setPadding(rectangleInsets22);
        piePlot1.setLabelPadding(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 15.0d + "'", double27 == 15.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, 0.0d, (double) (-1.0f), (double) (byte) 10, (double) ' ');
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, 10.0d, (double) 1L, (double) 15);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        double double15 = rectangleInsets13.calculateTopInset((double) (byte) -1);
        org.jfree.chart.LegendItemSource legendItemSource16 = null;
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle(legendItemSource16);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle17.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createInsetRectangle(rectangle2D18, false, true);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets7.createOutsetRectangle(rectangle2D21, true, false);
        int int25 = objectList1.indexOf((java.lang.Object) true);
        org.jfree.chart.ui.ProjectInfo projectInfo26 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library library31 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        projectInfo26.addLibrary(library31);
        org.jfree.chart.ui.Library library37 = new org.jfree.chart.ui.Library("", "", "Rotation.CLOCKWISE", "Rotation.CLOCKWISE");
        org.jfree.chart.ChartColor chartColor41 = new org.jfree.chart.ChartColor((int) (byte) 100, 3, (int) (byte) 1);
        boolean boolean42 = library37.equals((java.lang.Object) chartColor41);
        projectInfo26.addOptionalLibrary(library37);
        org.jfree.chart.ui.Library library48 = new org.jfree.chart.ui.Library("", "", "", "hi!");
        java.lang.String str49 = library48.getLicenceName();
        projectInfo26.addLibrary(library48);
        boolean boolean51 = objectList1.equals((java.lang.Object) library48);
        java.lang.String str52 = library48.getName();
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(projectInfo26);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setWidth((double) 0L);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = legendTitle1.getVerticalAlignment();
        java.awt.geom.Rectangle2D rectangle2D5 = legendTitle1.getBounds();
        double double6 = legendTitle1.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle1.getPosition();
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Image image2 = piePlot1.getBackgroundImage();
        java.awt.Paint paint3 = piePlot1.getLabelLinkPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelGenerator();
        java.awt.Paint paint6 = piePlot1.getSectionPaint((java.lang.Comparable) "Rotation.CLOCKWISE");
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(paint6);
    }
}

