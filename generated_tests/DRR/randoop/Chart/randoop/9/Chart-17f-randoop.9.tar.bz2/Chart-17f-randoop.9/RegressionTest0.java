import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) ' ', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day5, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = null;
        try {
            timeSeries14.add(timeSeriesDataItem19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class14);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries15.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        int int21 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day19);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        try {
            timeSeries4.add(regularTimePeriod9, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            java.lang.Number number9 = timeSeries7.getValue(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        try {
            timeSeries4.delete((int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            timeSeries4.add(regularTimePeriod8, (double) 0L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 0, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (-1.0d));
        try {
            timeSeries7.add(timeSeriesDataItem17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day5.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries4.getDescription();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        java.lang.Class class0 = null;
//        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
//        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader1);
//        org.junit.Assert.assertNotNull(classLoader1);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy(regularTimePeriod9, regularTimePeriod11);
        try {
            timeSeries7.delete(2, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        java.lang.Class class1 = null;
//        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", class1);
//        org.junit.Assert.assertNull(uRL2);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries4.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.getDataItem(regularTimePeriod14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1, (int) (short) 10, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        int int9 = year8.getYear();
        try {
            java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) int9);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year3.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        java.util.Date date10 = regularTimePeriod9.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 1900, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) '4', (java.lang.Object) seriesChangeListener9);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day5.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class19);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        timeSeries23.fireSeriesChanged();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
        java.util.Date date29 = regularTimePeriod28.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) day30);
        try {
            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        long long9 = year8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100, (int) (short) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        java.util.Calendar calendar9 = null;
        try {
            year8.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.removeChangeListener(seriesChangeListener5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        int int10 = day5.getMonth();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day5.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-459), 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        boolean boolean9 = year3.equals((java.lang.Object) '#');
        java.util.Calendar calendar10 = null;
        try {
            year3.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
        int int29 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) day27);
        try {
            timeSeries14.add((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 10L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Comparable comparable19 = null;
        try {
            timeSeries18.setKey(comparable19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        java.util.List list11 = timeSeries7.getItems();
        try {
            java.util.Collection collection12 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list11);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener11);
        try {
            java.lang.Number number14 = timeSeries4.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year8.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        timeSeries7.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries7.addChangeListener(seriesChangeListener9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        try {
//            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 10.0f);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -459");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        boolean boolean25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year21, (java.lang.Object) date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24);
        java.lang.Number number27 = null;
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year26, number27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int5 = day3.compareTo((java.lang.Object) 1560409200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year13, (java.lang.Object) date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year18, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener11);
        timeSeries4.setNotify(true);
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day20);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (-1.0d), true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year3.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("13-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
//        long long10 = day5.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//        org.junit.Assert.assertNotNull(classLoader0);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int10);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Value");
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        java.util.List list11 = timeSeries7.getItems();
        try {
            timeSeries7.delete((-459), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -459");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy(regularTimePeriod9, regularTimePeriod11);
        timeSeries7.setKey((java.lang.Comparable) 10.0f);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener16);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries7.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        java.lang.String str21 = timeSeries18.getRangeDescription();
        timeSeries18.setRangeDescription("Value");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeries18.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries7.setRangeDescription("Time");
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class<?> wildcardClass8 = year3.getClass();
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(classLoader9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertNotNull(class11);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = day5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class<?> wildcardClass8 = year3.getClass();
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader9);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(classLoader9);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate12);
        boolean boolean14 = timeSeriesDataItem9.equals((java.lang.Object) serialDate12);
        java.lang.Object obj15 = timeSeriesDataItem9.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.lang.String str5 = serialDate2.getDescription();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, 2019, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        try {
            java.util.Collection collection9 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Friday" + "'", str1.equals("Friday"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        java.lang.String str5 = timeSeries4.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = day5.toString();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day5.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        java.lang.String str19 = month18.toString();
        java.lang.String str20 = month18.toString();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month18.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        timeSeries7.fireSeriesChanged();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        java.util.Date date13 = regularTimePeriod12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries7.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        long long21 = fixedMillisecond18.getLastMillisecond();
//        try {
//            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1900);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560439866760L + "'", long20 == 1560439866760L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560439866760L + "'", long21 == 1560439866760L);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        int int5 = year3.compareTo((java.lang.Object) (short) 0);
        int int7 = year3.compareTo((java.lang.Object) false);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year3.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year6, (java.lang.Object) date9);
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        java.lang.Class class12 = null;
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Preceding", (java.lang.Class) wildcardClass11, class12);
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ClassContext", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(inputStream14);
        org.junit.Assert.assertNull(inputStream15);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439867297L + "'", long2 == 1560439867297L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439867297L + "'", long3 == 1560439867297L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560439867297L + "'", long5 == 1560439867297L);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, (int) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        boolean boolean20 = timeSeries14.equals((java.lang.Object) (short) 0);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy((int) (short) 0, 0);
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day34);
        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day34);
        java.lang.Class class38 = null;
        java.lang.ClassLoader classLoader39 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class38);
        int int40 = day34.compareTo((java.lang.Object) class38);
        try {
            timeSeries14.add((org.jfree.data.time.RegularTimePeriod) day34, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(classLoader39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
        timeSeriesDataItem9.setValue((java.lang.Number) 1560409200000L);
        java.lang.Object obj18 = timeSeriesDataItem9.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        try {
            java.lang.Number number20 = timeSeries18.getValue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        java.lang.String str21 = timeSeries18.getRangeDescription();
        timeSeries18.setRangeDescription("Value");
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class27);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        timeSeries31.fireSeriesChanged();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) 1900);
        java.lang.Comparable comparable42 = timeSeries18.getKey();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + "Overwritten values from: hi!" + "'", comparable42.equals("Overwritten values from: hi!"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries7.setMaximumItemAge(0L);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        boolean boolean28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year24, (java.lang.Object) date27);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean28, class29);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries30.removePropertyChangeListener(propertyChangeListener31);
        java.lang.Comparable comparable33 = timeSeries30.getKey();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
        java.util.Date date36 = regularTimePeriod35.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date36, timeZone38);
        java.lang.String str40 = month39.toString();
        java.lang.String str41 = month39.toString();
        int int42 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month39);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month39, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + false + "'", comparable33.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "June 2019" + "'", str40.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "June 2019" + "'", str41.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Object obj19 = timeSeries14.clone();
        try {
            java.lang.Number number21 = timeSeries14.getValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (-1.0d));
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        java.util.Date date30 = regularTimePeriod29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
        boolean boolean33 = timeSeriesDataItem27.equals((java.lang.Object) regularTimePeriod32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, regularTimePeriod32);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        int int5 = day4.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.util.Date date12 = regularTimePeriod11.getEnd();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = timeSeriesDataItem9.equals(obj16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        long long21 = fixedMillisecond18.getLastMillisecond();
//        boolean boolean22 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond18);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond18.getFirstMillisecond(calendar23);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560439869425L + "'", long20 == 1560439869425L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560439869425L + "'", long21 == 1560439869425L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560439869425L + "'", long24 == 1560439869425L);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        java.lang.String str19 = month18.toString();
        java.lang.String str20 = month18.toString();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries9.addOrUpdate(regularTimePeriod22, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        java.lang.String str21 = timeSeries18.getRangeDescription();
        timeSeries18.setRangeDescription("Value");
        boolean boolean24 = timeSeries18.isEmpty();
        java.lang.Comparable comparable25 = timeSeries18.getKey();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + "Overwritten values from: hi!" + "'", comparable25.equals("Overwritten values from: hi!"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) date7);
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Overwritten values from: hi!", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(inputStream10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 520764324 + "'", int1 == 520764324);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        boolean boolean21 = timeSeries18.isEmpty();
        try {
            timeSeries18.delete((int) (byte) 10, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate2);
        serialDate3.setDescription("");
        serialDate3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=4]");
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate11);
        int int14 = year3.compareTo((java.lang.Object) serialDate11);
        serialDate11.setDescription("6-April-1900");
        java.lang.String str17 = serialDate11.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "6-April-1900" + "'", str17.equals("6-April-1900"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 2, (-452));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        java.lang.String str21 = timeSeries18.getRangeDescription();
        timeSeries18.setRangeDescription("13-June-2019");
        long long24 = timeSeries18.getMaximumItemAge();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem9.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1900);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.addOrUpdate(regularTimePeriod2, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries9.add(regularTimePeriod13, (java.lang.Number) 7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2147483647);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate11);
        int int14 = year3.compareTo((java.lang.Object) serialDate11);
        try {
            org.jfree.data.time.SerialDate serialDate16 = serialDate11.getFollowingDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.util.Date date12 = regularTimePeriod11.getEnd();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = timeSeriesDataItem9.equals(obj16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        long long21 = fixedMillisecond18.getLastMillisecond();
//        boolean boolean22 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond18);
//        java.lang.Object obj23 = timeSeriesDataItem9.clone();
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560439872113L + "'", long20 == 1560439872113L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560439872113L + "'", long21 == 1560439872113L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(obj23);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries7.setMaximumItemAge(0L);
        org.jfree.data.time.TimeSeries timeSeries21 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries7.addAndOrUpdate(timeSeries21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        try {
//            java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) int3);
//            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
//        } catch (java.lang.CloneNotSupportedException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 12);
        java.lang.Object obj11 = timeSeriesDataItem10.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year6, (java.lang.Object) date9);
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        java.util.Date date19 = regularTimePeriod18.getEnd();
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year16, (java.lang.Object) date19);
        java.lang.Class<?> wildcardClass21 = year16.getClass();
        java.lang.ClassLoader classLoader22 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass21);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("6-April-1900", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass21);
        java.io.InputStream inputStream24 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(classLoader22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNotNull(inputStream24);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener19);
        java.util.Collection collection21 = timeSeries7.getTimePeriods();
        java.util.Collection collection22 = org.jfree.chart.util.ObjectUtilities.deepClone(collection21);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(collection22);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        java.lang.Class<?> wildcardClass3 = day0.getClass();
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year6, (java.lang.Object) date9);
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("Friday", (java.lang.Class) wildcardClass11);
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries(comparable0, (java.lang.Class) wildcardClass11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        serialDate6.setDescription("");
        boolean boolean9 = spreadsheetDate1.isOn(serialDate6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year13, (java.lang.Object) date16);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate21);
        int int24 = year13.compareTo((java.lang.Object) serialDate21);
        serialDate21.setDescription("6-April-1900");
        boolean boolean27 = spreadsheetDate1.isOn(serialDate21);
        int int28 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f));
        try {
            int int31 = spreadsheetDate1.compareTo((java.lang.Object) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
        java.lang.Number number16 = timeSeriesDataItem9.getValue();
        java.lang.Number number17 = null;
        timeSeriesDataItem9.setValue(number17);
        timeSeriesDataItem9.setValue((java.lang.Number) 1.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.0d) + "'", number16.equals((-1.0d)));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        long long7 = year6.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        long long19 = timeSeries18.getMaximumItemAge();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jan" + "'", str2.equals("Jan"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate3 = null;
        try {
            boolean boolean4 = spreadsheetDate1.isOn(serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        java.lang.Object obj21 = null;
//        boolean boolean22 = day19.equals(obj21);
//        java.lang.String str23 = day19.toString();
//        java.lang.String str24 = day19.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
//        try {
//            timeSeries14.delete((-452), 11);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.String str4 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str4.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (-1));
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        java.lang.String str4 = day0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (byte) 1);
//        java.lang.Object obj4 = timeSeriesDataItem3.clone();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(obj4);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        java.lang.String str19 = month18.toString();
        java.lang.String str20 = month18.toString();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month18.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod22, (double) 5);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        boolean boolean8 = timeSeries4.getNotify();
        java.lang.Comparable comparable9 = null;
        try {
            timeSeries4.setKey(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        boolean boolean21 = timeSeries18.isEmpty();
        int int22 = timeSeries18.getMaximumItemCount();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        java.util.Date date25 = regularTimePeriod24.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (-1.0d));
        java.lang.Number number29 = timeSeriesDataItem28.getValue();
        try {
            timeSeries18.add(timeSeriesDataItem28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (-1.0d) + "'", number29.equals((-1.0d)));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        serialDate6.setDescription("");
        boolean boolean9 = spreadsheetDate1.isOn(serialDate6);
        java.lang.String str10 = spreadsheetDate1.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "8-January-1900" + "'", str10.equals("8-January-1900"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate2);
        serialDate3.setDescription("");
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate3.getPreviousDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        serialDate6.setDescription("");
        boolean boolean9 = spreadsheetDate1.isOn(serialDate6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year14, (java.lang.Object) date17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate22);
        int int25 = year14.compareTo((java.lang.Object) serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate22);
        boolean boolean27 = spreadsheetDate1.isOn(serialDate26);
        java.util.Date date28 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate29 = null;
        try {
            boolean boolean30 = spreadsheetDate1.isBefore(serialDate29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        long long5 = day4.getSerialIndex();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate6);
        serialDate7.setDescription("");
        boolean boolean10 = spreadsheetDate2.isOn(serialDate7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year14, (java.lang.Object) date17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate22);
        int int25 = year14.compareTo((java.lang.Object) serialDate22);
        serialDate22.setDescription("6-April-1900");
        boolean boolean28 = spreadsheetDate2.isOn(serialDate22);
        int int29 = spreadsheetDate2.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8 + "'", int29 == 8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9, serialDate4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate4.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        int int14 = day13.getMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
//        java.lang.Object obj19 = timeSeries14.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        java.lang.Object obj24 = null;
//        boolean boolean25 = day22.equals(obj24);
//        java.lang.String str26 = day22.toString();
//        java.lang.String str27 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 43629L);
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries14.removePropertyChangeListener(propertyChangeListener30);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener19);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (-1.0d));
        try {
            timeSeries7.add(timeSeriesDataItem30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class27);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        timeSeries31.fireSeriesChanged();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        boolean boolean40 = timeSeries23.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries7.addAndOrUpdate(timeSeries31);
        java.lang.String str42 = timeSeries41.getDescription();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNull(str42);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Overwritten values from: hi!");
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        try {
            int int4 = spreadsheetDate1.compareTo((java.lang.Object) 1560439865519L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
//        java.lang.Object obj19 = timeSeries14.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        java.lang.Object obj24 = null;
//        boolean boolean25 = day22.equals(obj24);
//        java.lang.String str26 = day22.toString();
//        java.lang.String str27 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 43629L);
//        java.lang.Class class30 = timeSeries14.getTimePeriodClass();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNull(class30);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries4.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries4.addChangeListener(seriesChangeListener14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries4.removeChangeListener(seriesChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) 'a', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener11);
        timeSeries4.setNotify(true);
        timeSeries4.setMaximumItemAge(1560439872113L);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        java.util.Date date19 = regularTimePeriod18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        boolean boolean24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year20, (java.lang.Object) date23);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean24, class25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries26.removePropertyChangeListener(propertyChangeListener27);
        java.lang.Comparable comparable29 = timeSeries26.getKey();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
        java.util.Date date32 = regularTimePeriod31.getEnd();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date32, timeZone34);
        java.lang.String str36 = month35.toString();
        java.lang.String str37 = month35.toString();
        int int38 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.next();
        java.util.Date date41 = regularTimePeriod40.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) 43629L);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day42, (double) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + false + "'", comparable29.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        java.lang.String str19 = month18.toString();
        java.lang.String str20 = month18.toString();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 43629L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries9.getNextTimePeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate11);
        int int14 = year3.compareTo((java.lang.Object) serialDate11);
        java.lang.String str15 = serialDate11.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        timeSeries7.setMaximumItemCount(100);
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        int int5 = year3.compareTo((java.lang.Object) (short) 0);
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date6, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
        java.lang.Number number16 = timeSeriesDataItem9.getValue();
        java.lang.Number number17 = null;
        timeSeriesDataItem9.setValue(number17);
        java.lang.Number number19 = timeSeriesDataItem9.getValue();
        java.lang.Number number20 = timeSeriesDataItem9.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.0d) + "'", number16.equals((-1.0d)));
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertNull(number20);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        boolean boolean25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year21, (java.lang.Object) date24);
        boolean boolean27 = year21.equals((java.lang.Object) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (double) 0.0f);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate11);
        int int14 = year3.compareTo((java.lang.Object) serialDate11);
        long long15 = year3.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries4.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        boolean boolean25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year21, (java.lang.Object) date24);
        boolean boolean27 = year21.equals((java.lang.Object) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (double) 0.0f);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
        java.util.Date date32 = regularTimePeriod31.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
        java.util.Date date36 = regularTimePeriod35.getEnd();
        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year33, (java.lang.Object) date36);
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean37, class38);
        int int40 = timeSeries39.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries7.addAndOrUpdate(timeSeries39);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2147483647 + "'", int40 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        java.util.Date date10 = regularTimePeriod9.getEnd();
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year7, (java.lang.Object) date10);
        java.lang.Class<?> wildcardClass12 = year7.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ClassContext", "Value", "ClassContext", (java.lang.Class) wildcardClass12);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("13-June-2019", (java.lang.Class) wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(uRL14);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Jan");
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ClassContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.String str19 = timeSeries18.getDescription();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (-1.0d));
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        java.util.Date date30 = regularTimePeriod29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
        boolean boolean33 = timeSeriesDataItem27.equals((java.lang.Object) regularTimePeriod32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, regularTimePeriod32);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries7.addChangeListener(seriesChangeListener35);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate6);
        serialDate7.setDescription("");
        boolean boolean10 = spreadsheetDate2.isOn(serialDate7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
        java.util.Date date14 = regularTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
        java.util.Date date18 = regularTimePeriod17.getEnd();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year15, (java.lang.Object) date18);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate23);
        int int26 = year15.compareTo((java.lang.Object) serialDate23);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate23);
        boolean boolean28 = spreadsheetDate2.isOn(serialDate27);
        try {
            org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '4', serialDate27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        try {
            java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate12);
        boolean boolean14 = timeSeriesDataItem9.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate12);
        int int16 = day15.getMonth();
        java.lang.Class<?> wildcardClass17 = day15.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(8, (int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        int int5 = year3.compareTo((java.lang.Object) (short) 0);
        int int7 = year3.compareTo((java.lang.Object) false);
        long long8 = year3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        java.lang.String str4 = day0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        java.lang.String str6 = month5.toString();
        int int7 = month5.getMonth();
        long long8 = month5.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        timeSeries7.setMaximumItemCount(100);
        java.lang.String str13 = timeSeries7.getRangeDescription();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class17);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        int int24 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) day22);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener25);
        timeSeries18.setNotify(true);
        boolean boolean29 = timeSeries18.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries7.addAndOrUpdate(timeSeries18);
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.next();
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) day36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (-1.0d));
        java.text.DateFormatSymbols dateFormatSymbols41 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) dateFormatSymbols41);
        try {
            timeSeries7.add(timeSeriesDataItem40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(dateFormatSymbols41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem10.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.util.Date date5 = day4.getEnd();
        long long6 = day4.getSerialIndex();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Year year14 = month13.getYear();
        int int15 = day4.compareTo((java.lang.Object) year14);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year14.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.util.Date date2 = regularTimePeriod1.getEnd();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getLastMillisecond(calendar5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond4.next();
//        long long8 = fixedMillisecond4.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560581999999L + "'", long6 == 1560581999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560581999999L + "'", long8 == 1560581999999L);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year6, (java.lang.Object) date9);
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ClassContext", "Value", "ClassContext", (java.lang.Class) wildcardClass11);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class16);
        timeSeries17.setMaximumItemCount(1);
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "Value", (java.lang.Object) timeSeries17);
        boolean boolean21 = timeSeries17.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class27);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        timeSeries31.fireSeriesChanged();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        boolean boolean40 = timeSeries23.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries7.addAndOrUpdate(timeSeries31);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeries7.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate11);
        int int14 = year3.compareTo((java.lang.Object) serialDate11);
        try {
            org.jfree.data.time.SerialDate serialDate16 = serialDate11.getPreviousDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SerialDate serialDate4 = null;
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getEndOfCurrentMonth(serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        java.lang.String str21 = timeSeries18.getRangeDescription();
        timeSeries18.setRangeDescription("Value");
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class27);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        timeSeries31.fireSeriesChanged();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) 1900);
        try {
            timeSeries18.update(2958465, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate6);
        serialDate7.setDescription("");
        boolean boolean10 = spreadsheetDate2.isOn(serialDate7);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
        java.util.Date date14 = regularTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
        try {
            int int17 = spreadsheetDate2.compareTo((java.lang.Object) fixedMillisecond16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.FixedMillisecond cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        serialDate6.setDescription("");
        boolean boolean9 = spreadsheetDate1.isOn(serialDate6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year13, (java.lang.Object) date16);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate21);
        int int24 = year13.compareTo((java.lang.Object) serialDate21);
        serialDate21.setDescription("6-April-1900");
        boolean boolean27 = spreadsheetDate1.isOn(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date30 = spreadsheetDate29.toDate();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate33);
        serialDate34.setDescription("");
        boolean boolean37 = spreadsheetDate29.isOn(serialDate34);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.next();
        java.util.Date date41 = regularTimePeriod40.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
        java.util.Date date45 = regularTimePeriod44.getEnd();
        boolean boolean46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year42, (java.lang.Object) date45);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate50);
        int int53 = year42.compareTo((java.lang.Object) serialDate50);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate50);
        boolean boolean55 = spreadsheetDate29.isOn(serialDate54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day56.next();
        java.util.Date date58 = regularTimePeriod57.getEnd();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day60.next();
        java.util.Date date62 = regularTimePeriod61.getEnd();
        boolean boolean63 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year59, (java.lang.Object) date62);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate67);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate67);
        int int70 = year59.compareTo((java.lang.Object) serialDate67);
        serialDate67.setDescription("6-April-1900");
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate75);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(serialDate75);
        boolean boolean78 = spreadsheetDate29.isInRange(serialDate67, serialDate75);
        boolean boolean79 = spreadsheetDate1.isOnOrAfter(serialDate75);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        boolean boolean8 = timeSeries4.getNotify();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date11, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date18 = spreadsheetDate17.toDate();
        boolean boolean19 = month15.equals((java.lang.Object) date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Year year6 = month5.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month5.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date11, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date6, timeZone13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(serialDate16);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        java.util.Date date7 = regularTimePeriod6.getEnd();
//        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) date7);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean8, class9);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.Comparable comparable13 = timeSeries10.getKey();
//        boolean boolean14 = fixedMillisecond0.equals((java.lang.Object) comparable13);
//        long long15 = fixedMillisecond0.getSerialIndex();
//        long long16 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + false + "'", comparable13.equals(false));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560439896252L + "'", long15 == 1560439896252L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560439896252L + "'", long16 == 1560439896252L);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        java.util.Date date7 = regularTimePeriod6.getEnd();
//        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) date7);
//        java.lang.Class<?> wildcardClass9 = year4.getClass();
//        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("Value", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        java.util.Date date15 = regularTimePeriod14.getEnd();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
//        java.util.Date date19 = regularTimePeriod18.getEnd();
//        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year16, (java.lang.Object) date19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getFirstMillisecond(calendar22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond21.getMiddleMillisecond(calendar24);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond21.getLastMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond21.getTime();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.next();
//        java.util.Date date31 = regularTimePeriod30.getEnd();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.next();
//        java.util.Date date35 = regularTimePeriod34.getEnd();
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year32, (java.lang.Object) date35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.next();
//        java.util.Date date40 = regularTimePeriod39.getEnd();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date40, timeZone42);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date35, timeZone42);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date28, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date19, timeZone42);
//        java.util.TimeZone timeZone47 = null;
//        try {
//            org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date19, timeZone47);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(classLoader10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560439896352L + "'", long23 == 1560439896352L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560439896352L + "'", long25 == 1560439896352L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560439896352L + "'", long27 == 1560439896352L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (byte) 1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        java.util.Date date10 = regularTimePeriod9.getEnd();
//        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year7, (java.lang.Object) date10);
//        java.lang.Class<?> wildcardClass12 = year7.getClass();
//        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
//        java.lang.ClassLoader classLoader14 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
//        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (byte) 1, (java.lang.Object) classLoader14);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(classLoader13);
//        org.junit.Assert.assertNotNull(classLoader14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        boolean boolean21 = timeSeries18.isEmpty();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (-1.0d));
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
        java.util.Date date34 = regularTimePeriod33.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        boolean boolean37 = timeSeriesDataItem31.equals((java.lang.Object) regularTimePeriod36);
        try {
            timeSeries18.add(timeSeriesDataItem31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        java.util.Date date8 = regularTimePeriod7.getEnd();
        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year5, (java.lang.Object) date8);
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, class11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Friday", class11);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) date7);
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, class10);
        boolean boolean12 = timeSeries11.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.util.Date date5 = day4.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day4.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (-1.0d));
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        java.util.Date date30 = regularTimePeriod29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
        boolean boolean33 = timeSeriesDataItem27.equals((java.lang.Object) regularTimePeriod32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, regularTimePeriod32);
        java.lang.String str35 = timeSeries34.getRangeDescription();
        timeSeries34.setNotify(true);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries4.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        boolean boolean12 = timeSeries4.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.lang.Class<?> wildcardClass2 = spreadsheetDate1.getClass();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate6);
        boolean boolean9 = spreadsheetDate1.isBefore(serialDate6);
        java.lang.String str10 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.Object obj0 = null;
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        timeSeries8.fireSeriesChanged();
        java.util.List list12 = timeSeries8.getItems();
        java.util.Collection collection13 = timeSeries8.getTimePeriods();
        java.lang.Class class14 = null;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date17, timeZone18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, 0.0d);
        boolean boolean23 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) timeSeries8);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2019, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        java.lang.String str19 = month18.toString();
        java.lang.String str20 = month18.toString();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month18.previous();
        long long23 = month18.getSerialIndex();
        long long24 = month18.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 24234L + "'", long23 == 24234L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) date7);
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesChangeEvent[source=4]", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertNull(inputStream11);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        java.lang.String str6 = month5.toString();
        java.lang.String str7 = month5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.previous();
        int int9 = month5.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        int int8 = year3.getYear();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year3.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        boolean boolean9 = year3.equals((java.lang.Object) '#');
        long long10 = year3.getFirstMillisecond();
        java.text.DateFormatSymbols dateFormatSymbols11 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        boolean boolean12 = year3.equals((java.lang.Object) dateFormatSymbols11);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(dateFormatSymbols11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        int int7 = spreadsheetDate1.compare(serialDate6);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.removeChangeListener(seriesChangeListener16);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.addAndOrUpdate(timeSeries22);
        timeSeries26.setDescription("");
        java.lang.String str29 = timeSeries26.getRangeDescription();
        long long30 = timeSeries26.getMaximumItemAge();
        boolean boolean31 = spreadsheetDate1.equals((java.lang.Object) timeSeries26);
        java.lang.Comparable comparable32 = timeSeries26.getKey();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-394) + "'", int7 == (-394));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + "Overwritten values from: hi!" + "'", comparable32.equals("Overwritten values from: hi!"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        int int11 = day8.getMonth();
        int int12 = day8.getMonth();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        timeSeries7.removeAgedItems(true);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        boolean boolean25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year21, (java.lang.Object) date24);
        boolean boolean27 = year21.equals((java.lang.Object) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (double) 0.0f);
        boolean boolean30 = timeSeries7.isEmpty();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate7);
        serialDate8.setDescription("");
        boolean boolean11 = spreadsheetDate3.isOn(serialDate8);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(520764324, (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        java.util.List list13 = timeSeries9.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate6);
        serialDate7.setDescription("");
        boolean boolean10 = spreadsheetDate2.isOn(serialDate7);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        java.util.Date date19 = regularTimePeriod18.getEnd();
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year16, (java.lang.Object) date19);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate24);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate24);
        int int27 = year16.compareTo((java.lang.Object) serialDate24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate24);
        boolean boolean29 = spreadsheetDate2.isOnOrAfter(serialDate24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("Time");
        timePeriodFormatException31.addSuppressed((java.lang.Throwable) seriesException33);
        try {
            int int35 = spreadsheetDate2.compareTo((java.lang.Object) timePeriodFormatException31);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodFormatException cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        try {
            timeSeries4.removeAgedItems((long) (byte) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.lang.Class<?> wildcardClass2 = spreadsheetDate1.getClass();
        java.lang.Class<?> wildcardClass3 = spreadsheetDate1.getClass();
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getNearestDayOfWeek(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560409200000L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-459), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        java.lang.String str19 = month18.toString();
        java.lang.String str20 = month18.toString();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        java.util.Date date28 = regularTimePeriod27.getEnd();
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year25, (java.lang.Object) date28);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate33);
        int int36 = year25.compareTo((java.lang.Object) serialDate33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (double) 5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year25.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        int int8 = year3.getYear();
        long long9 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439903960L + "'", long2 == 1560439903960L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439903960L + "'", long4 == 1560439903960L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560439903960L + "'", long5 == 1560439903960L);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
//        timeSeries18.setDescription("");
//        timeSeries18.clear();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        java.util.Date date24 = regularTimePeriod23.getEnd();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date24, timeZone26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.Year year29 = month28.getYear();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
//        java.lang.Object obj32 = null;
//        boolean boolean33 = day30.equals(obj32);
//        java.lang.String str34 = day30.toString();
//        java.lang.String str35 = day30.toString();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.next();
//        java.util.Date date38 = regularTimePeriod37.getEnd();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
//        int int41 = year39.compareTo((java.lang.Object) (short) 0);
//        int int43 = year39.compareTo((java.lang.Object) false);
//        boolean boolean44 = day30.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month28, (org.jfree.data.time.RegularTimePeriod) day30);
//        timeSeries18.setMaximumItemCount(12);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(timeSeries45);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class<?> wildcardClass8 = year3.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        serialDate6.setDescription("");
        boolean boolean9 = spreadsheetDate1.isOn(serialDate6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year14, (java.lang.Object) date17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate22);
        int int25 = year14.compareTo((java.lang.Object) serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate22);
        boolean boolean27 = spreadsheetDate1.isOn(serialDate26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date34 = spreadsheetDate33.toDate();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate37);
        int int39 = spreadsheetDate33.compare(serialDate38);
        boolean boolean40 = spreadsheetDate1.isInRange(serialDate30, serialDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date43 = spreadsheetDate42.toDate();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate46);
        serialDate47.setDescription("");
        boolean boolean50 = spreadsheetDate42.isOn(serialDate47);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day52.next();
        java.util.Date date54 = regularTimePeriod53.getEnd();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day56.next();
        java.util.Date date58 = regularTimePeriod57.getEnd();
        boolean boolean59 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year55, (java.lang.Object) date58);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate63);
        int int66 = year55.compareTo((java.lang.Object) serialDate63);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate63);
        boolean boolean68 = spreadsheetDate42.isOn(serialDate67);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate71);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date75 = spreadsheetDate74.toDate();
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate78);
        int int80 = spreadsheetDate74.compare(serialDate79);
        boolean boolean81 = spreadsheetDate42.isInRange(serialDate71, serialDate79);
        java.lang.Class class85 = null;
        org.jfree.data.time.TimeSeries timeSeries86 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class85);
        org.jfree.data.time.TimeSeries timeSeries89 = timeSeries86.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = day90.next();
        int int92 = timeSeries86.getIndex((org.jfree.data.time.RegularTimePeriod) day90);
        boolean boolean93 = spreadsheetDate42.equals((java.lang.Object) int92);
        boolean boolean94 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-394) + "'", int39 == (-394));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-394) + "'", int80 == (-394));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(timeSeries89);
        org.junit.Assert.assertNotNull(regularTimePeriod91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-1) + "'", int92 == (-1));
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        java.util.Date date10 = regularTimePeriod9.getEnd();
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year7, (java.lang.Object) date10);
        java.lang.Class<?> wildcardClass12 = year7.getClass();
        java.lang.Class class13 = null;
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Preceding", (java.lang.Class) wildcardClass12, class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "ThreadContext", "6-April-1900", (java.lang.Class) wildcardClass12);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
        java.util.Date date18 = regularTimePeriod17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date18, timeZone20);
        org.jfree.data.time.Year year22 = month21.getYear();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (-1.0d));
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate35);
        boolean boolean37 = timeSeriesDataItem32.equals((java.lang.Object) serialDate35);
        java.lang.String str38 = serialDate35.toString();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str38);
        int int40 = month21.compareTo((java.lang.Object) timeSeries39);
        try {
            timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 1560439867104L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "6-April-1900" + "'", str38.equals("6-April-1900"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Friday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Year year6 = month5.getYear();
        long long7 = month5.getSerialIndex();
        long long8 = month5.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        timeSeries7.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries7.addChangeListener(seriesChangeListener9);
        try {
            timeSeries7.delete(4, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year6, (java.lang.Object) date9);
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        java.util.Date date19 = regularTimePeriod18.getEnd();
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year16, (java.lang.Object) date19);
        java.lang.Class<?> wildcardClass21 = year16.getClass();
        java.lang.ClassLoader classLoader22 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass21);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("6-April-1900", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass21);
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass21);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(classLoader22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(class25);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        serialDate6.setDescription("");
        boolean boolean9 = spreadsheetDate1.isOn(serialDate6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year13, (java.lang.Object) date16);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate21);
        int int24 = year13.compareTo((java.lang.Object) serialDate21);
        serialDate21.setDescription("6-April-1900");
        boolean boolean27 = spreadsheetDate1.isOn(serialDate21);
        try {
            org.jfree.data.time.SerialDate serialDate29 = serialDate21.getNearestDayOfWeek(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1900, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) date7);
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, class10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        timeSeries7.fireSeriesChanged();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        java.util.Date date13 = regularTimePeriod12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries7.addChangeListener(seriesChangeListener16);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
//        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (-1.0d));
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
//        java.util.Date date30 = regularTimePeriod29.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
//        boolean boolean33 = timeSeriesDataItem27.equals((java.lang.Object) regularTimePeriod32);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = timeSeriesDataItem27.equals(obj34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getFirstMillisecond(calendar37);
//        long long39 = fixedMillisecond36.getLastMillisecond();
//        boolean boolean40 = timeSeriesDataItem27.equals((java.lang.Object) fixedMillisecond36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 97L);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560439907377L + "'", long38 == 1560439907377L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560439907377L + "'", long39 == 1560439907377L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date7, timeZone14);
        int int17 = year16.getYear();
        try {
            org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((-1), year16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate12);
        boolean boolean14 = timeSeriesDataItem9.equals((java.lang.Object) serialDate12);
        try {
            org.jfree.data.time.SerialDate serialDate16 = serialDate12.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener19);
//        java.util.Collection collection21 = timeSeries7.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond22.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 97L);
//        timeSeries7.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560439907734L + "'", long24 == 1560439907734L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560439907734L + "'", long26 == 1560439907734L);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate8);
        serialDate9.setDescription("");
        boolean boolean12 = spreadsheetDate4.isOn(serialDate9);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year17, (java.lang.Object) date20);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate25);
        int int28 = year17.compareTo((java.lang.Object) serialDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate25);
        boolean boolean30 = spreadsheetDate4.isOn(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date37 = spreadsheetDate36.toDate();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate40);
        int int42 = spreadsheetDate36.compare(serialDate41);
        boolean boolean43 = spreadsheetDate4.isInRange(serialDate33, serialDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date47 = spreadsheetDate46.toDate();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate50);
        serialDate51.setDescription("");
        boolean boolean54 = spreadsheetDate46.isOn(serialDate51);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.next();
        java.util.Date date57 = regularTimePeriod56.getEnd();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day59.next();
        java.util.Date date61 = regularTimePeriod60.getEnd();
        boolean boolean62 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year58, (java.lang.Object) date61);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate66);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate66);
        int int69 = year58.compareTo((java.lang.Object) serialDate66);
        serialDate66.setDescription("6-April-1900");
        boolean boolean72 = spreadsheetDate46.isOn(serialDate66);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears(7, serialDate66);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = day74.next();
        java.util.Date date76 = regularTimePeriod75.getEnd();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day78.next();
        java.util.Date date80 = regularTimePeriod79.getEnd();
        boolean boolean81 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year77, (java.lang.Object) date80);
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date80);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date80);
        org.jfree.data.time.SerialDate serialDate84 = serialDate73.getEndOfCurrentMonth(serialDate83);
        boolean boolean85 = spreadsheetDate4.isOnOrBefore(serialDate83);
        boolean boolean86 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int87 = spreadsheetDate4.getMonth();
        org.jfree.data.time.SerialDate serialDate88 = null;
        try {
            boolean boolean89 = spreadsheetDate4.isOnOrBefore(serialDate88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-394) + "'", int42 == (-394));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        java.util.Date date7 = regularTimePeriod6.getEnd();
//        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) date7);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean8, class9);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries10.removePropertyChangeListener(propertyChangeListener11);
//        java.lang.Comparable comparable13 = timeSeries10.getKey();
//        boolean boolean14 = fixedMillisecond0.equals((java.lang.Object) comparable13);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond0.getFirstMillisecond(calendar15);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + false + "'", comparable13.equals(false));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560439907854L + "'", long16 == 1560439907854L);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        java.util.Date date8 = regularTimePeriod7.getEnd();
        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year5, (java.lang.Object) date8);
        java.lang.Class<?> wildcardClass10 = year5.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, class11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", class11);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        java.util.List list11 = timeSeries7.getItems();
        timeSeries7.setMaximumItemAge((long) 7);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ThreadContext");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        java.util.Date date8 = regularTimePeriod7.getEnd();
        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year5, (java.lang.Object) date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date8, timeZone15);
        int int18 = year17.getYear();
        int int19 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getLastMillisecond();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        long long5 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439908517L + "'", long2 == 1560439908517L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439908517L + "'", long3 == 1560439908517L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560439908517L + "'", long5 == 1560439908517L);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate6);
        serialDate7.setDescription("");
        boolean boolean10 = spreadsheetDate2.isOn(serialDate7);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        java.util.Date date19 = regularTimePeriod18.getEnd();
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year16, (java.lang.Object) date19);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate24);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate24);
        int int27 = year16.compareTo((java.lang.Object) serialDate24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate24);
        boolean boolean29 = spreadsheetDate2.isOnOrAfter(serialDate24);
        int int30 = spreadsheetDate2.getYYYY();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        int int5 = year3.compareTo((java.lang.Object) (short) 0);
        int int7 = year3.compareTo((java.lang.Object) false);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year3.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        java.lang.String str19 = month18.toString();
        java.lang.String str20 = month18.toString();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month18.previous();
        java.lang.String str23 = month18.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.util.Date date12 = regularTimePeriod11.getEnd();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = timeSeriesDataItem9.equals(obj16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getMiddleMillisecond(calendar21);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond18.getLastMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond18.getTime();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
//        java.util.Date date28 = regularTimePeriod27.getEnd();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
//        java.util.Date date32 = regularTimePeriod31.getEnd();
//        boolean boolean33 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year29, (java.lang.Object) date32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
//        java.util.Date date37 = regularTimePeriod36.getEnd();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37, timeZone39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date32, timeZone39);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date25, timeZone39);
//        int int43 = month42.getMonth();
//        org.jfree.data.time.Year year44 = month42.getYear();
//        boolean boolean45 = timeSeriesDataItem9.equals((java.lang.Object) year44);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560439909279L + "'", long20 == 1560439909279L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560439909279L + "'", long22 == 1560439909279L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560439909279L + "'", long24 == 1560439909279L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day8.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day13);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day13);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class20);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries21.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries24.removeChangeListener(seriesChangeListener25);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries24.addAndOrUpdate(timeSeries31);
        java.lang.Object obj36 = timeSeries31.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries31.removeChangeListener(seriesChangeListener37);
        timeSeries31.setDomainDescription("13-June-2019");
        java.util.Collection collection41 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        timeSeries31.clear();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(collection41);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560495599999L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries7.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(class16);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date9 = spreadsheetDate8.toDate();
        boolean boolean10 = month6.equals((java.lang.Object) date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        int int15 = month6.compareTo((java.lang.Object) year14);
        long long16 = year14.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day13);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries7.removeChangeListener(seriesChangeListener17);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        java.lang.Object obj8 = timeSeries4.clone();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (-1.0d));
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        java.util.Date date21 = regularTimePeriod20.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        boolean boolean24 = timeSeriesDataItem18.equals((java.lang.Object) regularTimePeriod23);
        java.lang.Number number25 = timeSeriesDataItem18.getValue();
        java.lang.Number number26 = null;
        timeSeriesDataItem18.setValue(number26);
        java.lang.Number number28 = timeSeriesDataItem18.getValue();
        try {
            timeSeries4.add(timeSeriesDataItem18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.0d) + "'", number25.equals((-1.0d)));
        org.junit.Assert.assertNull(number28);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesChangeEvent[source=4]", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (-1.0d));
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate15);
        boolean boolean17 = timeSeriesDataItem12.equals((java.lang.Object) serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears(7, serialDate15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate18);
        try {
            org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears(2958465, serialDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-459));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-571) + "'", int1 == (-571));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate7);
        int int9 = spreadsheetDate3.compare(serialDate8);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(2019, serialDate13);
        boolean boolean16 = spreadsheetDate3.isOnOrBefore(serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears(2019, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, serialDate17);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-394) + "'", int9 == (-394));
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9, serialDate4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate4.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) date7);
        long long9 = year4.getFirstMillisecond();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) '4', serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getLastMillisecond();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9);
//        java.util.Date date7 = spreadsheetDate6.toDate();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate10);
//        serialDate11.setDescription("");
//        boolean boolean14 = spreadsheetDate6.isOn(serialDate11);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        java.util.Date date18 = regularTimePeriod17.getEnd();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
//        java.util.Date date22 = regularTimePeriod21.getEnd();
//        boolean boolean23 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year19, (java.lang.Object) date22);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate27);
//        int int30 = year19.compareTo((java.lang.Object) serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate27);
//        boolean boolean32 = spreadsheetDate6.isOn(serialDate31);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(9);
//        java.util.Date date39 = spreadsheetDate38.toDate();
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate42);
//        int int44 = spreadsheetDate38.compare(serialDate43);
//        boolean boolean45 = spreadsheetDate6.isInRange(serialDate35, serialDate43);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(9);
//        java.util.Date date49 = spreadsheetDate48.toDate();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate52);
//        serialDate53.setDescription("");
//        boolean boolean56 = spreadsheetDate48.isOn(serialDate53);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day57.next();
//        java.util.Date date59 = regularTimePeriod58.getEnd();
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day61.next();
//        java.util.Date date63 = regularTimePeriod62.getEnd();
//        boolean boolean64 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year60, (java.lang.Object) date63);
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate68);
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate68);
//        int int71 = year60.compareTo((java.lang.Object) serialDate68);
//        serialDate68.setDescription("6-April-1900");
//        boolean boolean74 = spreadsheetDate48.isOn(serialDate68);
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addYears(7, serialDate68);
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = day76.next();
//        java.util.Date date78 = regularTimePeriod77.getEnd();
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date78);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day80.next();
//        java.util.Date date82 = regularTimePeriod81.getEnd();
//        boolean boolean83 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year79, (java.lang.Object) date82);
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date82);
//        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance(date82);
//        org.jfree.data.time.SerialDate serialDate86 = serialDate75.getEndOfCurrentMonth(serialDate85);
//        boolean boolean87 = spreadsheetDate6.isOnOrBefore(serialDate85);
//        int int88 = fixedMillisecond0.compareTo((java.lang.Object) serialDate85);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439912331L + "'", long2 == 1560439912331L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439912331L + "'", long3 == 1560439912331L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439912331L + "'", long4 == 1560439912331L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-394) + "'", int44 == (-394));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(3);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
//        long long11 = day8.getFirstMillisecond();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day8.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
//        java.lang.Object obj19 = timeSeries14.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        java.lang.Object obj24 = null;
//        boolean boolean25 = day22.equals(obj24);
//        java.lang.String str26 = day22.toString();
//        java.lang.String str27 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 43629L);
//        long long30 = day22.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries7.setMaximumItemAge(1560439866088L);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        java.lang.Class class11 = null;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
        java.util.Date date14 = regularTimePeriod13.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date14);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) 1560439912127L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        java.lang.String str4 = day0.toString();
//        java.lang.String str5 = day0.toString();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        java.util.Date date8 = regularTimePeriod7.getEnd();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
//        int int11 = year9.compareTo((java.lang.Object) (short) 0);
//        int int13 = year9.compareTo((java.lang.Object) false);
//        boolean boolean14 = day0.equals((java.lang.Object) false);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class18);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries19.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries22.removeChangeListener(seriesChangeListener23);
//        java.lang.String str25 = timeSeries22.getDomainDescription();
//        timeSeries22.setMaximumItemCount(100);
//        boolean boolean28 = day0.equals((java.lang.Object) 100);
//        int int29 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-394), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.util.Date date12 = regularTimePeriod11.getEnd();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = timeSeriesDataItem9.equals(obj16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        long long21 = fixedMillisecond18.getLastMillisecond();
//        boolean boolean22 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond18);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class26);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries27.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
//        int int33 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) day31);
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener34);
//        timeSeries27.setNotify(true);
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries27.addPropertyChangeListener(propertyChangeListener38);
//        java.lang.String str40 = timeSeries27.getDescription();
//        int int41 = fixedMillisecond18.compareTo((java.lang.Object) str40);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560439915676L + "'", long20 == 1560439915676L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560439915676L + "'", long21 == 1560439915676L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        java.lang.String str19 = month18.toString();
        java.lang.String str20 = month18.toString();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month18.previous();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = month18.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        timeSeries7.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries7.addChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries7.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class27);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        timeSeries31.fireSeriesChanged();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        boolean boolean40 = timeSeries23.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries7.addAndOrUpdate(timeSeries31);
        java.util.Collection collection42 = timeSeries31.getTimePeriods();
        java.lang.Comparable comparable43 = timeSeries31.getKey();
        timeSeries31.fireSeriesChanged();
        try {
            timeSeries31.delete(2, 520764324);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + "hi!" + "'", comparable43.equals("hi!"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class8);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        timeSeries12.fireSeriesChanged();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
        java.util.Date date18 = regularTimePeriod17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        boolean boolean21 = timeSeries4.equals((java.lang.Object) timeSeries12);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (-1.0d));
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
        java.util.Date date34 = regularTimePeriod33.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        boolean boolean37 = timeSeriesDataItem31.equals((java.lang.Object) regularTimePeriod36);
        java.lang.Object obj38 = null;
        boolean boolean39 = timeSeriesDataItem31.equals(obj38);
        try {
            timeSeries4.add(timeSeriesDataItem31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date11, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date6, timeZone13);
        int int16 = year15.getYear();
        int int17 = year15.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (-1.0d));
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        java.util.Date date30 = regularTimePeriod29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
        boolean boolean33 = timeSeriesDataItem27.equals((java.lang.Object) regularTimePeriod32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, regularTimePeriod32);
        timeSeries7.setMaximumItemAge(0L);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f));
        timeSeries1.setDomainDescription("");
        java.lang.Class class4 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNotNull(class4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener19);
        java.util.Collection collection21 = timeSeries7.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener22);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection21);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.util.Date date2 = regularTimePeriod1.getEnd();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getLastMillisecond(calendar5);
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond4.peg(calendar7);
//        long long9 = fixedMillisecond4.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560581999999L + "'", long6 == 1560581999999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560581999999L + "'", long9 == 1560581999999L);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate7);
        serialDate8.setDescription("");
        boolean boolean11 = spreadsheetDate3.isOn(serialDate8);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year17, (java.lang.Object) date20);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate25);
        int int28 = year17.compareTo((java.lang.Object) serialDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate25);
        boolean boolean30 = spreadsheetDate3.isOnOrAfter(serialDate25);
        int int31 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8 + "'", int31 == 8);
        org.junit.Assert.assertNotNull(serialDate32);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        boolean boolean25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year21, (java.lang.Object) date24);
        boolean boolean27 = year21.equals((java.lang.Object) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (double) 0.0f);
        java.lang.Object obj30 = null;
        int int31 = year21.compareTo(obj30);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("6-April-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Preceding");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 12);
        java.lang.String str11 = year8.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("6-April-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        java.util.Collection collection11 = timeSeries7.getTimePeriods();
        java.util.Collection collection12 = org.jfree.chart.util.ObjectUtilities.deepClone(collection11);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNotNull(collection12);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond0.getTime();
//        long long8 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439917595L + "'", long2 == 1560439917595L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439917595L + "'", long4 == 1560439917595L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439917595L + "'", long6 == 1560439917595L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560439917595L + "'", long8 == 1560439917595L);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        boolean boolean25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year21, (java.lang.Object) date24);
        boolean boolean27 = year21.equals((java.lang.Object) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (double) 0.0f);
        int int30 = year21.getYear();
        int int31 = year21.getYear();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        serialDate6.setDescription("");
        boolean boolean9 = spreadsheetDate1.isOn(serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate15);
        int int17 = spreadsheetDate11.compare(serialDate16);
        boolean boolean18 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        boolean boolean28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year24, (java.lang.Object) date27);
        long long29 = year24.getFirstMillisecond();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
        java.util.Date date32 = regularTimePeriod31.getEnd();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year24, (java.lang.Object) serialDate33);
        boolean boolean35 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, serialDate33);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-394) + "'", int17 == (-394));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        timeSeries7.fireSeriesChanged();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        java.util.Date date13 = regularTimePeriod12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
//        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (-1.0d));
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
//        java.util.Date date30 = regularTimePeriod29.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
//        boolean boolean33 = timeSeriesDataItem27.equals((java.lang.Object) regularTimePeriod32);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, regularTimePeriod32);
//        long long35 = fixedMillisecond17.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560439918099L + "'", long35 == 1560439918099L);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
        java.lang.Object obj16 = null;
        boolean boolean17 = timeSeriesDataItem9.equals(obj16);
        java.lang.Number number18 = timeSeriesDataItem9.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.0d) + "'", number18.equals((-1.0d)));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year6, (java.lang.Object) date9);
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Class class14 = null;
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", class13, class14);
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("6-April-1900", class13);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(1900);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        timeSeries7.fireSeriesChanged();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        java.util.Date date13 = regularTimePeriod12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
//        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (-1.0d));
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
//        java.util.Date date30 = regularTimePeriod29.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
//        boolean boolean33 = timeSeriesDataItem27.equals((java.lang.Object) regularTimePeriod32);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, regularTimePeriod32);
//        long long35 = fixedMillisecond17.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560439918706L + "'", long35 == 1560439918706L);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        boolean boolean8 = timeSeries4.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.util.Date date12 = regularTimePeriod11.getEnd();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year13, (java.lang.Object) date16);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean17, class18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries19.removePropertyChangeListener(propertyChangeListener20);
//        java.lang.Comparable comparable22 = timeSeries19.getKey();
//        boolean boolean23 = fixedMillisecond9.equals((java.lang.Object) comparable22);
//        long long24 = fixedMillisecond9.getSerialIndex();
//        java.lang.Number number25 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number25);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + false + "'", comparable22.equals(false));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560439919372L + "'", long24 == 1560439919372L);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class27);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        timeSeries31.fireSeriesChanged();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        boolean boolean40 = timeSeries23.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries7.addAndOrUpdate(timeSeries31);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
        java.util.Date date44 = regularTimePeriod43.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date44, timeZone46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date51 = spreadsheetDate50.toDate();
        boolean boolean52 = month48.equals((java.lang.Object) date51);
        long long53 = month48.getSerialIndex();
        int int54 = month48.getYearValue();
        try {
            timeSeries31.add((org.jfree.data.time.RegularTimePeriod) month48, (double) (-1L), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 24234L + "'", long53 == 24234L);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day8.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        java.lang.String str21 = timeSeries18.getRangeDescription();
        timeSeries18.setRangeDescription("Value");
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class27);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        timeSeries31.fireSeriesChanged();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) 1900);
        java.util.Calendar calendar42 = null;
        try {
            long long43 = day38.getLastMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date6, timeZone9);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate6);
        serialDate7.setDescription("");
        boolean boolean10 = spreadsheetDate2.isOn(serialDate7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
        java.util.Date date14 = regularTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
        java.util.Date date18 = regularTimePeriod17.getEnd();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year15, (java.lang.Object) date18);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate23);
        int int26 = year15.compareTo((java.lang.Object) serialDate23);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate23);
        boolean boolean28 = spreadsheetDate2.isOn(serialDate27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.next();
        java.util.Date date31 = regularTimePeriod30.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.next();
        java.util.Date date35 = regularTimePeriod34.getEnd();
        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year32, (java.lang.Object) date35);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate40);
        int int43 = year32.compareTo((java.lang.Object) serialDate40);
        serialDate40.setDescription("6-April-1900");
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate48);
        boolean boolean51 = spreadsheetDate2.isInRange(serialDate40, serialDate48);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, serialDate40);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(serialDate52);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 4);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 4 + "'", obj2.equals(4));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=4]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=4]"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        java.util.Date date10 = regularTimePeriod9.getEnd();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
//        java.util.Date date14 = regularTimePeriod13.getEnd();
//        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year11, (java.lang.Object) date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
//        java.util.Date date19 = regularTimePeriod18.getEnd();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date19, timeZone21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date14, timeZone21);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date7, timeZone21);
//        int int25 = month24.getMonth();
//        org.jfree.data.time.Year year26 = month24.getYear();
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = year26.getLastMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439920582L + "'", long2 == 1560439920582L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439920582L + "'", long4 == 1560439920582L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439920582L + "'", long6 == 1560439920582L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(year26);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries7.createCopy(2, 2);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-452), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -452");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.String str19 = timeSeries18.getDomainDescription();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class23);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries24.createCopy((int) (short) 0, 0);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.next();
        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) day33);
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day33);
        int int37 = day33.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day33.previous();
        timeSeries18.setKey((java.lang.Comparable) regularTimePeriod38);
        java.util.Calendar calendar40 = null;
        try {
            long long41 = regularTimePeriod38.getMiddleMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2147483647);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate12);
        boolean boolean14 = timeSeriesDataItem9.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate12);
        java.lang.String str16 = serialDate12.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "6-April-1900" + "'", str16.equals("6-April-1900"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class27);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        timeSeries31.fireSeriesChanged();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        boolean boolean40 = timeSeries23.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries7.addAndOrUpdate(timeSeries31);
        java.util.Collection collection42 = timeSeries31.getTimePeriods();
        java.lang.Comparable comparable43 = timeSeries31.getKey();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.next();
        java.util.Date date46 = regularTimePeriod45.getEnd();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day48.next();
        java.util.Date date50 = regularTimePeriod49.getEnd();
        boolean boolean51 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year47, (java.lang.Object) date50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date50);
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) year52);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + "hi!" + "'", comparable43.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (-1.0d));
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        java.util.Date date15 = regularTimePeriod14.getEnd();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        boolean boolean18 = timeSeriesDataItem12.equals((java.lang.Object) regularTimePeriod17);
//        java.lang.Class<?> wildcardClass19 = regularTimePeriod17.getClass();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2, (java.lang.Class) wildcardClass19);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (-1.0d));
        timeSeriesDataItem5.setValue((java.lang.Number) 1560439908100L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesChangeEvent[source=4]");
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.util.Date date5 = day4.getEnd();
        long long6 = day4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-394));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.util.Date date5 = day4.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            day4.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-571), 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -571");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day13);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day13);
        int int17 = day13.getYear();
        int int18 = day13.getYear();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        java.lang.Class<?> wildcardClass3 = day0.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class4);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(classLoader5);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        boolean boolean8 = timeSeries4.getNotify();
        boolean boolean9 = timeSeries4.isEmpty();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.util.Calendar calendar16 = null;
        try {
            day14.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date9 = spreadsheetDate8.toDate();
        boolean boolean10 = month6.equals((java.lang.Object) date9);
        long long11 = month6.getSerialIndex();
        int int12 = month6.getYearValue();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month6.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 24234L + "'", long11 == 24234L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Friday");
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Object obj19 = timeSeries14.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries14.removeChangeListener(seriesChangeListener20);
        boolean boolean22 = timeSeries14.getNotify();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate12);
        boolean boolean14 = timeSeriesDataItem9.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate12);
        java.lang.Class<?> wildcardClass16 = day15.getClass();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = day15.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        int int7 = spreadsheetDate1.compare(serialDate6);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.removeChangeListener(seriesChangeListener16);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.addAndOrUpdate(timeSeries22);
        timeSeries26.setDescription("");
        java.lang.String str29 = timeSeries26.getRangeDescription();
        long long30 = timeSeries26.getMaximumItemAge();
        boolean boolean31 = spreadsheetDate1.equals((java.lang.Object) timeSeries26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date34 = spreadsheetDate33.toDate();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate37);
        serialDate38.setDescription("");
        boolean boolean41 = spreadsheetDate33.isOn(serialDate38);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
        java.util.Date date45 = regularTimePeriod44.getEnd();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day47.next();
        java.util.Date date49 = regularTimePeriod48.getEnd();
        boolean boolean50 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year46, (java.lang.Object) date49);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate54);
        int int57 = year46.compareTo((java.lang.Object) serialDate54);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate54);
        boolean boolean59 = spreadsheetDate33.isOn(serialDate58);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date66 = spreadsheetDate65.toDate();
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate69);
        int int71 = spreadsheetDate65.compare(serialDate70);
        boolean boolean72 = spreadsheetDate33.isInRange(serialDate62, serialDate70);
        java.lang.Class class76 = null;
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class76);
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries77.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = day81.next();
        int int83 = timeSeries77.getIndex((org.jfree.data.time.RegularTimePeriod) day81);
        boolean boolean84 = spreadsheetDate33.equals((java.lang.Object) int83);
        try {
            int int85 = spreadsheetDate1.compareTo((java.lang.Object) int83);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-394) + "'", int7 == (-394));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-394) + "'", int71 == (-394));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        int int7 = spreadsheetDate1.compare(serialDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year12, (java.lang.Object) date15);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate20);
        int int23 = year12.compareTo((java.lang.Object) serialDate20);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate20);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
        java.lang.Object obj27 = null;
        boolean boolean28 = day25.equals(obj27);
        org.jfree.data.time.SerialDate serialDate29 = day25.getSerialDate();
        boolean boolean31 = spreadsheetDate1.isInRange(serialDate20, serialDate29, (int) (short) 10);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-394) + "'", int7 == (-394));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class<?> wildcardClass8 = year3.getClass();
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader10);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(classLoader9);
        org.junit.Assert.assertNotNull(classLoader10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f));
        timeSeries1.setMaximumItemCount((int) (byte) 0);
        java.lang.Class class4 = timeSeries1.getTimePeriodClass();
        timeSeries1.setNotify(false);
        org.junit.Assert.assertNotNull(class4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Object obj19 = timeSeries14.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries14.removeChangeListener(seriesChangeListener20);
        timeSeries14.setDomainDescription("13-June-2019");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries14.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(7);
        try {
            org.jfree.data.time.SerialDate serialDate9 = serialDate5.getNearestDayOfWeek(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries4.removeChangeListener(seriesChangeListener8);
        timeSeries4.setMaximumItemAge(0L);
        java.lang.Class class12 = timeSeries4.getTimePeriodClass();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(class12);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2147483647);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        serialDate6.setDescription("");
        boolean boolean9 = spreadsheetDate1.isOn(serialDate6);
        int int10 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        java.lang.Class<?> wildcardClass3 = day0.getClass();
//        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(classLoader4);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        timeSeries7.fireSeriesChanged();
        java.lang.Class class9 = null;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date12, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        timeSeries7.clear();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        java.util.Date date7 = regularTimePeriod6.getEnd();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year4, (java.lang.Object) date7);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean8, class9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener11);
        java.lang.Comparable comparable13 = timeSeries10.getKey();
        boolean boolean14 = fixedMillisecond0.equals((java.lang.Object) comparable13);
        java.util.Date date15 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + false + "'", comparable13.equals(false));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (byte) 1);
//        java.util.Date date4 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class<?> wildcardClass8 = year3.getClass();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        java.util.Date date11 = regularTimePeriod10.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date11, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date18 = spreadsheetDate17.toDate();
        boolean boolean19 = month15.equals((java.lang.Object) date18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
        java.util.Date date22 = regularTimePeriod21.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        int int25 = year23.compareTo((java.lang.Object) (short) 0);
        java.util.Date date26 = year23.getStart();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
        java.util.Date date29 = regularTimePeriod28.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date29, timeZone31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date26, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date18, timeZone31);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date18, timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeZone35);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        boolean boolean9 = year3.equals((java.lang.Object) '#');
        long long10 = year3.getFirstMillisecond();
        java.lang.String str11 = year3.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.util.Date date2 = regularTimePeriod1.getEnd();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
//        java.lang.Comparable comparable12 = timeSeries9.getKey();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        java.util.Date date15 = regularTimePeriod14.getEnd();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
//        java.lang.String str19 = month18.toString();
//        java.lang.String str20 = month18.toString();
//        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        java.util.Date date24 = regularTimePeriod23.getEnd();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 43629L);
//        int int29 = day25.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 14 + "'", int29 == 14);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f));
        timeSeries1.setMaximumItemCount((int) (byte) 0);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.util.Date date2 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (-1.0d));
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setValue((java.lang.Number) (short) 0);
        java.lang.Object obj9 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        java.lang.String str7 = month6.toString();
        long long8 = month6.getFirstMillisecond();
        int int9 = month6.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        long long4 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        java.util.Calendar calendar6 = null;
        fixedMillisecond4.peg(calendar6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class<?> wildcardClass8 = year3.getClass();
        long long9 = year3.getFirstMillisecond();
        long long10 = year3.getSerialIndex();
        java.lang.String str11 = year3.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year13, (java.lang.Object) date16);
        java.lang.Class<?> wildcardClass18 = year13.getClass();
        long long19 = year13.getFirstMillisecond();
        boolean boolean21 = year13.equals((java.lang.Object) (-459));
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        java.util.Date date25 = regularTimePeriod24.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
        java.util.Date date29 = regularTimePeriod28.getEnd();
        boolean boolean30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year26, (java.lang.Object) date29);
        java.lang.Class<?> wildcardClass31 = year26.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass31);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        int int34 = year13.compareTo((java.lang.Object) class33);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str7, "Nearest", "ClassContext", class33);
        timeSeries35.setNotify(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year6, (java.lang.Object) date9);
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year17, (java.lang.Object) date20);
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("6-April-1900", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass22);
        java.lang.Object obj26 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Nearest", (java.lang.Class) wildcardClass22);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(obj26);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.lang.Class<?> wildcardClass2 = spreadsheetDate1.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        java.util.Date date8 = regularTimePeriod7.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        int int11 = year9.compareTo((java.lang.Object) (short) 0);
        java.util.Date date12 = year9.getStart();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date12, timeZone17);
        long long20 = month19.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate24);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(9, serialDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate25.getEndOfCurrentMonth(serialDate30);
        int int34 = month19.compareTo((java.lang.Object) serialDate33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.next();
        java.util.Date date41 = regularTimePeriod40.getEnd();
        boolean boolean42 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year38, (java.lang.Object) date41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date41);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date41);
        boolean boolean46 = spreadsheetDate4.isInRange(serialDate33, serialDate44, (int) (short) 10);
        boolean boolean47 = spreadsheetDate1.isOn(serialDate44);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        int int10 = timeSeries9.getMaximumItemCount();
        java.lang.Comparable comparable11 = timeSeries9.getKey();
        boolean boolean12 = timeSeries9.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + false + "'", comparable11.equals(false));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (-1.0d));
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate14);
        boolean boolean16 = timeSeriesDataItem11.equals((java.lang.Object) serialDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears(7, serialDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate14);
        java.lang.Class<?> wildcardClass19 = serialDate14.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        int int16 = year14.compareTo((java.lang.Object) (short) 0);
        java.util.Date date17 = year14.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date20, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date17, timeZone22);
        long long25 = month24.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate28);
        java.util.Date date31 = day30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month24, (org.jfree.data.time.RegularTimePeriod) day30);
        int int33 = day30.getDayOfMonth();
        long long34 = day30.getFirstMillisecond();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-2200752000000L) + "'", long34 == (-2200752000000L));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        serialDate6.setDescription("");
        boolean boolean9 = spreadsheetDate1.isOn(serialDate6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year14, (java.lang.Object) date17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate22);
        int int25 = year14.compareTo((java.lang.Object) serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate22);
        boolean boolean27 = spreadsheetDate1.isOn(serialDate26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date34 = spreadsheetDate33.toDate();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate37);
        int int39 = spreadsheetDate33.compare(serialDate38);
        boolean boolean40 = spreadsheetDate1.isInRange(serialDate30, serialDate38);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class44);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries45.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.next();
        int int51 = timeSeries45.getIndex((org.jfree.data.time.RegularTimePeriod) day49);
        boolean boolean52 = spreadsheetDate1.equals((java.lang.Object) int51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date55 = spreadsheetDate54.toDate();
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate58);
        int int60 = spreadsheetDate54.compare(serialDate59);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate64);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths(2019, serialDate64);
        boolean boolean67 = spreadsheetDate54.isOnOrBefore(serialDate66);
        boolean boolean68 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-394) + "'", int39 == (-394));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-394) + "'", int60 == (-394));
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year6, (java.lang.Object) date9);
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year17, (java.lang.Object) date20);
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("6-April-1900", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass22);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
        java.util.Date date32 = regularTimePeriod31.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
        java.util.Date date36 = regularTimePeriod35.getEnd();
        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year33, (java.lang.Object) date36);
        java.lang.Class<?> wildcardClass38 = year33.getClass();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.next();
        java.util.Date date42 = regularTimePeriod41.getEnd();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.next();
        java.util.Date date46 = regularTimePeriod45.getEnd();
        boolean boolean47 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year43, (java.lang.Object) date46);
        java.lang.Class<?> wildcardClass48 = year43.getClass();
        java.lang.ClassLoader classLoader49 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass48);
        java.lang.Object obj50 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("6-April-1900", (java.lang.Class) wildcardClass38, (java.lang.Class) wildcardClass48);
        java.lang.Object obj51 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass48);
        java.lang.Object obj52 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Value", (java.lang.Class) wildcardClass48);
        java.lang.Object obj53 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Nearest", (java.lang.Class) wildcardClass22, (java.lang.Class) wildcardClass48);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(classLoader49);
        org.junit.Assert.assertNull(obj50);
        org.junit.Assert.assertNull(obj51);
        org.junit.Assert.assertNull(obj52);
        org.junit.Assert.assertNull(obj53);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f));
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + (-1.0f) + "'", comparable2.equals((-1.0f)));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate12);
        boolean boolean14 = timeSeriesDataItem9.equals((java.lang.Object) serialDate12);
        java.lang.String str15 = serialDate12.toString();
        try {
            org.jfree.data.time.SerialDate serialDate17 = serialDate12.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6-April-1900" + "'", str15.equals("6-April-1900"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        int int5 = year3.compareTo((java.lang.Object) (short) 0);
        long long6 = year3.getSerialIndex();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
        org.jfree.data.time.Year year13 = month12.getYear();
        java.lang.Object obj14 = null;
        int int15 = month12.compareTo(obj14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month12.previous();
        boolean boolean17 = year3.equals((java.lang.Object) month12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        long long6 = month5.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener19);
//        java.util.Collection collection21 = timeSeries7.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond22.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 97L);
//        java.util.List list29 = timeSeries7.getItems();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
//        java.util.Date date32 = regularTimePeriod31.getEnd();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, (-1.0d));
//        java.lang.Object obj36 = timeSeriesDataItem35.clone();
//        timeSeries7.setKey((java.lang.Comparable) timeSeriesDataItem35);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560439935482L + "'", long24 == 1560439935482L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560439935482L + "'", long26 == 1560439935482L);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(list29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(obj36);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        boolean boolean20 = timeSeries14.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.TimeSeries timeSeries21 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries14.addAndOrUpdate(timeSeries21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        java.util.Date date10 = regularTimePeriod9.getEnd();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
//        java.util.Date date14 = regularTimePeriod13.getEnd();
//        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year11, (java.lang.Object) date14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
//        java.util.Date date19 = regularTimePeriod18.getEnd();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date19, timeZone21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date14, timeZone21);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date7, timeZone21);
//        int int25 = month24.getMonth();
//        org.jfree.data.time.Year year26 = month24.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439935662L + "'", long2 == 1560439935662L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439935662L + "'", long4 == 1560439935662L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439935662L + "'", long6 == 1560439935662L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        boolean boolean25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year21, (java.lang.Object) date24);
        boolean boolean27 = year21.equals((java.lang.Object) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (double) 0.0f);
        int int30 = year21.getYear();
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.next();
        timeSeries36.delete((org.jfree.data.time.RegularTimePeriod) day37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (-1.0d));
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate44);
        boolean boolean46 = timeSeriesDataItem41.equals((java.lang.Object) serialDate44);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addYears(7, serialDate44);
        int int48 = year21.compareTo((java.lang.Object) 7);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day54.next();
        java.util.Date date56 = regularTimePeriod55.getEnd();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.next();
        java.util.Date date60 = regularTimePeriod59.getEnd();
        boolean boolean61 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year57, (java.lang.Object) date60);
        java.lang.Class<?> wildcardClass62 = year57.getClass();
        java.lang.Class class63 = null;
        java.lang.Object obj64 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Preceding", (java.lang.Class) wildcardClass62, class63);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "ThreadContext", "6-April-1900", (java.lang.Class) wildcardClass62);
        java.lang.Object obj66 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Preceding", (java.lang.Class) wildcardClass62);
        boolean boolean67 = year21.equals((java.lang.Object) "Preceding");
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNull(obj64);
        org.junit.Assert.assertNull(obj66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.lang.Class<?> wildcardClass2 = spreadsheetDate1.getClass();
        java.lang.Class<?> wildcardClass3 = spreadsheetDate1.getClass();
        spreadsheetDate1.setDescription("");
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9, serialDate4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate4.getEndOfCurrentMonth(serialDate9);
        java.lang.Class<?> wildcardClass13 = serialDate12.getClass();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        boolean boolean25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year21, (java.lang.Object) date24);
        boolean boolean27 = year21.equals((java.lang.Object) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (double) 0.0f);
        int int30 = year21.getYear();
        java.util.Date date31 = year21.getStart();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year7 = month6.getYear();
        long long8 = month6.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 4);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=4]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=4]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=4]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=4]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=4]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=4]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=4]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=4]"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class8);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        timeSeries12.fireSeriesChanged();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
        java.util.Date date18 = regularTimePeriod17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        boolean boolean21 = timeSeries4.equals((java.lang.Object) timeSeries12);
        java.lang.String str22 = timeSeries4.getDescription();
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        int int10 = day5.getMonth();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day5.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
        java.lang.Number number16 = timeSeriesDataItem9.getValue();
        java.lang.Number number17 = null;
        timeSeriesDataItem9.setValue(number17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem9.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.0d) + "'", number16.equals((-1.0d)));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        java.lang.String str4 = day0.toString();
//        long long5 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.String str19 = timeSeries18.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "ThreadContext");
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries18.addAndOrUpdate(timeSeries21);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        java.util.Date date10 = regularTimePeriod9.getEnd();
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year7, (java.lang.Object) date10);
        java.lang.Class<?> wildcardClass12 = year7.getClass();
        java.lang.Class class13 = null;
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Preceding", (java.lang.Class) wildcardClass12, class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "ThreadContext", "6-April-1900", (java.lang.Class) wildcardClass12);
        boolean boolean16 = timeSeries15.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass2 = seriesException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        int int11 = day8.getMonth();
        java.util.Date date12 = day8.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        java.util.Date date10 = regularTimePeriod9.getEnd();
//        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year7, (java.lang.Object) date10);
//        java.lang.Class<?> wildcardClass12 = year7.getClass();
//        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
//        java.lang.ClassLoader classLoader14 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
//        int int15 = fixedMillisecond0.compareTo((java.lang.Object) classLoader14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) '#');
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond0.peg(calendar18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
//        java.util.Date date22 = regularTimePeriod21.getEnd();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.next();
//        java.util.Date date26 = regularTimePeriod25.getEnd();
//        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year23, (java.lang.Object) date26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
//        boolean boolean29 = fixedMillisecond0.equals((java.lang.Object) fixedMillisecond28);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond28.getMiddleMillisecond(calendar30);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439937354L + "'", long2 == 1560439937354L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439937354L + "'", long3 == 1560439937354L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(classLoader13);
//        org.junit.Assert.assertNotNull(classLoader14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560581999999L + "'", long31 == 1560581999999L);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 100.0f);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("Time");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("");
        java.lang.String str10 = seriesException9.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str10.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date9 = spreadsheetDate8.toDate();
        boolean boolean10 = month6.equals((java.lang.Object) date9);
        long long11 = month6.getSerialIndex();
        int int12 = month6.getYearValue();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        java.util.Date date19 = regularTimePeriod18.getEnd();
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year16, (java.lang.Object) date19);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean20, class21);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries22.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Comparable comparable25 = timeSeries22.getKey();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        java.util.Date date28 = regularTimePeriod27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date28, timeZone30);
        java.lang.String str32 = month31.toString();
        java.lang.String str33 = month31.toString();
        int int34 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) month31);
        boolean boolean35 = month6.equals((java.lang.Object) timeSeries22);
        java.util.Calendar calendar36 = null;
        try {
            long long37 = month6.getLastMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 24234L + "'", long11 == 24234L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + false + "'", comparable25.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries9.getKey();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        java.lang.String str19 = month18.toString();
        java.lang.String str20 = month18.toString();
        int int21 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        java.util.Date date28 = regularTimePeriod27.getEnd();
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year25, (java.lang.Object) date28);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate33);
        int int36 = year25.compareTo((java.lang.Object) serialDate33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (double) 5);
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class42);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries43.createCopy((int) (short) 0, 0);
        timeSeries46.fireSeriesChanged();
        java.lang.Class class48 = null;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.next();
        java.util.Date date51 = regularTimePeriod50.getEnd();
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date51, timeZone52);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date51);
        int int55 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) month54);
        java.lang.Number number56 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month54);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + false + "'", comparable12.equals(false));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 5.0d + "'", number56.equals(5.0d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate6);
        int int8 = spreadsheetDate2.compare(serialDate7);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(2019, serialDate12);
        boolean boolean15 = spreadsheetDate2.isOnOrBefore(serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(2019, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int17 = spreadsheetDate2.toSerial();
        int int18 = spreadsheetDate2.getMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-394) + "'", int8 == (-394));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        java.lang.String str7 = month6.toString();
        long long8 = month6.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries4.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries4.addChangeListener(seriesChangeListener14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries4.removeChangeListener(seriesChangeListener16);
        try {
            java.lang.Number number19 = timeSeries4.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        java.util.Collection collection17 = timeSeries7.getTimePeriods();
        timeSeries7.setDescription("Overwritten values from: hi!");
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560439866088L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439866088L + "'", long3 == 1560439866088L);
    }
}

