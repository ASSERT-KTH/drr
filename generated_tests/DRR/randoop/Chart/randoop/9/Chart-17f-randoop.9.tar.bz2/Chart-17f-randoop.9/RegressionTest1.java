import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ThreadContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        java.lang.Class class1 = null;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(5, year7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener19);
        java.util.Collection collection21 = timeSeries7.getTimePeriods();
        java.lang.Object obj22 = timeSeries7.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries7.addChangeListener(seriesChangeListener23);
        boolean boolean25 = timeSeries7.getNotify();
        try {
            timeSeries7.removeAgedItems((long) (-459), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        long long8 = year3.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year3.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "April" + "'", str1.equals("April"));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        timeSeries7.setMaximumItemCount(100);
        java.lang.String str13 = timeSeries7.getRangeDescription();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class17);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        int int24 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) day22);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener25);
        timeSeries18.setNotify(true);
        boolean boolean29 = timeSeries18.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries7.addAndOrUpdate(timeSeries18);
        timeSeries18.setMaximumItemCount(11);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(timeSeries30);
    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test08");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.util.Date date12 = regularTimePeriod11.getEnd();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = timeSeriesDataItem9.equals(obj16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        long long21 = fixedMillisecond18.getLastMillisecond();
//        boolean boolean22 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond18);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond18.getMiddleMillisecond(calendar23);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560439939492L + "'", long20 == 1560439939492L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560439939492L + "'", long21 == 1560439939492L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560439939492L + "'", long24 == 1560439939492L);
//    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate12);
        boolean boolean14 = timeSeriesDataItem9.equals((java.lang.Object) serialDate12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate12);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day15.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, class8);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test11");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            timeSeries7.add(regularTimePeriod19, (double) 1560439927309L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate9.getNearestDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        int int5 = day4.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        timeSeries7.setMaximumItemCount(100);
        timeSeries7.clear();
        try {
            java.lang.Number number15 = timeSeries7.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        long long5 = day4.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9L + "'", long5 == 9L);
    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        java.util.Date date4 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
//        java.util.Date date7 = regularTimePeriod6.getEnd();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.util.Date date12 = regularTimePeriod11.getEnd();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        boolean boolean17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year13, (java.lang.Object) date16);
//        java.lang.Class<?> wildcardClass18 = year13.getClass();
//        java.lang.ClassLoader classLoader19 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass18);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResource("Value", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        java.util.Date date24 = regularTimePeriod23.getEnd();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
//        java.util.Date date28 = regularTimePeriod27.getEnd();
//        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year25, (java.lang.Object) date28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getFirstMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond30.getMiddleMillisecond(calendar33);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond30.getLastMillisecond(calendar35);
//        java.util.Date date37 = fixedMillisecond30.getTime();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.next();
//        java.util.Date date40 = regularTimePeriod39.getEnd();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
//        java.util.Date date44 = regularTimePeriod43.getEnd();
//        boolean boolean45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year41, (java.lang.Object) date44);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date44);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day47.next();
//        java.util.Date date49 = regularTimePeriod48.getEnd();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date49, timeZone51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date44, timeZone51);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date37, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date28, timeZone51);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date7, timeZone51);
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date4, timeZone51);
//        try {
//            org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date0, timeZone51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(classLoader19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNull(uRL21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560439939772L + "'", long32 == 1560439939772L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560439939772L + "'", long34 == 1560439939772L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560439939772L + "'", long36 == 1560439939772L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6, timeZone8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date6, timeZone17);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date2, timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year3, (java.lang.Object) date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate9);
    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test22");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener19);
//        java.util.Collection collection21 = timeSeries7.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond22.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 97L);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond22.getLastMillisecond(calendar29);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.next();
//        java.util.Date date38 = regularTimePeriod37.getEnd();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.next();
//        java.util.Date date42 = regularTimePeriod41.getEnd();
//        boolean boolean43 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year39, (java.lang.Object) date42);
//        java.lang.Class<?> wildcardClass44 = year39.getClass();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass44);
//        java.io.InputStream inputStream46 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Overwritten values from: hi!", (java.lang.Class) wildcardClass44);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day52.next();
//        java.util.Date date54 = regularTimePeriod53.getEnd();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day56.next();
//        java.util.Date date58 = regularTimePeriod57.getEnd();
//        boolean boolean59 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year55, (java.lang.Object) date58);
//        java.lang.Class<?> wildcardClass60 = year55.getClass();
//        java.lang.Class class61 = null;
//        java.lang.Object obj62 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Preceding", (java.lang.Class) wildcardClass60, class61);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "ThreadContext", "6-April-1900", (java.lang.Class) wildcardClass60);
//        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass60);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day67.next();
//        java.util.Date date69 = regularTimePeriod68.getEnd();
//        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date69);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day71.next();
//        java.util.Date date73 = regularTimePeriod72.getEnd();
//        boolean boolean74 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year70, (java.lang.Object) date73);
//        java.lang.Class<?> wildcardClass75 = year70.getClass();
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = day77.next();
//        java.util.Date date79 = regularTimePeriod78.getEnd();
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date79);
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = day81.next();
//        java.util.Date date83 = regularTimePeriod82.getEnd();
//        boolean boolean84 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year80, (java.lang.Object) date83);
//        java.lang.Class<?> wildcardClass85 = year80.getClass();
//        java.lang.ClassLoader classLoader86 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass85);
//        java.lang.Object obj87 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("6-April-1900", (java.lang.Class) wildcardClass75, (java.lang.Class) wildcardClass85);
//        java.lang.Object obj88 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Friday", (java.lang.Class) wildcardClass60, (java.lang.Class) wildcardClass75);
//        java.lang.Object obj89 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", (java.lang.Class) wildcardClass44, (java.lang.Class) wildcardClass75);
//        org.jfree.data.time.TimeSeries timeSeries90 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "ERROR : Relative To String", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass44);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560439940405L + "'", long24 == 1560439940405L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560439940405L + "'", long26 == 1560439940405L);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560439940405L + "'", long30 == 1560439940405L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNull(inputStream46);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNull(obj62);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertNotNull(wildcardClass85);
//        org.junit.Assert.assertNotNull(classLoader86);
//        org.junit.Assert.assertNull(obj87);
//        org.junit.Assert.assertNull(obj88);
//        org.junit.Assert.assertNull(obj89);
//    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        java.lang.String str21 = timeSeries18.getRangeDescription();
        timeSeries18.setDescription("");
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.next();
        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (-1.0d));
        int int34 = day29.getMonth();
        try {
            timeSeries18.update((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test24");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.util.Date date12 = regularTimePeriod11.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy(regularTimePeriod9, regularTimePeriod11);
//        timeSeries7.setKey((java.lang.Comparable) 10.0f);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener16);
//        timeSeries7.setMaximumItemCount((int) (short) 100);
//        timeSeries7.clear();
//        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries7);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class25);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries26.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener30);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class35);
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries36.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries29.addAndOrUpdate(timeSeries36);
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timeSeries29.addPropertyChangeListener(propertyChangeListener41);
//        java.util.Collection collection43 = timeSeries29.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond44.getFirstMillisecond(calendar45);
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond44.getMiddleMillisecond(calendar47);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 97L);
//        java.util.Collection collection51 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        int int52 = timeSeries29.getItemCount();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(collection43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560439942644L + "'", long46 == 1560439942644L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560439942644L + "'", long48 == 1560439942644L);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) 1560439939492L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test26");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.util.Date date2 = regularTimePeriod1.getEnd();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
//        long long6 = fixedMillisecond4.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560581999999L + "'", long6 == 1560581999999L);
//    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13, timeZone15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date13);
        java.lang.String str18 = month17.toString();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        boolean boolean28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year24, (java.lang.Object) date27);
        java.lang.Class<?> wildcardClass29 = year24.getClass();
        long long30 = year24.getFirstMillisecond();
        boolean boolean32 = year24.equals((java.lang.Object) (-459));
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
        java.util.Date date36 = regularTimePeriod35.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.next();
        java.util.Date date40 = regularTimePeriod39.getEnd();
        boolean boolean41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year37, (java.lang.Object) date40);
        java.lang.Class<?> wildcardClass42 = year37.getClass();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass42);
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
        int int45 = year24.compareTo((java.lang.Object) class44);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "Nearest", "ClassContext", class44);
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries46.removePropertyChangeListener(propertyChangeListener47);
        java.util.Collection collection49 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(collection49);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        java.lang.Class class1 = null;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(8, serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test30");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
//        java.lang.Object obj19 = timeSeries14.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
//        java.lang.Object obj24 = null;
//        boolean boolean25 = day22.equals(obj24);
//        java.lang.String str26 = day22.toString();
//        java.lang.String str27 = day22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 43629L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day22.previous();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 4);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 4 + "'", obj2.equals(4));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 4 + "'", obj3.equals(4));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate8);
        serialDate9.setDescription("");
        boolean boolean12 = spreadsheetDate4.isOn(serialDate9);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year17, (java.lang.Object) date20);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate25);
        int int28 = year17.compareTo((java.lang.Object) serialDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate25);
        boolean boolean30 = spreadsheetDate4.isOn(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date37 = spreadsheetDate36.toDate();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate40);
        int int42 = spreadsheetDate36.compare(serialDate41);
        boolean boolean43 = spreadsheetDate4.isInRange(serialDate33, serialDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date47 = spreadsheetDate46.toDate();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate50);
        serialDate51.setDescription("");
        boolean boolean54 = spreadsheetDate46.isOn(serialDate51);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.next();
        java.util.Date date57 = regularTimePeriod56.getEnd();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day59.next();
        java.util.Date date61 = regularTimePeriod60.getEnd();
        boolean boolean62 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year58, (java.lang.Object) date61);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate66);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate66);
        int int69 = year58.compareTo((java.lang.Object) serialDate66);
        serialDate66.setDescription("6-April-1900");
        boolean boolean72 = spreadsheetDate46.isOn(serialDate66);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears(7, serialDate66);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = day74.next();
        java.util.Date date76 = regularTimePeriod75.getEnd();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day78.next();
        java.util.Date date80 = regularTimePeriod79.getEnd();
        boolean boolean81 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year77, (java.lang.Object) date80);
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date80);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date80);
        org.jfree.data.time.SerialDate serialDate84 = serialDate73.getEndOfCurrentMonth(serialDate83);
        boolean boolean85 = spreadsheetDate4.isOnOrBefore(serialDate83);
        boolean boolean86 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            org.jfree.data.time.SerialDate serialDate88 = spreadsheetDate4.getNearestDayOfWeek((-571));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-394) + "'", int42 == (-394));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        timeSeriesDataItem9.setValue((java.lang.Number) 11);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDomainDescription();
        timeSeries7.setMaximumItemCount(100);
        java.lang.String str13 = timeSeries7.getRangeDescription();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class17);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.next();
        int int24 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) day22);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener25);
        timeSeries18.setNotify(true);
        boolean boolean29 = timeSeries18.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries7.addAndOrUpdate(timeSeries18);
        try {
            timeSeries7.update(0, (java.lang.Number) 1560439930267L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(timeSeries30);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (-1.0d));
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        java.util.Date date30 = regularTimePeriod29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
        boolean boolean33 = timeSeriesDataItem27.equals((java.lang.Object) regularTimePeriod32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, regularTimePeriod32);
        java.lang.Class class35 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNull(class35);
    }

//    @Test
//    public void test37() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test37");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
//        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day13);
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day13);
//        int int17 = day13.getMonth();
//        java.lang.String str18 = day13.toString();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy(regularTimePeriod9, regularTimePeriod11);
        java.lang.Object obj14 = timeSeries7.clone();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        int int8 = year6.compareTo((java.lang.Object) (short) 0);
        java.util.Date date9 = year6.getStart();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12, timeZone14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date9, timeZone14);
        long long17 = month16.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(9, serialDate22);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate27);
        org.jfree.data.time.SerialDate serialDate30 = serialDate22.getEndOfCurrentMonth(serialDate27);
        int int31 = month16.compareTo((java.lang.Object) serialDate30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
        java.util.Date date34 = regularTimePeriod33.getEnd();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.next();
        java.util.Date date38 = regularTimePeriod37.getEnd();
        boolean boolean39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year35, (java.lang.Object) date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date38);
        boolean boolean43 = spreadsheetDate1.isInRange(serialDate30, serialDate41, (int) (short) 10);
        try {
            org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate1.getFollowingDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date5 = spreadsheetDate4.toDate();
        java.lang.Class<?> wildcardClass6 = date5.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "June 2019", "8-January-1900", (java.lang.Class) wildcardClass6);
        int int8 = timeSeries7.getItemCount();
        try {
            java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) int8);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test41");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class6);
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries7.createCopy((int) (short) 0, 0);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        int int20 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries10);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate23);
//        java.util.Date date26 = day25.getEnd();
//        long long27 = day25.getSerialIndex();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
//        java.util.Date date30 = regularTimePeriod29.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date30, timeZone32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date30);
//        org.jfree.data.time.Year year35 = month34.getYear();
//        int int36 = day25.compareTo((java.lang.Object) year35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, 10.0d);
//        org.jfree.data.general.SeriesException seriesException40 = new org.jfree.data.general.SeriesException("");
//        java.lang.Class<?> wildcardClass41 = seriesException40.getClass();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, (java.lang.Class) wildcardClass41);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439944390L + "'", long2 == 1560439944390L);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 97L + "'", long27 == 97L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate6);
        serialDate7.setDescription("");
        boolean boolean10 = spreadsheetDate2.isOn(serialDate7);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (-1.0d));
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate25);
        boolean boolean27 = timeSeriesDataItem22.equals((java.lang.Object) serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears(7, serialDate25);
        boolean boolean29 = spreadsheetDate2.isOnOrBefore(serialDate25);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date33 = spreadsheetDate32.toDate();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate36);
        serialDate37.setDescription("");
        boolean boolean40 = spreadsheetDate32.isOn(serialDate37);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
        java.util.Date date44 = regularTimePeriod43.getEnd();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.next();
        java.util.Date date48 = regularTimePeriod47.getEnd();
        boolean boolean49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year45, (java.lang.Object) date48);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate53);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate53);
        int int56 = year45.compareTo((java.lang.Object) serialDate53);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate53);
        boolean boolean58 = spreadsheetDate32.isOn(serialDate57);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date65 = spreadsheetDate64.toDate();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate68);
        int int70 = spreadsheetDate64.compare(serialDate69);
        boolean boolean71 = spreadsheetDate32.isInRange(serialDate61, serialDate69);
        boolean boolean72 = spreadsheetDate2.equals((java.lang.Object) boolean71);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException74 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException76 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.general.SeriesException seriesException78 = new org.jfree.data.general.SeriesException("Time");
        timePeriodFormatException76.addSuppressed((java.lang.Throwable) seriesException78);
        timePeriodFormatException74.addSuppressed((java.lang.Throwable) timePeriodFormatException76);
        boolean boolean81 = spreadsheetDate2.equals((java.lang.Object) timePeriodFormatException74);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-394) + "'", int70 == (-394));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.util.Date date5 = day4.getEnd();
        long long6 = day4.getSerialIndex();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Year year14 = month13.getYear();
        int int15 = day4.compareTo((java.lang.Object) year14);
        long long16 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.next();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
        java.util.Date date22 = regularTimePeriod21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date22, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date22);
        java.lang.String str27 = month26.toString();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
        java.util.Date date32 = regularTimePeriod31.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
        java.util.Date date36 = regularTimePeriod35.getEnd();
        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year33, (java.lang.Object) date36);
        java.lang.Class<?> wildcardClass38 = year33.getClass();
        long long39 = year33.getFirstMillisecond();
        boolean boolean41 = year33.equals((java.lang.Object) (-459));
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
        java.util.Date date45 = regularTimePeriod44.getEnd();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day47.next();
        java.util.Date date49 = regularTimePeriod48.getEnd();
        boolean boolean50 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year46, (java.lang.Object) date49);
        java.lang.Class<?> wildcardClass51 = year46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass51);
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
        int int54 = year33.compareTo((java.lang.Object) class53);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str27, "Nearest", "ClassContext", class53);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14, "org.jfree.data.general.SeriesException: ", "June 2019", class53);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod14);
        java.lang.Number number16 = timeSeriesDataItem9.getValue();
        java.lang.Number number17 = null;
        timeSeriesDataItem9.setValue(number17);
        java.lang.Number number19 = timeSeriesDataItem9.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem9.getPeriod();
        java.lang.Object obj21 = timeSeriesDataItem9.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.0d) + "'", number16.equals((-1.0d)));
        org.junit.Assert.assertNull(number19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        int int5 = year3.compareTo((java.lang.Object) (short) 0);
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year3.next();
        java.util.Date date8 = year3.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        int int7 = spreadsheetDate1.compare(serialDate6);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.removeChangeListener(seriesChangeListener16);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.addAndOrUpdate(timeSeries22);
        timeSeries26.setDescription("");
        java.lang.String str29 = timeSeries26.getRangeDescription();
        long long30 = timeSeries26.getMaximumItemAge();
        boolean boolean31 = spreadsheetDate1.equals((java.lang.Object) timeSeries26);
        int int32 = spreadsheetDate1.getMonth();
        int int33 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-394) + "'", int7 == (-394));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 8 + "'", int33 == 8);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        java.lang.String str6 = month5.toString();
        int int7 = month5.getMonth();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        java.util.Date date10 = regularTimePeriod9.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
        java.util.Date date14 = regularTimePeriod13.getEnd();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year11, (java.lang.Object) date14);
        java.lang.Class<?> wildcardClass16 = year11.getClass();
        long long17 = year11.getFirstMillisecond();
        boolean boolean19 = year11.equals((java.lang.Object) (-459));
        java.util.Date date20 = year11.getStart();
        long long21 = year11.getFirstMillisecond();
        boolean boolean22 = month5.equals((java.lang.Object) long21);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

//    @Test
//    public void test49() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test49");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate6);
        serialDate7.setDescription("");
        boolean boolean10 = spreadsheetDate2.isOn(serialDate7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year14, (java.lang.Object) date17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate22);
        int int25 = year14.compareTo((java.lang.Object) serialDate22);
        serialDate22.setDescription("6-April-1900");
        boolean boolean28 = spreadsheetDate2.isOn(serialDate22);
        try {
            org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ClassContext");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: ClassContext" + "'", str2.equals("org.jfree.data.general.SeriesException: ClassContext"));
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy(regularTimePeriod9, regularTimePeriod11);
        timeSeries7.setKey((java.lang.Comparable) 10.0f);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener16);
        timeSeries7.setMaximumItemCount((int) (short) 100);
        timeSeries7.clear();
        java.lang.String str21 = timeSeries7.getDomainDescription();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year6, (java.lang.Object) date9);
        java.lang.Class<?> wildcardClass11 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year17, (java.lang.Object) date20);
        java.lang.Class<?> wildcardClass22 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, (java.lang.Class) wildcardClass22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("6-April-1900", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass22);
        java.lang.Object obj26 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", (java.lang.Class) wildcardClass22);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(obj26);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate8);
        serialDate9.setDescription("");
        boolean boolean12 = spreadsheetDate4.isOn(serialDate9);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = regularTimePeriod19.getEnd();
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year17, (java.lang.Object) date20);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate25);
        int int28 = year17.compareTo((java.lang.Object) serialDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate25);
        boolean boolean30 = spreadsheetDate4.isOn(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date37 = spreadsheetDate36.toDate();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate40);
        int int42 = spreadsheetDate36.compare(serialDate41);
        boolean boolean43 = spreadsheetDate4.isInRange(serialDate33, serialDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date47 = spreadsheetDate46.toDate();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate50);
        serialDate51.setDescription("");
        boolean boolean54 = spreadsheetDate46.isOn(serialDate51);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.next();
        java.util.Date date57 = regularTimePeriod56.getEnd();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day59.next();
        java.util.Date date61 = regularTimePeriod60.getEnd();
        boolean boolean62 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year58, (java.lang.Object) date61);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate66);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate66);
        int int69 = year58.compareTo((java.lang.Object) serialDate66);
        serialDate66.setDescription("6-April-1900");
        boolean boolean72 = spreadsheetDate46.isOn(serialDate66);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears(7, serialDate66);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = day74.next();
        java.util.Date date76 = regularTimePeriod75.getEnd();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day78.next();
        java.util.Date date80 = regularTimePeriod79.getEnd();
        boolean boolean81 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year77, (java.lang.Object) date80);
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date80);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date80);
        org.jfree.data.time.SerialDate serialDate84 = serialDate73.getEndOfCurrentMonth(serialDate83);
        boolean boolean85 = spreadsheetDate4.isOnOrBefore(serialDate83);
        boolean boolean86 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.util.Date date87 = spreadsheetDate1.toDate();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-394) + "'", int42 == (-394));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(date87);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        timeSeries7.fireSeriesChanged();
        java.lang.String str9 = timeSeries7.getDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate5);
        serialDate6.setDescription("");
        boolean boolean9 = spreadsheetDate1.isOn(serialDate6);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year14, (java.lang.Object) date17);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate22);
        int int25 = year14.compareTo((java.lang.Object) serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate22);
        boolean boolean27 = spreadsheetDate1.isOn(serialDate26);
        try {
            org.jfree.data.time.SerialDate serialDate29 = serialDate26.getFollowingDayOfWeek((-452));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (-1.0d));
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate13);
        boolean boolean15 = timeSeriesDataItem10.equals((java.lang.Object) serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(7, serialDate13);
        try {
            org.jfree.data.time.SerialDate serialDate18 = serialDate13.getFollowingDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year7 = month6.getYear();
        long long8 = month6.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        int int5 = year3.compareTo((java.lang.Object) (short) 0);
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year3.next();
        long long8 = year3.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.util.Date date5 = day4.getEnd();
        long long6 = day4.getSerialIndex();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Year year14 = month13.getYear();
        int int15 = day4.compareTo((java.lang.Object) year14);
        long long16 = day4.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2200708800001L) + "'", long16 == (-2200708800001L));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9, serialDate4);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate4.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (-1.0d));
        java.text.DateFormatSymbols dateFormatSymbols10 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) dateFormatSymbols10);
        java.lang.Number number12 = timeSeriesDataItem9.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(dateFormatSymbols10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (-1.0d));
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        java.util.Date date30 = regularTimePeriod29.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.next();
        boolean boolean33 = timeSeriesDataItem27.equals((java.lang.Object) regularTimePeriod32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, regularTimePeriod32);
        java.lang.String str35 = timeSeries34.getRangeDescription();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.next();
        java.util.Date date38 = regularTimePeriod37.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date38, timeZone40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(9);
        java.util.Date date45 = spreadsheetDate44.toDate();
        boolean boolean46 = month42.equals((java.lang.Object) date45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month42.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries34.createCopy(regularTimePeriod47, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.lang.Class class53 = null;
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class53);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.next();
        timeSeries54.delete((org.jfree.data.time.RegularTimePeriod) day55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day55, (-1.0d));
        int int60 = day55.getMonth();
        timeSeries49.delete((org.jfree.data.time.RegularTimePeriod) day55);
        timeSeries49.setMaximumItemCount((int) '#');
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
    }

//    @Test
//    public void test66() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test66");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getFirstMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439951051L + "'", long2 == 1560439951051L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439951051L + "'", long4 == 1560439951051L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439951051L + "'", long6 == 1560439951051L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560439951051L + "'", long8 == 1560439951051L);
//    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        timeSeries18.setDescription("");
        java.lang.String str21 = timeSeries18.getRangeDescription();
        timeSeries18.setDescription("");
        try {
            java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
        int int10 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        int int11 = day8.getMonth();
        java.util.Date date12 = day8.getEnd();
        org.jfree.data.time.SerialDate serialDate13 = day8.getSerialDate();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class3);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class13);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy((int) (short) 0, 0);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries7.addAndOrUpdate(timeSeries14);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class22);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class27);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries28.createCopy((int) (short) 0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        timeSeries31.fireSeriesChanged();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) day38);
        boolean boolean40 = timeSeries23.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries7.addAndOrUpdate(timeSeries31);
        java.util.Collection collection42 = timeSeries31.getTimePeriods();
        java.lang.Comparable comparable43 = timeSeries31.getKey();
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.next();
        timeSeries48.delete((org.jfree.data.time.RegularTimePeriod) day49);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day49, (-1.0d));
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day54.next();
        java.util.Date date56 = regularTimePeriod55.getEnd();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day57.next();
        boolean boolean59 = timeSeriesDataItem53.equals((java.lang.Object) regularTimePeriod58);
        try {
            timeSeries31.add(timeSeriesDataItem53, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + "hi!" + "'", comparable43.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

//    @Test
//    public void test70() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test70");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class6);
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries7.createCopy((int) (short) 0, 0);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day16);
//        int int20 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries10);
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!", class24);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy((int) (short) 0, 0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener29);
//        java.lang.String str31 = timeSeries28.getDomainDescription();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        java.util.Date date34 = regularTimePeriod33.getEnd();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
//        int int37 = year35.compareTo((java.lang.Object) (short) 0);
//        java.util.Date date38 = year35.getStart();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.next();
//        java.util.Date date41 = regularTimePeriod40.getEnd();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date41, timeZone43);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date38, timeZone43);
//        long long46 = month45.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addYears((int) (short) 10, serialDate49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(serialDate49);
//        java.util.Date date52 = day51.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month45, (org.jfree.data.time.RegularTimePeriod) day51);
//        int int54 = day51.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) 1.0f);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439951144L + "'", long2 == 1560439951144L);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//    }
//}

