import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test1");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-9999), "org.jfree.data.event.SeriesChangeEvent[source=-1.0]", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 0);
        boolean boolean10 = timeSeriesDataItem9.isSelected();
        java.lang.Object obj11 = timeSeriesDataItem9.clone();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int14 = year12.compareTo((java.lang.Object) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        boolean boolean16 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod15);
        timeSeries3.add(timeSeriesDataItem9);
        java.lang.Object obj18 = timeSeries3.clone();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener19);
        timeSeries3.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=-1.0]");
        java.lang.String str23 = timeSeries3.getRangeDescription();
        java.util.List list24 = timeSeries3.getItems();
        timeSeries3.clear();
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1.0]" + "'", str23.equals("org.jfree.data.event.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertNotNull(list24);
    }

//    @Test
//    public void test2() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test2");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-9999), "org.jfree.data.event.SeriesChangeEvent[source=-1.0]", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 0);
//        boolean boolean10 = timeSeriesDataItem9.isSelected();
//        java.lang.Object obj11 = timeSeriesDataItem9.clone();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        int int14 = year12.compareTo((java.lang.Object) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
//        boolean boolean16 = timeSeriesDataItem9.equals((java.lang.Object) regularTimePeriod15);
//        timeSeries3.add(timeSeriesDataItem9);
//        java.lang.Object obj18 = timeSeries3.clone();
//        int int19 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond20.previous();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond20.getMiddleMillisecond(calendar22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond20.getMiddleMillisecond(calendar24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond20.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 28799999L);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-9999), "org.jfree.data.event.SeriesChangeEvent[source=-1.0]", "");
//        java.util.Collection collection34 = timeSeries33.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) 0);
//        boolean boolean40 = timeSeriesDataItem39.isSelected();
//        java.lang.Object obj41 = timeSeriesDataItem39.clone();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        int int44 = year42.compareTo((java.lang.Object) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year42.next();
//        boolean boolean46 = timeSeriesDataItem39.equals((java.lang.Object) regularTimePeriod45);
//        timeSeries33.add(timeSeriesDataItem39);
//        java.lang.Object obj48 = timeSeries33.clone();
//        int int49 = timeSeries33.getItemCount();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.util.Date date51 = day50.getStart();
//        long long52 = day50.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) day50);
//        timeSeries33.removeAgedItems(false);
//        timeSeries33.fireSeriesChanged();
//        java.util.Collection collection57 = timeSeries33.getTimePeriods();
//        long long58 = timeSeries33.getMaximumItemAge();
//        int int59 = year29.compareTo((java.lang.Object) timeSeries33);
//        int int60 = year29.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 24234L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = timeSeriesDataItem62.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries3.getDataItem(regularTimePeriod63);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond65.previous();
//        java.util.Calendar calendar67 = null;
//        long long68 = fixedMillisecond65.getMiddleMillisecond(calendar67);
//        java.util.Calendar calendar69 = null;
//        long long70 = fixedMillisecond65.getLastMillisecond(calendar69);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond65.next();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond65);
//        java.util.Date date73 = fixedMillisecond65.getTime();
//        long long74 = fixedMillisecond65.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560183451782L + "'", long23 == 1560183451782L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560183451782L + "'", long25 == 1560183451782L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(obj48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 43626L + "'", long52 == 43626L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
//        org.junit.Assert.assertNotNull(collection57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 9223372036854775807L + "'", long58 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem64);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560183451790L + "'", long68 == 1560183451790L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560183451790L + "'", long70 == 1560183451790L);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560183451790L + "'", long74 == 1560183451790L);
//        org.junit.Assert.assertNull(timeSeriesDataItem75);
//    }
//}

