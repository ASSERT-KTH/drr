import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setLowerMargin((double) 1.0f);
        java.lang.Class<?> wildcardClass8 = categoryAxis1.getClass();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3, false);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer(11);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot0.getDomainAxis(11);
        categoryPlot0.setRangeCrosshairValue(2.0d, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(categoryAxis16);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-6.0d), (double) 10.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str5 = chartChangeEventType4.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) intervalMarker2, jFreeChart3, chartChangeEventType4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker2.setLabelAnchor(rectangleAnchor7);
        intervalMarker2.setLabel("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]");
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.ASCENDING;
        boolean boolean12 = intervalMarker2.equals((java.lang.Object) sortOrder11);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        java.awt.Color color15 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean17 = color15.equals((java.lang.Object) textAnchor16);
        dateAxis7.setAxisLinePaint((java.awt.Paint) color15);
        double double19 = dateAxis7.getLabelAngle();
        double double20 = dateAxis7.getLowerBound();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double22 = rectangleInsets21.getLeft();
        double double24 = rectangleInsets21.calculateTopOutset((double) 100L);
        dateAxis7.setTickLabelInsets(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setPositiveArrowVisible(true);
        dateAxis0.setUpperMargin(1.0d);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isPositiveArrowVisible();
        java.awt.Stroke stroke8 = dateAxis6.getTickMarkStroke();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis6.setTickMarkStroke(stroke9);
        dateAxis6.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        java.awt.Shape shape15 = dateAxis13.getDownArrow();
        dateAxis6.setLeftArrow(shape15);
        dateAxis0.setDownArrow(shape15);
        try {
            dateAxis0.zoomRange((double) 13, (double) 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (13.0) <= upper (2.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        double double16 = rectangleInsets14.extendWidth((double) 1560452399999L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.560452400015E12d + "'", double16 == 1.560452400015E12d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean18 = numberAxis17.getAutoRangeIncludesZero();
        numberAxis17.setAutoRangeStickyZero(true);
        numberAxis17.setAutoRangeIncludesZero(true);
        categoryPlot14.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis17, true);
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot14.getDataset();
        boolean boolean26 = categoryPlot14.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot14.setRenderer((int) '4', categoryItemRenderer28, true);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot14.getDataset();
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 106.0d, dataset35);
        categoryPlot14.datasetChanged(datasetChangeEvent36);
        categoryPlot0.datasetChanged(datasetChangeEvent36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(categoryDataset33);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        xYPlot25.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot25.getDomainAxisLocation(100);
        int int37 = xYPlot25.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setLabel("13-June-2019");
        org.jfree.data.RangeType rangeType14 = numberAxis11.getRangeType();
        numberAxis6.setRangeType(rangeType14);
        numberAxis6.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rangeType14);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setTickMarkStroke(stroke3);
        dateAxis0.setVerticalTickLabels(true);
        dateAxis0.centerRange((double) (byte) -1);
        boolean boolean9 = dateAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBComponents(floatArray1);
        int int3 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-12517377) + "'", int3 == (-12517377));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot12.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        java.awt.Stroke stroke21 = dateAxis19.getTickMarkStroke();
        double double22 = dateAxis19.getUpperMargin();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis19.setTickMarkStroke(stroke23);
        categoryMarker18.setOutlineStroke(stroke23);
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        xYPlot12.setFixedRangeAxisSpace(axisSpace28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot12.getRangeAxisLocation(13);
        float float32 = xYPlot12.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        java.awt.Stroke stroke34 = xYPlot25.getOutlineStroke();
        boolean boolean35 = xYPlot25.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.plot.Plot plot14 = plotChangeEvent13.getPlot();
        org.jfree.chart.plot.Plot plot15 = plotChangeEvent13.getPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Paint paint15 = xYPlot12.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot12.getDomainAxisEdge((-515));
        java.awt.Stroke stroke18 = xYPlot12.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        java.lang.String str16 = xYPlot12.getNoDataMessage();
        xYPlot12.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot12.getDomainAxisLocation();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot12.getDomainAxisForDataset(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 2 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        try {
            categoryPlot0.setRenderer((-8355712), categoryItemRenderer5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        xYPlot25.setDomainCrosshairValue((double) (-1.0f));
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.plot.CrosshairState crosshairState38 = null;
        boolean boolean39 = xYPlot25.render(graphics2D34, rectangle2D35, (-515), plotRenderingInfo37, crosshairState38);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getLabelAngle();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        dateAxis11.setTickMarkOutsideLength((float) 10);
        boolean boolean16 = dateAxis11.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isPositiveArrowVisible();
        dateAxis17.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot22.getDomainAxisEdge();
        try {
            java.util.List list24 = categoryAxis1.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP" + "'", str1.equals("RectangleAnchor.TOP"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(0, categoryDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        double double31 = xYPlot28.getRangeCrosshairValue();
        java.awt.Paint paint32 = xYPlot28.getRangeCrosshairPaint();
        xYPlot28.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D35 = xYPlot28.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D35, false);
        int int38 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker41 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj42 = intervalMarker41.clone();
        double double43 = intervalMarker41.getStartValue();
        java.awt.Paint paint44 = null;
        intervalMarker41.setOutlinePaint(paint44);
        boolean boolean46 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker41);
        java.awt.Color color48 = java.awt.Color.WHITE;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        boolean boolean50 = dateAxis49.isPositiveArrowVisible();
        java.awt.Stroke stroke51 = dateAxis49.getTickMarkStroke();
        java.awt.Color color52 = java.awt.Color.BLUE;
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        boolean boolean56 = dateAxis55.isPositiveArrowVisible();
        java.awt.Stroke stroke57 = dateAxis55.getTickMarkStroke();
        double double58 = dateAxis55.getUpperMargin();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis55.setTickMarkStroke(stroke59);
        categoryMarker54.setOutlineStroke(stroke59);
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color48, stroke51, (java.awt.Paint) color52, stroke59, (float) (short) 1);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color48);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 9.0d + "'", double43 == 9.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.05d + "'", double58 == 0.05d);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation31, plotOrientation32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        xYPlot25.setRangeAxis(valueAxis32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = xYPlot25.getFixedLegendItems();
        boolean boolean35 = xYPlot25.isSubplot();
        int int36 = xYPlot25.getSeriesCount();
        xYPlot25.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(legendItemCollection34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        boolean boolean13 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateBottomInset((double) 1.0f);
        boolean boolean18 = datasetRenderingOrder14.equals((java.lang.Object) rectangleInsets15);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder14);
        java.lang.String str20 = datasetRenderingOrder14.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str20.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot25.setRangeAxisLocation(0, axisLocation33, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj39 = intervalMarker38.clone();
        double double40 = intervalMarker38.getStartValue();
        java.awt.Paint paint41 = null;
        intervalMarker38.setOutlinePaint(paint41);
        xYPlot25.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        java.lang.Object obj44 = intervalMarker38.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 9.0d + "'", double40 == 9.0d);
        org.junit.Assert.assertNotNull(obj44);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        xYPlot21.setDomainZeroBaselineVisible(false);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.util.List list28 = null;
        xYPlot21.drawDomainTickBands(graphics2D26, rectangle2D27, list28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = xYPlot21.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier30);
        int int32 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis0.setNumberFormatOverride(numberFormat6);
        numberAxis0.setAutoRange(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        double double16 = dateAxis15.getLabelAngle();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        dateAxis15.setTickMarkOutsideLength((float) 10);
        boolean boolean20 = dateAxis15.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
        dateAxis21.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot26.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean29 = xYPlot26.isRangeCrosshairVisible();
        xYPlot26.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo13, point2D32);
        categoryPlot0.clearRangeMarkers(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(point2D32);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj13 = intervalMarker12.clone();
        double double14 = intervalMarker12.getStartValue();
        java.awt.Paint paint15 = null;
        intervalMarker12.setOutlinePaint(paint15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker(5, (org.jfree.chart.plot.Marker) intervalMarker12, layer17);
        org.jfree.chart.util.SortOrder sortOrder19 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setColumnRenderingOrder(sortOrder19);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.0d + "'", double14 == 9.0d);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(sortOrder19);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color34 = java.awt.Color.lightGray;
        categoryMarker33.setLabelPaint((java.awt.Paint) color34);
        boolean boolean36 = categoryMarker33.getDrawAsLine();
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = xYPlot25.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker33, layer37);
        int int39 = xYPlot25.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        xYPlot25.setParent((org.jfree.chart.plot.Plot) categoryPlot40);
        xYPlot25.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        java.lang.String str16 = xYPlot12.getNoDataMessage();
        xYPlot12.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot12.getDomainAxisLocation();
        java.awt.Paint paint21 = xYPlot12.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        java.lang.String str16 = xYPlot12.getNoDataMessage();
        xYPlot12.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot12.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot12.setFixedDomainAxisSpace(axisSpace21);
        boolean boolean23 = xYPlot12.isSubplot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        xYPlot25.addChangeListener(plotChangeListener34);
        java.awt.Image image36 = null;
        xYPlot25.setBackgroundImage(image36);
        org.jfree.chart.axis.AxisSpace axisSpace38 = xYPlot25.getFixedDomainAxisSpace();
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.CrosshairState crosshairState43 = null;
        boolean boolean44 = xYPlot25.render(graphics2D39, rectangle2D40, (int) (byte) 100, plotRenderingInfo42, crosshairState43);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(axisSpace38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat2 = null;
        numberAxis0.setNumberFormatOverride(numberFormat2);
        org.jfree.data.Range range4 = null;
        try {
            numberAxis0.setRange(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.Timeline timeline1 = null;
//        dateAxis0.setTimeline(timeline1);
//        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
//        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
//        dateAxis0.setRangeWithMargins((double) 2, (double) 10);
//        dateAxis0.resizeRange((double) (byte) 1);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean13 = day10.equals((java.lang.Object) day12);
//        java.util.Date date14 = day10.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day10.next();
//        int int16 = day10.getMonth();
//        java.util.Date date17 = day10.getEnd();
//        java.util.Date date18 = null;
//        try {
//            dateAxis0.setRange(date17, date18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNull(plot4);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(date17);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color2 = java.awt.Color.lightGray;
        categoryMarker1.setLabelPaint((java.awt.Paint) color2);
        java.lang.Object obj4 = categoryMarker1.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = categoryMarker1.getLabelOffsetType();
        java.awt.Color color6 = java.awt.Color.yellow;
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) seriesRenderingOrder7);
        java.lang.String str9 = chartChangeEvent8.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent8.setType(chartChangeEventType10);
        boolean boolean12 = color6.equals((java.lang.Object) chartChangeEvent8);
        categoryMarker1.setOutlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]" + "'", str9.equals("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]"));
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot0.getDataset();
        boolean boolean12 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer14, true);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = categoryPlot0.getDataset();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 106.0d, dataset21);
        categoryPlot0.datasetChanged(datasetChangeEvent22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryDataset19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(0, categoryDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        double double31 = xYPlot28.getRangeCrosshairValue();
        java.awt.Paint paint32 = xYPlot28.getRangeCrosshairPaint();
        xYPlot28.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D35 = xYPlot28.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D35, false);
        java.lang.String str38 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Category Plot" + "'", str38.equals("Category Plot"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        xYPlot25.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset35 = xYPlot25.getDataset();
        boolean boolean36 = xYPlot25.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot25.getDomainAxisEdge((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, true);
        java.awt.Color color8 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean10 = color8.equals((java.lang.Object) textAnchor9);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        java.awt.Color color9 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean11 = color9.equals((java.lang.Object) textAnchor10);
        categoryAxis1.setLabelPaint((java.awt.Paint) color9);
        double double13 = categoryAxis1.getUpperMargin();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        boolean boolean21 = dateAxis19.isVerticalTickLabels();
        dateAxis19.setTickMarkOutsideLength((float) 10);
        boolean boolean24 = dateAxis19.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isPositiveArrowVisible();
        dateAxis25.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        double double33 = dateAxis32.getLabelAngle();
        boolean boolean34 = dateAxis32.isVerticalTickLabels();
        dateAxis32.setTickMarkOutsideLength((float) 10);
        boolean boolean37 = dateAxis32.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        boolean boolean39 = dateAxis38.isPositiveArrowVisible();
        dateAxis38.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer42);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder44 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot43.setDatasetRenderingOrder(datasetRenderingOrder44);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier46 = xYPlot43.getDrawingSupplier();
        dateAxis19.setPlot((org.jfree.chart.plot.Plot) xYPlot43);
        java.awt.Stroke stroke48 = xYPlot43.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot43.getDomainAxisLocation();
        int int50 = xYPlot43.getBackgroundImageAlignment();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        boolean boolean52 = dateAxis51.isPositiveArrowVisible();
        java.awt.Stroke stroke53 = dateAxis51.getTickMarkStroke();
        double double54 = dateAxis51.getUpperMargin();
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis51.setTickMarkStroke(stroke55);
        xYPlot43.setDomainZeroBaselineStroke(stroke55);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = xYPlot43.getRangeAxisEdge(9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        try {
            org.jfree.chart.axis.AxisState axisState61 = categoryAxis1.draw(graphics2D14, 9.223372036854776E18d, rectangle2D16, rectangle2D17, rectangleEdge59, plotRenderingInfo60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder44);
        org.junit.Assert.assertNotNull(drawingSupplier46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 15 + "'", int50 == 15);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(rectangleEdge59);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        double double16 = dateAxis15.getLabelAngle();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        dateAxis15.setTickMarkOutsideLength((float) 10);
        boolean boolean20 = dateAxis15.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
        dateAxis21.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot26.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean29 = xYPlot26.isRangeCrosshairVisible();
        xYPlot26.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo13, point2D32);
        categoryPlot0.setRangeCrosshairVisible(false);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(point2D32);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabel("13-June-2019");
        org.jfree.data.RangeType rangeType3 = numberAxis0.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit4, true, false);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getLabelAngle();
        boolean boolean15 = dateAxis13.isVerticalTickLabels();
        dateAxis13.setTickMarkOutsideLength((float) 10);
        boolean boolean18 = dateAxis13.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        dateAxis19.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot24.setDomainAxisLocation(axisLocation25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        double double29 = dateAxis28.getLabelAngle();
        boolean boolean30 = dateAxis28.isVerticalTickLabels();
        dateAxis28.setTickMarkOutsideLength((float) 10);
        boolean boolean33 = dateAxis28.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isPositiveArrowVisible();
        dateAxis34.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer38);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        xYPlot39.markerChanged(markerChangeEvent40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot39.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation43 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot39.setOrientation(plotOrientation43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation25, plotOrientation43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        try {
            org.jfree.chart.axis.AxisState axisState47 = numberAxis0.draw(graphics2D8, (double) '4', rectangle2D10, rectangle2D11, rectangleEdge45, plotRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plotOrientation43);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.setAnchorValue((double) 10.0f, true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot0.getRendererForDataset(categoryDataset14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        xYPlot12.setNoDataMessage("ChartChangeEventType.GENERAL");
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection20 = xYPlot12.getDomainMarkers(layer19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = xYPlot12.getInsets();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Paint paint15 = xYPlot12.getDomainZeroBaselinePaint();
        java.awt.Paint paint16 = xYPlot12.getDomainCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot12.getDataset(6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(xYDataset18);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        xYPlot12.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D18 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        float float21 = dateAxis19.getTickMarkInsideLength();
        int int22 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = xYPlot12.getInsets();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        double double26 = dateAxis25.getLabelAngle();
        boolean boolean27 = dateAxis25.isVerticalTickLabels();
        dateAxis25.setTickMarkOutsideLength((float) 10);
        boolean boolean30 = dateAxis25.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        boolean boolean32 = dateAxis31.isPositiveArrowVisible();
        dateAxis31.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot36.setDatasetRenderingOrder(datasetRenderingOrder37);
        boolean boolean39 = xYPlot36.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = xYPlot36.getOrientation();
        boolean boolean42 = plotOrientation40.equals((java.lang.Object) (short) 1);
        xYPlot12.setOrientation(plotOrientation40);
        xYPlot12.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) "DatasetRenderingOrder.REVERSE");
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLabelAngle();
        boolean boolean6 = dateAxis4.isVerticalTickLabels();
        dateAxis4.setTickMarkOutsideLength((float) 10);
        boolean boolean9 = dateAxis4.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isPositiveArrowVisible();
        dateAxis10.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer14);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot15.setDatasetRenderingOrder(datasetRenderingOrder16);
        java.awt.Paint paint18 = xYPlot15.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot15.getDomainAxisEdge((-515));
        boolean boolean21 = categoryAnchor0.equals((java.lang.Object) xYPlot15);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean16 = numberAxis15.getAutoRangeIncludesZero();
        numberAxis15.setAutoRangeStickyZero(true);
        numberAxis15.setAutoRangeIncludesZero(true);
        categoryPlot12.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis15, true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot12.setDataset(0, categoryDataset24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        double double30 = dateAxis29.getLabelAngle();
        boolean boolean31 = dateAxis29.isVerticalTickLabels();
        dateAxis29.setTickMarkOutsideLength((float) 10);
        boolean boolean34 = dateAxis29.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        boolean boolean36 = dateAxis35.isPositiveArrowVisible();
        dateAxis35.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer39);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot40.setDatasetRenderingOrder(datasetRenderingOrder41);
        double double43 = xYPlot40.getRangeCrosshairValue();
        java.awt.Paint paint44 = xYPlot40.getRangeCrosshairPaint();
        xYPlot40.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D47 = xYPlot40.getQuadrantOrigin();
        categoryPlot12.zoomDomainAxes((double) (byte) 10, plotRenderingInfo27, point2D47, false);
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo11, point2D47);
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis0.getMarkerBand();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(markerAxisBand4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        double double16 = dateAxis15.getLabelAngle();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        dateAxis15.setTickMarkOutsideLength((float) 10);
        boolean boolean20 = dateAxis15.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
        dateAxis21.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot26.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean29 = xYPlot26.isRangeCrosshairVisible();
        xYPlot26.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo13, point2D32);
        categoryPlot0.setRangeCrosshairVisible(false);
        categoryPlot0.clearRangeAxes();
        java.awt.Color color38 = java.awt.Color.WHITE;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        boolean boolean40 = dateAxis39.isPositiveArrowVisible();
        java.awt.Stroke stroke41 = dateAxis39.getTickMarkStroke();
        java.awt.Color color42 = java.awt.Color.BLUE;
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        boolean boolean46 = dateAxis45.isPositiveArrowVisible();
        java.awt.Stroke stroke47 = dateAxis45.getTickMarkStroke();
        double double48 = dateAxis45.getUpperMargin();
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis45.setTickMarkStroke(stroke49);
        categoryMarker44.setOutlineStroke(stroke49);
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color38, stroke41, (java.awt.Paint) color42, stroke49, (float) (short) 1);
        int int54 = color42.getGreen();
        java.awt.Color color55 = color42.brighter();
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(color55);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        xYPlot25.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset35 = xYPlot25.getDataset();
        boolean boolean36 = xYPlot25.isDomainCrosshairLockedOnData();
        xYPlot25.mapDatasetToRangeAxis(4, 12);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        xYPlot25.setDataset(0, xYDataset41);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        xYPlot21.setDomainZeroBaselineVisible(false);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.util.List list28 = null;
        xYPlot21.drawDomainTickBands(graphics2D26, rectangle2D27, list28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = xYPlot21.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier30);
        categoryPlot0.mapDatasetToRangeAxis((int) '#', 1);
        java.lang.Object obj35 = categoryPlot0.clone();
        boolean boolean36 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.Marker marker28 = null;
        try {
            boolean boolean29 = categoryPlot0.removeRangeMarker(marker28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color34 = java.awt.Color.lightGray;
        categoryMarker33.setLabelPaint((java.awt.Paint) color34);
        boolean boolean36 = categoryMarker33.getDrawAsLine();
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = xYPlot25.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker33, layer37);
        xYPlot25.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        java.lang.Object obj4 = objectList0.get((-8355712));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(axisLocation13);
        int int15 = xYPlot12.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis17.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color20 = java.awt.Color.cyan;
        categoryAxis17.setTickLabelPaint((java.awt.Paint) color20);
        double double22 = categoryAxis17.getLowerMargin();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        double double25 = dateAxis24.getLabelAngle();
        boolean boolean26 = dateAxis24.isVerticalTickLabels();
        dateAxis24.setTickMarkOutsideLength((float) 10);
        boolean boolean29 = dateAxis24.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        boolean boolean31 = dateAxis30.isPositiveArrowVisible();
        dateAxis30.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot35.setDatasetRenderingOrder(datasetRenderingOrder36);
        boolean boolean38 = xYPlot35.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = xYPlot35.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        boolean boolean43 = dateAxis42.isPositiveArrowVisible();
        java.awt.Stroke stroke44 = dateAxis42.getTickMarkStroke();
        double double45 = dateAxis42.getUpperMargin();
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis42.setTickMarkStroke(stroke46);
        categoryMarker41.setOutlineStroke(stroke46);
        org.jfree.chart.util.Layer layer49 = null;
        xYPlot35.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker41, layer49);
        boolean boolean51 = categoryAxis17.equals((java.lang.Object) xYPlot35);
        java.awt.Font font53 = categoryAxis17.getTickLabelFont((java.lang.Comparable) 10.0d);
        xYPlot12.setNoDataMessageFont(font53);
        float float55 = xYPlot12.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 1.0f + "'", float55 == 1.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.setBackgroundAlpha((float) '#');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        xYPlot12.axisChanged(axisChangeEvent17);
        xYPlot12.zoom((double) 12);
        boolean boolean21 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        double double24 = dateAxis23.getLabelAngle();
        boolean boolean25 = dateAxis23.isVerticalTickLabels();
        dateAxis23.setTickMarkOutsideLength((float) 10);
        boolean boolean28 = dateAxis23.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isPositiveArrowVisible();
        dateAxis29.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer33);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot34.setDatasetRenderingOrder(datasetRenderingOrder35);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = xYPlot34.getDrawingSupplier();
        xYPlot34.setBackgroundImageAlpha((float) 1L);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        double double43 = dateAxis42.getLabelAngle();
        boolean boolean44 = dateAxis42.isVerticalTickLabels();
        dateAxis42.setTickMarkOutsideLength((float) 10);
        boolean boolean47 = dateAxis42.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        boolean boolean49 = dateAxis48.isPositiveArrowVisible();
        dateAxis48.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis48, xYItemRenderer52);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot53.setDomainAxisLocation(axisLocation54);
        xYPlot34.setRangeAxisLocation(11, axisLocation54, true);
        xYPlot12.setRangeAxisLocation(axisLocation54, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
        org.junit.Assert.assertNotNull(drawingSupplier37);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean16 = numberAxis15.getAutoRangeIncludesZero();
        numberAxis15.setAutoRangeStickyZero(true);
        numberAxis15.setAutoRangeIncludesZero(true);
        categoryPlot12.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis15, true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot12.setDataset(0, categoryDataset24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        double double30 = dateAxis29.getLabelAngle();
        boolean boolean31 = dateAxis29.isVerticalTickLabels();
        dateAxis29.setTickMarkOutsideLength((float) 10);
        boolean boolean34 = dateAxis29.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        boolean boolean36 = dateAxis35.isPositiveArrowVisible();
        dateAxis35.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer39);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot40.setDatasetRenderingOrder(datasetRenderingOrder41);
        double double43 = xYPlot40.getRangeCrosshairValue();
        java.awt.Paint paint44 = xYPlot40.getRangeCrosshairPaint();
        xYPlot40.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D47 = xYPlot40.getQuadrantOrigin();
        categoryPlot12.zoomDomainAxes((double) (byte) 10, plotRenderingInfo27, point2D47, false);
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo11, point2D47);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = categoryPlot0.getOrientation();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertNotNull(plotOrientation51);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot0.getDataset();
        boolean boolean12 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer((int) (short) 0, categoryItemRenderer14, false);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot0.getRenderer();
        java.awt.Image image19 = categoryPlot0.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryItemRenderer18);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        java.awt.Paint paint14 = xYPlot12.getNoDataMessagePaint();
        java.awt.Paint paint15 = xYPlot12.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        xYPlot12.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((-6.0d), (double) 10.0f);
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str24 = chartChangeEventType23.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) intervalMarker21, jFreeChart22, chartChangeEventType23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker21.setLabelAnchor(rectangleAnchor26);
        intervalMarker21.setLabel("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]");
        xYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        xYPlot12.setRenderer(2, xYItemRenderer32, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str24.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(rectangleAnchor26);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.trimHeight(0.0d);
        double double4 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-6.0d) + "'", double3 == (-6.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        double double1 = categoryPlot0.getAnchorValue();
//        java.awt.Color color3 = java.awt.Color.WHITE;
//        java.awt.Color color4 = java.awt.Color.getColor("", color3);
//        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
//        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
//        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
//        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
//        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
//        org.jfree.data.xy.XYDataset xYDataset14 = null;
//        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
//        double double16 = dateAxis15.getLabelAngle();
//        boolean boolean17 = dateAxis15.isVerticalTickLabels();
//        dateAxis15.setTickMarkOutsideLength((float) 10);
//        boolean boolean20 = dateAxis15.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
//        dateAxis21.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
//        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer25);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        xYPlot26.setDatasetRenderingOrder(datasetRenderingOrder27);
//        boolean boolean29 = xYPlot26.isRangeCrosshairVisible();
//        xYPlot26.setRangeCrosshairLockedOnData(true);
//        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
//        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo13, point2D32);
//        java.awt.Color color35 = java.awt.Color.BLUE;
//        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot36.clearDomainMarkers();
//        categoryPlot36.setDrawSharedDomainAxis(false);
//        java.awt.Stroke stroke40 = categoryPlot36.getDomainGridlineStroke();
//        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true, (java.awt.Paint) color35, stroke40);
//        categoryPlot0.setRangeGridlineStroke(stroke40);
//        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        boolean boolean49 = day46.equals((java.lang.Object) day48);
//        java.lang.String str50 = categoryAxis45.getCategoryLabelToolTip((java.lang.Comparable) day46);
//        int int51 = categoryAxis45.getMaximumCategoryLabelLines();
//        categoryAxis45.configure();
//        categoryPlot0.setDomainAxis(100, categoryAxis45, false);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertNull(valueAxis6);
//        org.junit.Assert.assertNotNull(rectangleEdge8);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(point2D32);
//        org.junit.Assert.assertNotNull(color35);
//        org.junit.Assert.assertNotNull(stroke40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNull(str50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        java.awt.Color color15 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean17 = color15.equals((java.lang.Object) textAnchor16);
        dateAxis7.setAxisLinePaint((java.awt.Paint) color15);
        double double19 = dateAxis7.getLabelAngle();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        double double22 = dateAxis21.getLabelAngle();
        boolean boolean23 = dateAxis21.isVerticalTickLabels();
        dateAxis21.setTickMarkOutsideLength((float) 10);
        boolean boolean26 = dateAxis21.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = dateAxis27.isPositiveArrowVisible();
        dateAxis27.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot32.setDatasetRenderingOrder(datasetRenderingOrder33);
        java.awt.Color color35 = java.awt.Color.cyan;
        xYPlot32.setNoDataMessagePaint((java.awt.Paint) color35);
        dateAxis7.setPlot((org.jfree.chart.plot.Plot) xYPlot32);
        java.awt.Color color39 = java.awt.Color.BLUE;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot40.clearDomainMarkers();
        categoryPlot40.setDrawSharedDomainAxis(false);
        java.awt.Stroke stroke44 = categoryPlot40.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true, (java.awt.Paint) color39, stroke44);
        xYPlot32.setRangeZeroBaselinePaint((java.awt.Paint) color39);
        java.awt.Color color47 = java.awt.Color.WHITE;
        int int48 = color47.getBlue();
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray50 = null;
        float[] floatArray51 = color49.getRGBComponents(floatArray50);
        float[] floatArray52 = color47.getColorComponents(floatArray50);
        float[] floatArray53 = color39.getRGBComponents(floatArray50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 255 + "'", int48 == 255);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, 0.0d, 0.0d, 0.05d, (double) 3);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis10.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color13 = java.awt.Color.cyan;
        categoryAxis10.setTickLabelPaint((java.awt.Paint) color13);
        categoryAxis10.setLowerMargin((double) 1.0f);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        double double32 = dateAxis31.getLabelAngle();
        boolean boolean33 = dateAxis31.isVerticalTickLabels();
        dateAxis31.setTickMarkOutsideLength((float) 10);
        boolean boolean36 = dateAxis31.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis37.isPositiveArrowVisible();
        dateAxis37.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer41);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder43 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot42.setDatasetRenderingOrder(datasetRenderingOrder43);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = xYPlot42.getDrawingSupplier();
        dateAxis18.setPlot((org.jfree.chart.plot.Plot) xYPlot42);
        java.awt.Stroke stroke47 = xYPlot42.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot42.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        xYPlot42.setRangeAxis(valueAxis49);
        org.jfree.chart.LegendItemCollection legendItemCollection51 = xYPlot42.getFixedLegendItems();
        categoryAxis10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot42);
        categoryAxis10.clearCategoryLabelToolTips();
        boolean boolean54 = unitType3.equals((java.lang.Object) categoryAxis10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder43);
        org.junit.Assert.assertNotNull(drawingSupplier45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNull(legendItemCollection51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        double double2 = dateAxis0.getLabelAngle();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLabelAngle();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLabelAngle();
        dateAxis5.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Stroke stroke11 = dateAxis9.getTickMarkStroke();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis9.setTickMarkStroke(stroke12);
        org.jfree.data.Range range14 = dateAxis9.getRange();
        dateAxis5.setDefaultAutoRange(range14);
        dateAxis3.setRange(range14, false, false);
        dateAxis0.setDefaultAutoRange(range14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLabelAngle();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis3.getTimeline();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        boolean boolean9 = categoryPlot8.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat2 = null;
        numberAxis0.setNumberFormatOverride(numberFormat2);
        java.awt.Paint paint4 = numberAxis0.getTickLabelPaint();
        java.lang.Object obj5 = numberAxis0.clone();
        org.jfree.data.Range range6 = numberAxis0.getRange();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getLabelAngle();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        dateAxis11.setTickMarkOutsideLength((float) 10);
        boolean boolean16 = dateAxis11.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isPositiveArrowVisible();
        dateAxis17.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot22.setDomainAxisLocation(axisLocation23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getLabelAngle();
        boolean boolean28 = dateAxis26.isVerticalTickLabels();
        dateAxis26.setTickMarkOutsideLength((float) 10);
        boolean boolean31 = dateAxis26.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isPositiveArrowVisible();
        dateAxis32.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer36);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        xYPlot37.markerChanged(markerChangeEvent38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot37.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot37.setOrientation(plotOrientation41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation23, plotOrientation41);
        try {
            java.util.List list44 = numberAxis0.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        xYPlot12.setNoDataMessage("ChartChangeEventType.GENERAL");
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.CrosshairState crosshairState23 = null;
        boolean boolean24 = xYPlot12.render(graphics2D19, rectangle2D20, (-1), plotRenderingInfo22, crosshairState23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = xYPlot12.getDatasetRenderingOrder();
        java.awt.Paint paint15 = xYPlot12.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        categoryMarker17.setDrawAsLine(false);
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryMarker17, jFreeChart20, chartChangeEventType21);
        xYPlot12.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker17);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryMarker17.notifyListeners(markerChangeEvent24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis0.removeChangeListener(axisChangeListener2);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis0.lengthToJava2D((double) 6, rectangle2D5, rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        xYPlot21.setDomainZeroBaselineVisible(false);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.util.List list28 = null;
        xYPlot21.drawDomainTickBands(graphics2D26, rectangle2D27, list28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = xYPlot21.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier30);
        categoryPlot0.mapDatasetToRangeAxis((int) '#', 1);
        java.lang.Object obj35 = categoryPlot0.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer37);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace13, true);
        float float16 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabel("13-June-2019");
        org.jfree.data.RangeType rangeType3 = numberAxis0.getRangeType();
        double double4 = numberAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets1.getLeft();
        double double4 = rectangleInsets1.calculateTopOutset((double) 100L);
        boolean boolean5 = textAnchor0.equals((java.lang.Object) rectangleInsets1);
        double double7 = rectangleInsets1.calculateBottomOutset((double) (short) 1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        xYPlot12.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D18 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        float float21 = dateAxis19.getTickMarkInsideLength();
        int int22 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = xYPlot12.getInsets();
        xYPlot12.setNoDataMessage("hi!");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color2 = java.awt.Color.lightGray;
        categoryMarker1.setLabelPaint((java.awt.Paint) color2);
        java.lang.Object obj4 = categoryMarker1.clone();
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryMarker1.getLabelTextAnchor();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker1.setPaint((java.awt.Paint) color6);
        boolean boolean8 = categoryMarker1.getDrawAsLine();
        java.awt.Stroke stroke9 = categoryMarker1.getStroke();
        java.awt.Paint paint10 = categoryMarker1.getOutlinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.util.Date date3 = dateAxis0.getMinimumDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28799999L + "'", long5 == 28799999L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets14.createInsetRectangle(rectangle2D15, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        java.awt.Color color9 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean11 = color9.equals((java.lang.Object) textAnchor10);
        categoryAxis1.setLabelPaint((java.awt.Paint) color9);
        double double13 = categoryAxis1.getLabelAngle();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        int int15 = day14.getMonth();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) day14, "SortOrder.DESCENDING");
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLabelAngle();
        boolean boolean4 = dateAxis2.isVerticalTickLabels();
        dateAxis2.setTickMarkOutsideLength((float) 10);
        boolean boolean7 = dateAxis2.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isPositiveArrowVisible();
        dateAxis8.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        boolean boolean16 = xYPlot13.isRangeCrosshairVisible();
        xYPlot13.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D19 = xYPlot13.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        double double21 = dateAxis20.getLabelAngle();
        float float22 = dateAxis20.getTickMarkInsideLength();
        int int23 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
        boolean boolean24 = rectangleAnchor0.equals((java.lang.Object) int23);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
        dateAxis0.setLowerMargin((double) 7);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis0.setTickUnit(dateTickUnit7);
        dateAxis0.setLowerBound((double) 9);
        org.jfree.chart.plot.Plot plot11 = dateAxis0.getPlot();
        java.lang.String str12 = dateAxis0.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 3, (float) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1783) + "'", int3 == (-1783));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Stroke stroke4 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        double double6 = categoryPlot5.getAnchorValue();
        java.awt.Color color8 = java.awt.Color.WHITE;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        categoryPlot5.setDomainGridlinePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot5.getRangeAxis();
        java.util.List list12 = categoryPlot5.getCategories();
        categoryPlot5.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot5.setDomainAxis(100, categoryAxis16);
        categoryPlot0.setDomainAxis(categoryAxis16);
        categoryAxis16.setCategoryMargin((double) (short) 1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(list12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis0.removeChangeListener(axisChangeListener2);
        numberAxis0.setPositiveArrowVisible(false);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        double double10 = dateAxis9.getLabelAngle();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        dateAxis9.setTickMarkOutsideLength((float) 10);
        boolean boolean14 = dateAxis9.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isPositiveArrowVisible();
        dateAxis15.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot20.setDatasetRenderingOrder(datasetRenderingOrder21);
        double double23 = xYPlot20.getRangeCrosshairValue();
        java.awt.Paint paint24 = xYPlot20.getRangeCrosshairPaint();
        xYPlot20.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        int int28 = xYPlot20.indexOf(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot20.getRangeAxisEdge();
        try {
            double double30 = numberAxis0.valueToJava2D((-1.0d), rectangle2D7, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = java.awt.Color.cyan;
        xYPlot12.setNoDataMessagePaint((java.awt.Paint) color15);
        int int17 = color15.getRGB();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-16711681) + "'", int17 == (-16711681));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(0, categoryDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        double double31 = xYPlot28.getRangeCrosshairValue();
        java.awt.Paint paint32 = xYPlot28.getRangeCrosshairPaint();
        xYPlot28.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D35 = xYPlot28.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D35, false);
        int int38 = categoryPlot0.getRangeAxisCount();
        java.util.List list39 = categoryPlot0.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot0.setRenderer(categoryItemRenderer40, false);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNull(list39);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot29.setDomainAxisLocation(axisLocation30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        double double34 = dateAxis33.getLabelAngle();
        boolean boolean35 = dateAxis33.isVerticalTickLabels();
        dateAxis33.setTickMarkOutsideLength((float) 10);
        boolean boolean38 = dateAxis33.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        boolean boolean40 = dateAxis39.isPositiveArrowVisible();
        dateAxis39.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis39, xYItemRenderer43);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent45 = null;
        xYPlot44.markerChanged(markerChangeEvent45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = xYPlot44.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot44.setOrientation(plotOrientation48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation30, plotOrientation48);
        org.jfree.chart.axis.AxisLocation axisLocation51 = axisLocation30.getOpposite();
        xYPlot12.setDomainAxisLocation((int) (byte) 10, axisLocation51, true);
        java.awt.Paint paint54 = xYPlot12.getRangeZeroBaselinePaint();
        java.awt.Paint paint55 = xYPlot12.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(paint55);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        int int4 = day0.getYear();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        dateAxis0.setAutoTickUnitSelection(true);
        boolean boolean5 = dateAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot0.getDataset();
        boolean boolean12 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer14, true);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = categoryPlot0.getDataset();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 106.0d, dataset21);
        categoryPlot0.datasetChanged(datasetChangeEvent22);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent24);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryDataset19);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color2 = java.awt.Color.lightGray;
        categoryMarker1.setLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = categoryMarker1.getDrawAsLine();
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryMarker1.getLabelTextAnchor();
        float float6 = categoryMarker1.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = xYPlot12.getDatasetRenderingOrder();
        java.awt.Paint paint15 = xYPlot12.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        categoryMarker17.setDrawAsLine(false);
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryMarker17, jFreeChart20, chartChangeEventType21);
        xYPlot12.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker17);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        double double26 = dateAxis25.getLabelAngle();
        dateAxis25.setNegativeArrowVisible(false);
        java.awt.Color color31 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean33 = color31.equals((java.lang.Object) textAnchor32);
        dateAxis25.setLabelPaint((java.awt.Paint) color31);
        java.awt.Paint paint35 = dateAxis25.getLabelPaint();
        try {
            xYPlot12.setQuadrantPaint(10, paint35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange((double) 255, (-12.0d));
        dateAxis0.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLabelAngle();
        boolean boolean9 = dateAxis7.isVerticalTickLabels();
        dateAxis7.setTickMarkOutsideLength((float) 10);
        boolean boolean12 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        dateAxis13.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot18.setDomainAxisLocation(axisLocation19);
        boolean boolean21 = dateAxis0.hasListener((java.util.EventListener) xYPlot18);
        float float22 = xYPlot18.getForegroundAlpha();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = xYPlot18.getRenderer();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNull(xYItemRenderer23);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        java.util.List list11 = categoryPlot0.getCategories();
        categoryPlot0.clearRangeAxes();
        java.awt.Paint paint13 = categoryPlot0.getBackgroundPaint();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        double double33 = dateAxis32.getLabelAngle();
        boolean boolean34 = dateAxis32.isVerticalTickLabels();
        dateAxis32.setTickMarkOutsideLength((float) 10);
        boolean boolean37 = dateAxis32.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        boolean boolean39 = dateAxis38.isPositiveArrowVisible();
        dateAxis38.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer42);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder44 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot43.setDatasetRenderingOrder(datasetRenderingOrder44);
        double double46 = xYPlot43.getRangeCrosshairValue();
        java.awt.Paint paint47 = xYPlot43.getRangeCrosshairPaint();
        xYPlot43.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D50 = xYPlot43.getQuadrantOrigin();
        xYPlot28.setQuadrantOrigin(point2D50);
        org.jfree.chart.plot.PlotState plotState52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        try {
            categoryPlot0.draw(graphics2D14, rectangle2D15, point2D50, plotState52, plotRenderingInfo53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(list11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(point2D50);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        java.awt.Paint paint3 = dateAxis0.getAxisLinePaint();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setDefaultAutoRange(range4);
        java.util.Date date6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        double double9 = categoryPlot8.getAnchorValue();
        int int10 = categoryPlot8.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot8.getDomainAxisEdge((int) (short) 10);
        try {
            double double13 = dateAxis0.dateToJava2D(date6, rectangle2D7, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer(categoryItemRenderer14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke16);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        java.awt.Stroke stroke18 = xYPlot12.getRangeCrosshairStroke();
        java.awt.Paint paint19 = xYPlot12.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        xYPlot12.setDomainAxis(valueAxis20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setLabel("13-June-2019");
        org.jfree.data.RangeType rangeType6 = numberAxis3.getRangeType();
        numberAxis0.setRangeType(rangeType6);
        try {
            numberAxis0.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rangeType6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabel("13-June-2019");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis0.getTickUnit();
        java.text.NumberFormat numberFormat4 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis0, jFreeChart1);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean11 = numberAxis10.getAutoRangeIncludesZero();
        numberAxis10.setAutoRangeStickyZero(true);
        numberAxis10.setAutoRangeIncludesZero(true);
        categoryPlot7.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis10, true);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot7.setFixedDomainAxisSpace(axisSpace18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot7.getDomainAxisEdge((int) (short) 0);
        try {
            double double22 = numberAxis0.lengthToJava2D((double) (short) 1, rectangle2D6, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        java.awt.Stroke stroke18 = xYPlot12.getRangeCrosshairStroke();
        java.awt.Paint paint19 = xYPlot12.getRangeZeroBaselinePaint();
        java.lang.Object obj20 = null;
        boolean boolean21 = xYPlot12.equals(obj20);
        xYPlot12.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot0.getOrientation();
        java.awt.Font font12 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateTopOutset((double) '4');
        boolean boolean16 = categoryPlot0.equals((java.lang.Object) '4');
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot0.getDomainAxisLocation((int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        try {
            int int20 = categoryPlot0.getRangeAxisIndex(valueAxis19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double3 = rectangleInsets1.calculateBottomInset((double) 1.0f);
        boolean boolean4 = datasetRenderingOrder0.equals((java.lang.Object) rectangleInsets1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isPositiveArrowVisible();
        dateAxis5.setAutoRange(false);
        dateAxis5.resizeRange(0.0d, (double) 10);
        dateAxis5.setInverted(true);
        boolean boolean14 = datasetRenderingOrder0.equals((java.lang.Object) dateAxis5);
        java.lang.Object obj15 = dateAxis5.clone();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        boolean boolean16 = xYPlot12.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        boolean boolean19 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = xYPlot12.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        double double24 = dateAxis23.getLabelAngle();
        boolean boolean25 = dateAxis23.isVerticalTickLabels();
        dateAxis23.setTickMarkOutsideLength((float) 10);
        boolean boolean28 = dateAxis23.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isPositiveArrowVisible();
        dateAxis29.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer33);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot34.setDatasetRenderingOrder(datasetRenderingOrder35);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = xYPlot34.getDrawingSupplier();
        xYPlot34.setBackgroundImageAlpha((float) 1L);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        double double43 = dateAxis42.getLabelAngle();
        boolean boolean44 = dateAxis42.isVerticalTickLabels();
        dateAxis42.setTickMarkOutsideLength((float) 10);
        boolean boolean47 = dateAxis42.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        boolean boolean49 = dateAxis48.isPositiveArrowVisible();
        dateAxis48.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis48, xYItemRenderer52);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot53.setDomainAxisLocation(axisLocation54);
        xYPlot34.setRangeAxisLocation(11, axisLocation54, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker59 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color60 = java.awt.Color.lightGray;
        categoryMarker59.setLabelPaint((java.awt.Paint) color60);
        java.lang.Object obj62 = categoryMarker59.clone();
        org.jfree.chart.text.TextAnchor textAnchor63 = categoryMarker59.getLabelTextAnchor();
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker59.setPaint((java.awt.Paint) color64);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker59.setLabelOffsetType(lengthAdjustmentType66);
        boolean boolean68 = axisLocation54.equals((java.lang.Object) lengthAdjustmentType66);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType69 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str70 = lengthAdjustmentType69.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D71 = rectangleInsets20.createAdjustedRectangle(rectangle2D21, lengthAdjustmentType66, lengthAdjustmentType69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
        org.junit.Assert.assertNotNull(drawingSupplier37);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertNotNull(textAnchor63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(lengthAdjustmentType66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "CONTRACT" + "'", str70.equals("CONTRACT"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        xYPlot12.clearDomainMarkers();
        xYPlot12.clearRangeMarkers(0);
        xYPlot12.configureDomainAxes();
        java.awt.Paint paint17 = xYPlot12.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot12.setFixedRangeAxisSpace(axisSpace18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setAutoRange(false);
        dateAxis0.resizeRange(0.0d, (double) 10);
        java.util.Date date7 = dateAxis0.getMinimumDate();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLabelAngle();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        dateAxis12.setTickMarkOutsideLength((float) 10);
        boolean boolean17 = dateAxis12.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isPositiveArrowVisible();
        dateAxis18.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot23.setDatasetRenderingOrder(datasetRenderingOrder24);
        java.awt.Color color26 = java.awt.Color.cyan;
        xYPlot23.setNoDataMessagePaint((java.awt.Paint) color26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot23.getDomainAxisEdge();
        org.jfree.data.general.Dataset dataset29 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleEdge28, dataset29);
        try {
            java.util.List list31 = dateAxis0.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot0.setDomainAxisLocation((int) '4', axisLocation13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot0.getRangeAxis(1);
        java.awt.Paint paint17 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateTopOutset((double) 100L);
        double double5 = rectangleInsets0.extendWidth((double) 100.0f);
        java.lang.String str6 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 106.0d + "'", double5 == 106.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str6.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis0.setTickMarkStroke(stroke4);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        double double8 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.plot.Plot plot9 = dateAxis0.getPlot();
        boolean boolean10 = dateAxis0.isInverted();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone11);
        dateAxis0.setTimeZone(timeZone11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.resizeRange((double) 255, (-12.0d));
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline19 = null;
        dateAxis18.setTimeline(timeline19);
        java.util.Date date21 = dateAxis18.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
        java.awt.Stroke stroke24 = dateAxis22.getTickMarkStroke();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis22.setTickMarkStroke(stroke25);
        org.jfree.data.Range range27 = dateAxis22.getRange();
        dateAxis18.setRangeWithMargins(range27, false, true);
        dateAxis14.setRange(range27);
        dateAxis0.setRangeWithMargins(range27, true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(tickUnitSource12);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        int int32 = xYPlot25.getBackgroundImageAlignment();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis33.isPositiveArrowVisible();
        java.awt.Stroke stroke35 = dateAxis33.getTickMarkStroke();
        double double36 = dateAxis33.getUpperMargin();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis33.setTickMarkStroke(stroke37);
        xYPlot25.setDomainZeroBaselineStroke(stroke37);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot25.getRangeAxisEdge(9);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        org.jfree.chart.plot.CrosshairState crosshairState46 = null;
        boolean boolean47 = xYPlot25.render(graphics2D42, rectangle2D43, 3, plotRenderingInfo45, crosshairState46);
        xYPlot25.clearDomainMarkers((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(axisLocation13);
        int int15 = xYPlot12.getWeight();
        int int16 = xYPlot12.getDomainAxisCount();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot29.setDatasetRenderingOrder(datasetRenderingOrder30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot29.setDomainGridlinePaint((java.awt.Paint) color32);
        int int34 = color32.getRed();
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray36 = null;
        float[] floatArray37 = color35.getRGBComponents(floatArray36);
        float[] floatArray38 = color32.getComponents(floatArray36);
        xYPlot12.setBackgroundPaint((java.awt.Paint) color32);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        xYPlot12.drawAnnotations(graphics2D40, rectangle2D41, plotRenderingInfo42);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat3 = null;
        numberAxis1.setNumberFormatOverride(numberFormat3);
        java.awt.Paint paint5 = numberAxis1.getTickLabelPaint();
        java.lang.Object obj6 = numberAxis1.clone();
        org.jfree.data.Range range7 = numberAxis1.getRange();
        boolean boolean8 = categoryAnchor0.equals((java.lang.Object) numberAxis1);
        numberAxis1.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent28 = null;
        categoryPlot0.axisChanged(axisChangeEvent28);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        intervalMarker2.setPaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot17.setDomainAxisLocation(axisLocation18);
        int int20 = xYPlot17.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis22.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color25 = java.awt.Color.cyan;
        categoryAxis22.setTickLabelPaint((java.awt.Paint) color25);
        double double27 = categoryAxis22.getLowerMargin();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        double double30 = dateAxis29.getLabelAngle();
        boolean boolean31 = dateAxis29.isVerticalTickLabels();
        dateAxis29.setTickMarkOutsideLength((float) 10);
        boolean boolean34 = dateAxis29.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        boolean boolean36 = dateAxis35.isPositiveArrowVisible();
        dateAxis35.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer39);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot40.setDatasetRenderingOrder(datasetRenderingOrder41);
        boolean boolean43 = xYPlot40.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = xYPlot40.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        boolean boolean48 = dateAxis47.isPositiveArrowVisible();
        java.awt.Stroke stroke49 = dateAxis47.getTickMarkStroke();
        double double50 = dateAxis47.getUpperMargin();
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis47.setTickMarkStroke(stroke51);
        categoryMarker46.setOutlineStroke(stroke51);
        org.jfree.chart.util.Layer layer54 = null;
        xYPlot40.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker46, layer54);
        boolean boolean56 = categoryAxis22.equals((java.lang.Object) xYPlot40);
        java.awt.Font font58 = categoryAxis22.getTickLabelFont((java.lang.Comparable) 10.0d);
        xYPlot17.setNoDataMessageFont(font58);
        intervalMarker2.setLabelFont(font58);
        java.lang.Object obj61 = intervalMarker2.clone();
        java.lang.Object obj62 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.05d + "'", double50 == 0.05d);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(obj61);
        org.junit.Assert.assertNotNull(obj62);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 0, (double) 0.0f, (-12.0d), (double) (-1.0f));
        double double7 = rectangleInsets5.extendHeight((double) 10.0f);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createOutsetRectangle(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-2.0d) + "'", double7 == (-2.0d));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace11);
        java.lang.Object obj13 = categoryPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            categoryPlot0.drawBackground(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.CENTER" + "'", str1.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color17 = java.awt.Color.lightGray;
        categoryMarker16.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLabelAngle();
        boolean boolean24 = dateAxis22.isVerticalTickLabels();
        dateAxis22.setTickMarkOutsideLength((float) 10);
        boolean boolean27 = dateAxis22.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean29 = dateAxis28.isPositiveArrowVisible();
        dateAxis28.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        double double36 = dateAxis35.getLabelAngle();
        boolean boolean37 = dateAxis35.isVerticalTickLabels();
        dateAxis35.setTickMarkOutsideLength((float) 10);
        boolean boolean40 = dateAxis35.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        boolean boolean42 = dateAxis41.isPositiveArrowVisible();
        dateAxis41.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis41, xYItemRenderer45);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder47 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot46.setDatasetRenderingOrder(datasetRenderingOrder47);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier49 = xYPlot46.getDrawingSupplier();
        dateAxis22.setPlot((org.jfree.chart.plot.Plot) xYPlot46);
        org.jfree.chart.LegendItemCollection legendItemCollection51 = null;
        xYPlot46.setFixedLegendItems(legendItemCollection51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot46.setRangeAxisLocation(0, axisLocation54, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray57 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot46.setDomainAxes(valueAxisArray57);
        xYPlot12.setRangeAxes(valueAxisArray57);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        int int61 = xYPlot12.getIndexOf(xYItemRenderer60);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder47);
        org.junit.Assert.assertNotNull(drawingSupplier49);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(valueAxisArray57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        dateAxis0.setTickMarkInsideLength((float) '#');
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.resizeRange((double) 255, (-12.0d));
        dateAxis6.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getLabelAngle();
        boolean boolean15 = dateAxis13.isVerticalTickLabels();
        dateAxis13.setTickMarkOutsideLength((float) 10);
        boolean boolean18 = dateAxis13.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        dateAxis19.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot24.setDomainAxisLocation(axisLocation25);
        boolean boolean27 = dateAxis6.hasListener((java.util.EventListener) xYPlot24);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot24);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isPositiveArrowVisible();
        java.awt.Stroke stroke31 = dateAxis29.getTickMarkStroke();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis29.setTickMarkStroke(stroke32);
        org.jfree.data.Range range34 = dateAxis29.getRange();
        dateAxis0.setRangeWithMargins(range34, false, false);
        dateAxis0.configure();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(range34);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color17 = java.awt.Color.lightGray;
        categoryMarker16.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryMarker16.notifyListeners(markerChangeEvent21);
        java.awt.Paint paint23 = categoryMarker16.getLabelPaint();
        java.awt.Stroke stroke24 = categoryMarker16.getStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        dateAxis1.setNegativeArrowVisible(false);
        java.awt.Color color7 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean9 = color7.equals((java.lang.Object) textAnchor8);
        dateAxis1.setLabelPaint((java.awt.Paint) color7);
        java.awt.Paint paint11 = dateAxis1.getLabelPaint();
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        java.awt.Stroke stroke18 = dateAxis16.getTickMarkStroke();
        double double19 = dateAxis16.getUpperMargin();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis16.setTickMarkStroke(stroke20);
        categoryMarker15.setOutlineStroke(stroke20);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(4.0d, paint11, stroke12, (java.awt.Paint) color13, stroke20, (float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(axisLocation13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        double double17 = dateAxis16.getLabelAngle();
        boolean boolean18 = dateAxis16.isVerticalTickLabels();
        dateAxis16.setTickMarkOutsideLength((float) 10);
        boolean boolean21 = dateAxis16.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
        dateAxis22.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer26);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        xYPlot27.markerChanged(markerChangeEvent28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot27.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot27.setOrientation(plotOrientation31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = axisLocation13.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation35 = axisLocation34.getOpposite();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis0.setNumberFormatOverride(numberFormat6);
        numberAxis0.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat10 = null;
        numberAxis0.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setLabel("13-June-2019");
        org.jfree.data.RangeType rangeType15 = numberAxis12.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit16, true, false);
        numberAxis0.setTickUnit(numberTickUnit16, false, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rangeType15);
        org.junit.Assert.assertNotNull(numberTickUnit16);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis0.setTickMarkStroke(stroke4);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        org.jfree.chart.axis.Timeline timeline8 = dateAxis0.getTimeline();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) timeline8, jFreeChart9, chartChangeEventType10);
        org.jfree.chart.JFreeChart jFreeChart12 = chartChangeEvent11.getChart();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(timeline8);
        org.junit.Assert.assertNull(jFreeChart12);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        boolean boolean3 = dateAxis0.isInverted();
        float float4 = dateAxis0.getTickMarkOutsideLength();
        dateAxis0.setVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot25.setRangeAxisLocation(0, axisLocation33, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot25.setDomainAxes(valueAxisArray36);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        double double40 = dateAxis39.getLabelAngle();
        boolean boolean41 = dateAxis39.isVerticalTickLabels();
        dateAxis39.setTickMarkOutsideLength((float) 10);
        boolean boolean44 = dateAxis39.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        boolean boolean46 = dateAxis45.isPositiveArrowVisible();
        dateAxis45.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer49);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder51 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot50.setDatasetRenderingOrder(datasetRenderingOrder51);
        double double53 = xYPlot50.getRangeCrosshairValue();
        java.awt.Paint paint54 = xYPlot50.getRangeCrosshairPaint();
        xYPlot50.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D57 = xYPlot50.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = xYPlot50.getOrientation();
        xYPlot25.setOrientation(plotOrientation58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        double double61 = categoryPlot60.getAnchorValue();
        java.awt.Color color63 = java.awt.Color.WHITE;
        java.awt.Color color64 = java.awt.Color.getColor("", color63);
        categoryPlot60.setDomainGridlinePaint((java.awt.Paint) color63);
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean67 = numberAxis66.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat68 = null;
        numberAxis66.setNumberFormatOverride(numberFormat68);
        categoryPlot60.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis66);
        categoryPlot60.mapDatasetToRangeAxis((int) (byte) 0, 0);
        java.awt.Stroke stroke74 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot60.setRangeGridlineStroke(stroke74);
        xYPlot25.setDomainZeroBaselineStroke(stroke74);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(point2D57);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setAxisLineStroke(stroke3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone5);
        dateAxis0.setStandardTickUnits(tickUnitSource6);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(tickUnitSource6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        int int3 = color1.getRed();
        java.awt.Color color4 = color1.darker();
        java.awt.Color color5 = color1.darker();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot25.getRangeAxis(3);
        java.lang.String str33 = xYPlot25.getPlotType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "XY Plot" + "'", str33.equals("XY Plot"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Stroke stroke7 = categoryAxis1.getAxisLineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        double double10 = dateAxis9.getLabelAngle();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        dateAxis9.setTickMarkOutsideLength((float) 10);
        boolean boolean14 = dateAxis9.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isPositiveArrowVisible();
        dateAxis15.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot20.setDatasetRenderingOrder(datasetRenderingOrder21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot20.setDomainGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        xYPlot20.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) numberAxis26);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis26.setTickUnit(numberTickUnit28);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) numberTickUnit28);
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(numberTickUnit28);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        dateAxis13.setAutoRange(false);
        dateAxis13.resizeRange(0.0d, (double) 10);
        org.jfree.data.Range range20 = dateAxis13.getRange();
        dateAxis13.setTickMarkOutsideLength(2.0f);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { dateAxis13 };
        categoryPlot0.setRangeAxes(valueAxisArray23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryPlot0.getAxisOffset();
        double double26 = rectangleInsets25.getLeft();
        double double27 = rectangleInsets25.getLeft();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        intervalMarker2.setPaint((java.awt.Paint) color3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer5);
        intervalMarker2.setEndValue((double) 13);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setAutoRange(false);
        dateAxis0.resizeRange(0.0d, (double) 10);
        dateAxis0.setInverted(true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Stroke stroke11 = dateAxis9.getTickMarkStroke();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis9.setTickMarkStroke(stroke12);
        org.jfree.data.Range range14 = dateAxis9.getRange();
        dateAxis0.setRange(range14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        java.awt.Stroke stroke18 = dateAxis16.getTickMarkStroke();
        double double19 = dateAxis16.getUpperMargin();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis16.setTickMarkStroke(stroke20);
        dateAxis0.setTickMarkStroke(stroke20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        double double16 = dateAxis15.getLabelAngle();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        dateAxis15.setTickMarkOutsideLength((float) 10);
        boolean boolean20 = dateAxis15.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
        dateAxis21.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot26.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean29 = xYPlot26.isRangeCrosshairVisible();
        xYPlot26.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo13, point2D32);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((-6.0d), (double) 10.0f);
        org.jfree.chart.JFreeChart jFreeChart39 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType40 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str41 = chartChangeEventType40.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) intervalMarker38, jFreeChart39, chartChangeEventType40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker38.setLabelAnchor(rectangleAnchor43);
        intervalMarker38.setLabel("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]");
        intervalMarker38.setStartValue((-12.0d));
        boolean boolean49 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(chartChangeEventType40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str41.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color30 = java.awt.Color.lightGray;
        categoryMarker29.setLabelPaint((java.awt.Paint) color30);
        java.lang.Object obj32 = categoryMarker29.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = categoryMarker29.getLabelOffsetType();
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean35 = categoryPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker29, layer34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        double double38 = dateAxis37.getLabelAngle();
        boolean boolean39 = dateAxis37.isVerticalTickLabels();
        dateAxis37.setTickMarkOutsideLength((float) 10);
        boolean boolean42 = dateAxis37.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean44 = dateAxis43.isPositiveArrowVisible();
        dateAxis43.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot48.setDatasetRenderingOrder(datasetRenderingOrder49);
        boolean boolean51 = xYPlot48.isRangeCrosshairVisible();
        java.awt.Paint paint52 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        xYPlot48.setBackgroundPaint(paint52);
        categoryMarker29.setLabelPaint(paint52);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(lengthAdjustmentType33);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        xYPlot12.markerChanged(markerChangeEvent13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot12.getDomainAxisEdge();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot12.getSeriesRenderingOrder();
        xYPlot12.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getYear();
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection28 = categoryPlot0.getRangeMarkers(layer27);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        double double33 = dateAxis32.getLabelAngle();
        boolean boolean34 = dateAxis32.isVerticalTickLabels();
        org.jfree.chart.axis.Timeline timeline35 = dateAxis32.getTimeline();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis32, categoryItemRenderer36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray39 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer38 };
        categoryPlot37.setRenderers(categoryItemRendererArray39);
        categoryPlot0.setRenderers(categoryItemRendererArray39);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeline35);
        org.junit.Assert.assertNotNull(categoryItemRendererArray39);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean16 = numberAxis15.getAutoRangeIncludesZero();
        numberAxis15.setAutoRangeStickyZero(true);
        numberAxis15.setAutoRangeIncludesZero(true);
        categoryPlot12.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis15, true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot12.setDataset(0, categoryDataset24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        double double30 = dateAxis29.getLabelAngle();
        boolean boolean31 = dateAxis29.isVerticalTickLabels();
        dateAxis29.setTickMarkOutsideLength((float) 10);
        boolean boolean34 = dateAxis29.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        boolean boolean36 = dateAxis35.isPositiveArrowVisible();
        dateAxis35.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer39);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot40.setDatasetRenderingOrder(datasetRenderingOrder41);
        double double43 = xYPlot40.getRangeCrosshairValue();
        java.awt.Paint paint44 = xYPlot40.getRangeCrosshairPaint();
        xYPlot40.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D47 = xYPlot40.getQuadrantOrigin();
        categoryPlot12.zoomDomainAxes((double) (byte) 10, plotRenderingInfo27, point2D47, false);
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo11, point2D47);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = categoryPlot0.getRenderer(100);
        org.jfree.chart.util.SortOrder sortOrder53 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot0.setColumnRenderingOrder(sortOrder53);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent55 = null;
        categoryPlot0.markerChanged(markerChangeEvent55);
        org.jfree.chart.axis.AxisLocation axisLocation57 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertNull(categoryItemRenderer52);
        org.junit.Assert.assertNotNull(sortOrder53);
        org.junit.Assert.assertNotNull(axisLocation57);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot12.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot29.setDatasetRenderingOrder(datasetRenderingOrder30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color34 = java.awt.Color.lightGray;
        categoryMarker33.setLabelPaint((java.awt.Paint) color34);
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean37 = xYPlot29.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker33, layer36);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        categoryMarker33.notifyListeners(markerChangeEvent38);
        boolean boolean40 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker33);
        try {
            xYPlot12.setBackgroundImageAlpha((float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        numberAxis6.setAutoRangeIncludesZero(false);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        double double17 = dateAxis16.getLabelAngle();
        boolean boolean18 = dateAxis16.isVerticalTickLabels();
        dateAxis16.setTickMarkOutsideLength((float) 10);
        boolean boolean21 = dateAxis16.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
        dateAxis22.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot27.setDatasetRenderingOrder(datasetRenderingOrder28);
        double double30 = xYPlot27.getRangeCrosshairValue();
        java.awt.Paint paint31 = xYPlot27.getRangeCrosshairPaint();
        xYPlot27.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        int int35 = xYPlot27.indexOf(xYDataset34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot27.getRangeAxisEdge();
        try {
            double double37 = numberAxis6.java2DToValue(0.0d, rectangle2D14, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateBottomInset((double) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot25.setFixedRangeAxisSpace(axisSpace32, true);
        xYPlot25.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        intervalMarker2.setPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets5.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 100, (double) 8, (-6.0d), (double) 10.0f);
        boolean boolean14 = intervalMarker2.equals((java.lang.Object) rectangleInsets13);
        double double16 = rectangleInsets13.trimWidth(1.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-17.0d) + "'", double16 == (-17.0d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot25.setFixedRangeAxisSpace(axisSpace32, true);
        xYPlot25.setRangeCrosshairValue((double) 9);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot25.getDomainAxisEdge((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        dateAxis0.setTickMarkInsideLength((float) '#');
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.resizeRange((double) 255, (-12.0d));
        dateAxis6.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getLabelAngle();
        boolean boolean15 = dateAxis13.isVerticalTickLabels();
        dateAxis13.setTickMarkOutsideLength((float) 10);
        boolean boolean18 = dateAxis13.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        dateAxis19.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot24.setDomainAxisLocation(axisLocation25);
        boolean boolean27 = dateAxis6.hasListener((java.util.EventListener) xYPlot24);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot24);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = null;
        try {
            dateAxis0.setTickLabelInsets(rectangleInsets29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot0.getDomainAxis(11);
        boolean boolean17 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        xYPlot12.zoom(0.0d);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation18 = null;
        try {
            boolean boolean19 = xYPlot12.removeAnnotation(xYAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        dateAxis13.setAutoRange(false);
        dateAxis13.resizeRange(0.0d, (double) 10);
        org.jfree.data.Range range20 = dateAxis13.getRange();
        dateAxis13.setTickMarkOutsideLength(2.0f);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { dateAxis13 };
        categoryPlot0.setRangeAxes(valueAxisArray23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(valueAxis25);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) seriesRenderingOrder0);
        java.lang.String str2 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str2.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        float float32 = xYPlot25.getForegroundAlpha();
        xYPlot25.zoom((double) 4);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        double double38 = dateAxis37.getLabelAngle();
        boolean boolean39 = dateAxis37.isVerticalTickLabels();
        dateAxis37.setTickMarkOutsideLength((float) 10);
        boolean boolean42 = dateAxis37.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean44 = dateAxis43.isPositiveArrowVisible();
        dateAxis43.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot48.setDatasetRenderingOrder(datasetRenderingOrder49);
        java.awt.Color color51 = java.awt.Color.cyan;
        xYPlot48.setNoDataMessagePaint((java.awt.Paint) color51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = xYPlot48.getDomainAxisEdge();
        xYPlot48.setRangeCrosshairValue(2.0d);
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot48.setRangeAxisLocation(axisLocation56);
        xYPlot25.setRangeAxisLocation(0, axisLocation56);
        java.awt.Color color59 = java.awt.Color.YELLOW;
        xYPlot25.setOutlinePaint((java.awt.Paint) color59);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(color59);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3, false);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis((int) (short) 10);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(categoryAxis9);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        java.lang.String str2 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CONTRACT" + "'", str1.equals("CONTRACT"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CONTRACT" + "'", str2.equals("CONTRACT"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = dateAxis3.isPositiveArrowVisible();
        java.awt.Stroke stroke5 = dateAxis3.getTickMarkStroke();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis3.setTickMarkStroke(stroke6);
        dateAxis3.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isPositiveArrowVisible();
        java.awt.Shape shape12 = dateAxis10.getDownArrow();
        dateAxis3.setLeftArrow(shape12);
        numberAxis2.setDownArrow(shape12);
        boolean boolean15 = color0.equals((java.lang.Object) shape12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        intervalMarker2.setStartValue(0.0d);
        intervalMarker2.setLabel("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.Object obj7 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        java.awt.Paint paint17 = xYPlot12.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot12.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot12.setFixedDomainAxisSpace(axisSpace19);
        java.awt.Paint paint21 = xYPlot12.getDomainZeroBaselinePaint();
        xYPlot12.clearRangeMarkers(3);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot12.getDomainAxisForDataset((-515));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -515 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setTickMarkStroke(stroke3);
        dateAxis0.setVerticalTickLabels(true);
        dateAxis0.centerRange((double) (byte) -1);
        try {
            dateAxis0.setAutoRangeMinimumSize((double) (-2112128), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer();
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNull(datasetGroup14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isPositiveArrowVisible();
        java.awt.Stroke stroke4 = dateAxis2.getTickMarkStroke();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis2.setTickMarkStroke(stroke5);
        dateAxis2.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Shape shape11 = dateAxis9.getDownArrow();
        dateAxis2.setLeftArrow(shape11);
        numberAxis1.setDownArrow(shape11);
        java.awt.Paint paint14 = numberAxis1.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("XY Plot");
        boolean boolean2 = dateAxis1.isTickMarksVisible();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone3);
        dateAxis1.setTimeZone(timeZone3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange((double) 255, (-12.0d));
        dateAxis0.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLabelAngle();
        boolean boolean9 = dateAxis7.isVerticalTickLabels();
        dateAxis7.setTickMarkOutsideLength((float) 10);
        boolean boolean12 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        dateAxis13.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot18.setDomainAxisLocation(axisLocation19);
        boolean boolean21 = dateAxis0.hasListener((java.util.EventListener) xYPlot18);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        dateAxis0.setTickLabelInsets(rectangleInsets22);
        org.jfree.data.Range range24 = dateAxis0.getDefaultAutoRange();
        double double25 = dateAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        java.lang.String str16 = xYPlot12.getNoDataMessage();
        xYPlot12.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        double double20 = xYPlot12.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        boolean boolean4 = dateAxis1.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot5 = dateAxis1.getPlot();
        dateAxis1.setLowerMargin((double) 7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = dateAxis1.getStandardTickUnits();
        double double9 = dateAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        dateAxis10.setNegativeArrowVisible(false);
        java.awt.Color color16 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean18 = color16.equals((java.lang.Object) textAnchor17);
        dateAxis10.setLabelPaint((java.awt.Paint) color16);
        double double20 = dateAxis10.getUpperMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        try {
            org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot25.setRangeAxisLocation(0, axisLocation33, false);
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str37 = textAnchor36.toString();
        boolean boolean38 = xYPlot25.equals((java.lang.Object) textAnchor36);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder39 = xYPlot25.getSeriesRenderingOrder();
        boolean boolean40 = xYPlot25.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str37.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot0.getOrientation();
        java.awt.Font font12 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis1.getCategoryLabelPositions();
        java.lang.String str8 = categoryAxis1.getLabelURL();
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color2 = java.awt.Color.lightGray;
        categoryMarker1.setLabelPaint((java.awt.Paint) color2);
        java.lang.Object obj4 = categoryMarker1.clone();
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryMarker1.getLabelTextAnchor();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryMarker1.notifyListeners(markerChangeEvent6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        double double10 = dateAxis9.getLabelAngle();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        dateAxis9.setTickMarkOutsideLength((float) 10);
        boolean boolean14 = dateAxis9.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        boolean boolean16 = dateAxis15.isPositiveArrowVisible();
        dateAxis15.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot20.setDatasetRenderingOrder(datasetRenderingOrder21);
        double double23 = xYPlot20.getRangeCrosshairValue();
        java.awt.Paint paint24 = xYPlot20.getRangeCrosshairPaint();
        java.awt.Paint paint25 = xYPlot20.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot20.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot20.setFixedDomainAxisSpace(axisSpace27);
        java.awt.Paint paint29 = xYPlot20.getDomainZeroBaselinePaint();
        categoryMarker1.setLabelPaint(paint29);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        dateAxis13.setAutoRange(false);
        dateAxis13.resizeRange(0.0d, (double) 10);
        org.jfree.data.Range range20 = dateAxis13.getRange();
        dateAxis13.setTickMarkOutsideLength(2.0f);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { dateAxis13 };
        categoryPlot0.setRangeAxes(valueAxisArray23);
        boolean boolean25 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("PlotOrientation.VERTICAL");
        java.awt.Paint paint2 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        java.lang.Object obj9 = categoryPlot0.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        int int4 = day0.getYear();
//        org.jfree.data.xy.XYDataset xYDataset5 = null;
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
//        double double7 = dateAxis6.getLabelAngle();
//        boolean boolean8 = dateAxis6.isVerticalTickLabels();
//        dateAxis6.setTickMarkOutsideLength((float) 10);
//        boolean boolean11 = dateAxis6.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
//        dateAxis12.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
//        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
//        java.awt.Color color20 = java.awt.Color.cyan;
//        xYPlot17.setNoDataMessagePaint((java.awt.Paint) color20);
//        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot17.getDomainAxisEdge();
//        xYPlot17.setRangeCrosshairValue(2.0d);
//        xYPlot17.setNoDataMessage("XY Plot");
//        int int27 = day0.compareTo((java.lang.Object) xYPlot17);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
//        org.junit.Assert.assertNotNull(color20);
//        org.junit.Assert.assertNotNull(rectangleEdge22);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setPositiveArrowVisible(true);
        dateAxis0.setAutoTickUnitSelection(true, true);
        org.jfree.chart.axis.Timeline timeline7 = dateAxis0.getTimeline();
        dateAxis0.setRangeAboutValue((double) 11, 0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(timeline7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot0.getDataset();
        boolean boolean12 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer((int) (short) 0, categoryItemRenderer14, false);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        dateAxis19.setAutoRange(false);
        dateAxis19.resizeRange(0.0d, (double) 10);
        org.jfree.data.Range range26 = dateAxis19.getRange();
        dateAxis19.setTickMarkOutsideLength(2.0f);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) dateAxis19, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation31 = null;
        try {
            boolean boolean33 = categoryPlot0.removeAnnotation(categoryAnnotation31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range26);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
//        dateAxis0.setAutoRange(false);
//        dateAxis0.resizeRange(0.0d, (double) 10);
//        dateAxis0.setInverted(true);
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
//        java.awt.Stroke stroke11 = dateAxis9.getTickMarkStroke();
//        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        dateAxis9.setTickMarkStroke(stroke12);
//        org.jfree.data.Range range14 = dateAxis9.getRange();
//        dateAxis0.setRange(range14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        boolean boolean19 = day16.equals((java.lang.Object) day18);
//        java.util.Date date20 = day16.getStart();
//        dateAxis0.setMaximumDate(date20);
//        dateAxis0.setAutoRangeMinimumSize((double) 10, true);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(stroke11);
//        org.junit.Assert.assertNotNull(stroke12);
//        org.junit.Assert.assertNotNull(range14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabel("13-June-2019");
        org.jfree.data.RangeType rangeType3 = numberAxis0.getRangeType();
        org.jfree.data.RangeType rangeType4 = numberAxis0.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = numberAxis0.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNull(markerAxisBand5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.awt.Color color1 = java.awt.Color.YELLOW;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLabelAngle();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        dateAxis3.setTickMarkOutsideLength((float) 10);
        boolean boolean8 = dateAxis3.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        dateAxis9.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot14.setDatasetRenderingOrder(datasetRenderingOrder15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot14.setDomainGridlinePaint((java.awt.Paint) color17);
        int int19 = color17.getRed();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray21 = null;
        float[] floatArray22 = color20.getRGBComponents(floatArray21);
        float[] floatArray23 = color17.getComponents(floatArray21);
        float[] floatArray24 = color1.getComponents(floatArray23);
        float[] floatArray25 = color0.getColorComponents(floatArray23);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(106.0d);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker1, jFreeChart2, chartChangeEventType3);
        valueMarker1.setValue((double) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getAnchorValue();
        java.awt.Color color10 = java.awt.Color.WHITE;
        java.awt.Color color11 = java.awt.Color.getColor("", color10);
        categoryPlot7.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot7.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        double double17 = categoryPlot16.getAnchorValue();
        java.awt.Color color19 = java.awt.Color.WHITE;
        java.awt.Color color20 = java.awt.Color.getColor("", color19);
        categoryPlot16.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot16.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot16.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace25, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        double double32 = dateAxis31.getLabelAngle();
        boolean boolean33 = dateAxis31.isVerticalTickLabels();
        dateAxis31.setTickMarkOutsideLength((float) 10);
        boolean boolean36 = dateAxis31.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis37.isPositiveArrowVisible();
        dateAxis37.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer41);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder43 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot42.setDatasetRenderingOrder(datasetRenderingOrder43);
        boolean boolean45 = xYPlot42.isRangeCrosshairVisible();
        xYPlot42.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D48 = xYPlot42.getQuadrantOrigin();
        categoryPlot16.zoomRangeAxes((double) 100.0f, plotRenderingInfo29, point2D48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        double double54 = dateAxis53.getLabelAngle();
        boolean boolean55 = dateAxis53.isVerticalTickLabels();
        dateAxis53.setTickMarkOutsideLength((float) 10);
        boolean boolean58 = dateAxis53.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis();
        boolean boolean60 = dateAxis59.isPositiveArrowVisible();
        dateAxis59.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset52, (org.jfree.chart.axis.ValueAxis) dateAxis53, (org.jfree.chart.axis.ValueAxis) dateAxis59, xYItemRenderer63);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder65 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot64.setDatasetRenderingOrder(datasetRenderingOrder65);
        double double67 = xYPlot64.getRangeCrosshairValue();
        java.awt.Paint paint68 = xYPlot64.getRangeCrosshairPaint();
        xYPlot64.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D71 = xYPlot64.getQuadrantOrigin();
        categoryPlot16.zoomDomainAxes((double) '4', plotRenderingInfo51, point2D71, true);
        categoryPlot7.zoomRangeAxes(106.0d, plotRenderingInfo15, point2D71, false);
        boolean boolean76 = categoryPlot7.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor77 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean79 = categoryAnchor77.equals((java.lang.Object) "DatasetRenderingOrder.REVERSE");
        categoryPlot7.setDomainGridlinePosition(categoryAnchor77);
        boolean boolean81 = valueMarker1.equals((java.lang.Object) categoryPlot7);
        categoryPlot7.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(point2D71);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(categoryAnchor77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isPositiveArrowVisible();
        java.awt.Stroke stroke4 = dateAxis2.getTickMarkStroke();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis2.setTickMarkStroke(stroke5);
        dateAxis2.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Shape shape11 = dateAxis9.getDownArrow();
        dateAxis2.setLeftArrow(shape11);
        numberAxis1.setDownArrow(shape11);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        double double17 = categoryPlot16.getAnchorValue();
        java.awt.Color color19 = java.awt.Color.WHITE;
        java.awt.Color color20 = java.awt.Color.getColor("", color19);
        categoryPlot16.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot16.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot16.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace25, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        double double32 = dateAxis31.getLabelAngle();
        boolean boolean33 = dateAxis31.isVerticalTickLabels();
        dateAxis31.setTickMarkOutsideLength((float) 10);
        boolean boolean36 = dateAxis31.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis37.isPositiveArrowVisible();
        dateAxis37.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer41);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder43 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot42.setDatasetRenderingOrder(datasetRenderingOrder43);
        boolean boolean45 = xYPlot42.isRangeCrosshairVisible();
        xYPlot42.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D48 = xYPlot42.getQuadrantOrigin();
        categoryPlot16.zoomRangeAxes((double) 100.0f, plotRenderingInfo29, point2D48);
        categoryPlot16.setRangeCrosshairVisible(false);
        categoryPlot16.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot16.getRangeAxisEdge(9);
        try {
            double double55 = numberAxis1.valueToJava2D((double) 1, rectangle2D15, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        java.util.List list11 = categoryPlot0.getCategories();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot0.getLegendItems();
        categoryPlot0.setForegroundAlpha((float) 100L);
        boolean boolean16 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(list11);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.plot.Plot plot17 = xYPlot12.getParent();
        boolean boolean18 = xYPlot12.isDomainCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot12.getRenderer((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(xYItemRenderer20);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat2 = null;
        numberAxis0.setNumberFormatOverride(numberFormat2);
        java.awt.Paint paint4 = numberAxis0.getTickLabelPaint();
        boolean boolean5 = numberAxis0.isPositiveArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline7 = null;
        dateAxis6.setTimeline(timeline7);
        boolean boolean9 = dateAxis6.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot10 = dateAxis6.getPlot();
        dateAxis6.setLowerMargin((double) 7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = dateAxis6.getStandardTickUnits();
        numberAxis0.setStandardTickUnits(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertNotNull(tickUnitSource13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        int int10 = categoryPlot0.getWeight();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLabelAngle();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        dateAxis12.setTickMarkOutsideLength((float) 10);
        boolean boolean17 = dateAxis12.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isPositiveArrowVisible();
        dateAxis18.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot23.setDatasetRenderingOrder(datasetRenderingOrder24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = xYPlot23.getDrawingSupplier();
        boolean boolean27 = xYPlot23.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        boolean boolean30 = xYPlot23.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        categoryPlot0.addDomainMarker(categoryMarker29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation32, true);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline36 = null;
        dateAxis35.setTimeline(timeline36);
        boolean boolean38 = dateAxis35.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot39 = dateAxis35.getPlot();
        dateAxis35.setLowerMargin((double) 7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = dateAxis35.getStandardTickUnits();
        double double43 = dateAxis35.getAutoRangeMinimumSize();
        int int44 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis35);
        java.lang.Object obj45 = dateAxis35.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(plot39);
        org.junit.Assert.assertNotNull(tickUnitSource42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = java.awt.Color.cyan;
        xYPlot12.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot12.getDomainAxisEdge();
        xYPlot12.setRangeCrosshairValue(2.0d);
        java.awt.Paint paint20 = xYPlot12.getRangeGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot12.getRangeAxis(0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(valueAxis22);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("XY Plot");
        boolean boolean2 = dateAxis1.isTickMarksVisible();
        org.jfree.chart.plot.Plot plot3 = dateAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double30 = rectangleInsets28.calculateBottomInset((double) 1.0f);
        boolean boolean31 = datasetRenderingOrder27.equals((java.lang.Object) rectangleInsets28);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isPositiveArrowVisible();
        dateAxis32.setAutoRange(false);
        dateAxis32.resizeRange(0.0d, (double) 10);
        dateAxis32.setInverted(true);
        boolean boolean41 = datasetRenderingOrder27.equals((java.lang.Object) dateAxis32);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean44 = datasetRenderingOrder27.equals((java.lang.Object) 'a');
        java.lang.Object obj45 = null;
        boolean boolean46 = datasetRenderingOrder27.equals(obj45);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        java.awt.Shape shape3 = numberAxis1.getDownArrow();
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLabelAngle();
        boolean boolean7 = dateAxis5.isVerticalTickLabels();
        dateAxis5.setTickMarkOutsideLength((float) 10);
        boolean boolean10 = dateAxis5.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isPositiveArrowVisible();
        dateAxis11.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot29.setDatasetRenderingOrder(datasetRenderingOrder30);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = xYPlot29.getDrawingSupplier();
        dateAxis5.setPlot((org.jfree.chart.plot.Plot) xYPlot29);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = null;
        xYPlot29.setFixedLegendItems(legendItemCollection34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot29.setRangeAxisLocation(0, axisLocation37, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot29.setDomainAxes(valueAxisArray40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        double double44 = dateAxis43.getLabelAngle();
        boolean boolean45 = dateAxis43.isVerticalTickLabels();
        dateAxis43.setTickMarkOutsideLength((float) 10);
        boolean boolean48 = dateAxis43.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        boolean boolean50 = dateAxis49.isPositiveArrowVisible();
        dateAxis49.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) dateAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis49, xYItemRenderer53);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot54.setDatasetRenderingOrder(datasetRenderingOrder55);
        double double57 = xYPlot54.getRangeCrosshairValue();
        java.awt.Paint paint58 = xYPlot54.getRangeCrosshairPaint();
        xYPlot54.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D61 = xYPlot54.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation62 = xYPlot54.getOrientation();
        xYPlot29.setOrientation(plotOrientation62);
        categoryPlot0.setOrientation(plotOrientation62);
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot();
        double double67 = categoryPlot66.getAnchorValue();
        java.awt.Color color69 = java.awt.Color.WHITE;
        java.awt.Color color70 = java.awt.Color.getColor("", color69);
        categoryPlot66.setDomainGridlinePaint((java.awt.Paint) color69);
        org.jfree.chart.axis.ValueAxis valueAxis72 = categoryPlot66.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot66.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.IntervalMarker intervalMarker78 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj79 = intervalMarker78.clone();
        double double80 = intervalMarker78.getStartValue();
        java.awt.Paint paint81 = null;
        intervalMarker78.setOutlinePaint(paint81);
        org.jfree.chart.util.Layer layer83 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot66.addRangeMarker(5, (org.jfree.chart.plot.Marker) intervalMarker78, layer83);
        java.util.Collection collection85 = categoryPlot0.getDomainMarkers((-2112128), layer83);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxisArray40);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(point2D61);
        org.junit.Assert.assertNotNull(plotOrientation62);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNull(valueAxis72);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 9.0d + "'", double80 == 9.0d);
        org.junit.Assert.assertNotNull(layer83);
        org.junit.Assert.assertNull(collection85);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        xYPlot12.setNoDataMessage("ChartChangeEventType.GENERAL");
        int int19 = xYPlot12.getDomainAxisCount();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot12.getRendererForDataset(xYDataset20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
        java.awt.Stroke stroke24 = dateAxis22.getTickMarkStroke();
        java.awt.Paint paint25 = dateAxis22.getAxisLinePaint();
        org.jfree.data.Range range26 = xYPlot12.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(range26);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setPositiveArrowVisible(true);
        dateAxis0.setRangeWithMargins((double) 6, (double) 11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            xYPlot25.drawBackground(graphics2D32, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        double double4 = categoryPlot3.getAnchorValue();
        java.awt.Color color6 = java.awt.Color.WHITE;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot3.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot3.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot3.getDomainAxisEdge((int) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        boolean boolean13 = numberAxis0.equals((java.lang.Object) categoryPlot3);
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot3.getDataset((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset15);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        java.util.List list11 = categoryPlot0.getCategories();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot0.getLegendItems();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(list11);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        java.awt.Paint paint17 = xYPlot12.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot12.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot12.setFixedDomainAxisSpace(axisSpace19);
        java.awt.Paint paint21 = xYPlot12.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color17 = java.awt.Color.lightGray;
        categoryMarker16.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryMarker16.notifyListeners(markerChangeEvent21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean27 = numberAxis26.getAutoRangeIncludesZero();
        numberAxis26.setAutoRangeStickyZero(true);
        numberAxis26.setAutoRangeIncludesZero(true);
        categoryPlot23.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis26, true);
        org.jfree.data.category.CategoryDataset categoryDataset34 = categoryPlot23.getDataset();
        boolean boolean35 = categoryMarker16.equals((java.lang.Object) categoryDataset34);
        java.lang.Object obj36 = categoryMarker16.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
        java.lang.String str3 = dateAxis0.getLabel();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(106.0d);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker1, jFreeChart2, chartChangeEventType3);
        double double5 = valueMarker1.getValue();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) seriesRenderingOrder6);
        boolean boolean9 = seriesRenderingOrder6.equals((java.lang.Object) true);
        boolean boolean10 = valueMarker1.equals((java.lang.Object) seriesRenderingOrder6);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 106.0d + "'", double5 == 106.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("XY Plot");
        boolean boolean2 = dateAxis1.isTickMarksVisible();
        dateAxis1.setLabelAngle((double) 500);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        dateAxis1.setTickLabelFont(font5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        int int32 = xYPlot25.getIndexOf(xYItemRenderer31);
        int int33 = xYPlot25.getDomainAxisCount();
        xYPlot25.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        java.util.List list11 = categoryPlot0.getCategories();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot0.getLegendItems();
        categoryPlot0.setBackgroundImageAlignment(13);
        java.util.List list16 = categoryPlot0.getCategories();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(list11);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNull(list16);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot34.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis38.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis38.setUpperMargin(0.0d);
        categoryAxis38.clearCategoryLabelToolTips();
        java.util.List list44 = categoryPlot34.getCategoriesForAxis(categoryAxis38);
        xYPlot25.drawDomainTickBands(graphics2D32, rectangle2D33, list44);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(list44);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        boolean boolean13 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Stroke stroke8 = categoryAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) seriesRenderingOrder0);
        boolean boolean3 = seriesRenderingOrder0.equals((java.lang.Object) true);
        java.lang.String str4 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str4.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        int int32 = xYPlot25.getBackgroundImageAlignment();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis33.isPositiveArrowVisible();
        java.awt.Stroke stroke35 = dateAxis33.getTickMarkStroke();
        double double36 = dateAxis33.getUpperMargin();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis33.setTickMarkStroke(stroke37);
        xYPlot25.setDomainZeroBaselineStroke(stroke37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot25.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot12.getDomainAxis();
        boolean boolean17 = xYPlot12.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        java.awt.Paint paint2 = dateAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabel("13-June-2019");
        org.jfree.data.RangeType rangeType3 = numberAxis0.getRangeType();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis0.setDownArrow(shape4);
        numberAxis0.setAutoRange(false);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8388608) + "'", int1 == (-8388608));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis0.removeChangeListener(axisChangeListener2);
        numberAxis0.setLabel("hi!");
        numberAxis0.setLowerMargin((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        double double9 = categoryPlot8.getAnchorValue();
        java.awt.Color color11 = java.awt.Color.WHITE;
        java.awt.Color color12 = java.awt.Color.getColor("", color11);
        categoryPlot8.setDomainGridlinePaint((java.awt.Paint) color11);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot8.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot8.getDomainAxisEdge((int) '4');
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, (double) 0, (double) 0.0f, (-12.0d), (double) (-1.0f));
        double double24 = rectangleInsets22.extendHeight((double) 10.0f);
        categoryPlot8.setAxisOffset(rectangleInsets22);
        org.jfree.chart.util.SortOrder sortOrder26 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str27 = sortOrder26.toString();
        categoryPlot8.setColumnRenderingOrder(sortOrder26);
        boolean boolean29 = numberAxis0.equals((java.lang.Object) sortOrder26);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        categoryMarker31.setDrawAsLine(false);
        org.jfree.chart.text.TextAnchor textAnchor34 = categoryMarker31.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryMarker31.getLabelOffset();
        numberAxis0.setTickLabelInsets(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-2.0d) + "'", double24 == (-2.0d));
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "SortOrder.DESCENDING" + "'", str27.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        int int32 = xYPlot25.getIndexOf(xYItemRenderer31);
        int int33 = xYPlot25.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        double double36 = dateAxis35.getLabelAngle();
        boolean boolean37 = dateAxis35.isVerticalTickLabels();
        dateAxis35.setTickMarkOutsideLength((float) 10);
        boolean boolean40 = dateAxis35.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        boolean boolean42 = dateAxis41.isPositiveArrowVisible();
        dateAxis41.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis41, xYItemRenderer45);
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot46.setDomainAxisLocation(axisLocation47);
        int int49 = xYPlot46.getWeight();
        int int50 = xYPlot46.getDomainAxisCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color54 = java.awt.Color.lightGray;
        categoryMarker53.setLabelPaint((java.awt.Paint) color54);
        java.lang.Object obj56 = categoryMarker53.clone();
        org.jfree.chart.text.TextAnchor textAnchor57 = categoryMarker53.getLabelTextAnchor();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot46.addRangeMarker(2019, (org.jfree.chart.plot.Marker) categoryMarker53, layer58);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        double double61 = categoryPlot60.getAnchorValue();
        java.awt.Color color63 = java.awt.Color.WHITE;
        java.awt.Color color64 = java.awt.Color.getColor("", color63);
        categoryPlot60.setDomainGridlinePaint((java.awt.Paint) color63);
        org.jfree.chart.axis.ValueAxis valueAxis66 = categoryPlot60.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot60.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.IntervalMarker intervalMarker72 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj73 = intervalMarker72.clone();
        double double74 = intervalMarker72.getStartValue();
        java.awt.Paint paint75 = null;
        intervalMarker72.setOutlinePaint(paint75);
        org.jfree.chart.util.Layer layer77 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot60.addRangeMarker(5, (org.jfree.chart.plot.Marker) intervalMarker72, layer77);
        boolean boolean79 = xYPlot25.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker53, layer77);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNull(valueAxis66);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertNotNull(obj73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 9.0d + "'", double74 == 9.0d);
        org.junit.Assert.assertNotNull(layer77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        xYPlot12.clearRangeAxes();
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = xYPlot12.getOrientation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(plotOrientation18);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot25.setRangeAxisLocation(0, axisLocation33, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot25.setDomainAxes(valueAxisArray36);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = xYPlot25.getLegendItems();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNotNull(legendItemCollection38);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.setBackgroundAlpha((float) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        xYPlot12.zoomDomainAxes((double) 7, plotRenderingInfo18, point2D19);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        java.awt.Stroke stroke31 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        double double33 = categoryPlot32.getAnchorValue();
        java.awt.Color color35 = java.awt.Color.WHITE;
        java.awt.Color color36 = java.awt.Color.getColor("", color35);
        categoryPlot32.setDomainGridlinePaint((java.awt.Paint) color35);
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot32.getRangeAxis();
        java.util.List list39 = categoryPlot32.getCategories();
        categoryPlot32.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot32.setDomainAxis(100, categoryAxis43);
        boolean boolean45 = categoryPlot32.isDomainGridlinesVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder46 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double49 = rectangleInsets47.calculateBottomInset((double) 1.0f);
        boolean boolean50 = datasetRenderingOrder46.equals((java.lang.Object) rectangleInsets47);
        categoryPlot32.setDatasetRenderingOrder(datasetRenderingOrder46);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        double double54 = categoryPlot53.getAnchorValue();
        java.awt.Color color56 = java.awt.Color.WHITE;
        java.awt.Color color57 = java.awt.Color.getColor("", color56);
        categoryPlot53.setDomainGridlinePaint((java.awt.Paint) color56);
        org.jfree.chart.axis.ValueAxis valueAxis59 = categoryPlot53.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot53.getDomainAxisEdge((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        categoryPlot53.setRenderer(categoryItemRenderer62);
        categoryPlot53.mapDatasetToDomainAxis((int) (byte) 100, (int) (short) -1);
        org.jfree.chart.axis.AxisLocation axisLocation67 = categoryPlot53.getRangeAxisLocation();
        categoryPlot32.setDomainAxisLocation(8, axisLocation67);
        xYPlot25.setRangeAxisLocation(axisLocation67, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNull(list39);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 3.0d + "'", double49 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNull(valueAxis59);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(axisLocation67);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Stroke stroke4 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        double double6 = categoryPlot5.getAnchorValue();
        java.awt.Color color8 = java.awt.Color.WHITE;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        categoryPlot5.setDomainGridlinePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot5.getRangeAxis();
        java.util.List list12 = categoryPlot5.getCategories();
        categoryPlot5.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot5.setDomainAxis(100, categoryAxis16);
        categoryPlot0.setDomainAxis(categoryAxis16);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color24 = java.awt.Color.lightGray;
        categoryMarker23.setLabelPaint((java.awt.Paint) color24);
        java.lang.Object obj26 = categoryMarker23.clone();
        org.jfree.chart.text.TextAnchor textAnchor27 = categoryMarker23.getLabelTextAnchor();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker23.setPaint((java.awt.Paint) color28);
        dateAxis20.setTickLabelPaint((java.awt.Paint) color28);
        boolean boolean31 = dateAxis20.isVisible();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(list12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (short) 10, "DatasetRenderingOrder.REVERSE");
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.awt.Font font11 = categoryAxis1.getTickLabelFont((java.lang.Comparable) day10);
        java.util.Date date12 = day10.getStart();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("XY Plot");
        boolean boolean2 = dateAxis1.isTickMarksVisible();
        dateAxis1.setFixedDimension((double) (byte) 1);
        dateAxis1.setLabelAngle((double) 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        float float14 = xYPlot12.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace15 = xYPlot12.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.plot.Plot plot17 = xYPlot12.getParent();
        boolean boolean18 = xYPlot12.isDomainCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        try {
            xYPlot12.setRenderer((-12517377), xYItemRenderer20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.resizeRange((double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Color color6 = java.awt.Color.getColor("", color5);
        dateAxis0.setLabelPaint((java.awt.Paint) color5);
        dateAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Shape shape11 = dateAxis9.getUpArrow();
        dateAxis0.setUpArrow(shape11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) 100, (double) 8, (-6.0d), (double) 10.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) 1L, (double) 100, (double) 4, (double) (-515));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1L));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis3.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis3.setUpperMargin(0.0d);
        boolean boolean8 = defaultDrawingSupplier0.equals((java.lang.Object) 0.0d);
        java.lang.Object obj9 = null;
        boolean boolean10 = defaultDrawingSupplier0.equals(obj9);
        java.awt.Paint paint11 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color2 = java.awt.Color.lightGray;
        categoryMarker1.setLabelPaint((java.awt.Paint) color2);
        java.lang.Object obj4 = categoryMarker1.clone();
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryMarker1.getLabelTextAnchor();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker1.setPaint((java.awt.Paint) color6);
        boolean boolean8 = categoryMarker1.getDrawAsLine();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        double double10 = categoryPlot9.getAnchorValue();
        java.awt.Color color12 = java.awt.Color.WHITE;
        java.awt.Color color13 = java.awt.Color.getColor("", color12);
        categoryPlot9.setDomainGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean16 = numberAxis15.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat17 = null;
        numberAxis15.setNumberFormatOverride(numberFormat17);
        categoryPlot9.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis15);
        categoryPlot9.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot9.getInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        double double25 = categoryPlot24.getAnchorValue();
        java.awt.Color color27 = java.awt.Color.WHITE;
        java.awt.Color color28 = java.awt.Color.getColor("", color27);
        categoryPlot24.setDomainGridlinePaint((java.awt.Paint) color27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot24.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot24.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot24.setFixedDomainAxisSpace(axisSpace33, true);
        org.jfree.chart.axis.ValueAxis valueAxis36 = categoryPlot24.getRangeAxis();
        java.awt.Stroke stroke37 = categoryPlot24.getRangeCrosshairStroke();
        categoryPlot9.setDomainGridlineStroke(stroke37);
        categoryMarker1.setStroke(stroke37);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        boolean boolean2 = dateAxis0.isVerticalTickLabels();
        dateAxis0.setLowerMargin((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        boolean boolean16 = xYPlot12.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color19 = java.awt.Color.lightGray;
        categoryMarker18.setLabelPaint((java.awt.Paint) color19);
        java.lang.Object obj21 = categoryMarker18.clone();
        org.jfree.chart.text.TextAnchor textAnchor22 = categoryMarker18.getLabelTextAnchor();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        double double24 = dateAxis23.getLabelAngle();
        dateAxis23.setNegativeArrowVisible(false);
        boolean boolean27 = categoryMarker18.equals((java.lang.Object) false);
        boolean boolean28 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        java.awt.Font font29 = categoryMarker18.getLabelFont();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
        dateAxis0.setRangeWithMargins((double) 2, (double) 10);
        java.text.DateFormat dateFormat8 = null;
        dateAxis0.setDateFormatOverride(dateFormat8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (int) (short) 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("XY Plot");
        boolean boolean2 = dateAxis1.isTickMarksVisible();
        dateAxis1.setLabelAngle((double) 500);
        java.text.DateFormat dateFormat5 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateFormat5);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        java.awt.Color color15 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean17 = color15.equals((java.lang.Object) textAnchor16);
        dateAxis7.setAxisLinePaint((java.awt.Paint) color15);
        double double19 = dateAxis7.getLabelAngle();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        double double22 = dateAxis21.getLabelAngle();
        boolean boolean23 = dateAxis21.isVerticalTickLabels();
        dateAxis21.setTickMarkOutsideLength((float) 10);
        boolean boolean26 = dateAxis21.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = dateAxis27.isPositiveArrowVisible();
        dateAxis27.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot32.setDatasetRenderingOrder(datasetRenderingOrder33);
        java.awt.Color color35 = java.awt.Color.cyan;
        xYPlot32.setNoDataMessagePaint((java.awt.Paint) color35);
        dateAxis7.setPlot((org.jfree.chart.plot.Plot) xYPlot32);
        java.awt.Color color39 = java.awt.Color.WHITE;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        boolean boolean41 = dateAxis40.isPositiveArrowVisible();
        java.awt.Stroke stroke42 = dateAxis40.getTickMarkStroke();
        java.awt.Color color43 = java.awt.Color.BLUE;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        boolean boolean47 = dateAxis46.isPositiveArrowVisible();
        java.awt.Stroke stroke48 = dateAxis46.getTickMarkStroke();
        double double49 = dateAxis46.getUpperMargin();
        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis46.setTickMarkStroke(stroke50);
        categoryMarker45.setOutlineStroke(stroke50);
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color39, stroke42, (java.awt.Paint) color43, stroke50, (float) (short) 1);
        int int55 = color43.getGreen();
        java.awt.Color color56 = color43.brighter();
        dateAxis7.setLabelPaint((java.awt.Paint) color56);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.05d + "'", double49 == 0.05d);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(color56);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = numberAxis0.getStandardTickUnits();
        numberAxis0.setPositiveArrowVisible(true);
        numberAxis0.setLabelURL("");
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        intervalMarker2.setPaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets5.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 100, (double) 8, (-6.0d), (double) 10.0f);
        boolean boolean14 = intervalMarker2.equals((java.lang.Object) rectangleInsets13);
        intervalMarker2.setStartValue((double) 10L);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        double double5 = rectangleInsets0.calculateRightInset((double) 255);
        double double6 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        double double9 = dateAxis8.getLabelAngle();
        boolean boolean10 = dateAxis8.isVerticalTickLabels();
        dateAxis8.setTickMarkOutsideLength((float) 10);
        boolean boolean13 = dateAxis8.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isPositiveArrowVisible();
        dateAxis14.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot19.setDatasetRenderingOrder(datasetRenderingOrder20);
        boolean boolean22 = xYPlot19.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot19.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        java.awt.Stroke stroke28 = dateAxis26.getTickMarkStroke();
        double double29 = dateAxis26.getUpperMargin();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis26.setTickMarkStroke(stroke30);
        categoryMarker25.setOutlineStroke(stroke30);
        org.jfree.chart.util.Layer layer33 = null;
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25, layer33);
        boolean boolean35 = categoryAxis1.equals((java.lang.Object) xYPlot19);
        xYPlot19.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        boolean boolean2 = sortOrder0.equals((java.lang.Object) day1);
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.configure();
        org.jfree.chart.plot.Plot plot5 = categoryAxis1.getPlot();
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setPositiveArrowVisible(true);
        dateAxis0.setUpperMargin(1.0d);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot21.setDatasetRenderingOrder(datasetRenderingOrder22);
        java.awt.Color color24 = java.awt.Color.cyan;
        xYPlot21.setNoDataMessagePaint((java.awt.Paint) color24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot21.getDomainAxisEdge();
        org.jfree.data.general.Dataset dataset27 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleEdge26, dataset27);
        try {
            java.util.List list29 = dateAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.clearDomainAxes();
        boolean boolean16 = xYPlot12.isDomainCrosshairLockedOnData();
        boolean boolean17 = xYPlot12.isOutlineVisible();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray19 = null;
        float[] floatArray20 = color18.getRGBComponents(floatArray19);
        xYPlot12.setDomainCrosshairPaint((java.awt.Paint) color18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.configure();
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        double double16 = dateAxis15.getLabelAngle();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        dateAxis15.setTickMarkOutsideLength((float) 10);
        boolean boolean20 = dateAxis15.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
        dateAxis21.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot26.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean29 = xYPlot26.isRangeCrosshairVisible();
        xYPlot26.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo13, point2D32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        double double38 = dateAxis37.getLabelAngle();
        boolean boolean39 = dateAxis37.isVerticalTickLabels();
        dateAxis37.setTickMarkOutsideLength((float) 10);
        boolean boolean42 = dateAxis37.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean44 = dateAxis43.isPositiveArrowVisible();
        dateAxis43.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot48.setDatasetRenderingOrder(datasetRenderingOrder49);
        double double51 = xYPlot48.getRangeCrosshairValue();
        java.awt.Paint paint52 = xYPlot48.getRangeCrosshairPaint();
        xYPlot48.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D55 = xYPlot48.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) '4', plotRenderingInfo35, point2D55, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis();
        boolean boolean61 = dateAxis60.isPositiveArrowVisible();
        java.awt.Stroke stroke62 = dateAxis60.getTickMarkStroke();
        boolean boolean63 = dateAxis60.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        boolean boolean65 = dateAxis64.isPositiveArrowVisible();
        java.awt.Stroke stroke66 = dateAxis64.getTickMarkStroke();
        java.awt.Stroke stroke67 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis64.setTickMarkStroke(stroke67);
        org.jfree.data.Range range69 = dateAxis64.getRange();
        dateAxis60.setRange(range69);
        boolean boolean71 = dateAxis60.isTickMarksVisible();
        org.jfree.chart.axis.Timeline timeline72 = dateAxis60.getTimeline();
        categoryPlot0.setRangeAxis(3, (org.jfree.chart.axis.ValueAxis) dateAxis60, true);
        org.jfree.chart.util.Layer layer75 = null;
        java.util.Collection collection76 = categoryPlot0.getRangeMarkers(layer75);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(point2D55);
        org.junit.Assert.assertNull(categoryAxis58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(timeline72);
        org.junit.Assert.assertNull(collection76);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        xYPlot25.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset35 = xYPlot25.getDataset();
        boolean boolean36 = xYPlot25.isDomainCrosshairLockedOnData();
        xYPlot25.mapDatasetToRangeAxis(4, 12);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation40 = null;
        try {
            xYPlot25.addAnnotation(xYAnnotation40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 100, (float) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-83) + "'", int3 == (-83));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        dateAxis0.setTickMarkInsideLength((float) '#');
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.resizeRange((double) 255, (-12.0d));
        dateAxis6.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getLabelAngle();
        boolean boolean15 = dateAxis13.isVerticalTickLabels();
        dateAxis13.setTickMarkOutsideLength((float) 10);
        boolean boolean18 = dateAxis13.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        dateAxis19.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot24.setDomainAxisLocation(axisLocation25);
        boolean boolean27 = dateAxis6.hasListener((java.util.EventListener) xYPlot24);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot24);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation29 = null;
        try {
            boolean boolean30 = xYPlot24.removeAnnotation(xYAnnotation29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLabelAngle();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis3.getTimeline();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        double double24 = dateAxis23.getLabelAngle();
        boolean boolean25 = dateAxis23.isVerticalTickLabels();
        dateAxis23.setTickMarkOutsideLength((float) 10);
        boolean boolean28 = dateAxis23.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isPositiveArrowVisible();
        dateAxis29.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer33);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot34.setDatasetRenderingOrder(datasetRenderingOrder35);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = xYPlot34.getDrawingSupplier();
        dateAxis10.setPlot((org.jfree.chart.plot.Plot) xYPlot34);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        xYPlot34.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot34.setRangeAxisLocation(0, axisLocation42, false);
        categoryPlot8.setRangeAxisLocation(axisLocation42);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
        org.junit.Assert.assertNotNull(drawingSupplier37);
        org.junit.Assert.assertNotNull(axisLocation42);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean2 = sortOrder0.equals((java.lang.Object) day1);
//        java.lang.String str3 = day1.toString();
//        org.junit.Assert.assertNotNull(sortOrder0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        java.util.Date date4 = day2.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        intervalMarker2.setPaint((java.awt.Paint) color3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot17.setDomainAxisLocation(axisLocation18);
        int int20 = xYPlot17.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis22.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color25 = java.awt.Color.cyan;
        categoryAxis22.setTickLabelPaint((java.awt.Paint) color25);
        double double27 = categoryAxis22.getLowerMargin();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        double double30 = dateAxis29.getLabelAngle();
        boolean boolean31 = dateAxis29.isVerticalTickLabels();
        dateAxis29.setTickMarkOutsideLength((float) 10);
        boolean boolean34 = dateAxis29.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        boolean boolean36 = dateAxis35.isPositiveArrowVisible();
        dateAxis35.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer39);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot40.setDatasetRenderingOrder(datasetRenderingOrder41);
        boolean boolean43 = xYPlot40.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = xYPlot40.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        boolean boolean48 = dateAxis47.isPositiveArrowVisible();
        java.awt.Stroke stroke49 = dateAxis47.getTickMarkStroke();
        double double50 = dateAxis47.getUpperMargin();
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis47.setTickMarkStroke(stroke51);
        categoryMarker46.setOutlineStroke(stroke51);
        org.jfree.chart.util.Layer layer54 = null;
        xYPlot40.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker46, layer54);
        boolean boolean56 = categoryAxis22.equals((java.lang.Object) xYPlot40);
        java.awt.Font font58 = categoryAxis22.getTickLabelFont((java.lang.Comparable) 10.0d);
        xYPlot17.setNoDataMessageFont(font58);
        intervalMarker2.setLabelFont(font58);
        org.jfree.chart.text.TextAnchor textAnchor61 = intervalMarker2.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.05d + "'", double50 == 0.05d);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(textAnchor61);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Category Plot");
        boolean boolean2 = categoryAxis1.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        xYPlot12.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D18 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        float float21 = dateAxis19.getTickMarkInsideLength();
        int int22 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        xYPlot12.setDomainAxis(3, (org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj3 = intervalMarker2.clone();
        double double4 = intervalMarker2.getStartValue();
        java.awt.Paint paint5 = intervalMarker2.getOutlinePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.0d + "'", double4 == 9.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        java.awt.Paint paint17 = xYPlot12.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot12.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot12.setFixedDomainAxisSpace(axisSpace19);
        java.awt.Paint paint21 = xYPlot12.getDomainZeroBaselinePaint();
        xYPlot12.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        categoryPlot0.clearAnnotations();
        java.util.List list28 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNull(list28);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        xYPlot12.setBackgroundImageAlpha((float) 1L);
        org.jfree.data.general.DatasetGroup datasetGroup18 = xYPlot12.getDatasetGroup();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean25 = numberAxis24.getAutoRangeIncludesZero();
        numberAxis24.setAutoRangeStickyZero(true);
        numberAxis24.setAutoRangeIncludesZero(true);
        categoryPlot21.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis24, true);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot21.setDataset(0, categoryDataset33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        double double39 = dateAxis38.getLabelAngle();
        boolean boolean40 = dateAxis38.isVerticalTickLabels();
        dateAxis38.setTickMarkOutsideLength((float) 10);
        boolean boolean43 = dateAxis38.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        boolean boolean45 = dateAxis44.isPositiveArrowVisible();
        dateAxis44.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer48);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder50 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot49.setDatasetRenderingOrder(datasetRenderingOrder50);
        double double52 = xYPlot49.getRangeCrosshairValue();
        java.awt.Paint paint53 = xYPlot49.getRangeCrosshairPaint();
        xYPlot49.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D56 = xYPlot49.getQuadrantOrigin();
        categoryPlot21.zoomDomainAxes((double) (byte) 10, plotRenderingInfo36, point2D56, false);
        int int59 = categoryPlot21.getRangeAxisCount();
        java.util.List list60 = categoryPlot21.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot();
        double double64 = categoryPlot63.getAnchorValue();
        java.awt.Color color66 = java.awt.Color.WHITE;
        java.awt.Color color67 = java.awt.Color.getColor("", color66);
        categoryPlot63.setDomainGridlinePaint((java.awt.Paint) color66);
        org.jfree.chart.axis.ValueAxis valueAxis69 = categoryPlot63.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = categoryPlot63.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace72 = null;
        categoryPlot63.setFixedDomainAxisSpace(axisSpace72, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        org.jfree.data.xy.XYDataset xYDataset77 = null;
        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis();
        double double79 = dateAxis78.getLabelAngle();
        boolean boolean80 = dateAxis78.isVerticalTickLabels();
        dateAxis78.setTickMarkOutsideLength((float) 10);
        boolean boolean83 = dateAxis78.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis84 = new org.jfree.chart.axis.DateAxis();
        boolean boolean85 = dateAxis84.isPositiveArrowVisible();
        dateAxis84.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer88 = null;
        org.jfree.chart.plot.XYPlot xYPlot89 = new org.jfree.chart.plot.XYPlot(xYDataset77, (org.jfree.chart.axis.ValueAxis) dateAxis78, (org.jfree.chart.axis.ValueAxis) dateAxis84, xYItemRenderer88);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder90 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot89.setDatasetRenderingOrder(datasetRenderingOrder90);
        boolean boolean92 = xYPlot89.isRangeCrosshairVisible();
        xYPlot89.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D95 = xYPlot89.getQuadrantOrigin();
        categoryPlot63.zoomRangeAxes((double) 100.0f, plotRenderingInfo76, point2D95);
        categoryPlot21.zoomDomainAxes((double) 10.0f, plotRenderingInfo62, point2D95);
        try {
            xYPlot12.zoomRangeAxes(8.0d, plotRenderingInfo20, point2D95, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(point2D56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 53 + "'", int59 == 53);
        org.junit.Assert.assertNull(list60);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNull(valueAxis69);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(point2D95);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(0, categoryDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        double double31 = xYPlot28.getRangeCrosshairValue();
        java.awt.Paint paint32 = xYPlot28.getRangeCrosshairPaint();
        xYPlot28.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D35 = xYPlot28.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D35, false);
        int int38 = categoryPlot0.getRangeAxisCount();
        java.util.List list39 = categoryPlot0.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot0.setRenderer(categoryItemRenderer40, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder43 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint44 = null;
        categoryPlot0.setOutlinePaint(paint44);
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        double double49 = dateAxis48.getLabelAngle();
        boolean boolean50 = dateAxis48.isVerticalTickLabels();
        dateAxis48.setTickMarkOutsideLength((float) 10);
        boolean boolean53 = dateAxis48.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        boolean boolean55 = dateAxis54.isPositiveArrowVisible();
        dateAxis54.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) dateAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer58);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder60 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot59.setDatasetRenderingOrder(datasetRenderingOrder60);
        double double62 = xYPlot59.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer63 = null;
        java.util.Collection collection64 = xYPlot59.getRangeMarkers(layer63);
        java.awt.Stroke stroke65 = xYPlot59.getRangeCrosshairStroke();
        xYPlot59.mapDatasetToRangeAxis(100, 0);
        org.jfree.chart.axis.AxisLocation axisLocation69 = xYPlot59.getDomainAxisLocation();
        try {
            categoryPlot0.setDomainAxisLocation((-1783), axisLocation69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNull(list39);
        org.junit.Assert.assertNotNull(datasetRenderingOrder43);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(axisLocation69);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setNegativeArrowVisible(false);
        java.awt.Color color6 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean8 = color6.equals((java.lang.Object) textAnchor7);
        dateAxis0.setLabelPaint((java.awt.Paint) color6);
        double double10 = dateAxis0.getUpperMargin();
        dateAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot0.getRangeAxis(10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        categoryPlot0.addChangeListener(plotChangeListener29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNull(axisSpace31);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        double double9 = dateAxis8.getLabelAngle();
        boolean boolean10 = dateAxis8.isVerticalTickLabels();
        dateAxis8.setTickMarkOutsideLength((float) 10);
        boolean boolean13 = dateAxis8.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isPositiveArrowVisible();
        dateAxis14.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot19.setDatasetRenderingOrder(datasetRenderingOrder20);
        boolean boolean22 = xYPlot19.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot19.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        java.awt.Stroke stroke28 = dateAxis26.getTickMarkStroke();
        double double29 = dateAxis26.getUpperMargin();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis26.setTickMarkStroke(stroke30);
        categoryMarker25.setOutlineStroke(stroke30);
        org.jfree.chart.util.Layer layer33 = null;
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25, layer33);
        boolean boolean35 = categoryAxis1.equals((java.lang.Object) xYPlot19);
        java.awt.Font font37 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        double double43 = categoryPlot42.getAnchorValue();
        java.awt.Color color45 = java.awt.Color.WHITE;
        java.awt.Color color46 = java.awt.Color.getColor("", color45);
        categoryPlot42.setDomainGridlinePaint((java.awt.Paint) color45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot42.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot42.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        try {
            org.jfree.chart.axis.AxisState axisState52 = categoryAxis1.draw(graphics2D38, (double) (-1.0f), rectangle2D40, rectangle2D41, rectangleEdge50, plotRenderingInfo51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(valueAxis48);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        xYPlot25.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset35 = xYPlot25.getDataset();
        int int36 = xYPlot25.getDatasetCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        double double2 = dateAxis0.getUpperBound();
        boolean boolean3 = dateAxis0.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setAxisLineStroke(stroke3);
        org.jfree.data.Range range5 = dateAxis0.getRange();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        boolean boolean3 = dateAxis0.isInverted();
        java.util.TimeZone timeZone4 = dateAxis0.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isPositiveArrowVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color9 = java.awt.Color.lightGray;
        categoryMarker8.setLabelPaint((java.awt.Paint) color9);
        java.lang.Object obj11 = categoryMarker8.clone();
        org.jfree.chart.text.TextAnchor textAnchor12 = categoryMarker8.getLabelTextAnchor();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker8.setPaint((java.awt.Paint) color13);
        dateAxis5.setTickLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        dateAxis16.resizeRange(0.0d, (double) 10);
        dateAxis16.setInverted(true);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isPositiveArrowVisible();
        java.awt.Stroke stroke27 = dateAxis25.getTickMarkStroke();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis25.setTickMarkStroke(stroke28);
        org.jfree.data.Range range30 = dateAxis25.getRange();
        dateAxis16.setRange(range30);
        dateAxis5.setRangeWithMargins(range30, false, false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date36 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit35);
        dateAxis0.setTickUnit(dateTickUnit35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(date36);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        xYPlot21.setDomainZeroBaselineVisible(false);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.util.List list28 = null;
        xYPlot21.drawDomainTickBands(graphics2D26, rectangle2D27, list28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = xYPlot21.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier30);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot0.setDataset((int) (byte) 10, categoryDataset33);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(drawingSupplier30);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot0.getDataset();
        boolean boolean12 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer((int) (short) 0, categoryItemRenderer14, false);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        boolean boolean21 = dateAxis19.isVerticalTickLabels();
        dateAxis19.setTickMarkOutsideLength((float) 10);
        boolean boolean24 = dateAxis19.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isPositiveArrowVisible();
        dateAxis25.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer29);
        java.awt.Color color33 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean35 = color33.equals((java.lang.Object) textAnchor34);
        dateAxis25.setAxisLinePaint((java.awt.Paint) color33);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline38 = null;
        dateAxis37.setTimeline(timeline38);
        java.util.Date date40 = dateAxis37.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        boolean boolean42 = dateAxis41.isPositiveArrowVisible();
        java.awt.Stroke stroke43 = dateAxis41.getTickMarkStroke();
        java.awt.Stroke stroke44 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis41.setTickMarkStroke(stroke44);
        org.jfree.data.Range range46 = dateAxis41.getRange();
        dateAxis37.setRangeWithMargins(range46, false, true);
        dateAxis25.setRange(range46, true, false);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color1 };
        java.awt.Paint[] paintArray3 = null;
        java.awt.Paint[] paintArray4 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Color color7 = java.awt.Color.yellow;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color8, dataset9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { paint5, paint6, color7, color8, color11 };
        java.awt.Paint[] paintArray13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isPositiveArrowVisible();
        java.awt.Shape shape19 = dateAxis17.getDownArrow();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setLabel("13-June-2019");
        org.jfree.data.RangeType rangeType23 = numberAxis20.getRangeType();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis20.setDownArrow(shape24);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getLabelAngle();
        dateAxis26.setPositiveArrowVisible(true);
        dateAxis26.setUpperMargin(1.0d);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isPositiveArrowVisible();
        java.awt.Stroke stroke34 = dateAxis32.getTickMarkStroke();
        java.awt.Stroke stroke35 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis32.setTickMarkStroke(stroke35);
        dateAxis32.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        boolean boolean40 = dateAxis39.isPositiveArrowVisible();
        java.awt.Shape shape41 = dateAxis39.getDownArrow();
        dateAxis32.setLeftArrow(shape41);
        dateAxis26.setDownArrow(shape41);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        numberAxis44.setLabel("13-June-2019");
        org.jfree.data.RangeType rangeType47 = numberAxis44.getRangeType();
        java.awt.Shape shape48 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis44.setDownArrow(shape48);
        java.awt.Shape[] shapeArray50 = new java.awt.Shape[] { shape16, shape19, shape24, shape41, shape48 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray12, paintArray13, strokeArray14, strokeArray15, shapeArray50);
        java.awt.Stroke[] strokeArray52 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray53 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier54 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray2, paintArray3, strokeArray15, strokeArray52, shapeArray53);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rangeType23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(rangeType47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertNotNull(strokeArray52);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        double double1 = categoryPlot0.getAnchorValue();
//        java.awt.Color color3 = java.awt.Color.WHITE;
//        java.awt.Color color4 = java.awt.Color.getColor("", color3);
//        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
//        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
//        java.util.List list7 = categoryPlot0.getCategories();
//        categoryPlot0.configureRangeAxes();
//        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        categoryPlot0.setDomainAxis(100, categoryAxis11);
//        boolean boolean13 = categoryPlot0.isDomainGridlinesVisible();
//        java.awt.Color color15 = java.awt.Color.WHITE;
//        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
//        java.awt.Stroke stroke18 = dateAxis16.getTickMarkStroke();
//        java.awt.Color color19 = java.awt.Color.BLUE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
//        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
//        java.awt.Stroke stroke24 = dateAxis22.getTickMarkStroke();
//        double double25 = dateAxis22.getUpperMargin();
//        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        dateAxis22.setTickMarkStroke(stroke26);
//        categoryMarker21.setOutlineStroke(stroke26);
//        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color15, stroke18, (java.awt.Paint) color19, stroke26, (float) (short) 1);
//        categoryPlot0.setRangeCrosshairStroke(stroke18);
//        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        categoryAxis33.setMaximumCategoryLabelWidthRatio(0.0f);
//        java.awt.Color color36 = java.awt.Color.cyan;
//        categoryAxis33.setTickLabelPaint((java.awt.Paint) color36);
//        double double38 = categoryAxis33.getLowerMargin();
//        java.awt.Color color41 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
//        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
//        boolean boolean43 = color41.equals((java.lang.Object) textAnchor42);
//        categoryAxis33.setLabelPaint((java.awt.Paint) color41);
//        double double45 = categoryAxis33.getLabelAngle();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getMonth();
//        categoryAxis33.addCategoryLabelToolTip((java.lang.Comparable) day46, "SortOrder.DESCENDING");
//        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.String str53 = day52.toString();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        boolean boolean55 = day52.equals((java.lang.Object) day54);
//        java.lang.String str56 = categoryAxis51.getCategoryLabelToolTip((java.lang.Comparable) day52);
//        int int57 = categoryAxis51.getMaximumCategoryLabelLines();
//        categoryAxis51.setMaximumCategoryLabelWidthRatio(0.5f);
//        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray62 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis33, categoryAxis51, categoryAxis61 };
//        categoryPlot0.setDomainAxes(categoryAxisArray62);
//        try {
//            categoryPlot0.mapDatasetToDomainAxis((-8355712), 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertNull(valueAxis6);
//        org.junit.Assert.assertNull(list7);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(color15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(stroke24);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
//        org.junit.Assert.assertNotNull(stroke26);
//        org.junit.Assert.assertNotNull(color36);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
//        org.junit.Assert.assertNotNull(color41);
//        org.junit.Assert.assertNotNull(textAnchor42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "13-June-2019" + "'", str53.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertNull(str56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(categoryAxisArray62);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.getAutoRangeIncludesZero();
        numberAxis5.setAutoRangeStickyZero(true);
        numberAxis5.setAutoRangeIncludesZero(true);
        categoryPlot2.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot2.setDataset(0, categoryDataset14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        boolean boolean21 = dateAxis19.isVerticalTickLabels();
        dateAxis19.setTickMarkOutsideLength((float) 10);
        boolean boolean24 = dateAxis19.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isPositiveArrowVisible();
        dateAxis25.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot30.setDatasetRenderingOrder(datasetRenderingOrder31);
        double double33 = xYPlot30.getRangeCrosshairValue();
        java.awt.Paint paint34 = xYPlot30.getRangeCrosshairPaint();
        xYPlot30.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D37 = xYPlot30.getQuadrantOrigin();
        categoryPlot2.zoomDomainAxes((double) (byte) 10, plotRenderingInfo17, point2D37, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier40 = categoryPlot2.getDrawingSupplier();
        boolean boolean41 = unitType0.equals((java.lang.Object) categoryPlot2);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = categoryPlot2.getFixedLegendItems();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(point2D37);
        org.junit.Assert.assertNotNull(drawingSupplier40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(legendItemCollection42);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        double double16 = dateAxis15.getLabelAngle();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        dateAxis15.setTickMarkOutsideLength((float) 10);
        boolean boolean20 = dateAxis15.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
        dateAxis21.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot26.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean29 = xYPlot26.isRangeCrosshairVisible();
        xYPlot26.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo13, point2D32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        double double38 = dateAxis37.getLabelAngle();
        boolean boolean39 = dateAxis37.isVerticalTickLabels();
        dateAxis37.setTickMarkOutsideLength((float) 10);
        boolean boolean42 = dateAxis37.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean44 = dateAxis43.isPositiveArrowVisible();
        dateAxis43.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot48.setDatasetRenderingOrder(datasetRenderingOrder49);
        double double51 = xYPlot48.getRangeCrosshairValue();
        java.awt.Paint paint52 = xYPlot48.getRangeCrosshairPaint();
        xYPlot48.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D55 = xYPlot48.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) '4', plotRenderingInfo35, point2D55, true);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = categoryPlot0.getRendererForDataset(categoryDataset58);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(point2D55);
        org.junit.Assert.assertNull(categoryItemRenderer59);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setAutoRange(false);
        dateAxis0.resizeRange(0.0d, (double) 10);
        boolean boolean8 = dateAxis0.isHiddenValue((long) 3);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Stroke stroke11 = dateAxis9.getTickMarkStroke();
        double double12 = dateAxis9.getUpperMargin();
        dateAxis9.setTickMarkInsideLength((float) '#');
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.resizeRange((double) 255, (-12.0d));
        dateAxis15.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLabelAngle();
        boolean boolean24 = dateAxis22.isVerticalTickLabels();
        dateAxis22.setTickMarkOutsideLength((float) 10);
        boolean boolean27 = dateAxis22.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean29 = dateAxis28.isPositiveArrowVisible();
        dateAxis28.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot33.setDomainAxisLocation(axisLocation34);
        boolean boolean36 = dateAxis15.hasListener((java.util.EventListener) xYPlot33);
        dateAxis9.setPlot((org.jfree.chart.plot.Plot) xYPlot33);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        boolean boolean39 = dateAxis38.isPositiveArrowVisible();
        java.awt.Stroke stroke40 = dateAxis38.getTickMarkStroke();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis38.setTickMarkStroke(stroke41);
        org.jfree.data.Range range43 = dateAxis38.getRange();
        dateAxis9.setRangeWithMargins(range43, false, false);
        dateAxis0.setRange(range43);
        org.jfree.data.Range range48 = null;
        try {
            dateAxis0.setRange(range48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color17 = java.awt.Color.lightGray;
        categoryMarker16.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
        java.awt.Stroke stroke23 = dateAxis21.getTickMarkStroke();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis21.setTickMarkStroke(stroke24);
        org.jfree.data.Range range26 = dateAxis21.getRange();
        int int27 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.awt.Stroke stroke28 = dateAxis21.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat3 = null;
        numberAxis1.setNumberFormatOverride(numberFormat3);
        java.awt.Paint paint5 = numberAxis1.getTickLabelPaint();
        java.lang.Object obj6 = numberAxis1.clone();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        java.awt.Stroke stroke9 = dateAxis7.getTickMarkStroke();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis7.setTickMarkStroke(stroke10);
        dateAxis7.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isPositiveArrowVisible();
        java.awt.Shape shape16 = dateAxis14.getDownArrow();
        dateAxis7.setLeftArrow(shape16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.clearDomainAxes();
        java.awt.Paint paint16 = xYPlot12.getRangeTickBandPaint();
        java.awt.Paint paint17 = xYPlot12.getOutlinePaint();
        java.awt.Paint paint19 = null;
        try {
            xYPlot12.setQuadrantPaint(4, paint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (4) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("PlotOrientation.VERTICAL");
        double double2 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        xYPlot25.addChangeListener(plotChangeListener34);
        java.awt.Image image36 = null;
        xYPlot25.setBackgroundImage(image36);
        org.jfree.chart.axis.AxisSpace axisSpace38 = xYPlot25.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace39 = xYPlot25.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(axisSpace38);
        org.junit.Assert.assertNull(axisSpace39);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        boolean boolean2 = numberAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        double double4 = categoryPlot3.getAnchorValue();
        java.awt.Color color6 = java.awt.Color.WHITE;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        categoryPlot3.setDomainGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot3.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot3.getDomainAxisEdge((int) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        boolean boolean13 = numberAxis0.equals((java.lang.Object) categoryPlot3);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot3.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(sortOrder14);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot25.removeChangeListener(plotChangeListener32);
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        double double37 = dateAxis36.getLabelAngle();
        boolean boolean38 = dateAxis36.isVerticalTickLabels();
        dateAxis36.setTickMarkOutsideLength((float) 10);
        boolean boolean41 = dateAxis36.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        boolean boolean43 = dateAxis42.isPositiveArrowVisible();
        dateAxis42.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis42, xYItemRenderer46);
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot47.setDomainAxisLocation(axisLocation48);
        int int50 = xYPlot47.getWeight();
        int int51 = xYPlot47.getDomainAxisCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color55 = java.awt.Color.lightGray;
        categoryMarker54.setLabelPaint((java.awt.Paint) color55);
        java.lang.Object obj57 = categoryMarker54.clone();
        org.jfree.chart.text.TextAnchor textAnchor58 = categoryMarker54.getLabelTextAnchor();
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot47.addRangeMarker(2019, (org.jfree.chart.plot.Marker) categoryMarker54, layer59);
        try {
            xYPlot25.addDomainMarker(marker34, layer59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(textAnchor58);
        org.junit.Assert.assertNotNull(layer59);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabel("13-June-2019");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis0.getTickUnit();
        java.awt.Shape shape4 = numberAxis0.getLeftArrow();
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        int int17 = color15.getRed();
        java.awt.Color color18 = color15.darker();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double33 = rectangleInsets31.calculateBottomInset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets31.getUnitType();
        xYPlot25.setInsets(rectangleInsets31);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        double double40 = dateAxis39.getLabelAngle();
        boolean boolean41 = dateAxis39.isVerticalTickLabels();
        dateAxis39.setTickMarkOutsideLength((float) 10);
        boolean boolean44 = dateAxis39.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        boolean boolean46 = dateAxis45.isPositiveArrowVisible();
        dateAxis45.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer49);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder51 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot50.setDatasetRenderingOrder(datasetRenderingOrder51);
        double double53 = xYPlot50.getRangeCrosshairValue();
        java.awt.Paint paint54 = xYPlot50.getRangeCrosshairPaint();
        xYPlot50.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D57 = xYPlot50.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState58 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        try {
            xYPlot25.draw(graphics2D36, rectangle2D37, point2D57, plotState58, plotRenderingInfo59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33 == 3.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(point2D57);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        double double16 = categoryPlot15.getAnchorValue();
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = java.awt.Color.getColor("", color18);
        categoryPlot15.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot15.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot15.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot15.setFixedDomainAxisSpace(axisSpace24, true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot15.getRangeAxis();
        java.awt.Stroke stroke28 = categoryPlot15.getRangeCrosshairStroke();
        categoryPlot0.setDomainGridlineStroke(stroke28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace31);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(axisSpace30);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis2.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis2.setUpperMargin(0.0d);
        categoryAxis2.clearCategoryLabelToolTips();
        java.awt.Stroke stroke8 = categoryAxis2.getAxisLineStroke();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Stroke stroke11 = dateAxis9.getTickMarkStroke();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis9.setTickMarkStroke(stroke12);
        org.jfree.data.Range range14 = dateAxis9.getRange();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer15);
        categoryPlot16.clearDomainMarkers((int) (byte) 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(range14);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        int int4 = day0.getYear();
//        java.lang.String str5 = day0.toString();
//        java.util.Date date6 = day0.getEnd();
//        java.util.Calendar calendar7 = null;
//        try {
//            day0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color17 = java.awt.Color.lightGray;
        categoryMarker16.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer19);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot12.setNoDataMessageFont(font21);
        java.awt.Stroke stroke23 = xYPlot12.getRangeCrosshairStroke();
        float float24 = xYPlot12.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.5f + "'", float24 == 0.5f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Color color1 = java.awt.Color.WHITE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isPositiveArrowVisible();
        java.awt.Stroke stroke4 = dateAxis2.getTickMarkStroke();
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isPositiveArrowVisible();
        java.awt.Stroke stroke10 = dateAxis8.getTickMarkStroke();
        double double11 = dateAxis8.getUpperMargin();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis8.setTickMarkStroke(stroke12);
        categoryMarker7.setOutlineStroke(stroke12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color1, stroke4, (java.awt.Paint) color5, stroke12, (float) (short) 1);
        java.awt.Color color17 = color1.brighter();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        boolean boolean8 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        java.awt.Paint paint32 = xYPlot25.getRangeTickBandPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        double double2 = dateAxis0.getLabelAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        dateAxis0.zoomRange((double) (-1), 0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis0.getTickUnit();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(dateTickUnit7);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        xYPlot12.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D19 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = xYPlot12.getOrientation();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = xYPlot12.getFixedLegendItems();
        xYPlot12.clearDomainAxes();
        xYPlot12.zoom((double) (-2112128));
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot12.setRangeCrosshairStroke(stroke25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot25.getRangeAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot25.setFixedRangeAxisSpace(axisSpace33, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation32);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double30 = rectangleInsets28.calculateBottomInset((double) 1.0f);
        boolean boolean31 = datasetRenderingOrder27.equals((java.lang.Object) rectangleInsets28);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isPositiveArrowVisible();
        dateAxis32.setAutoRange(false);
        dateAxis32.resizeRange(0.0d, (double) 10);
        dateAxis32.setInverted(true);
        boolean boolean41 = datasetRenderingOrder27.equals((java.lang.Object) dateAxis32);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder27);
        categoryPlot0.setRangeCrosshairValue((double) (-1.0f), true);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        numberAxis46.setLabel("13-June-2019");
        org.jfree.data.Range range49 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis46);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        boolean boolean16 = xYPlot12.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        boolean boolean19 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = xYPlot12.getAxisOffset();
        xYPlot12.clearDomainMarkers((int) (byte) 0);
        java.awt.Paint paint23 = xYPlot12.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        int int32 = xYPlot25.getBackgroundImageAlignment();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis33.isPositiveArrowVisible();
        java.awt.Stroke stroke35 = dateAxis33.getTickMarkStroke();
        double double36 = dateAxis33.getUpperMargin();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis33.setTickMarkStroke(stroke37);
        xYPlot25.setDomainZeroBaselineStroke(stroke37);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot25.getRangeAxisEdge(9);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        double double43 = categoryPlot42.getAnchorValue();
        java.awt.Color color45 = java.awt.Color.WHITE;
        java.awt.Color color46 = java.awt.Color.getColor("", color45);
        categoryPlot42.setDomainGridlinePaint((java.awt.Paint) color45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot42.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot42.getDomainAxisEdge((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        categoryPlot42.setRenderer(categoryItemRenderer51);
        java.util.List list53 = categoryPlot42.getCategories();
        categoryPlot42.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection55 = categoryPlot42.getLegendItems();
        xYPlot25.setFixedLegendItems(legendItemCollection55);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = xYPlot25.getRangeAxisEdge((-8388608));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(valueAxis48);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNull(list53);
        org.junit.Assert.assertNotNull(legendItemCollection55);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis2.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis2.setUpperMargin(0.0d);
        categoryAxis2.clearCategoryLabelToolTips();
        java.awt.Stroke stroke8 = categoryAxis2.getAxisLineStroke();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Stroke stroke11 = dateAxis9.getTickMarkStroke();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis9.setTickMarkStroke(stroke12);
        org.jfree.data.Range range14 = dateAxis9.getRange();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer15);
        dateAxis9.setFixedDimension((-6.0d));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        xYPlot12.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D18 = xYPlot12.getQuadrantOrigin();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        double double22 = dateAxis21.getLabelAngle();
        boolean boolean23 = dateAxis21.isVerticalTickLabels();
        dateAxis21.setTickMarkOutsideLength((float) 10);
        boolean boolean26 = dateAxis21.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = dateAxis27.isPositiveArrowVisible();
        dateAxis27.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot32.setDomainAxisLocation(axisLocation33);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        double double37 = dateAxis36.getLabelAngle();
        boolean boolean38 = dateAxis36.isVerticalTickLabels();
        dateAxis36.setTickMarkOutsideLength((float) 10);
        boolean boolean41 = dateAxis36.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        boolean boolean43 = dateAxis42.isPositiveArrowVisible();
        dateAxis42.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis42, xYItemRenderer46);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        xYPlot47.markerChanged(markerChangeEvent48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot47.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot47.setOrientation(plotOrientation51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation33, plotOrientation51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = axisLocation33.getOpposite();
        xYPlot12.setRangeAxisLocation((int) 'a', axisLocation54, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(plotOrientation51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot32.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot32.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        double double39 = dateAxis38.getLabelAngle();
        boolean boolean40 = dateAxis38.isVerticalTickLabels();
        dateAxis38.setTickMarkOutsideLength((float) 10);
        boolean boolean43 = dateAxis38.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        boolean boolean45 = dateAxis44.isPositiveArrowVisible();
        dateAxis44.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer48);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder50 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot49.setDatasetRenderingOrder(datasetRenderingOrder50);
        double double52 = xYPlot49.getRangeCrosshairValue();
        java.awt.Paint paint53 = xYPlot49.getRangeCrosshairPaint();
        xYPlot49.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D56 = xYPlot49.getQuadrantOrigin();
        categoryPlot32.zoomDomainAxes((double) (-1L), plotRenderingInfo36, point2D56, true);
        org.jfree.chart.plot.PlotState plotState59 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        try {
            categoryPlot0.draw(graphics2D30, rectangle2D31, point2D56, plotState59, plotRenderingInfo60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(point2D56);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setAutoRange(false);
        dateAxis0.resizeRange(0.0d, (double) 10);
        org.jfree.data.Range range7 = dateAxis0.getRange();
        dateAxis0.setTickMarkOutsideLength(2.0f);
        dateAxis0.setLowerBound((double) 255);
        java.awt.Paint paint12 = dateAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        boolean boolean2 = dateAxis0.isVerticalTickLabels();
        dateAxis0.setTickMarkOutsideLength((float) 10);
        boolean boolean5 = dateAxis0.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        java.awt.Shape shape10 = numberAxis6.getRightArrow();
        dateAxis0.setLeftArrow(shape10);
        java.text.DateFormat dateFormat12 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(dateFormat12);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        boolean boolean13 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Color color15 = java.awt.Color.WHITE;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        java.awt.Stroke stroke18 = dateAxis16.getTickMarkStroke();
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
        java.awt.Stroke stroke24 = dateAxis22.getTickMarkStroke();
        double double25 = dateAxis22.getUpperMargin();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis22.setTickMarkStroke(stroke26);
        categoryMarker21.setOutlineStroke(stroke26);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color15, stroke18, (java.awt.Paint) color19, stroke26, (float) (short) 1);
        categoryPlot0.setRangeCrosshairStroke(stroke18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        int int33 = categoryPlot0.getIndexOf(categoryItemRenderer32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot25.setRangeAxisLocation(0, axisLocation33, false);
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str37 = textAnchor36.toString();
        boolean boolean38 = xYPlot25.equals((java.lang.Object) textAnchor36);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        boolean boolean40 = dateAxis39.isPositiveArrowVisible();
        java.awt.Stroke stroke41 = dateAxis39.getTickMarkStroke();
        boolean boolean42 = dateAxis39.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean44 = dateAxis43.isPositiveArrowVisible();
        java.awt.Stroke stroke45 = dateAxis43.getTickMarkStroke();
        java.awt.Stroke stroke46 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis43.setTickMarkStroke(stroke46);
        org.jfree.data.Range range48 = dateAxis43.getRange();
        dateAxis39.setRange(range48);
        org.jfree.data.Range range50 = xYPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis39);
        org.jfree.chart.axis.AxisSpace axisSpace51 = null;
        xYPlot25.setFixedDomainAxisSpace(axisSpace51, true);
        java.awt.Stroke stroke54 = xYPlot25.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str37.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.awt.Color color3 = java.awt.Color.getHSBColor(10.0f, (float) 7, (float) (byte) 10);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Category Plot");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Font font3 = categoryAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
        dateAxis0.setLowerMargin((double) 7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis0.getStandardTickUnits();
        boolean boolean8 = dateAxis0.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        dateAxis9.setAutoRange(false);
        dateAxis9.resizeRange(0.0d, (double) 10);
        java.util.Date date16 = dateAxis9.getMinimumDate();
        dateAxis0.setMinimumDate(date16);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        xYPlot25.addChangeListener(plotChangeListener34);
        boolean boolean36 = xYPlot25.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        xYPlot12.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        java.awt.Paint paint18 = xYPlot12.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot12.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setAutoRange(false);
        dateAxis0.resizeRange(0.0d, (double) 10);
        java.util.Date date7 = dateAxis0.getMinimumDate();
        dateAxis0.setUpperMargin((double) 0.0f);
        dateAxis0.setLowerBound((double) 11);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis0.getLabelInsets();
        double double14 = rectangleInsets12.trimWidth((double) (-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-7.0d) + "'", double14 == (-7.0d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer(categoryItemRenderer14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double19 = rectangleInsets18.getLeft();
        double double21 = rectangleInsets18.calculateTopOutset((double) 100L);
        double double22 = rectangleInsets18.getLeft();
        double double24 = rectangleInsets18.calculateTopOutset(1.560452400015E12d);
        double double26 = rectangleInsets18.calculateTopInset((double) 8);
        categoryPlot0.setAxisOffset(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        categoryMarker1.setDrawAsLine(false);
        org.jfree.chart.text.TextAnchor textAnchor4 = categoryMarker1.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryMarker1.getLabelOffset();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLabelAngle();
        boolean boolean9 = dateAxis7.isVerticalTickLabels();
        dateAxis7.setTickMarkOutsideLength((float) 10);
        boolean boolean12 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        dateAxis13.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        double double21 = dateAxis20.getLabelAngle();
        boolean boolean22 = dateAxis20.isVerticalTickLabels();
        dateAxis20.setTickMarkOutsideLength((float) 10);
        boolean boolean25 = dateAxis20.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        dateAxis26.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = xYPlot31.getDrawingSupplier();
        dateAxis7.setPlot((org.jfree.chart.plot.Plot) xYPlot31);
        java.awt.Stroke stroke36 = xYPlot31.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot31.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        xYPlot31.setRangeAxis(valueAxis38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = xYPlot31.getFixedLegendItems();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        boolean boolean42 = dateAxis41.isPositiveArrowVisible();
        java.awt.Stroke stroke43 = dateAxis41.getTickMarkStroke();
        java.awt.Stroke stroke44 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis41.setTickMarkStroke(stroke44);
        xYPlot31.setDomainCrosshairStroke(stroke44);
        categoryMarker1.setOutlineStroke(stroke44);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange((double) 255, (-12.0d));
        dateAxis0.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLabelAngle();
        boolean boolean9 = dateAxis7.isVerticalTickLabels();
        dateAxis7.setTickMarkOutsideLength((float) 10);
        boolean boolean12 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        dateAxis13.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot18.setDomainAxisLocation(axisLocation19);
        boolean boolean21 = dateAxis0.hasListener((java.util.EventListener) xYPlot18);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        dateAxis0.setTickLabelInsets(rectangleInsets22);
        org.jfree.data.Range range24 = dateAxis0.getDefaultAutoRange();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        double double30 = categoryPlot29.getAnchorValue();
        java.awt.Color color32 = java.awt.Color.WHITE;
        java.awt.Color color33 = java.awt.Color.getColor("", color32);
        categoryPlot29.setDomainGridlinePaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot29.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot29.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        try {
            org.jfree.chart.axis.AxisState axisState39 = dateAxis0.draw(graphics2D25, 0.0d, rectangle2D27, rectangle2D28, rectangleEdge37, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis0.removeChangeListener(axisChangeListener2);
        numberAxis0.setLabel("hi!");
        numberAxis0.setLowerMargin((-1.0d));
        numberAxis0.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        categoryPlot0.setNoDataMessage("RectangleAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleAnchor.TOP_LEFT");
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(axisLocation13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot12.getDomainAxis();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(valueAxis15);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        boolean boolean16 = xYPlot12.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        boolean boolean19 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        java.awt.Stroke stroke22 = dateAxis20.getTickMarkStroke();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis20.setTickMarkStroke(stroke23);
        dateAxis20.setVerticalTickLabels(true);
        double double27 = dateAxis20.getUpperBound();
        org.jfree.data.Range range28 = xYPlot12.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        dateAxis20.setAutoRangeMinimumSize((double) 5);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        double double33 = dateAxis32.getLabelAngle();
        boolean boolean34 = dateAxis32.isVerticalTickLabels();
        dateAxis32.setTickMarkOutsideLength((float) 10);
        boolean boolean37 = dateAxis32.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        boolean boolean39 = dateAxis38.isPositiveArrowVisible();
        dateAxis38.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer42);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder44 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot43.setDatasetRenderingOrder(datasetRenderingOrder44);
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color48 = java.awt.Color.lightGray;
        categoryMarker47.setLabelPaint((java.awt.Paint) color48);
        org.jfree.chart.util.Layer layer50 = null;
        boolean boolean51 = xYPlot43.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker47, layer50);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot43.setNoDataMessageFont(font52);
        java.awt.Stroke stroke54 = xYPlot43.getRangeCrosshairStroke();
        dateAxis20.setAxisLineStroke(stroke54);
        dateAxis20.setInverted(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        xYPlot25.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset35 = xYPlot25.getDataset();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        xYPlot25.setRenderer((int) (byte) 10, xYItemRenderer37);
        boolean boolean39 = xYPlot25.isDomainCrosshairVisible();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation40 = null;
        try {
            xYPlot25.addAnnotation(xYAnnotation40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        double double16 = dateAxis15.getLabelAngle();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        dateAxis15.setTickMarkOutsideLength((float) 10);
        boolean boolean20 = dateAxis15.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
        dateAxis21.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot26.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean29 = xYPlot26.isRangeCrosshairVisible();
        xYPlot26.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo13, point2D32);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis36.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color39 = java.awt.Color.cyan;
        categoryAxis36.setTickLabelPaint((java.awt.Paint) color39);
        double double41 = categoryAxis36.getLowerMargin();
        java.awt.Font font43 = categoryAxis36.getTickLabelFont((java.lang.Comparable) 5);
        float float44 = categoryAxis36.getMaximumCategoryLabelWidthRatio();
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis36, false);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot0.getRangeAxisLocation(0);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation48);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        int int32 = xYPlot25.getIndexOf(xYItemRenderer31);
        int int33 = xYPlot25.getRangeAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = xYPlot25.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(legendItemCollection34);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLabelAngle();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        dateAxis12.setTickMarkOutsideLength((float) 10);
        boolean boolean17 = dateAxis12.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isPositiveArrowVisible();
        dateAxis18.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        double double26 = dateAxis25.getLabelAngle();
        boolean boolean27 = dateAxis25.isVerticalTickLabels();
        dateAxis25.setTickMarkOutsideLength((float) 10);
        boolean boolean30 = dateAxis25.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        boolean boolean32 = dateAxis31.isPositiveArrowVisible();
        dateAxis31.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot36.setDatasetRenderingOrder(datasetRenderingOrder37);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier39 = xYPlot36.getDrawingSupplier();
        dateAxis12.setPlot((org.jfree.chart.plot.Plot) xYPlot36);
        java.lang.String str41 = xYPlot36.getPlotType();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(drawingSupplier39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "XY Plot" + "'", str41.equals("XY Plot"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setAutoRange(false);
        dateAxis0.resizeRange(0.0d, (double) 10);
        java.util.Date date7 = dateAxis0.getMinimumDate();
        boolean boolean8 = dateAxis0.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        boolean boolean3 = dateAxis0.isInverted();
        java.awt.Shape shape4 = dateAxis0.getRightArrow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace11, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        xYPlot25.addChangeListener(plotChangeListener34);
        xYPlot25.setRangeCrosshairValue((double) 10L, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent22 = null;
        xYPlot21.markerChanged(markerChangeEvent22);
        xYPlot21.setDomainZeroBaselineVisible(false);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.util.List list28 = null;
        xYPlot21.drawDomainTickBands(graphics2D26, rectangle2D27, list28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = xYPlot21.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier30);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot0.setDataset((int) (byte) 10, categoryDataset33);
        int int35 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 1560452399999L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        java.lang.String str16 = xYPlot12.getNoDataMessage();
        xYPlot12.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot12.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot12.setFixedDomainAxisSpace(axisSpace21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        double double27 = dateAxis26.getLabelAngle();
        boolean boolean28 = dateAxis26.isVerticalTickLabels();
        dateAxis26.setTickMarkOutsideLength((float) 10);
        boolean boolean31 = dateAxis26.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isPositiveArrowVisible();
        dateAxis32.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer36);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot37.setDatasetRenderingOrder(datasetRenderingOrder38);
        double double40 = xYPlot37.getRangeCrosshairValue();
        java.awt.Paint paint41 = xYPlot37.getRangeCrosshairPaint();
        xYPlot37.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D44 = xYPlot37.getQuadrantOrigin();
        xYPlot12.zoomDomainAxes((double) 2.0f, plotRenderingInfo24, point2D44);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(point2D44);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Stroke stroke4 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        double double6 = categoryPlot5.getAnchorValue();
        java.awt.Color color8 = java.awt.Color.WHITE;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        categoryPlot5.setDomainGridlinePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot5.getRangeAxis();
        java.util.List list12 = categoryPlot5.getCategories();
        categoryPlot5.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot5.setDomainAxis(100, categoryAxis16);
        categoryPlot0.setDomainAxis(categoryAxis16);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        double double24 = dateAxis23.getLabelAngle();
        boolean boolean25 = dateAxis23.isVerticalTickLabels();
        dateAxis23.setTickMarkOutsideLength((float) 10);
        boolean boolean28 = dateAxis23.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isPositiveArrowVisible();
        dateAxis29.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer33);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot34.setDatasetRenderingOrder(datasetRenderingOrder35);
        double double37 = xYPlot34.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = xYPlot34.getRangeMarkers(layer38);
        java.lang.Class<?> wildcardClass40 = xYPlot34.getClass();
        java.awt.Font font41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot34.setNoDataMessageFont(font41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = xYPlot34.getRangeAxisEdge(10);
        try {
            double double45 = categoryAxis16.getCategoryMiddle((int) (byte) 10, (-16711681), rectangle2D21, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(list12);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        categoryMarker35.setDrawAsLine(false);
        boolean boolean38 = xYPlot25.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setPositiveArrowVisible(true);
        dateAxis0.setFixedAutoRange(1.0E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-6.0d), (double) 10.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str5 = chartChangeEventType4.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) intervalMarker2, jFreeChart3, chartChangeEventType4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker2.setLabelAnchor(rectangleAnchor7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        intervalMarker2.setPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(color9);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot0.clearDomainMarkers();
//        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
//        org.jfree.data.xy.XYDataset xYDataset5 = null;
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
//        double double7 = dateAxis6.getLabelAngle();
//        boolean boolean8 = dateAxis6.isVerticalTickLabels();
//        dateAxis6.setTickMarkOutsideLength((float) 10);
//        boolean boolean11 = dateAxis6.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
//        dateAxis12.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
//        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
//        double double20 = xYPlot17.getRangeCrosshairValue();
//        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
//        xYPlot17.setDomainCrosshairLockedOnData(false);
//        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
//        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
//        categoryPlot0.configureDomainAxes();
//        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
//        categoryPlot0.setFixedDomainAxisSpace(axisSpace28);
//        categoryPlot0.setDrawSharedDomainAxis(true);
//        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        boolean boolean38 = day35.equals((java.lang.Object) day37);
//        java.lang.String str39 = categoryAxis34.getCategoryLabelToolTip((java.lang.Comparable) day35);
//        categoryAxis34.setAxisLineVisible(true);
//        categoryPlot0.setDomainAxis((int) (byte) 100, categoryAxis34);
//        org.junit.Assert.assertNotNull(rectangleEdge2);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertNotNull(paint21);
//        org.junit.Assert.assertNotNull(point2D24);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNull(str39);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLabelAngle();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        dateAxis3.setTickMarkOutsideLength((float) 10);
        boolean boolean8 = dateAxis3.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        dateAxis9.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        double double17 = dateAxis16.getLabelAngle();
        boolean boolean18 = dateAxis16.isVerticalTickLabels();
        dateAxis16.setTickMarkOutsideLength((float) 10);
        boolean boolean21 = dateAxis16.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
        dateAxis22.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot27.setDatasetRenderingOrder(datasetRenderingOrder28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = xYPlot27.getDrawingSupplier();
        dateAxis3.setPlot((org.jfree.chart.plot.Plot) xYPlot27);
        java.lang.String str32 = xYPlot27.getPlotType();
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot27.setDomainZeroBaselineStroke(stroke33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot27.setBackgroundPaint((java.awt.Paint) color35);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color35);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertNotNull(drawingSupplier30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "XY Plot" + "'", str32.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        boolean boolean2 = dateAxis0.isVerticalTickLabels();
        dateAxis0.setTickMarkOutsideLength((float) 10);
        boolean boolean5 = dateAxis0.isTickLabelsVisible();
        dateAxis0.resizeRange((double) 10);
        java.lang.Class<?> wildcardClass8 = dateAxis0.getClass();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis0.setTimeZone(timeZone9);
        double double11 = dateAxis0.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        double double9 = dateAxis8.getLabelAngle();
        boolean boolean10 = dateAxis8.isVerticalTickLabels();
        dateAxis8.setTickMarkOutsideLength((float) 10);
        boolean boolean13 = dateAxis8.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isPositiveArrowVisible();
        dateAxis14.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot19.setDatasetRenderingOrder(datasetRenderingOrder20);
        boolean boolean22 = xYPlot19.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot19.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        java.awt.Stroke stroke28 = dateAxis26.getTickMarkStroke();
        double double29 = dateAxis26.getUpperMargin();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis26.setTickMarkStroke(stroke30);
        categoryMarker25.setOutlineStroke(stroke30);
        org.jfree.chart.util.Layer layer33 = null;
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25, layer33);
        boolean boolean35 = categoryAxis1.equals((java.lang.Object) xYPlot19);
        double double36 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setPositiveArrowVisible(true);
        java.lang.String str4 = dateAxis0.getLabel();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot25.setDomainZeroBaselineStroke(stroke31);
        boolean boolean33 = xYPlot25.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setAxisLineStroke(stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLabelAngle();
        dateAxis5.setPositiveArrowVisible(true);
        dateAxis5.setUpperMargin(1.0d);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isPositiveArrowVisible();
        java.awt.Stroke stroke13 = dateAxis11.getTickMarkStroke();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis11.setTickMarkStroke(stroke14);
        dateAxis11.setVerticalTickLabels(true);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isPositiveArrowVisible();
        java.awt.Shape shape20 = dateAxis18.getDownArrow();
        dateAxis11.setLeftArrow(shape20);
        dateAxis5.setDownArrow(shape20);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis5.setTickUnit(dateTickUnit23);
        java.util.Date date25 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit23);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateLeftOutset((double) (-1783));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        dateAxis0.setTickMarkInsideLength((float) '#');
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.resizeRange((double) 255, (-12.0d));
        dateAxis6.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getLabelAngle();
        boolean boolean15 = dateAxis13.isVerticalTickLabels();
        dateAxis13.setTickMarkOutsideLength((float) 10);
        boolean boolean18 = dateAxis13.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        dateAxis19.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot24.setDomainAxisLocation(axisLocation25);
        boolean boolean27 = dateAxis6.hasListener((java.util.EventListener) xYPlot24);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot24);
        dateAxis0.setUpperMargin(10.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.xy.XYDataset xYDataset6 = null;
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
//        double double8 = dateAxis7.getLabelAngle();
//        boolean boolean9 = dateAxis7.isVerticalTickLabels();
//        dateAxis7.setTickMarkOutsideLength((float) 10);
//        boolean boolean12 = dateAxis7.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
//        dateAxis13.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
//        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer17);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        xYPlot18.setDatasetRenderingOrder(datasetRenderingOrder19);
//        xYPlot18.clearDomainAxes();
//        java.awt.Paint paint22 = xYPlot18.getRangeTickBandPaint();
//        java.awt.Paint paint23 = xYPlot18.getOutlinePaint();
//        int int24 = day0.compareTo((java.lang.Object) xYPlot18);
//        java.util.List list25 = xYPlot18.getAnnotations();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
//        org.junit.Assert.assertNull(paint22);
//        org.junit.Assert.assertNotNull(paint23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(list25);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        xYPlot12.setBackgroundImageAlpha((float) 1L);
        org.jfree.data.general.DatasetGroup datasetGroup18 = xYPlot12.getDatasetGroup();
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot12.getFixedDomainAxisSpace();
        xYPlot12.setRangeCrosshairValue((double) '#');
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot12.getDomainAxisLocation(0);
        xYPlot12.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(axisLocation23);
    }
}

