import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.lang.Class class2 = null;
        try {
            java.util.EventListener[] eventListenerArray3 = categoryMarker1.getListeners(class2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = null;
        try {
            categoryMarker1.setLabelAnchor(rectangleAnchor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets1.getLeft();
        double double4 = rectangleInsets1.calculateTopOutset((double) 100L);
        boolean boolean5 = textAnchor0.equals((java.lang.Object) rectangleInsets1);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets1.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color0 = java.awt.Color.green;
        boolean boolean2 = color0.equals((java.lang.Object) 3.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0d, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1.0f);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) seriesRenderingOrder0);
        boolean boolean3 = seriesRenderingOrder0.equals((java.lang.Object) 10.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Paint paint1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isPositiveArrowVisible();
        java.awt.Stroke stroke4 = dateAxis2.getTickMarkStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color7 = java.awt.Color.lightGray;
        categoryMarker6.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Stroke stroke11 = dateAxis9.getTickMarkStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 255, paint1, stroke4, (java.awt.Paint) color7, stroke11, 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isPositiveArrowVisible();
        boolean boolean3 = textAnchor0.equals((java.lang.Object) boolean2);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        java.awt.Paint paint4 = dateAxis0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setAutoRange(false);
        org.jfree.data.Range range4 = null;
        try {
            dateAxis0.setRange(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        boolean boolean2 = dateAxis0.isVerticalTickLabels();
        dateAxis0.setTickMarkOutsideLength((float) 10);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis0.java2DToValue((double) 1, rectangle2D6, rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.223372036854776E18d + "'", double8 == 9.223372036854776E18d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1.0f);
        double double4 = rectangleInsets0.trimWidth((-6.0d));
        double double6 = rectangleInsets0.calculateTopOutset((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-12.0d) + "'", double4 == (-12.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        try {
            xYPlot12.zoomRangeAxes((double) '4', plotRenderingInfo17, point2D18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        java.awt.Paint paint14 = xYPlot12.getNoDataMessagePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        try {
            xYPlot12.zoomDomainAxes((double) 100, (double) 0, plotRenderingInfo17, point2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        try {
            xYPlot12.zoomDomainAxes((double) 10L, (double) (short) -1, plotRenderingInfo16, point2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = null;
        try {
            numberAxis0.setRangeType(rangeType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        try {
            xYPlot25.zoomDomainAxes((double) 100, plotRenderingInfo31, point2D32, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isPositiveArrowVisible();
        java.awt.Stroke stroke34 = dateAxis32.getTickMarkStroke();
        boolean boolean35 = dateAxis32.isTickLabelsVisible();
        java.awt.Color color37 = java.awt.Color.WHITE;
        java.awt.Color color38 = java.awt.Color.getColor("", color37);
        dateAxis32.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline41 = null;
        dateAxis40.setTimeline(timeline41);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        double double44 = dateAxis43.getLabelAngle();
        boolean boolean45 = dateAxis43.isVerticalTickLabels();
        dateAxis43.setTickMarkOutsideLength((float) 10);
        boolean boolean48 = dateAxis43.isTickLabelsVisible();
        dateAxis43.resizeRange((double) 10);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray51 = new org.jfree.chart.axis.ValueAxis[] { dateAxis32, dateAxis40, dateAxis43 };
        try {
            xYPlot25.setDomainAxes(valueAxisArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(valueAxisArray51);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        float float2 = dateAxis0.getTickMarkInsideLength();
        java.awt.Shape shape3 = null;
        try {
            dateAxis0.setLeftArrow(shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Color color2 = java.awt.Color.WHITE;
        java.awt.Color color3 = java.awt.Color.getColor("", color2);
        int int4 = color2.getRed();
        java.awt.Stroke stroke5 = null;
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        java.awt.Stroke stroke9 = dateAxis7.getTickMarkStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint) color2, stroke5, paint6, stroke9, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.clearDomainAxes();
        java.awt.Paint paint16 = xYPlot12.getRangeTickBandPaint();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            xYPlot12.drawBackground(graphics2D17, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline5 = null;
        dateAxis4.setTimeline(timeline5);
        java.util.Date date7 = dateAxis4.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline9 = null;
        dateAxis8.setTimeline(timeline9);
        java.util.Date date11 = dateAxis8.getMinimumDate();
        try {
            dateAxis0.setRange(date7, date11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        java.awt.Font font14 = null;
        try {
            xYPlot12.setNoDataMessageFont(font14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        org.jfree.chart.plot.Marker marker34 = null;
        try {
            xYPlot25.addDomainMarker(marker34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        dateAxis0.setTickMarkInsideLength((float) '#');
        double double6 = dateAxis0.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLabelAngle();
        boolean boolean6 = dateAxis4.isVerticalTickLabels();
        dateAxis4.setTickMarkOutsideLength((float) 10);
        boolean boolean9 = dateAxis4.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isPositiveArrowVisible();
        dateAxis10.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = xYPlot28.getDrawingSupplier();
        dateAxis4.setPlot((org.jfree.chart.plot.Plot) xYPlot28);
        java.awt.Stroke stroke33 = xYPlot28.getDomainZeroBaselineStroke();
        java.awt.Paint paint34 = xYPlot28.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace38 = dateAxis0.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) xYPlot28, rectangle2D35, rectangleEdge36, axisSpace37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(drawingSupplier31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        boolean boolean4 = dateAxis0.isAutoRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        java.util.Date date4 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis5.setTimeline(timeline6);
        java.util.Date date8 = dateAxis5.getMinimumDate();
        try {
            dateAxis0.setRange(date4, date8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis2.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color5 = java.awt.Color.cyan;
        categoryAxis2.setTickLabelPaint((java.awt.Paint) color5);
        double double7 = categoryAxis2.getLowerMargin();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline9 = null;
        dateAxis8.setTimeline(timeline9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis8.setAxisLineStroke(stroke11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis8, categoryItemRenderer13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot25.setFixedRangeAxisSpace(axisSpace32, true);
        xYPlot25.setRangeCrosshairValue((double) 9);
        try {
            java.awt.Paint paint38 = xYPlot25.getQuadrantPaint((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.clearDomainAxes();
        java.awt.Paint paint16 = xYPlot12.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline19 = null;
        dateAxis18.setTimeline(timeline19);
        java.util.Date date21 = dateAxis18.getMinimumDate();
        try {
            xYPlot12.setDomainAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) dateAxis18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        java.lang.Object obj14 = xYPlot12.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        java.lang.Comparable comparable6 = null;
        try {
            java.awt.Font font7 = categoryAxis1.getTickLabelFont(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleAnchor.BOTTOM_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleAnchor.BOTTOM_LEFT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        try {
            org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot25.getDomainAxisForDataset((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 35 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = numberAxis0.getRangeType();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLabelAngle();
        boolean boolean7 = dateAxis5.isVerticalTickLabels();
        dateAxis5.setTickMarkOutsideLength((float) 10);
        boolean boolean10 = dateAxis5.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isPositiveArrowVisible();
        dateAxis11.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer15);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot16.setDatasetRenderingOrder(datasetRenderingOrder17);
        java.awt.Color color19 = java.awt.Color.cyan;
        xYPlot16.setNoDataMessagePaint((java.awt.Paint) color19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot16.getDomainAxisEdge();
        try {
            double double22 = numberAxis0.java2DToValue((double) 3, rectangle2D3, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getLabelAngle();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        dateAxis11.setTickMarkOutsideLength((float) 10);
        boolean boolean16 = dateAxis11.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isPositiveArrowVisible();
        dateAxis17.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot22.setDatasetRenderingOrder(datasetRenderingOrder23);
        java.awt.Color color25 = java.awt.Color.cyan;
        xYPlot22.setNoDataMessagePaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot22.getDomainAxisEdge();
        try {
            java.util.List list28 = categoryAxis1.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        double double9 = dateAxis8.getLabelAngle();
        boolean boolean10 = dateAxis8.isVerticalTickLabels();
        dateAxis8.setTickMarkOutsideLength((float) 10);
        boolean boolean13 = dateAxis8.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isPositiveArrowVisible();
        dateAxis14.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot19.setDatasetRenderingOrder(datasetRenderingOrder20);
        java.awt.Color color22 = java.awt.Color.cyan;
        xYPlot19.setNoDataMessagePaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot19.getDomainAxisEdge();
        try {
            double double25 = categoryAxis1.getCategoryEnd(0, (int) '#', rectangle2D6, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateTopOutset((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateTopOutset((double) 100L);
        double double4 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Paint paint2 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isPositiveArrowVisible();
        java.awt.Stroke stroke7 = dateAxis5.getTickMarkStroke();
        double double8 = dateAxis5.getUpperMargin();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis5.setTickMarkStroke(stroke9);
        categoryMarker4.setOutlineStroke(stroke9);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getLabelAngle();
        boolean boolean15 = dateAxis13.isVerticalTickLabels();
        dateAxis13.setTickMarkOutsideLength((float) 10);
        boolean boolean18 = dateAxis13.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        dateAxis19.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer23);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot24.setDatasetRenderingOrder(datasetRenderingOrder25);
        double double27 = xYPlot24.getRangeCrosshairValue();
        java.awt.Paint paint28 = xYPlot24.getRangeCrosshairPaint();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 10L, (-1.0d), paint2, stroke9, paint28, stroke29, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) seriesRenderingOrder0);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        chartChangeEvent1.setChart(jFreeChart2);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        boolean boolean13 = xYPlot12.isSubplot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        double double24 = dateAxis23.getLabelAngle();
        boolean boolean25 = dateAxis23.isVerticalTickLabels();
        dateAxis23.setTickMarkOutsideLength((float) 10);
        boolean boolean28 = dateAxis23.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isPositiveArrowVisible();
        dateAxis29.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer33);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot34.setDatasetRenderingOrder(datasetRenderingOrder35);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = xYPlot34.getDrawingSupplier();
        dateAxis10.setPlot((org.jfree.chart.plot.Plot) xYPlot34);
        java.awt.Stroke stroke39 = xYPlot34.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot34.getDomainAxisLocation();
        int int41 = xYPlot34.getBackgroundImageAlignment();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        double double45 = dateAxis44.getLabelAngle();
        boolean boolean46 = dateAxis44.isVerticalTickLabels();
        dateAxis44.setTickMarkOutsideLength((float) 10);
        boolean boolean49 = dateAxis44.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        boolean boolean51 = dateAxis50.isPositiveArrowVisible();
        dateAxis50.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) dateAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis50, xYItemRenderer54);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder56 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot55.setDatasetRenderingOrder(datasetRenderingOrder56);
        java.awt.Color color58 = java.awt.Color.cyan;
        xYPlot55.setNoDataMessagePaint((java.awt.Paint) color58);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = xYPlot55.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace61 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace62 = categoryAxis1.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) xYPlot34, rectangle2D42, rectangleEdge60, axisSpace61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
        org.junit.Assert.assertNotNull(drawingSupplier37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 15 + "'", int41 == 15);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder56);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(rectangleEdge60);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = java.awt.Color.cyan;
        xYPlot12.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot12.getDomainAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double19 = rectangleInsets18.getLeft();
        double double21 = rectangleInsets18.calculateTopOutset((double) 100L);
        xYPlot12.setInsets(rectangleInsets18);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets18.createInsetRectangle(rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = java.awt.Color.cyan;
        xYPlot12.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot12.getDomainAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double19 = rectangleInsets18.getLeft();
        double double21 = rectangleInsets18.calculateTopOutset((double) 100L);
        xYPlot12.setInsets(rectangleInsets18);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot12.setFixedRangeAxisSpace(axisSpace23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        double double29 = dateAxis28.getLabelAngle();
        boolean boolean30 = dateAxis28.isVerticalTickLabels();
        dateAxis28.setTickMarkOutsideLength((float) 10);
        boolean boolean33 = dateAxis28.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isPositiveArrowVisible();
        dateAxis34.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer38);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder40 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot39.setDatasetRenderingOrder(datasetRenderingOrder40);
        double double42 = xYPlot39.getRangeCrosshairValue();
        java.awt.Paint paint43 = xYPlot39.getRangeCrosshairPaint();
        xYPlot39.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D46 = xYPlot39.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            xYPlot12.draw(graphics2D25, rectangle2D26, point2D46, plotState47, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        double double21 = dateAxis20.getLabelAngle();
        boolean boolean22 = dateAxis20.isVerticalTickLabels();
        dateAxis20.setTickMarkOutsideLength((float) 10);
        boolean boolean25 = dateAxis20.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        dateAxis26.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder32);
        double double34 = xYPlot31.getRangeCrosshairValue();
        java.awt.Paint paint35 = xYPlot31.getRangeCrosshairPaint();
        xYPlot31.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D38 = xYPlot31.getQuadrantOrigin();
        try {
            xYPlot12.zoomDomainAxes((double) 11, 0.0d, plotRenderingInfo18, point2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (11.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(point2D38);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        double double9 = dateAxis8.getLabelAngle();
        boolean boolean10 = dateAxis8.isVerticalTickLabels();
        dateAxis8.setTickMarkOutsideLength((float) 10);
        boolean boolean13 = dateAxis8.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isPositiveArrowVisible();
        dateAxis14.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot19.setDatasetRenderingOrder(datasetRenderingOrder20);
        boolean boolean22 = xYPlot19.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot19.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        java.awt.Stroke stroke28 = dateAxis26.getTickMarkStroke();
        double double29 = dateAxis26.getUpperMargin();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis26.setTickMarkStroke(stroke30);
        categoryMarker25.setOutlineStroke(stroke30);
        org.jfree.chart.util.Layer layer33 = null;
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25, layer33);
        boolean boolean35 = categoryAxis1.equals((java.lang.Object) xYPlot19);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation36 = null;
        try {
            xYPlot19.addAnnotation(xYAnnotation36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            java.awt.Color color1 = java.awt.Color.decode("13-June-2019");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"13-June-2019\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getEnd();
//        java.util.TimeZone timeZone3 = null;
//        try {
//            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        java.awt.Paint paint17 = xYPlot12.getNoDataMessagePaint();
        java.awt.Color color20 = java.awt.Color.WHITE;
        java.awt.Color color21 = java.awt.Color.getColor("", color20);
        try {
            xYPlot12.setQuadrantPaint((int) (byte) 10, (java.awt.Paint) color20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        xYPlot12.clearDomainMarkers();
        java.lang.Object obj14 = xYPlot12.clone();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot12.getDataset(5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNull(xYDataset16);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        int int2 = categoryPlot0.getWeight();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setTickMarkStroke(stroke3);
        dateAxis0.setVerticalTickLabels(true);
        double double7 = dateAxis0.getUpperBound();
        dateAxis0.setLabelAngle((double) 7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 0, (double) 0.0f, (-12.0d), (double) (-1.0f));
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets5.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightOutset((double) 9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            categoryPlot0.drawBackground(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        boolean boolean2 = dateAxis0.isVerticalTickLabels();
        dateAxis0.setTickMarkOutsideLength((float) 10);
        boolean boolean5 = dateAxis0.isTickLabelsVisible();
        dateAxis0.resizeRange((double) 10);
        dateAxis0.setUpperMargin(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        categoryAxis1.setCategoryLabelPositionOffset(4);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        xYPlot17.markerChanged(markerChangeEvent18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot17.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = numberAxis0.draw(graphics2D1, (-6.0d), rectangle2D3, rectangle2D4, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Color color1 = java.awt.Color.WHITE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isPositiveArrowVisible();
        java.awt.Stroke stroke4 = dateAxis2.getTickMarkStroke();
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isPositiveArrowVisible();
        java.awt.Stroke stroke10 = dateAxis8.getTickMarkStroke();
        double double11 = dateAxis8.getUpperMargin();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis8.setTickMarkStroke(stroke12);
        categoryMarker7.setOutlineStroke(stroke12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color1, stroke4, (java.awt.Paint) color5, stroke12, (float) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot29.setDatasetRenderingOrder(datasetRenderingOrder30);
        double double32 = xYPlot29.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = xYPlot29.getRangeMarkers(layer33);
        java.awt.Stroke stroke35 = xYPlot29.getRangeCrosshairStroke();
        xYPlot29.mapDatasetToRangeAxis(100, 0);
        categoryMarker16.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot29);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        java.awt.Stroke stroke18 = xYPlot12.getRangeCrosshairStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = xYPlot12.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(legendItemCollection19);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis5.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis5.setUpperMargin(0.0d);
        categoryAxis5.clearCategoryLabelToolTips();
        try {
            objectList0.set((int) (short) -1, (java.lang.Object) categoryAxis5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (short) 10, "DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLabelAngle();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        dateAxis12.setTickMarkOutsideLength((float) 10);
        boolean boolean17 = dateAxis12.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isPositiveArrowVisible();
        dateAxis18.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot23.setDatasetRenderingOrder(datasetRenderingOrder24);
        java.awt.Color color26 = java.awt.Color.cyan;
        xYPlot23.setNoDataMessagePaint((java.awt.Paint) color26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot23.getDomainAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double30 = rectangleInsets29.getLeft();
        double double32 = rectangleInsets29.calculateTopOutset((double) 100L);
        xYPlot23.setInsets(rectangleInsets29);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        xYPlot23.setFixedRangeAxisSpace(axisSpace34);
        boolean boolean36 = categoryAnchor10.equals((java.lang.Object) axisSpace34);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        double double42 = dateAxis41.getLabelAngle();
        boolean boolean43 = dateAxis41.isVerticalTickLabels();
        dateAxis41.setTickMarkOutsideLength((float) 10);
        boolean boolean46 = dateAxis41.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        boolean boolean48 = dateAxis47.isPositiveArrowVisible();
        dateAxis47.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer51);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder53 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot52.setDatasetRenderingOrder(datasetRenderingOrder53);
        java.awt.Color color55 = java.awt.Color.cyan;
        xYPlot52.setNoDataMessagePaint((java.awt.Paint) color55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = xYPlot52.getDomainAxisEdge();
        try {
            double double58 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor10, 11, 9, rectangle2D39, rectangleEdge57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabel("13-June-2019");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis0.getTickUnit();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getDomainAxisEdge();
        try {
            java.util.List list10 = numberAxis0.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange((double) 255, (-12.0d));
        dateAxis0.setPositiveArrowVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot9.getRangeAxisEdge();
        try {
            java.util.List list12 = dateAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean5 = day2.equals((java.lang.Object) day4);
//        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day2);
//        org.jfree.data.xy.XYDataset xYDataset7 = null;
//        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
//        double double9 = dateAxis8.getLabelAngle();
//        boolean boolean10 = dateAxis8.isVerticalTickLabels();
//        dateAxis8.setTickMarkOutsideLength((float) 10);
//        boolean boolean13 = dateAxis8.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean15 = dateAxis14.isPositiveArrowVisible();
//        dateAxis14.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
//        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
//        org.jfree.data.xy.XYDataset xYDataset20 = null;
//        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
//        double double22 = dateAxis21.getLabelAngle();
//        boolean boolean23 = dateAxis21.isVerticalTickLabels();
//        dateAxis21.setTickMarkOutsideLength((float) 10);
//        boolean boolean26 = dateAxis21.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean28 = dateAxis27.isPositiveArrowVisible();
//        dateAxis27.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
//        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer31);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        xYPlot32.setDatasetRenderingOrder(datasetRenderingOrder33);
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = xYPlot32.getDrawingSupplier();
//        dateAxis8.setPlot((org.jfree.chart.plot.Plot) xYPlot32);
//        java.awt.Stroke stroke37 = xYPlot32.getDomainZeroBaselineStroke();
//        java.awt.Paint paint38 = xYPlot32.getBackgroundPaint();
//        java.awt.Color color40 = java.awt.Color.WHITE;
//        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean42 = dateAxis41.isPositiveArrowVisible();
//        java.awt.Stroke stroke43 = dateAxis41.getTickMarkStroke();
//        java.awt.Color color44 = java.awt.Color.BLUE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
//        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean48 = dateAxis47.isPositiveArrowVisible();
//        java.awt.Stroke stroke49 = dateAxis47.getTickMarkStroke();
//        double double50 = dateAxis47.getUpperMargin();
//        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        dateAxis47.setTickMarkStroke(stroke51);
//        categoryMarker46.setOutlineStroke(stroke51);
//        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color40, stroke43, (java.awt.Paint) color44, stroke51, (float) (short) 1);
//        java.awt.Paint paint56 = null;
//        org.jfree.data.xy.XYDataset xYDataset57 = null;
//        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
//        double double59 = dateAxis58.getLabelAngle();
//        boolean boolean60 = dateAxis58.isVerticalTickLabels();
//        dateAxis58.setTickMarkOutsideLength((float) 10);
//        boolean boolean63 = dateAxis58.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean65 = dateAxis64.isPositiveArrowVisible();
//        dateAxis64.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
//        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset57, (org.jfree.chart.axis.ValueAxis) dateAxis58, (org.jfree.chart.axis.ValueAxis) dateAxis64, xYItemRenderer68);
//        org.jfree.data.xy.XYDataset xYDataset70 = null;
//        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis();
//        double double72 = dateAxis71.getLabelAngle();
//        boolean boolean73 = dateAxis71.isVerticalTickLabels();
//        dateAxis71.setTickMarkOutsideLength((float) 10);
//        boolean boolean76 = dateAxis71.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean78 = dateAxis77.isPositiveArrowVisible();
//        dateAxis77.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer81 = null;
//        org.jfree.chart.plot.XYPlot xYPlot82 = new org.jfree.chart.plot.XYPlot(xYDataset70, (org.jfree.chart.axis.ValueAxis) dateAxis71, (org.jfree.chart.axis.ValueAxis) dateAxis77, xYItemRenderer81);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder83 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        xYPlot82.setDatasetRenderingOrder(datasetRenderingOrder83);
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier85 = xYPlot82.getDrawingSupplier();
//        dateAxis58.setPlot((org.jfree.chart.plot.Plot) xYPlot82);
//        java.awt.Stroke stroke87 = xYPlot82.getDomainZeroBaselineStroke();
//        org.jfree.chart.axis.AxisLocation axisLocation88 = xYPlot82.getDomainAxisLocation();
//        int int89 = xYPlot82.getBackgroundImageAlignment();
//        org.jfree.chart.axis.DateAxis dateAxis90 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean91 = dateAxis90.isPositiveArrowVisible();
//        java.awt.Stroke stroke92 = dateAxis90.getTickMarkStroke();
//        double double93 = dateAxis90.getUpperMargin();
//        java.awt.Stroke stroke94 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        dateAxis90.setTickMarkStroke(stroke94);
//        xYPlot82.setDomainZeroBaselineStroke(stroke94);
//        try {
//            org.jfree.chart.plot.CategoryMarker categoryMarker98 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) str6, paint38, stroke51, paint56, stroke94, (float) (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
//        org.junit.Assert.assertNotNull(drawingSupplier35);
//        org.junit.Assert.assertNotNull(stroke37);
//        org.junit.Assert.assertNotNull(paint38);
//        org.junit.Assert.assertNotNull(color40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(stroke43);
//        org.junit.Assert.assertNotNull(color44);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(stroke49);
//        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.05d + "'", double50 == 0.05d);
//        org.junit.Assert.assertNotNull(stroke51);
//        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder83);
//        org.junit.Assert.assertNotNull(drawingSupplier85);
//        org.junit.Assert.assertNotNull(stroke87);
//        org.junit.Assert.assertNotNull(axisLocation88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 15 + "'", int89 == 15);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(stroke92);
//        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.05d + "'", double93 == 0.05d);
//        org.junit.Assert.assertNotNull(stroke94);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets1.getLeft();
        double double4 = rectangleInsets1.calculateTopOutset((double) 100L);
        boolean boolean5 = textAnchor0.equals((java.lang.Object) rectangleInsets1);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets1.createOutsetRectangle(rectangle2D6, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        xYPlot25.addChangeListener(plotChangeListener34);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder36 = null;
        try {
            xYPlot25.setSeriesRenderingOrder(seriesRenderingOrder36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.Comparable comparable7 = null;
        try {
            java.awt.Paint paint8 = categoryAxis1.getTickLabelPaint(comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        xYPlot25.setRangeAxis(valueAxis32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double35 = rectangleInsets34.getLeft();
        double double37 = rectangleInsets34.calculateTopInset((double) '4');
        xYPlot25.setInsets(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35 == 3.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 3.0d + "'", double37 == 3.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        xYPlot12.markerChanged(markerChangeEvent13);
        xYPlot12.setDomainZeroBaselineVisible(false);
        java.awt.Paint paint17 = xYPlot12.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.0d);
        categoryAxis1.setCategoryLabelPositionOffset(3);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        try {
            categoryPlot0.zoom((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isPositiveArrowVisible();
        java.awt.Stroke stroke4 = dateAxis2.getTickMarkStroke();
        double double5 = dateAxis2.getUpperMargin();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis2.setTickMarkStroke(stroke6);
        categoryMarker1.setOutlineStroke(stroke6);
        float float9 = categoryMarker1.getAlpha();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj3 = intervalMarker2.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = intervalMarker2.getGradientPaintTransformer();
        java.awt.Paint paint5 = intervalMarker2.getOutlinePaint();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double3 = rectangleInsets1.calculateBottomInset((double) 1.0f);
        boolean boolean4 = datasetRenderingOrder0.equals((java.lang.Object) rectangleInsets1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets1.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getEnd();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        java.awt.Stroke stroke18 = xYPlot12.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline21 = null;
        dateAxis20.setTimeline(timeline21);
        boolean boolean23 = dateAxis20.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot24 = dateAxis20.getPlot();
        dateAxis20.setLowerMargin((double) 7);
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = null;
        dateAxis20.setTickUnit(dateTickUnit27);
        try {
            xYPlot12.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(plot24);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Paint paint9 = categoryAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str1.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot21.setDatasetRenderingOrder(datasetRenderingOrder22);
        xYPlot21.clearDomainAxes();
        boolean boolean25 = xYPlot21.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        xYPlot21.zoomDomainAxes(0.0d, plotRenderingInfo27, point2D28);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        double double33 = dateAxis32.getLabelAngle();
        boolean boolean34 = dateAxis32.isVerticalTickLabels();
        dateAxis32.setTickMarkOutsideLength((float) 10);
        boolean boolean37 = dateAxis32.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        boolean boolean39 = dateAxis38.isPositiveArrowVisible();
        dateAxis38.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer42);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        xYPlot43.markerChanged(markerChangeEvent44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot43.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace48 = categoryAxis1.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) xYPlot21, rectangle2D30, rectangleEdge46, axisSpace47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange((double) 255, (-12.0d));
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color6 = java.awt.Color.lightGray;
        categoryMarker5.setLabelPaint((java.awt.Paint) color6);
        java.lang.Object obj8 = categoryMarker5.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = categoryMarker5.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor10 = categoryMarker5.getLabelTextAnchor();
        boolean boolean11 = dateAxis0.equals((java.lang.Object) categoryMarker5);
        float float12 = categoryMarker5.getAlpha();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.0d);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLabelAngle();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        dateAxis12.setTickMarkOutsideLength((float) 10);
        boolean boolean17 = dateAxis12.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isPositiveArrowVisible();
        dateAxis18.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot23.setDatasetRenderingOrder(datasetRenderingOrder24);
        java.awt.Color color26 = java.awt.Color.cyan;
        xYPlot23.setNoDataMessagePaint((java.awt.Paint) color26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot23.getDomainAxisEdge();
        try {
            double double29 = categoryAxis1.getCategoryMiddle((int) (short) -1, 5, rectangle2D10, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int3 = java.awt.Color.HSBtoRGB((float) 2019, (float) 255, 2.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-515) + "'", int3 == (-515));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        java.lang.String str16 = xYPlot12.getNoDataMessage();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        double double21 = dateAxis20.getLabelAngle();
        boolean boolean22 = dateAxis20.isVerticalTickLabels();
        dateAxis20.setTickMarkOutsideLength((float) 10);
        boolean boolean25 = dateAxis20.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        dateAxis26.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        double double34 = dateAxis33.getLabelAngle();
        boolean boolean35 = dateAxis33.isVerticalTickLabels();
        dateAxis33.setTickMarkOutsideLength((float) 10);
        boolean boolean38 = dateAxis33.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        boolean boolean40 = dateAxis39.isPositiveArrowVisible();
        dateAxis39.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis39, xYItemRenderer43);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot44.setDatasetRenderingOrder(datasetRenderingOrder45);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier47 = xYPlot44.getDrawingSupplier();
        dateAxis20.setPlot((org.jfree.chart.plot.Plot) xYPlot44);
        java.awt.Stroke stroke49 = xYPlot44.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation50 = xYPlot44.getDomainAxisLocation();
        xYPlot44.zoom((double) '4');
        xYPlot44.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker56 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj57 = intervalMarker56.clone();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot44.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker56, layer58);
        try {
            xYPlot12.addDomainMarker(10, marker18, layer58, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
        org.junit.Assert.assertNotNull(drawingSupplier47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(layer58);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = numberAxis0.getRangeType();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis0.setTickLabelFont(font2);
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.clearDomainAxes();
        java.awt.Color color16 = java.awt.Color.WHITE;
        int int17 = color16.getBlue();
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color16.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        xYPlot12.setBackgroundPaint((java.awt.Paint) color16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(paintContext23);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        java.awt.Paint paint13 = dateAxis7.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        xYPlot12.setBackgroundAlpha((float) (short) 0);
        xYPlot12.clearAnnotations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1.0f);
        double double4 = rectangleInsets0.trimWidth((-6.0d));
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-12.0d) + "'", double4 == (-12.0d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) ' ', 2.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Color color2 = java.awt.Color.getColor("XY Plot", (int) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.lang.Object obj3 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        double double2 = dateAxis0.getLabelAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = dateAxis0.getTickLabelInsets();
        double double4 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 5);
        double double9 = categoryAxis1.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        double double17 = dateAxis16.getLabelAngle();
        boolean boolean18 = dateAxis16.isVerticalTickLabels();
        dateAxis16.setTickMarkOutsideLength((float) 10);
        boolean boolean21 = dateAxis16.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
        dateAxis22.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer26);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        xYPlot27.markerChanged(markerChangeEvent28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot27.getDomainAxisEdge();
        try {
            double double31 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) "DatasetRenderingOrder.REVERSE", (java.lang.Comparable) 11, categoryDataset12, (double) 53, rectangle2D14, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 10L, (double) 6, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets0, jFreeChart3, chartChangeEventType4);
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent5.getChart();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Color color0 = java.awt.Color.BLUE;
        int int1 = color0.getBlue();
        int int2 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot12.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        java.awt.Stroke stroke21 = dateAxis19.getTickMarkStroke();
        double double22 = dateAxis19.getUpperMargin();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis19.setTickMarkStroke(stroke23);
        categoryMarker18.setOutlineStroke(stroke23);
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot12.setRenderer((int) (byte) 10, xYItemRenderer29);
        org.jfree.data.general.DatasetGroup datasetGroup31 = xYPlot12.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(datasetGroup31);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        java.awt.Paint paint31 = xYPlot25.getBackgroundPaint();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot25.getRendererForDataset(xYDataset32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(xYItemRenderer33);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean5 = day2.equals((java.lang.Object) day4);
//        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day2);
//        categoryAxis1.setAxisLineVisible(true);
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot12.clearDomainMarkers();
//        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getRangeAxisEdge();
//        try {
//            double double15 = categoryAxis1.getCategoryStart((int) '#', (int) (short) 10, rectangle2D11, rectangleEdge14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertNotNull(rectangleEdge14);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        java.awt.Color color9 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean11 = color9.equals((java.lang.Object) textAnchor10);
        categoryAxis1.setLabelPaint((java.awt.Paint) color9);
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryDataset11);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        boolean boolean3 = dateAxis0.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isPositiveArrowVisible();
        java.awt.Stroke stroke6 = dateAxis4.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis4.setTickMarkStroke(stroke7);
        org.jfree.data.Range range9 = dateAxis4.getRange();
        dateAxis0.setRange(range9);
        boolean boolean11 = dateAxis0.isTickMarksVisible();
        float float12 = dateAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        boolean boolean16 = xYPlot12.isRangeGridlinesVisible();
        java.awt.Color color17 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) 2019);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj3 = intervalMarker2.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = intervalMarker2.getGradientPaintTransformer();
        org.jfree.chart.text.TextAnchor textAnchor5 = null;
        try {
            intervalMarker2.setLabelTextAnchor(textAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(gradientPaintTransformer4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isPositiveArrowVisible();
        dateAxis34.setAutoRange(false);
        dateAxis34.resizeRange(0.0d, (double) 10);
        boolean boolean42 = dateAxis34.isHiddenValue((long) 3);
        xYPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
        dateAxis0.setLowerMargin((double) 7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis0.getStandardTickUnits();
        try {
            boolean boolean9 = dateAxis0.isHiddenValue((long) 53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(tickUnitSource7);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 5);
        double double9 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        double double9 = dateAxis8.getLabelAngle();
        boolean boolean10 = dateAxis8.isVerticalTickLabels();
        dateAxis8.setTickMarkOutsideLength((float) 10);
        boolean boolean13 = dateAxis8.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isPositiveArrowVisible();
        dateAxis14.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot19.setDatasetRenderingOrder(datasetRenderingOrder20);
        boolean boolean22 = xYPlot19.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot19.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        java.awt.Stroke stroke28 = dateAxis26.getTickMarkStroke();
        double double29 = dateAxis26.getUpperMargin();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis26.setTickMarkStroke(stroke30);
        categoryMarker25.setOutlineStroke(stroke30);
        org.jfree.chart.util.Layer layer33 = null;
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25, layer33);
        boolean boolean35 = categoryAxis1.equals((java.lang.Object) xYPlot19);
        java.awt.Font font37 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        java.lang.Object obj38 = null;
        boolean boolean39 = categoryAxis1.equals(obj38);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis0, jFreeChart1);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getRangeAxisEdge();
        try {
            double double8 = numberAxis0.valueToJava2D((double) 15, rectangle2D4, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLabelAngle();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        dateAxis12.setTickMarkOutsideLength((float) 10);
        boolean boolean17 = dateAxis12.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isPositiveArrowVisible();
        dateAxis18.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer22);
        boolean boolean24 = numberAxis6.hasListener((java.util.EventListener) xYPlot23);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, 2.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color0 = java.awt.Color.orange;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj2 = defaultDrawingSupplier1.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis4.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color7 = java.awt.Color.cyan;
        categoryAxis4.setTickLabelPaint((java.awt.Paint) color7);
        double double9 = categoryAxis4.getLowerMargin();
        java.awt.Color color12 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean14 = color12.equals((java.lang.Object) textAnchor13);
        categoryAxis4.setLabelPaint((java.awt.Paint) color12);
        boolean boolean16 = defaultDrawingSupplier1.equals((java.lang.Object) color12);
        java.awt.Paint paint17 = defaultDrawingSupplier1.getNextOutlinePaint();
        boolean boolean18 = color0.equals((java.lang.Object) defaultDrawingSupplier1);
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color0.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paintContext24);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        boolean boolean3 = dateAxis0.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isPositiveArrowVisible();
        java.awt.Stroke stroke6 = dateAxis4.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis4.setTickMarkStroke(stroke7);
        org.jfree.data.Range range9 = dateAxis4.getRange();
        dateAxis0.setRange(range9);
        boolean boolean11 = dateAxis0.isTickMarksVisible();
        dateAxis0.setLowerBound((double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = numberAxis0.getStandardTickUnits();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        xYPlot17.markerChanged(markerChangeEvent18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot17.getDomainAxisEdge();
        try {
            java.util.List list21 = numberAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        boolean boolean2 = sortOrder0.equals((java.lang.Object) day1);
        java.util.Calendar calendar3 = null;
        try {
            day1.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.Marker marker9 = null;
        try {
            boolean boolean10 = categoryPlot0.removeRangeMarker(marker9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        xYPlot12.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis18.setTickUnit(numberTickUnit20);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot24.getRangeAxisEdge();
        try {
            double double27 = numberAxis18.valueToJava2D((double) 9, rectangle2D23, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getRGBComponents(floatArray2);
        float[] floatArray4 = color0.getRGBComponents(floatArray3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj3 = intervalMarker2.clone();
        double double4 = intervalMarker2.getStartValue();
        intervalMarker2.setStartValue((double) (byte) 1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.0d + "'", double4 == 9.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot25.setRangeAxisLocation(0, axisLocation33, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot25.setDomainAxes(valueAxisArray36);
        boolean boolean38 = xYPlot25.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setTickMarkStroke(stroke3);
        dateAxis0.setVerticalTickLabels(true);
        java.lang.String str7 = dateAxis0.getLabel();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
        dateAxis0.setLowerMargin((double) 7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis0.getStandardTickUnits();
        java.awt.Color color10 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        dateAxis0.setTickLabelPaint((java.awt.Paint) color10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.getAutoRangeIncludesZero();
        numberAxis14.setAutoRangeStickyZero(true);
        numberAxis14.setAutoRangeIncludesZero(true);
        categoryPlot11.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis14, true);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        categoryPlot11.setDataset(0, categoryDataset23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        double double29 = dateAxis28.getLabelAngle();
        boolean boolean30 = dateAxis28.isVerticalTickLabels();
        dateAxis28.setTickMarkOutsideLength((float) 10);
        boolean boolean33 = dateAxis28.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isPositiveArrowVisible();
        dateAxis34.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer38);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder40 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot39.setDatasetRenderingOrder(datasetRenderingOrder40);
        double double42 = xYPlot39.getRangeCrosshairValue();
        java.awt.Paint paint43 = xYPlot39.getRangeCrosshairPaint();
        xYPlot39.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D46 = xYPlot39.getQuadrantOrigin();
        categoryPlot11.zoomDomainAxes((double) (byte) 10, plotRenderingInfo26, point2D46, false);
        org.jfree.chart.plot.PlotState plotState49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        try {
            categoryPlot0.draw(graphics2D9, rectangle2D10, point2D46, plotState49, plotRenderingInfo50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(0, categoryDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        double double31 = xYPlot28.getRangeCrosshairValue();
        java.awt.Paint paint32 = xYPlot28.getRangeCrosshairPaint();
        xYPlot28.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D35 = xYPlot28.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D35, false);
        int int38 = categoryPlot0.getRangeAxisCount();
        java.util.List list39 = categoryPlot0.getCategories();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot42.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot42.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        double double49 = dateAxis48.getLabelAngle();
        boolean boolean50 = dateAxis48.isVerticalTickLabels();
        dateAxis48.setTickMarkOutsideLength((float) 10);
        boolean boolean53 = dateAxis48.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        boolean boolean55 = dateAxis54.isPositiveArrowVisible();
        dateAxis54.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) dateAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer58);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder60 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot59.setDatasetRenderingOrder(datasetRenderingOrder60);
        double double62 = xYPlot59.getRangeCrosshairValue();
        java.awt.Paint paint63 = xYPlot59.getRangeCrosshairPaint();
        xYPlot59.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D66 = xYPlot59.getQuadrantOrigin();
        categoryPlot42.zoomDomainAxes((double) (-1L), plotRenderingInfo46, point2D66, true);
        org.jfree.chart.plot.PlotState plotState69 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        try {
            categoryPlot0.draw(graphics2D40, rectangle2D41, point2D66, plotState69, plotRenderingInfo70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNull(list39);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(point2D66);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        int int6 = day0.getMonth();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        xYPlot12.markerChanged(markerChangeEvent13);
        xYPlot12.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot17.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        double double24 = dateAxis23.getLabelAngle();
        boolean boolean25 = dateAxis23.isVerticalTickLabels();
        dateAxis23.setTickMarkOutsideLength((float) 10);
        boolean boolean28 = dateAxis23.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = dateAxis29.isPositiveArrowVisible();
        dateAxis29.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer33);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot34.setDatasetRenderingOrder(datasetRenderingOrder35);
        double double37 = xYPlot34.getRangeCrosshairValue();
        java.awt.Paint paint38 = xYPlot34.getRangeCrosshairPaint();
        xYPlot34.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D41 = xYPlot34.getQuadrantOrigin();
        categoryPlot17.zoomDomainAxes((double) (-1L), plotRenderingInfo21, point2D41, true);
        categoryPlot17.clearAnnotations();
        java.awt.Paint paint45 = categoryPlot17.getRangeGridlinePaint();
        xYPlot12.setRangeGridlinePaint(paint45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        xYPlot12.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D18 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        float float21 = dateAxis19.getTickMarkInsideLength();
        int int22 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        try {
            dateAxis19.setRangeWithMargins((double) 12, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (12.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        xYPlot25.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset35 = xYPlot25.getDataset();
        boolean boolean36 = xYPlot25.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        try {
            xYPlot25.handleClick((int) (short) 0, 0, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) 100, (double) 8, (-6.0d), (double) 10.0f);
        double double10 = rectangleInsets8.calculateTopOutset((double) 4);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color17 = java.awt.Color.lightGray;
        categoryMarker16.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryMarker16.notifyListeners(markerChangeEvent21);
        java.awt.Paint paint23 = categoryMarker16.getLabelPaint();
        java.awt.Paint paint24 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        categoryMarker16.setLabelPaint(paint24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean5 = day2.equals((java.lang.Object) day4);
//        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day2);
//        double double7 = categoryAxis1.getLowerMargin();
//        categoryAxis1.setVisible(false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset1);
        org.jfree.data.general.Dataset dataset3 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(dataset3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.0d);
        double double8 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis0.removeChangeListener(axisChangeListener2);
        numberAxis0.setLabel("SeriesRenderingOrder.REVERSE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets0.createInsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        java.lang.Class<?> wildcardClass18 = xYPlot12.getClass();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot12.setNoDataMessageFont(font19);
        java.awt.Paint paint21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        xYPlot12.setRangeGridlinePaint(paint21);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int3 = java.awt.Color.HSBtoRGB((float) 5, (float) 2019, (float) 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2112128) + "'", int3 == (-2112128));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setNegativeArrowVisible(false);
        java.awt.Color color6 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean8 = color6.equals((java.lang.Object) textAnchor7);
        dateAxis0.setLabelPaint((java.awt.Paint) color6);
        float[] floatArray10 = new float[] {};
        try {
            float[] floatArray11 = color6.getRGBColorComponents(floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        categoryAxis11.configure();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        xYPlot12.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D19 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        xYPlot12.markerChanged(markerChangeEvent20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(point2D19);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 0, (double) 0.0f, (-12.0d), (double) (-1.0f));
        double double7 = rectangleInsets5.calculateBottomInset((double) 53);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-12.0d) + "'", double7 == (-12.0d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot12.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        java.awt.Stroke stroke21 = dateAxis19.getTickMarkStroke();
        double double22 = dateAxis19.getUpperMargin();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis19.setTickMarkStroke(stroke23);
        categoryMarker18.setOutlineStroke(stroke23);
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer26);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        xYPlot12.setFixedRangeAxisSpace(axisSpace28);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color32 = java.awt.Color.lightGray;
        categoryMarker31.setLabelPaint((java.awt.Paint) color32);
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot12.setRenderer(0, xYItemRenderer16);
        boolean boolean18 = xYPlot12.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color34 = java.awt.Color.lightGray;
        categoryMarker33.setLabelPaint((java.awt.Paint) color34);
        boolean boolean36 = categoryMarker33.getDrawAsLine();
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = xYPlot25.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker33, layer37);
        int int39 = xYPlot25.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis40 = xYPlot25.getDomainAxis();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(valueAxis40);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setPositiveArrowVisible(true);
        dateAxis0.setRange((double) 0, (double) 0.5f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.util.Date date3 = dateAxis0.getMinimumDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        xYPlot12.clearDomainMarkers();
        java.lang.Object obj14 = xYPlot12.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot12.markerChanged(markerChangeEvent15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
        dateAxis0.setLowerMargin((double) 7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis0.getStandardTickUnits();
        dateAxis0.setInverted(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(tickUnitSource7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(5, 12, 7);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color4 = java.awt.Color.lightGray;
        categoryMarker3.setLabelPaint((java.awt.Paint) color4);
        java.lang.Object obj6 = categoryMarker3.clone();
        org.jfree.chart.text.TextAnchor textAnchor7 = categoryMarker3.getLabelTextAnchor();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker3.setPaint((java.awt.Paint) color8);
        dateAxis0.setTickLabelPaint((java.awt.Paint) color8);
        try {
            dateAxis0.zoomRange((double) 1560409200000L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.5604092E12) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        dateAxis0.setTickMarkInsideLength((float) '#');
        dateAxis0.setVisible(false);
        dateAxis0.resizeRange((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot0.getDomainAxisEdge((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot0.handleClick((-2112128), 1, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Color color0 = java.awt.Color.black;
        float[] floatArray3 = new float[] { '4', (byte) 10 };
        try {
            float[] floatArray4 = color0.getRGBColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        float[] floatArray7 = new float[] { 0L, 11, (short) 1, (short) 1 };
        float[] floatArray8 = java.awt.Color.RGBtoHSB((int) 'a', 0, 4, floatArray7);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(0, categoryDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        double double31 = xYPlot28.getRangeCrosshairValue();
        java.awt.Paint paint32 = xYPlot28.getRangeCrosshairPaint();
        xYPlot28.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D35 = xYPlot28.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D35, false);
        int int38 = categoryPlot0.getRangeAxisCount();
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        double double41 = dateAxis40.getLabelAngle();
        boolean boolean42 = dateAxis40.isVerticalTickLabels();
        dateAxis40.setTickMarkOutsideLength((float) 10);
        boolean boolean45 = dateAxis40.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        boolean boolean47 = dateAxis46.isPositiveArrowVisible();
        dateAxis46.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) dateAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis46, xYItemRenderer50);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder52 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot51.setDatasetRenderingOrder(datasetRenderingOrder52);
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color56 = java.awt.Color.lightGray;
        categoryMarker55.setLabelPaint((java.awt.Paint) color56);
        org.jfree.chart.util.Layer layer58 = null;
        boolean boolean59 = xYPlot51.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker55, layer58);
        categoryPlot0.addDomainMarker(categoryMarker55);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder52);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange((double) 255, (-12.0d));
        dateAxis0.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLabelAngle();
        boolean boolean9 = dateAxis7.isVerticalTickLabels();
        dateAxis7.setTickMarkOutsideLength((float) 10);
        boolean boolean12 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        dateAxis13.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot18.setDomainAxisLocation(axisLocation19);
        boolean boolean21 = dateAxis0.hasListener((java.util.EventListener) xYPlot18);
        java.awt.Paint paint22 = xYPlot18.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Paint paint15 = xYPlot12.getDomainZeroBaselinePaint();
        java.awt.Paint paint16 = xYPlot12.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        double double5 = rectangleInsets0.calculateRightInset((double) 255);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str9 = lengthAdjustmentType8.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets0.createAdjustedRectangle(rectangle2D6, lengthAdjustmentType7, lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CONTRACT" + "'", str9.equals("CONTRACT"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        xYPlot12.markerChanged(markerChangeEvent13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets15.getUnitType();
        xYPlot12.setInsets(rectangleInsets15, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17 == 3.0d);
        org.junit.Assert.assertNotNull(unitType18);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        int int6 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        xYPlot12.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis18.setTickUnit(numberTickUnit20);
        numberAxis18.configure();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(numberTickUnit20);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            categoryPlot0.handleClick((int) (short) -1, (int) (byte) 0, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            categoryPlot0.handleClick(0, 500, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(axisSpace3);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.xy.XYDataset xYDataset6 = null;
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
//        double double8 = dateAxis7.getLabelAngle();
//        boolean boolean9 = dateAxis7.isVerticalTickLabels();
//        dateAxis7.setTickMarkOutsideLength((float) 10);
//        boolean boolean12 = dateAxis7.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
//        dateAxis13.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
//        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer17);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        xYPlot18.setDatasetRenderingOrder(datasetRenderingOrder19);
//        xYPlot18.clearDomainAxes();
//        java.awt.Paint paint22 = xYPlot18.getRangeTickBandPaint();
//        java.awt.Paint paint23 = xYPlot18.getOutlinePaint();
//        int int24 = day0.compareTo((java.lang.Object) xYPlot18);
//        java.util.Calendar calendar25 = null;
//        try {
//            long long26 = day0.getLastMillisecond(calendar25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
//        org.junit.Assert.assertNull(paint22);
//        org.junit.Assert.assertNotNull(paint23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 1.0f);
        double double3 = rectangleInsets0.getLeft();
        double double5 = rectangleInsets0.calculateLeftOutset((-2.0d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int3 = java.awt.Color.HSBtoRGB((-1.0f), (float) (byte) 0, (float) 1L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot0.getOrientation();
        java.awt.Font font12 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        boolean boolean16 = xYPlot12.isRangeZeroBaselineVisible();
        java.lang.Object obj17 = xYPlot12.clone();
        java.awt.Stroke stroke18 = xYPlot12.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat2 = null;
        numberAxis0.setNumberFormatOverride(numberFormat2);
        java.awt.Paint paint4 = numberAxis0.getTickLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getRangeAxisEdge();
        try {
            double double10 = numberAxis0.java2DToValue((double) 10, rectangle2D6, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.clearDomainAxes();
        java.awt.Paint paint16 = xYPlot12.getRangeTickBandPaint();
        java.lang.Object obj17 = xYPlot12.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        xYPlot12.setBackgroundImageAlpha((float) 1L);
        org.jfree.data.general.DatasetGroup datasetGroup18 = xYPlot12.getDatasetGroup();
        xYPlot12.setRangeCrosshairValue((double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNull(datasetGroup18);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        int int2 = categoryPlot0.getWeight();
        int int3 = categoryPlot0.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.resizeRange((double) 255, (-12.0d));
        dateAxis4.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getLabelAngle();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        dateAxis11.setTickMarkOutsideLength((float) 10);
        boolean boolean16 = dateAxis11.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isPositiveArrowVisible();
        dateAxis17.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot22.setDomainAxisLocation(axisLocation23);
        boolean boolean25 = dateAxis4.hasListener((java.util.EventListener) xYPlot22);
        float float26 = xYPlot22.getForegroundAlpha();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = xYPlot22.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection27);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(legendItemCollection27);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
        dateAxis0.setLowerMargin((double) 7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis0.getStandardTickUnits();
        double double8 = dateAxis0.getAutoRangeMinimumSize();
        java.awt.Paint paint9 = dateAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        java.lang.String str11 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Category Plot" + "'", str11.equals("Category Plot"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        boolean boolean2 = sortOrder0.equals((java.lang.Object) day1);
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        java.util.Calendar calendar4 = null;
        try {
            day1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot12.getOrientation();
        java.awt.Paint paint18 = null;
        try {
            xYPlot12.setQuadrantPaint((int) (byte) 10, paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        boolean boolean2 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLabelAngle();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        dateAxis3.setTickMarkOutsideLength((float) 10);
        boolean boolean8 = dateAxis3.isTickLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot21.setDatasetRenderingOrder(datasetRenderingOrder22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color24);
        dateAxis3.setLabelPaint((java.awt.Paint) color24);
        dateAxis0.setLabelPaint((java.awt.Paint) color24);
        double double28 = dateAxis0.getAutoRangeMinimumSize();
        boolean boolean29 = dateAxis0.isAutoRange();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean5 = day2.equals((java.lang.Object) day4);
//        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day2);
//        int int7 = categoryAxis1.getMaximumCategoryLabelLines();
//        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.5f);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str2 = rectangleAnchor1.toString();
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str2.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setLowerMargin((double) 1.0f);
        categoryAxis1.setLabelToolTip("DatasetRenderingOrder.REVERSE");
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "TextAnchor.BOTTOM_RIGHT");
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        boolean boolean27 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        xYPlot12.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLabelAngle();
        boolean boolean24 = dateAxis22.isVerticalTickLabels();
        dateAxis22.setTickMarkOutsideLength((float) 10);
        boolean boolean27 = dateAxis22.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean29 = dateAxis28.isPositiveArrowVisible();
        dateAxis28.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer32);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder34 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot33.setDatasetRenderingOrder(datasetRenderingOrder34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        double double38 = dateAxis37.getLabelAngle();
        boolean boolean39 = dateAxis37.isVerticalTickLabels();
        dateAxis37.setTickMarkOutsideLength((float) 10);
        boolean boolean42 = dateAxis37.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean44 = dateAxis43.isPositiveArrowVisible();
        dateAxis43.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot48.setDatasetRenderingOrder(datasetRenderingOrder49);
        double double51 = xYPlot48.getRangeCrosshairValue();
        java.awt.Paint paint52 = xYPlot48.getRangeCrosshairPaint();
        xYPlot48.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D55 = xYPlot48.getQuadrantOrigin();
        xYPlot33.setQuadrantOrigin(point2D55);
        xYPlot12.zoomDomainAxes((double) (byte) 0, plotRenderingInfo20, point2D55, false);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource61 = numberAxis60.getStandardTickUnits();
        xYPlot12.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) numberAxis60);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(point2D55);
        org.junit.Assert.assertNotNull(tickUnitSource61);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        double double9 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.clearDomainAxes();
        java.awt.Paint paint16 = xYPlot12.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        double double32 = dateAxis31.getLabelAngle();
        boolean boolean33 = dateAxis31.isVerticalTickLabels();
        dateAxis31.setTickMarkOutsideLength((float) 10);
        boolean boolean36 = dateAxis31.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis37.isPositiveArrowVisible();
        dateAxis37.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer41);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder43 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot42.setDatasetRenderingOrder(datasetRenderingOrder43);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = xYPlot42.getDrawingSupplier();
        dateAxis18.setPlot((org.jfree.chart.plot.Plot) xYPlot42);
        java.awt.Stroke stroke47 = xYPlot42.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot42.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        xYPlot42.setFixedRangeAxisSpace(axisSpace49, true);
        xYPlot12.setParent((org.jfree.chart.plot.Plot) xYPlot42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        double double57 = categoryPlot56.getAnchorValue();
        java.awt.Color color59 = java.awt.Color.WHITE;
        java.awt.Color color60 = java.awt.Color.getColor("", color59);
        categoryPlot56.setDomainGridlinePaint((java.awt.Paint) color59);
        org.jfree.chart.axis.ValueAxis valueAxis62 = categoryPlot56.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot56.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot56.setFixedDomainAxisSpace(axisSpace65, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        org.jfree.data.xy.XYDataset xYDataset70 = null;
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis();
        double double72 = dateAxis71.getLabelAngle();
        boolean boolean73 = dateAxis71.isVerticalTickLabels();
        dateAxis71.setTickMarkOutsideLength((float) 10);
        boolean boolean76 = dateAxis71.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis();
        boolean boolean78 = dateAxis77.isPositiveArrowVisible();
        dateAxis77.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer81 = null;
        org.jfree.chart.plot.XYPlot xYPlot82 = new org.jfree.chart.plot.XYPlot(xYDataset70, (org.jfree.chart.axis.ValueAxis) dateAxis71, (org.jfree.chart.axis.ValueAxis) dateAxis77, xYItemRenderer81);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder83 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot82.setDatasetRenderingOrder(datasetRenderingOrder83);
        boolean boolean85 = xYPlot82.isRangeCrosshairVisible();
        xYPlot82.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D88 = xYPlot82.getQuadrantOrigin();
        categoryPlot56.zoomRangeAxes((double) 100.0f, plotRenderingInfo69, point2D88);
        try {
            xYPlot42.zoomDomainAxes(1.0d, (double) (-1.0f), plotRenderingInfo55, point2D88);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder43);
        org.junit.Assert.assertNotNull(drawingSupplier45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNull(valueAxis62);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(point2D88);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis0.removeChangeListener(axisChangeListener2);
        numberAxis0.setLabel("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getLabelAngle();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        dateAxis11.setTickMarkOutsideLength((float) 10);
        boolean boolean16 = dateAxis11.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = dateAxis17.isPositiveArrowVisible();
        dateAxis17.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        double double25 = dateAxis24.getLabelAngle();
        boolean boolean26 = dateAxis24.isVerticalTickLabels();
        dateAxis24.setTickMarkOutsideLength((float) 10);
        boolean boolean29 = dateAxis24.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        boolean boolean31 = dateAxis30.isPositiveArrowVisible();
        dateAxis30.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot35.setDatasetRenderingOrder(datasetRenderingOrder36);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier38 = xYPlot35.getDrawingSupplier();
        dateAxis11.setPlot((org.jfree.chart.plot.Plot) xYPlot35);
        java.awt.Stroke stroke40 = xYPlot35.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot35.getDomainAxisLocation();
        int int42 = xYPlot35.getBackgroundImageAlignment();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean44 = dateAxis43.isPositiveArrowVisible();
        java.awt.Stroke stroke45 = dateAxis43.getTickMarkStroke();
        double double46 = dateAxis43.getUpperMargin();
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis43.setTickMarkStroke(stroke47);
        xYPlot35.setDomainZeroBaselineStroke(stroke47);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot35.getRangeAxisEdge(9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        try {
            org.jfree.chart.axis.AxisState axisState53 = numberAxis0.draw(graphics2D6, (double) ' ', rectangle2D8, rectangle2D9, rectangleEdge51, plotRenderingInfo52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertNotNull(drawingSupplier38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLabelAngle();
        boolean boolean4 = dateAxis2.isVerticalTickLabels();
        dateAxis2.setTickMarkOutsideLength((float) 10);
        boolean boolean7 = dateAxis2.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isPositiveArrowVisible();
        dateAxis8.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        double double16 = xYPlot13.getRangeCrosshairValue();
        java.awt.Paint paint17 = xYPlot13.getRangeCrosshairPaint();
        java.awt.Paint paint18 = xYPlot13.getNoDataMessagePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color21 = java.awt.Color.lightGray;
        categoryMarker20.setLabelPaint((java.awt.Paint) color21);
        java.lang.Comparable comparable23 = categoryMarker20.getKey();
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker20);
        java.awt.Color color27 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean29 = color27.equals((java.lang.Object) textAnchor28);
        categoryMarker20.setLabelTextAnchor(textAnchor28);
        boolean boolean31 = axisLocation0.equals((java.lang.Object) textAnchor28);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 100 + "'", comparable23.equals(100));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        java.awt.Paint paint17 = xYPlot12.getNoDataMessagePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color20 = java.awt.Color.lightGray;
        categoryMarker19.setLabelPaint((java.awt.Paint) color20);
        java.lang.Comparable comparable22 = categoryMarker19.getKey();
        xYPlot12.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = categoryMarker19.getLabelAnchor();
        java.lang.String str25 = rectangleAnchor24.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100 + "'", comparable22.equals(100));
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str25.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLabelAngle();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        dateAxis3.setTickMarkOutsideLength((float) 10);
        boolean boolean8 = dateAxis3.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        dateAxis9.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer13);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot14.setDatasetRenderingOrder(datasetRenderingOrder15);
        double double17 = xYPlot14.getRangeCrosshairValue();
        java.awt.Paint paint18 = xYPlot14.getRangeCrosshairPaint();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        java.awt.Stroke stroke22 = dateAxis20.getTickMarkStroke();
        boolean boolean23 = dateAxis20.isTickLabelsVisible();
        java.awt.Color color25 = java.awt.Color.WHITE;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        dateAxis20.setLabelPaint((java.awt.Paint) color25);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        double double30 = dateAxis29.getLabelAngle();
        boolean boolean31 = dateAxis29.isVerticalTickLabels();
        dateAxis29.setTickMarkOutsideLength((float) 10);
        boolean boolean34 = dateAxis29.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        boolean boolean36 = dateAxis35.isPositiveArrowVisible();
        dateAxis35.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer39);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent41 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot40);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder42 = xYPlot40.getDatasetRenderingOrder();
        xYPlot40.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        double double47 = dateAxis46.getLabelAngle();
        boolean boolean48 = dateAxis46.isVerticalTickLabels();
        dateAxis46.setTickMarkOutsideLength((float) 10);
        boolean boolean51 = dateAxis46.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        boolean boolean53 = dateAxis52.isPositiveArrowVisible();
        dateAxis52.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis46, (org.jfree.chart.axis.ValueAxis) dateAxis52, xYItemRenderer56);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder58 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot57.setDatasetRenderingOrder(datasetRenderingOrder58);
        java.awt.Color color60 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot57.setDomainGridlinePaint((java.awt.Paint) color60);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis();
        xYPlot57.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) numberAxis63);
        boolean boolean65 = xYPlot40.equals((java.lang.Object) xYPlot57);
        java.awt.Stroke stroke66 = xYPlot57.getDomainZeroBaselineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker68 = new org.jfree.chart.plot.IntervalMarker((double) 7, (double) 500, paint18, stroke19, (java.awt.Paint) color25, stroke66, (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder42);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder58);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLabelAngle();
        boolean boolean4 = dateAxis2.isVerticalTickLabels();
        dateAxis2.setTickMarkOutsideLength((float) 10);
        boolean boolean7 = dateAxis2.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isPositiveArrowVisible();
        dateAxis8.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = xYPlot13.getDrawingSupplier();
        boolean boolean17 = xYPlot13.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        boolean boolean20 = xYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = xYPlot13.getAxisOffset();
        boolean boolean22 = lengthAdjustmentType0.equals((java.lang.Object) xYPlot13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        double double6 = dateAxis5.getLabelAngle();
        boolean boolean7 = dateAxis5.isVerticalTickLabels();
        dateAxis5.setTickMarkOutsideLength((float) 10);
        boolean boolean10 = dateAxis5.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = dateAxis11.isPositiveArrowVisible();
        dateAxis11.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot29.setDatasetRenderingOrder(datasetRenderingOrder30);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = xYPlot29.getDrawingSupplier();
        dateAxis5.setPlot((org.jfree.chart.plot.Plot) xYPlot29);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = null;
        xYPlot29.setFixedLegendItems(legendItemCollection34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot29.setRangeAxisLocation(0, axisLocation37, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot29.setDomainAxes(valueAxisArray40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        double double44 = dateAxis43.getLabelAngle();
        boolean boolean45 = dateAxis43.isVerticalTickLabels();
        dateAxis43.setTickMarkOutsideLength((float) 10);
        boolean boolean48 = dateAxis43.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        boolean boolean50 = dateAxis49.isPositiveArrowVisible();
        dateAxis49.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) dateAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis49, xYItemRenderer53);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot54.setDatasetRenderingOrder(datasetRenderingOrder55);
        double double57 = xYPlot54.getRangeCrosshairValue();
        java.awt.Paint paint58 = xYPlot54.getRangeCrosshairPaint();
        xYPlot54.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D61 = xYPlot54.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation62 = xYPlot54.getOrientation();
        xYPlot29.setOrientation(plotOrientation62);
        categoryPlot0.setOrientation(plotOrientation62);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent65 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation62);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(valueAxisArray40);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(point2D61);
        org.junit.Assert.assertNotNull(plotOrientation62);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        boolean boolean3 = dateAxis0.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isPositiveArrowVisible();
        java.awt.Stroke stroke6 = dateAxis4.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis4.setTickMarkStroke(stroke7);
        org.jfree.data.Range range9 = dateAxis4.getRange();
        dateAxis0.setRange(range9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis0.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        xYPlot12.setRangeCrosshairLockedOnData(true);
        boolean boolean18 = xYPlot12.isDomainZeroBaselineVisible();
        java.awt.Paint paint19 = xYPlot12.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 5);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "XY Plot", "SeriesRenderingOrder.REVERSE");
        float float12 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setAutoRange(false);
        dateAxis0.resizeRange(0.0d, (double) 10);
        java.util.Date date7 = dateAxis0.getMinimumDate();
        dateAxis0.centerRange(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setAutoRange(false);
        dateAxis0.resizeRange(0.0d, (double) 10);
        boolean boolean8 = dateAxis0.isHiddenValue((long) 3);
        dateAxis0.setLabelURL("SortOrder.DESCENDING");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Color color2 = java.awt.Color.getColor("", 3);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLabelAngle();
        boolean boolean6 = dateAxis4.isVerticalTickLabels();
        dateAxis4.setTickMarkOutsideLength((float) 10);
        boolean boolean9 = dateAxis4.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isPositiveArrowVisible();
        dateAxis10.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = xYPlot28.getDrawingSupplier();
        dateAxis4.setPlot((org.jfree.chart.plot.Plot) xYPlot28);
        java.awt.Stroke stroke33 = xYPlot28.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot28.getDomainAxisLocation();
        int int35 = xYPlot28.getBackgroundImageAlignment();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        boolean boolean37 = dateAxis36.isPositiveArrowVisible();
        java.awt.Stroke stroke38 = dateAxis36.getTickMarkStroke();
        double double39 = dateAxis36.getUpperMargin();
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis36.setTickMarkStroke(stroke40);
        xYPlot28.setDomainZeroBaselineStroke(stroke40);
        int int43 = objectList0.indexOf((java.lang.Object) stroke40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(drawingSupplier31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(0, categoryDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        double double31 = xYPlot28.getRangeCrosshairValue();
        java.awt.Paint paint32 = xYPlot28.getRangeCrosshairPaint();
        xYPlot28.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D35 = xYPlot28.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D35, false);
        int int38 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker41 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj42 = intervalMarker41.clone();
        double double43 = intervalMarker41.getStartValue();
        java.awt.Paint paint44 = null;
        intervalMarker41.setOutlinePaint(paint44);
        boolean boolean46 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker41);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline49 = null;
        dateAxis48.setTimeline(timeline49);
        boolean boolean51 = dateAxis48.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot52 = dateAxis48.getPlot();
        dateAxis48.setRangeWithMargins((double) 2, (double) 10);
        dateAxis48.resizeRange((double) (byte) 1);
        try {
            categoryPlot0.setRangeAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) dateAxis48, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 9.0d + "'", double43 == 9.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNull(plot52);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setAxisLineStroke(stroke3);
        double double5 = dateAxis0.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis7.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis7.setUpperMargin(0.0d);
        categoryAxis7.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = categoryAxis7.getCategoryLabelPositions();
        java.awt.Font font15 = categoryAxis7.getTickLabelFont((java.lang.Comparable) (short) 100);
        dateAxis0.setTickLabelFont(font15);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLabelAngle();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis3.getTimeline();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.Paint paint9 = null;
        try {
            categoryPlot8.setDomainGridlinePaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeline6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setInverted(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot0.getDomainAxis(11);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            categoryPlot0.drawBackground(graphics2D17, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(categoryAxis16);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.getAutoRangeIncludesZero();
        numberAxis21.setAutoRangeStickyZero(true);
        numberAxis21.setAutoRangeIncludesZero(true);
        categoryPlot18.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis21, true);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        categoryPlot18.setDataset(0, categoryDataset30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        double double36 = dateAxis35.getLabelAngle();
        boolean boolean37 = dateAxis35.isVerticalTickLabels();
        dateAxis35.setTickMarkOutsideLength((float) 10);
        boolean boolean40 = dateAxis35.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        boolean boolean42 = dateAxis41.isPositiveArrowVisible();
        dateAxis41.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis41, xYItemRenderer45);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder47 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot46.setDatasetRenderingOrder(datasetRenderingOrder47);
        double double49 = xYPlot46.getRangeCrosshairValue();
        java.awt.Paint paint50 = xYPlot46.getRangeCrosshairPaint();
        xYPlot46.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D53 = xYPlot46.getQuadrantOrigin();
        categoryPlot18.zoomDomainAxes((double) (byte) 10, plotRenderingInfo33, point2D53, false);
        int int56 = categoryPlot18.getRangeAxisCount();
        java.util.List list57 = categoryPlot18.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        double double61 = categoryPlot60.getAnchorValue();
        java.awt.Color color63 = java.awt.Color.WHITE;
        java.awt.Color color64 = java.awt.Color.getColor("", color63);
        categoryPlot60.setDomainGridlinePaint((java.awt.Paint) color63);
        org.jfree.chart.axis.ValueAxis valueAxis66 = categoryPlot60.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot60.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        categoryPlot60.setFixedDomainAxisSpace(axisSpace69, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        org.jfree.data.xy.XYDataset xYDataset74 = null;
        org.jfree.chart.axis.DateAxis dateAxis75 = new org.jfree.chart.axis.DateAxis();
        double double76 = dateAxis75.getLabelAngle();
        boolean boolean77 = dateAxis75.isVerticalTickLabels();
        dateAxis75.setTickMarkOutsideLength((float) 10);
        boolean boolean80 = dateAxis75.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis();
        boolean boolean82 = dateAxis81.isPositiveArrowVisible();
        dateAxis81.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset74, (org.jfree.chart.axis.ValueAxis) dateAxis75, (org.jfree.chart.axis.ValueAxis) dateAxis81, xYItemRenderer85);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder87 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot86.setDatasetRenderingOrder(datasetRenderingOrder87);
        boolean boolean89 = xYPlot86.isRangeCrosshairVisible();
        xYPlot86.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D92 = xYPlot86.getQuadrantOrigin();
        categoryPlot60.zoomRangeAxes((double) 100.0f, plotRenderingInfo73, point2D92);
        categoryPlot18.zoomDomainAxes((double) 10.0f, plotRenderingInfo59, point2D92);
        try {
            xYPlot12.zoomRangeAxes((double) (-1.0f), plotRenderingInfo17, point2D92, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 53 + "'", int56 == 53);
        org.junit.Assert.assertNull(list57);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNull(valueAxis66);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(point2D92);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        boolean boolean17 = xYPlot12.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        xYPlot25.drawAnnotations(graphics2D30, rectangle2D31, plotRenderingInfo32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline35 = null;
        dateAxis34.setTimeline(timeline35);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis34.setAxisLineStroke(stroke37);
        xYPlot25.setOutlineStroke(stroke37);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        xYPlot12.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D18 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        float float21 = dateAxis19.getTickMarkInsideLength();
        int int22 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        xYPlot12.setRangeAxis((int) (short) 100, valueAxis24, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        java.awt.Paint paint3 = dateAxis0.getAxisLinePaint();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setDefaultAutoRange(range4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isPositiveArrowVisible();
        java.awt.Stroke stroke8 = dateAxis6.getTickMarkStroke();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis6.setTickMarkStroke(stroke9);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline12 = null;
        dateAxis11.setTimeline(timeline12);
        java.util.Date date14 = dateAxis11.getMinimumDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        dateAxis6.setMinimumDate(date14);
        java.util.Date date17 = null;
        try {
            dateAxis0.setRange(date14, date17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(100.0d, (double) (-1L), (double) 0, (double) (byte) 100);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
        dateAxis0.setLowerMargin((double) 7);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis0.setTickUnit(dateTickUnit7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Shape shape11 = dateAxis9.getDownArrow();
        dateAxis0.setDownArrow(shape11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double30 = rectangleInsets28.calculateBottomInset((double) 1.0f);
        boolean boolean31 = datasetRenderingOrder27.equals((java.lang.Object) rectangleInsets28);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isPositiveArrowVisible();
        dateAxis32.setAutoRange(false);
        dateAxis32.resizeRange(0.0d, (double) 10);
        dateAxis32.setInverted(true);
        boolean boolean41 = datasetRenderingOrder27.equals((java.lang.Object) dateAxis32);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder27);
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        double double48 = dateAxis47.getLabelAngle();
        boolean boolean49 = dateAxis47.isVerticalTickLabels();
        org.jfree.chart.axis.Timeline timeline50 = dateAxis47.getTimeline();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis46, (org.jfree.chart.axis.ValueAxis) dateAxis47, categoryItemRenderer51);
        categoryPlot0.setDomainAxis(3, categoryAxis46, true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(timeline50);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = dateAxis1.isPositiveArrowVisible();
        java.awt.Stroke stroke3 = dateAxis1.getTickMarkStroke();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis1.setTickMarkStroke(stroke4);
        org.jfree.data.Range range6 = dateAxis1.getRange();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) range6);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot12.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot29.setDatasetRenderingOrder(datasetRenderingOrder30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color34 = java.awt.Color.lightGray;
        categoryMarker33.setLabelPaint((java.awt.Paint) color34);
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean37 = xYPlot29.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker33, layer36);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        categoryMarker33.notifyListeners(markerChangeEvent38);
        boolean boolean40 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker33);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation41 = null;
        try {
            boolean boolean42 = xYPlot12.removeAnnotation(xYAnnotation41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis3.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis3.setUpperMargin(0.0d);
        boolean boolean8 = defaultDrawingSupplier0.equals((java.lang.Object) 0.0d);
        java.lang.Object obj9 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        xYPlot12.setBackgroundImageAlpha((float) 1L);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        double double21 = dateAxis20.getLabelAngle();
        boolean boolean22 = dateAxis20.isVerticalTickLabels();
        dateAxis20.setTickMarkOutsideLength((float) 10);
        boolean boolean25 = dateAxis20.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        dateAxis26.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot31.setDomainAxisLocation(axisLocation32);
        xYPlot12.setRangeAxisLocation(11, axisLocation32, true);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        double double38 = dateAxis37.getLabelAngle();
        boolean boolean39 = dateAxis37.isVerticalTickLabels();
        dateAxis37.setTickMarkOutsideLength((float) 10);
        boolean boolean42 = dateAxis37.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean44 = dateAxis43.isPositiveArrowVisible();
        dateAxis43.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer47);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        xYPlot48.markerChanged(markerChangeEvent49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot48.getDomainAxisEdge();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder52 = xYPlot48.getSeriesRenderingOrder();
        xYPlot12.setSeriesRenderingOrder(seriesRenderingOrder52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(seriesRenderingOrder52);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        double double8 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Color color1 = java.awt.Color.BLUE;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers();
        categoryPlot2.setDrawSharedDomainAxis(false);
        java.awt.Stroke stroke6 = categoryPlot2.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true, (java.awt.Paint) color1, stroke6);
        org.jfree.chart.text.TextAnchor textAnchor8 = categoryMarker7.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        int int3 = objectList0.size();
        objectList0.clear();
        java.lang.Object obj6 = objectList0.get((int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.clearDomainAxes();
        java.awt.Paint paint16 = xYPlot12.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        double double32 = dateAxis31.getLabelAngle();
        boolean boolean33 = dateAxis31.isVerticalTickLabels();
        dateAxis31.setTickMarkOutsideLength((float) 10);
        boolean boolean36 = dateAxis31.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis37.isPositiveArrowVisible();
        dateAxis37.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer41);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder43 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot42.setDatasetRenderingOrder(datasetRenderingOrder43);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = xYPlot42.getDrawingSupplier();
        dateAxis18.setPlot((org.jfree.chart.plot.Plot) xYPlot42);
        java.awt.Stroke stroke47 = xYPlot42.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot42.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        xYPlot42.setFixedRangeAxisSpace(axisSpace49, true);
        xYPlot12.setParent((org.jfree.chart.plot.Plot) xYPlot42);
        java.awt.Paint paint54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        try {
            xYPlot12.setQuadrantPaint(2019, paint54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (2019) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder43);
        org.junit.Assert.assertNotNull(drawingSupplier45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange((double) 255, (-12.0d));
        dateAxis0.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLabelAngle();
        boolean boolean9 = dateAxis7.isVerticalTickLabels();
        dateAxis7.setTickMarkOutsideLength((float) 10);
        boolean boolean12 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        dateAxis13.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot18.setDomainAxisLocation(axisLocation19);
        boolean boolean21 = dateAxis0.hasListener((java.util.EventListener) xYPlot18);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        dateAxis0.setTickLabelInsets(rectangleInsets22);
        dateAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.util.Date date3 = dateAxis0.getMinimumDate();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date3);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        java.awt.Color color15 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean17 = color15.equals((java.lang.Object) textAnchor16);
        dateAxis7.setAxisLinePaint((java.awt.Paint) color15);
        double double19 = dateAxis7.getLabelAngle();
        java.text.DateFormat dateFormat20 = dateAxis7.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(dateFormat20);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        int int4 = day0.getYear();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis0, jFreeChart1);
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        java.lang.String str5 = numberAxis0.getLabelURL();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        double double11 = dateAxis10.getLabelAngle();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        dateAxis10.setTickMarkOutsideLength((float) 10);
        boolean boolean15 = dateAxis10.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        boolean boolean17 = dateAxis16.isPositiveArrowVisible();
        dateAxis16.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot21.getDomainAxisEdge();
        try {
            java.util.List list23 = numberAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(axisLocation13);
        int int15 = xYPlot12.getWeight();
        int int16 = xYPlot12.getDomainAxisCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color20 = java.awt.Color.lightGray;
        categoryMarker19.setLabelPaint((java.awt.Paint) color20);
        java.lang.Object obj22 = categoryMarker19.clone();
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryMarker19.getLabelTextAnchor();
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot12.addRangeMarker(2019, (org.jfree.chart.plot.Marker) categoryMarker19, layer24);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker19.setLabelOffsetType(lengthAdjustmentType26);
        java.awt.Paint paint28 = categoryMarker19.getOutlinePaint();
        java.awt.Paint paint29 = categoryMarker19.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setLowerMargin((double) 1.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis9.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis9.setUpperMargin(0.0d);
        java.awt.Font font15 = categoryAxis9.getTickLabelFont((java.lang.Comparable) 0.0d);
        categoryAxis9.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = categoryAxis9.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        intervalMarker2.setStartValue(0.0d);
        intervalMarker2.setStartValue((double) 7);
        double double7 = intervalMarker2.getEndValue();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setLowerMargin((double) 1.0f);
        categoryAxis1.setLabelToolTip("DatasetRenderingOrder.REVERSE");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setLabelAngle(106.0d);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        xYPlot12.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color16 = java.awt.Color.lightGray;
        categoryMarker15.setLabelPaint((java.awt.Paint) color16);
        java.lang.Object obj18 = categoryMarker15.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = categoryMarker15.getLabelAnchor();
        boolean boolean20 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot12.getRangeAxisForDataset((-515));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -515 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        categoryAxis1.setLowerMargin((double) 1.0f);
        categoryAxis1.setLabelToolTip("DatasetRenderingOrder.REVERSE");
        categoryAxis1.setLowerMargin(0.0d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        boolean boolean21 = dateAxis19.isVerticalTickLabels();
        dateAxis19.setTickMarkOutsideLength((float) 10);
        boolean boolean24 = dateAxis19.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isPositiveArrowVisible();
        dateAxis25.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot30.setDatasetRenderingOrder(datasetRenderingOrder31);
        double double33 = xYPlot30.getRangeCrosshairValue();
        java.awt.Paint paint34 = xYPlot30.getRangeCrosshairPaint();
        xYPlot30.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D37 = xYPlot30.getQuadrantOrigin();
        categoryPlot13.zoomDomainAxes((double) (-1L), plotRenderingInfo17, point2D37, true);
        categoryPlot13.configureDomainAxes();
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot13.setRangeGridlinePaint((java.awt.Paint) color41);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        double double45 = categoryPlot44.getAnchorValue();
        int int46 = categoryPlot44.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot44.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace50 = categoryAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot13, rectangle2D43, rectangleEdge48, axisSpace49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(point2D37);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        int int10 = categoryPlot0.getWeight();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLabelAngle();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        dateAxis12.setTickMarkOutsideLength((float) 10);
        boolean boolean17 = dateAxis12.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isPositiveArrowVisible();
        dateAxis18.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot23.setDatasetRenderingOrder(datasetRenderingOrder24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = xYPlot23.getDrawingSupplier();
        boolean boolean27 = xYPlot23.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        boolean boolean30 = xYPlot23.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        categoryPlot0.addDomainMarker(categoryMarker29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation32, true);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setAxisLineStroke(stroke3);
        dateAxis0.resizeRange((double) (short) 100);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.0d);
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 1);
        categoryAxis1.setTickLabelsVisible(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean20 = numberAxis19.getAutoRangeIncludesZero();
        numberAxis19.setAutoRangeStickyZero(true);
        numberAxis19.setAutoRangeIncludesZero(true);
        categoryPlot16.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis19, true);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot16.getDomainAxisEdge((int) (short) 0);
        try {
            double double31 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor12, 6, 9, rectangle2D15, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        int int10 = categoryPlot0.getWeight();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        double double13 = dateAxis12.getLabelAngle();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        dateAxis12.setTickMarkOutsideLength((float) 10);
        boolean boolean17 = dateAxis12.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = dateAxis18.isPositiveArrowVisible();
        dateAxis18.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot23.setDatasetRenderingOrder(datasetRenderingOrder24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = xYPlot23.getDrawingSupplier();
        boolean boolean27 = xYPlot23.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        boolean boolean30 = xYPlot23.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        categoryPlot0.addDomainMarker(categoryMarker29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        try {
            categoryMarker29.setLabelOffsetType(lengthAdjustmentType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot12.setRenderer(7, xYItemRenderer14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(axisLocation13);
        int int15 = xYPlot12.getWeight();
        int int16 = xYPlot12.getDomainAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = xYPlot12.getOrientation();
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj21 = intervalMarker20.clone();
        double double22 = intervalMarker20.getEndValue();
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean24 = xYPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker20, layer23);
        java.lang.Object obj25 = intervalMarker20.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Shape shape2 = dateAxis0.getUpArrow();
        dateAxis0.setAutoRangeMinimumSize((double) 1L, true);
        boolean boolean6 = dateAxis0.isAutoRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) "DatasetRenderingOrder.REVERSE");
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryAnchor0.equals(obj3);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        boolean boolean6 = categoryAnchor0.equals((java.lang.Object) paintArray5);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        int int13 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) seriesRenderingOrder0);
        java.lang.String str2 = chartChangeEvent1.toString();
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent1.getChart();
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent1.getChart();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent1.setChart(jFreeChart5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]"));
        org.junit.Assert.assertNull(jFreeChart3);
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        java.awt.Color color15 = java.awt.Color.cyan;
        xYPlot12.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot12.getDomainAxisEdge();
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot12.setOutlinePaint((java.awt.Paint) color18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color17 = java.awt.Color.lightGray;
        categoryMarker16.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryMarker16.notifyListeners(markerChangeEvent21);
        float float23 = categoryMarker16.getAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean5 = day2.equals((java.lang.Object) day4);
//        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day2);
//        java.awt.Graphics2D graphics2D7 = null;
//        java.awt.geom.Rectangle2D rectangle2D9 = null;
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        org.jfree.data.xy.XYDataset xYDataset11 = null;
//        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
//        double double13 = dateAxis12.getLabelAngle();
//        boolean boolean14 = dateAxis12.isVerticalTickLabels();
//        dateAxis12.setTickMarkOutsideLength((float) 10);
//        boolean boolean17 = dateAxis12.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean19 = dateAxis18.isPositiveArrowVisible();
//        dateAxis18.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
//        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer22);
//        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
//        xYPlot23.setDomainAxisLocation(axisLocation24);
//        org.jfree.data.xy.XYDataset xYDataset26 = null;
//        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
//        double double28 = dateAxis27.getLabelAngle();
//        boolean boolean29 = dateAxis27.isVerticalTickLabels();
//        dateAxis27.setTickMarkOutsideLength((float) 10);
//        boolean boolean32 = dateAxis27.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean34 = dateAxis33.isPositiveArrowVisible();
//        dateAxis33.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
//        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis33, xYItemRenderer37);
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent39 = null;
//        xYPlot38.markerChanged(markerChangeEvent39);
//        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot38.getDomainAxisEdge();
//        org.jfree.chart.plot.PlotOrientation plotOrientation42 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
//        xYPlot38.setOrientation(plotOrientation42);
//        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation24, plotOrientation42);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
//        try {
//            org.jfree.chart.axis.AxisState axisState46 = categoryAxis1.draw(graphics2D7, 0.0d, rectangle2D9, rectangle2D10, rectangleEdge44, plotRenderingInfo45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(axisLocation24);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge41);
//        org.junit.Assert.assertNotNull(plotOrientation42);
//        org.junit.Assert.assertNotNull(rectangleEdge44);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        intervalMarker2.setStartValue(0.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers();
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) categoryPlot5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.Comparable comparable0 = null;
        java.awt.Color color1 = java.awt.Color.lightGray;
        int int2 = color1.getAlpha();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint4 = null;
        java.awt.Stroke stroke5 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker(comparable0, (java.awt.Paint) color1, stroke3, paint4, stroke5, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double30 = rectangleInsets28.calculateBottomInset((double) 1.0f);
        boolean boolean31 = datasetRenderingOrder27.equals((java.lang.Object) rectangleInsets28);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        boolean boolean33 = dateAxis32.isPositiveArrowVisible();
        dateAxis32.setAutoRange(false);
        dateAxis32.resizeRange(0.0d, (double) 10);
        dateAxis32.setInverted(true);
        boolean boolean41 = datasetRenderingOrder27.equals((java.lang.Object) dateAxis32);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder27);
        categoryPlot0.setRangeCrosshairValue((double) (-1.0f), true);
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        double double49 = dateAxis48.getLabelAngle();
        boolean boolean50 = dateAxis48.isVerticalTickLabels();
        dateAxis48.setTickMarkOutsideLength((float) 10);
        boolean boolean53 = dateAxis48.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        boolean boolean55 = dateAxis54.isPositiveArrowVisible();
        dateAxis54.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) dateAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer58);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder60 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot59.setDatasetRenderingOrder(datasetRenderingOrder60);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier62 = xYPlot59.getDrawingSupplier();
        xYPlot59.setBackgroundImageAlpha((float) 1L);
        org.jfree.data.xy.XYDataset xYDataset66 = null;
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis();
        double double68 = dateAxis67.getLabelAngle();
        boolean boolean69 = dateAxis67.isVerticalTickLabels();
        dateAxis67.setTickMarkOutsideLength((float) 10);
        boolean boolean72 = dateAxis67.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis();
        boolean boolean74 = dateAxis73.isPositiveArrowVisible();
        dateAxis73.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer77 = null;
        org.jfree.chart.plot.XYPlot xYPlot78 = new org.jfree.chart.plot.XYPlot(xYDataset66, (org.jfree.chart.axis.ValueAxis) dateAxis67, (org.jfree.chart.axis.ValueAxis) dateAxis73, xYItemRenderer77);
        org.jfree.chart.axis.AxisLocation axisLocation79 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot78.setDomainAxisLocation(axisLocation79);
        xYPlot59.setRangeAxisLocation(11, axisLocation79, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker84 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color85 = java.awt.Color.lightGray;
        categoryMarker84.setLabelPaint((java.awt.Paint) color85);
        java.lang.Object obj87 = categoryMarker84.clone();
        org.jfree.chart.text.TextAnchor textAnchor88 = categoryMarker84.getLabelTextAnchor();
        java.awt.Color color89 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker84.setPaint((java.awt.Paint) color89);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType91 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker84.setLabelOffsetType(lengthAdjustmentType91);
        boolean boolean93 = axisLocation79.equals((java.lang.Object) lengthAdjustmentType91);
        categoryPlot0.setDomainAxisLocation(9, axisLocation79);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder60);
        org.junit.Assert.assertNotNull(drawingSupplier62);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertNotNull(obj87);
        org.junit.Assert.assertNotNull(textAnchor88);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNotNull(lengthAdjustmentType91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis0.setTickMarkStroke(stroke4);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        org.jfree.chart.axis.Timeline timeline8 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        dateAxis9.resizeRange((double) 255, (-12.0d));
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setRange((org.jfree.data.Range) dateRange13, true, true);
        dateAxis0.setRange((org.jfree.data.Range) dateRange13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(timeline8);
        org.junit.Assert.assertNotNull(dateRange13);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        java.awt.Color color15 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean17 = color15.equals((java.lang.Object) textAnchor16);
        dateAxis7.setAxisLinePaint((java.awt.Paint) color15);
        double double19 = dateAxis7.getLabelAngle();
        dateAxis7.centerRange((double) 12);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        double double28 = dateAxis27.getLabelAngle();
        boolean boolean29 = dateAxis27.isVerticalTickLabels();
        dateAxis27.setTickMarkOutsideLength((float) 10);
        boolean boolean32 = dateAxis27.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis33.isPositiveArrowVisible();
        dateAxis33.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis33, xYItemRenderer37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot38.setDatasetRenderingOrder(datasetRenderingOrder39);
        double double41 = xYPlot38.getRangeCrosshairValue();
        java.awt.Paint paint42 = xYPlot38.getRangeCrosshairPaint();
        xYPlot38.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        int int46 = xYPlot38.indexOf(xYDataset45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = xYPlot38.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            org.jfree.chart.axis.AxisState axisState49 = dateAxis7.draw(graphics2D22, (double) 6, rectangle2D24, rectangle2D25, rectangleEdge47, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot12.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        java.awt.Stroke stroke21 = dateAxis19.getTickMarkStroke();
        double double22 = dateAxis19.getUpperMargin();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis19.setTickMarkStroke(stroke23);
        categoryMarker18.setOutlineStroke(stroke23);
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer26);
        java.awt.Color color28 = java.awt.Color.green;
        categoryMarker18.setOutlinePaint((java.awt.Paint) color28);
        categoryMarker18.setKey((java.lang.Comparable) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setCategoryLabelPositionOffset(0);
        categoryAxis1.setVisible(false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        xYPlot12.zoom(0.0d);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        boolean boolean21 = dateAxis19.isVerticalTickLabels();
        dateAxis19.setTickMarkOutsideLength((float) 10);
        boolean boolean24 = dateAxis19.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isPositiveArrowVisible();
        dateAxis25.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot30.setDatasetRenderingOrder(datasetRenderingOrder31);
        java.lang.String str33 = datasetRenderingOrder31.toString();
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder31);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.resizeRange((double) 255, (-12.0d));
        org.jfree.data.time.DateRange dateRange39 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis35.setRange((org.jfree.data.Range) dateRange39, true, true);
        int int43 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str33.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(dateRange39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.resizeRange((double) 255, (-12.0d));
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        double double9 = dateAxis8.getLabelAngle();
        boolean boolean10 = dateAxis8.isVerticalTickLabels();
        dateAxis8.setTickMarkOutsideLength((float) 10);
        boolean boolean13 = dateAxis8.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isPositiveArrowVisible();
        dateAxis14.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot19.setDomainAxisLocation(axisLocation20);
        boolean boolean22 = dateAxis1.hasListener((java.util.EventListener) xYPlot19);
        float float23 = xYPlot19.getForegroundAlpha();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = xYPlot19.getLegendItems();
        boolean boolean25 = sortOrder0.equals((java.lang.Object) xYPlot19);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType5 = numberAxis4.getRangeType();
        objectList0.set((int) (short) 100, (java.lang.Object) rangeType5);
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(rangeType5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot0.getOrientation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot0.setRenderer(6, categoryItemRenderer13, false);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        xYPlot28.setRenderer(0, xYItemRenderer32);
        java.awt.Stroke stroke34 = xYPlot28.getDomainGridlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke34);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        double double38 = categoryPlot37.getAnchorValue();
        java.awt.Color color40 = java.awt.Color.WHITE;
        java.awt.Color color41 = java.awt.Color.getColor("", color40);
        categoryPlot37.setDomainGridlinePaint((java.awt.Paint) color40);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean44 = numberAxis43.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat45 = null;
        numberAxis43.setNumberFormatOverride(numberFormat45);
        categoryPlot37.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis43);
        categoryPlot37.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryPlot37.getInsets();
        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot37.getRangeAxisLocation((int) '#');
        categoryPlot0.setDomainAxisLocation(11, axisLocation53, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(axisLocation53);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean20 = numberAxis19.getAutoRangeIncludesZero();
        numberAxis19.setAutoRangeStickyZero(true);
        numberAxis19.setAutoRangeIncludesZero(true);
        categoryPlot16.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis19, true);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        categoryPlot16.setDataset(0, categoryDataset28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        double double34 = dateAxis33.getLabelAngle();
        boolean boolean35 = dateAxis33.isVerticalTickLabels();
        dateAxis33.setTickMarkOutsideLength((float) 10);
        boolean boolean38 = dateAxis33.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        boolean boolean40 = dateAxis39.isPositiveArrowVisible();
        dateAxis39.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis39, xYItemRenderer43);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot44.setDatasetRenderingOrder(datasetRenderingOrder45);
        double double47 = xYPlot44.getRangeCrosshairValue();
        java.awt.Paint paint48 = xYPlot44.getRangeCrosshairPaint();
        xYPlot44.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D51 = xYPlot44.getQuadrantOrigin();
        categoryPlot16.zoomDomainAxes((double) (byte) 10, plotRenderingInfo31, point2D51, false);
        categoryPlot0.zoomRangeAxes((double) 100, plotRenderingInfo15, point2D51, false);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis();
        double double58 = dateAxis57.getLabelAngle();
        boolean boolean59 = dateAxis57.isVerticalTickLabels();
        dateAxis57.setTickMarkOutsideLength((float) 10);
        boolean boolean62 = dateAxis57.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis();
        boolean boolean64 = dateAxis63.isPositiveArrowVisible();
        dateAxis63.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis63, xYItemRenderer67);
        org.jfree.chart.axis.AxisLocation axisLocation69 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot68.setDomainAxisLocation(axisLocation69);
        org.jfree.data.xy.XYDataset xYDataset71 = null;
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis();
        double double73 = dateAxis72.getLabelAngle();
        boolean boolean74 = dateAxis72.isVerticalTickLabels();
        dateAxis72.setTickMarkOutsideLength((float) 10);
        boolean boolean77 = dateAxis72.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis();
        boolean boolean79 = dateAxis78.isPositiveArrowVisible();
        dateAxis78.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer82 = null;
        org.jfree.chart.plot.XYPlot xYPlot83 = new org.jfree.chart.plot.XYPlot(xYDataset71, (org.jfree.chart.axis.ValueAxis) dateAxis72, (org.jfree.chart.axis.ValueAxis) dateAxis78, xYItemRenderer82);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent84 = null;
        xYPlot83.markerChanged(markerChangeEvent84);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = xYPlot83.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation87 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot83.setOrientation(plotOrientation87);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation69, plotOrientation87);
        categoryPlot0.setDomainAxisLocation(axisLocation69);
        org.jfree.chart.axis.AxisLocation axisLocation92 = categoryPlot0.getDomainAxisLocation((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(point2D51);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertNotNull(plotOrientation87);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertNotNull(axisLocation92);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color5 = java.awt.Color.lightGray;
        categoryMarker4.setLabelPaint((java.awt.Paint) color5);
        java.lang.Object obj7 = categoryMarker4.clone();
        org.jfree.chart.text.TextAnchor textAnchor8 = categoryMarker4.getLabelTextAnchor();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker4.setPaint((java.awt.Paint) color9);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker4.setLabelOffsetType(lengthAdjustmentType11);
        boolean boolean14 = lengthAdjustmentType11.equals((java.lang.Object) 11);
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(lengthAdjustmentType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
//        double double2 = dateAxis1.getLabelAngle();
//        boolean boolean3 = dateAxis1.isVerticalTickLabels();
//        dateAxis1.setTickMarkOutsideLength((float) 10);
//        boolean boolean6 = dateAxis1.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
//        dateAxis7.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
//        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
//        double double15 = xYPlot12.getRangeCrosshairValue();
//        org.jfree.chart.util.Layer layer16 = null;
//        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
//        java.lang.Class<?> wildcardClass18 = xYPlot12.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.String str22 = day21.toString();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean24 = day21.equals((java.lang.Object) day23);
//        java.util.Date date25 = day21.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day21.next();
//        int int27 = day21.getMonth();
//        java.util.Date date28 = day21.getEnd();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date28, timeZone29);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertNull(collection17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLabelAngle();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis3.getTimeline();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        categoryAxis2.setCategoryLabelPositionOffset((int) (short) 100);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis2.setTickLabelPaint(paint11);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        double double4 = dateAxis3.getLabelAngle();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis3.getTimeline();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer7);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getLabelAngle();
        boolean boolean15 = dateAxis13.isVerticalTickLabels();
        dateAxis13.setTickMarkOutsideLength((float) 10);
        boolean boolean18 = dateAxis13.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        dateAxis19.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer23);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot24.setDatasetRenderingOrder(datasetRenderingOrder25);
        boolean boolean27 = xYPlot24.isRangeCrosshairVisible();
        java.awt.Paint paint28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        xYPlot24.setBackgroundPaint(paint28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot24.getDomainAxisEdge((int) (byte) 10);
        try {
            double double32 = categoryAxis2.getCategoryStart(100, 11, rectangle2D11, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        xYPlot25.setRangeAxis(valueAxis32);
        xYPlot25.setWeight((int) '4');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        int int37 = xYPlot25.getIndexOf(xYItemRenderer36);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        xYPlot25.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset35 = xYPlot25.getDataset();
        boolean boolean36 = xYPlot25.isDomainCrosshairLockedOnData();
        xYPlot25.setWeight(12);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot25.getDomainAxis();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(xYDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(valueAxis39);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 100, (int) (short) -1);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.0d);
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 1);
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        double double17 = dateAxis16.getLabelAngle();
        boolean boolean18 = dateAxis16.isVerticalTickLabels();
        dateAxis16.setTickMarkOutsideLength((float) 10);
        boolean boolean21 = dateAxis16.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
        dateAxis22.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot27.setDatasetRenderingOrder(datasetRenderingOrder28);
        java.awt.Paint paint30 = xYPlot27.getDomainZeroBaselinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot27.getDomainAxisEdge((-515));
        try {
            double double33 = categoryAxis1.getCategoryMiddle((int) (short) 1, (int) (short) -1, rectangle2D14, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        double double19 = dateAxis18.getLabelAngle();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        dateAxis18.setTickMarkOutsideLength((float) 10);
        boolean boolean23 = dateAxis18.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isPositiveArrowVisible();
        dateAxis24.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        double double32 = dateAxis31.getLabelAngle();
        boolean boolean33 = dateAxis31.isVerticalTickLabels();
        dateAxis31.setTickMarkOutsideLength((float) 10);
        boolean boolean36 = dateAxis31.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        boolean boolean38 = dateAxis37.isPositiveArrowVisible();
        dateAxis37.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer41);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder43 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot42.setDatasetRenderingOrder(datasetRenderingOrder43);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = xYPlot42.getDrawingSupplier();
        dateAxis18.setPlot((org.jfree.chart.plot.Plot) xYPlot42);
        java.awt.Stroke stroke47 = xYPlot42.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot42.getDomainAxisLocation();
        xYPlot42.zoom((double) '4');
        xYPlot42.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj55 = intervalMarker54.clone();
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot42.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker54, layer56);
        org.jfree.chart.util.Layer layer58 = null;
        try {
            xYPlot12.addDomainMarker(255, (org.jfree.chart.plot.Marker) intervalMarker54, layer58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder43);
        org.junit.Assert.assertNotNull(drawingSupplier45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(layer56);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) ' ');
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        xYPlot12.zoom(0.0d);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot12.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke20 = categoryPlot19.getRangeGridlineStroke();
        xYPlot12.setRangeCrosshairStroke(stroke20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis0.setNumberFormatOverride(numberFormat6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        double double14 = dateAxis13.getLabelAngle();
        boolean boolean15 = dateAxis13.isVerticalTickLabels();
        dateAxis13.setTickMarkOutsideLength((float) 10);
        boolean boolean18 = dateAxis13.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        dateAxis19.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer23);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot24.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            org.jfree.chart.axis.AxisState axisState29 = numberAxis0.draw(graphics2D8, (double) 10, rectangle2D10, rectangle2D11, rectangleEdge27, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset4 = categoryPlot0.getDataset();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNull(categoryDataset4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        categoryPlot0.configureDomainAxes();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color28);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        boolean boolean31 = dateAxis30.isPositiveArrowVisible();
        java.awt.Stroke stroke32 = dateAxis30.getTickMarkStroke();
        double double33 = dateAxis30.getUpperMargin();
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis30.setTickMarkStroke(stroke34);
        org.jfree.data.Range range36 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        float float37 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        categoryPlot0.configureDomainAxes();
        java.awt.Stroke stroke28 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        java.lang.String str4 = unitType3.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UnitType.ABSOLUTE" + "'", str4.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        xYPlot12.clearDomainMarkers();
        int int14 = xYPlot12.getDomainAxisCount();
        org.jfree.data.general.DatasetGroup datasetGroup15 = xYPlot12.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(datasetGroup15);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        double double7 = dateAxis6.getLabelAngle();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        dateAxis6.setTickMarkOutsideLength((float) 10);
        boolean boolean11 = dateAxis6.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
        dateAxis12.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
        double double20 = xYPlot17.getRangeCrosshairValue();
        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
        xYPlot17.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot0.getRangeAxis(10);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNull(valueAxis28);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot12.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isPositiveArrowVisible();
        java.awt.Stroke stroke21 = dateAxis19.getTickMarkStroke();
        double double22 = dateAxis19.getUpperMargin();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis19.setTickMarkStroke(stroke23);
        categoryMarker18.setOutlineStroke(stroke23);
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer26);
        java.awt.Color color28 = java.awt.Color.green;
        categoryMarker18.setOutlinePaint((java.awt.Paint) color28);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        categoryMarker18.notifyListeners(markerChangeEvent30);
        java.awt.Stroke stroke32 = categoryMarker18.getStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        xYPlot25.setRangeAxis(valueAxis32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = xYPlot25.getFixedLegendItems();
        java.lang.String str35 = xYPlot25.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(legendItemCollection34);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot25.setRangeAxisLocation(0, axisLocation33, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot25.setDomainAxes(valueAxisArray36);
        int int38 = xYPlot25.getDomainAxisCount();
        xYPlot25.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(0, categoryDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        double double31 = xYPlot28.getRangeCrosshairValue();
        java.awt.Paint paint32 = xYPlot28.getRangeCrosshairPaint();
        xYPlot28.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D35 = xYPlot28.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D35, false);
        int int38 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker41 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj42 = intervalMarker41.clone();
        double double43 = intervalMarker41.getStartValue();
        java.awt.Paint paint44 = null;
        intervalMarker41.setOutlinePaint(paint44);
        boolean boolean46 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            categoryPlot0.handleClick(6, 3, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 9.0d + "'", double43 == 9.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
//        dateAxis0.setAutoRange(false);
//        dateAxis0.resizeRange(0.0d, (double) 10);
//        dateAxis0.setInverted(true);
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
//        java.awt.Stroke stroke11 = dateAxis9.getTickMarkStroke();
//        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
//        dateAxis9.setTickMarkStroke(stroke12);
//        org.jfree.data.Range range14 = dateAxis9.getRange();
//        dateAxis0.setRange(range14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        boolean boolean19 = day16.equals((java.lang.Object) day18);
//        java.util.Date date20 = day16.getStart();
//        dateAxis0.setMaximumDate(date20);
//        boolean boolean22 = dateAxis0.isPositiveArrowVisible();
//        java.awt.Shape shape23 = null;
//        try {
//            dateAxis0.setRightArrow(shape23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(stroke11);
//        org.junit.Assert.assertNotNull(stroke12);
//        org.junit.Assert.assertNotNull(range14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        double double2 = dateAxis0.getLabelAngle();
        dateAxis0.resizeRange((double) 500);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot12.getOrientation();
        boolean boolean18 = plotOrientation16.equals((java.lang.Object) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        double double21 = dateAxis20.getLabelAngle();
        boolean boolean22 = dateAxis20.isVerticalTickLabels();
        dateAxis20.setTickMarkOutsideLength((float) 10);
        boolean boolean25 = dateAxis20.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        dateAxis26.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot31.setDomainAxisLocation(axisLocation32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        double double36 = dateAxis35.getLabelAngle();
        boolean boolean37 = dateAxis35.isVerticalTickLabels();
        dateAxis35.setTickMarkOutsideLength((float) 10);
        boolean boolean40 = dateAxis35.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        boolean boolean42 = dateAxis41.isPositiveArrowVisible();
        dateAxis41.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis41, xYItemRenderer45);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent47 = null;
        xYPlot46.markerChanged(markerChangeEvent47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot46.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot46.setOrientation(plotOrientation50);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation32, plotOrientation50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = axisLocation32.getOpposite();
        boolean boolean54 = plotOrientation16.equals((java.lang.Object) axisLocation53);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        xYPlot12.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D19 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = xYPlot12.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot12.getRangeAxisLocation(9);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj26 = intervalMarker25.clone();
        xYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker25);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke29 = categoryPlot28.getRangeGridlineStroke();
        boolean boolean30 = intervalMarker25.equals((java.lang.Object) stroke29);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        float[] floatArray4 = null;
        float[] floatArray5 = color0.getColorComponents(colorSpace3, floatArray4);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 100, (int) (short) -1);
        org.jfree.chart.util.SortOrder sortOrder14 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str15 = sortOrder14.toString();
        categoryPlot0.setRowRenderingOrder(sortOrder14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "SortOrder.DESCENDING" + "'", str15.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setUpperMargin(0.0d);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        double double13 = categoryPlot12.getAnchorValue();
        java.awt.Color color15 = java.awt.Color.WHITE;
        java.awt.Color color16 = java.awt.Color.getColor("", color15);
        categoryPlot12.setDomainGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot12.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot12.getDomainAxisEdge((int) '4');
        try {
            java.util.List list21 = categoryAxis1.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis0.setTickMarkStroke(stroke4);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        xYPlot12.setBackgroundAlpha((float) '#');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot12.getRenderer(0);
        xYPlot12.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNull(xYItemRenderer18);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        java.awt.Color color9 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean11 = color9.equals((java.lang.Object) textAnchor10);
        categoryAxis1.setLabelPaint((java.awt.Paint) color9);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 1.0d, font14);
        categoryAxis1.setUpperMargin((double) 500);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) "RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot25.setRangeAxisLocation(0, axisLocation33, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj39 = intervalMarker38.clone();
        double double40 = intervalMarker38.getStartValue();
        java.awt.Paint paint41 = null;
        intervalMarker38.setOutlinePaint(paint41);
        xYPlot25.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        xYPlot25.setDomainCrosshairLockedOnData(false);
        java.awt.Paint paint46 = xYPlot25.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 9.0d + "'", double40 == 9.0d);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setAutoRange(false);
        dateAxis0.resizeRange(0.0d, (double) 10);
        boolean boolean8 = dateAxis0.isHiddenValue((long) 3);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = dateAxis9.isPositiveArrowVisible();
        java.awt.Stroke stroke11 = dateAxis9.getTickMarkStroke();
        double double12 = dateAxis9.getUpperMargin();
        dateAxis9.setTickMarkInsideLength((float) '#');
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.resizeRange((double) 255, (-12.0d));
        dateAxis15.setPositiveArrowVisible(true);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLabelAngle();
        boolean boolean24 = dateAxis22.isVerticalTickLabels();
        dateAxis22.setTickMarkOutsideLength((float) 10);
        boolean boolean27 = dateAxis22.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean29 = dateAxis28.isPositiveArrowVisible();
        dateAxis28.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot33.setDomainAxisLocation(axisLocation34);
        boolean boolean36 = dateAxis15.hasListener((java.util.EventListener) xYPlot33);
        dateAxis9.setPlot((org.jfree.chart.plot.Plot) xYPlot33);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        boolean boolean39 = dateAxis38.isPositiveArrowVisible();
        java.awt.Stroke stroke40 = dateAxis38.getTickMarkStroke();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis38.setTickMarkStroke(stroke41);
        org.jfree.data.Range range43 = dateAxis38.getRange();
        dateAxis9.setRangeWithMargins(range43, false, false);
        dateAxis0.setRange(range43);
        dateAxis0.setUpperMargin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets2, jFreeChart5, chartChangeEventType6);
        java.lang.String str8 = chartChangeEventType6.toString();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str8.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        double double32 = categoryPlot31.getAnchorValue();
        java.awt.Color color34 = java.awt.Color.WHITE;
        java.awt.Color color35 = java.awt.Color.getColor("", color34);
        categoryPlot31.setDomainGridlinePaint((java.awt.Paint) color34);
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot31.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot31.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj44 = intervalMarker43.clone();
        double double45 = intervalMarker43.getStartValue();
        java.awt.Paint paint46 = null;
        intervalMarker43.setOutlinePaint(paint46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot31.addRangeMarker(5, (org.jfree.chart.plot.Marker) intervalMarker43, layer48);
        java.util.Collection collection50 = xYPlot25.getDomainMarkers(layer48);
        xYPlot25.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 9.0d + "'", double45 == 9.0d);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection50);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3, false);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot0.setDomainAxisLocation((int) '4', axisLocation13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot12.setDomainAxisLocation(axisLocation13);
        int int15 = xYPlot12.getWeight();
        int int16 = xYPlot12.getDomainAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = xYPlot12.getOrientation();
        java.lang.String str18 = plotOrientation17.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PlotOrientation.VERTICAL" + "'", str18.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        xYPlot12.zoom(0.0d);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot12.removeChangeListener(plotChangeListener18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        double double22 = dateAxis21.getLabelAngle();
        boolean boolean23 = dateAxis21.isVerticalTickLabels();
        dateAxis21.setTickMarkOutsideLength((float) 10);
        boolean boolean26 = dateAxis21.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = dateAxis27.isPositiveArrowVisible();
        dateAxis27.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer31);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot32);
        org.jfree.chart.plot.Plot plot34 = plotChangeEvent33.getPlot();
        xYPlot12.notifyListeners(plotChangeEvent33);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        double double39 = dateAxis38.getLabelAngle();
        boolean boolean40 = dateAxis38.isVerticalTickLabels();
        dateAxis38.setTickMarkOutsideLength((float) 10);
        boolean boolean43 = dateAxis38.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        boolean boolean45 = dateAxis44.isPositiveArrowVisible();
        dateAxis44.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer48);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder50 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot49.setDatasetRenderingOrder(datasetRenderingOrder50);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier52 = xYPlot49.getDrawingSupplier();
        xYPlot49.setBackgroundImageAlpha((float) 1L);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis();
        double double58 = dateAxis57.getLabelAngle();
        boolean boolean59 = dateAxis57.isVerticalTickLabels();
        dateAxis57.setTickMarkOutsideLength((float) 10);
        boolean boolean62 = dateAxis57.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis();
        boolean boolean64 = dateAxis63.isPositiveArrowVisible();
        dateAxis63.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis63, xYItemRenderer67);
        org.jfree.chart.axis.AxisLocation axisLocation69 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot68.setDomainAxisLocation(axisLocation69);
        xYPlot49.setRangeAxisLocation(11, axisLocation69, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker74 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color75 = java.awt.Color.lightGray;
        categoryMarker74.setLabelPaint((java.awt.Paint) color75);
        java.lang.Object obj77 = categoryMarker74.clone();
        org.jfree.chart.text.TextAnchor textAnchor78 = categoryMarker74.getLabelTextAnchor();
        java.awt.Color color79 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker74.setPaint((java.awt.Paint) color79);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType81 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker74.setLabelOffsetType(lengthAdjustmentType81);
        boolean boolean83 = axisLocation69.equals((java.lang.Object) lengthAdjustmentType81);
        xYPlot12.setDomainAxisLocation(12, axisLocation69, false);
        org.jfree.data.xy.XYDataset xYDataset87 = xYPlot12.getDataset(4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(plot34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder50);
        org.junit.Assert.assertNotNull(drawingSupplier52);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(obj77);
        org.junit.Assert.assertNotNull(textAnchor78);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNotNull(lengthAdjustmentType81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(xYDataset87);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Category Plot");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getLabelAngle();
        boolean boolean9 = dateAxis7.isVerticalTickLabels();
        dateAxis7.setTickMarkOutsideLength((float) 10);
        boolean boolean12 = dateAxis7.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isPositiveArrowVisible();
        dateAxis13.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot18.setDomainAxisLocation(axisLocation19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        double double23 = dateAxis22.getLabelAngle();
        boolean boolean24 = dateAxis22.isVerticalTickLabels();
        dateAxis22.setTickMarkOutsideLength((float) 10);
        boolean boolean27 = dateAxis22.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        boolean boolean29 = dateAxis28.isPositiveArrowVisible();
        dateAxis28.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis28, xYItemRenderer32);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        xYPlot33.markerChanged(markerChangeEvent34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot33.getDomainAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot33.setOrientation(plotOrientation37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation37);
        try {
            double double40 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor2, 13, (int) '4', rectangle2D5, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Color color2 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean4 = color2.equals((java.lang.Object) textAnchor3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        boolean boolean6 = textAnchor3.equals((java.lang.Object) font5);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        int int11 = categoryPlot0.getWeight();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot0.clearDomainMarkers();
//        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
//        org.jfree.data.xy.XYDataset xYDataset5 = null;
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
//        double double7 = dateAxis6.getLabelAngle();
//        boolean boolean8 = dateAxis6.isVerticalTickLabels();
//        dateAxis6.setTickMarkOutsideLength((float) 10);
//        boolean boolean11 = dateAxis6.isTickLabelsVisible();
//        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
//        boolean boolean13 = dateAxis12.isPositiveArrowVisible();
//        dateAxis12.setAutoRange(false);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
//        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer16);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        xYPlot17.setDatasetRenderingOrder(datasetRenderingOrder18);
//        double double20 = xYPlot17.getRangeCrosshairValue();
//        java.awt.Paint paint21 = xYPlot17.getRangeCrosshairPaint();
//        xYPlot17.setDomainCrosshairLockedOnData(false);
//        java.awt.geom.Point2D point2D24 = xYPlot17.getQuadrantOrigin();
//        categoryPlot0.zoomDomainAxes((double) (-1L), plotRenderingInfo4, point2D24, true);
//        categoryPlot0.configureDomainAxes();
//        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
//        categoryPlot0.setFixedDomainAxisSpace(axisSpace28);
//        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        boolean boolean35 = day32.equals((java.lang.Object) day34);
//        java.lang.String str36 = categoryAxis31.getCategoryLabelToolTip((java.lang.Comparable) day32);
//        categoryAxis31.setAxisLineVisible(true);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        boolean boolean42 = day39.equals((java.lang.Object) day41);
//        categoryAxis31.removeCategoryLabelToolTip((java.lang.Comparable) day39);
//        java.util.List list44 = categoryPlot0.getCategoriesForAxis(categoryAxis31);
//        org.junit.Assert.assertNotNull(rectangleEdge2);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertNotNull(paint21);
//        org.junit.Assert.assertNotNull(point2D24);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(list44);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 0, (int) '4', 15);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
//        java.lang.Object obj1 = null;
//        int int2 = objectList0.indexOf(obj1);
//        int int3 = objectList0.size();
//        java.lang.Object obj4 = objectList0.clone();
//        java.awt.Color color6 = java.awt.Color.blue;
//        objectList0.set(3, (java.lang.Object) color6);
//        java.lang.Object obj9 = objectList0.get(12);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean14 = day11.equals((java.lang.Object) day13);
//        java.util.Date date15 = day11.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
//        int int17 = day11.getMonth();
//        java.util.Date date18 = day11.getEnd();
//        objectList0.set(15, (java.lang.Object) date18);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 0, (double) 0.0f, (-12.0d), (double) (-1.0f));
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        java.awt.Stroke stroke31 = xYPlot25.getDomainZeroBaselineStroke();
        xYPlot25.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        double double17 = dateAxis16.getLabelAngle();
        boolean boolean18 = dateAxis16.isVerticalTickLabels();
        dateAxis16.setTickMarkOutsideLength((float) 10);
        boolean boolean21 = dateAxis16.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
        dateAxis22.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot27.setDatasetRenderingOrder(datasetRenderingOrder28);
        double double30 = xYPlot27.getRangeCrosshairValue();
        java.awt.Paint paint31 = xYPlot27.getRangeCrosshairPaint();
        xYPlot27.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D34 = xYPlot27.getQuadrantOrigin();
        xYPlot12.setQuadrantOrigin(point2D34);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.util.List list38 = null;
        xYPlot12.drawDomainTickBands(graphics2D36, rectangle2D37, list38);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = xYPlot12.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        double double44 = categoryPlot43.getAnchorValue();
        java.awt.Color color46 = java.awt.Color.WHITE;
        java.awt.Color color47 = java.awt.Color.getColor("", color46);
        categoryPlot43.setDomainGridlinePaint((java.awt.Paint) color46);
        org.jfree.chart.axis.ValueAxis valueAxis49 = categoryPlot43.getRangeAxis();
        java.util.List list50 = categoryPlot43.getCategories();
        categoryPlot43.configureRangeAxes();
        boolean boolean52 = categoryPlot43.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot55.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean59 = numberAxis58.getAutoRangeIncludesZero();
        numberAxis58.setAutoRangeStickyZero(true);
        numberAxis58.setAutoRangeIncludesZero(true);
        categoryPlot55.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis58, true);
        org.jfree.data.category.CategoryDataset categoryDataset67 = null;
        categoryPlot55.setDataset(0, categoryDataset67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        org.jfree.data.xy.XYDataset xYDataset71 = null;
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis();
        double double73 = dateAxis72.getLabelAngle();
        boolean boolean74 = dateAxis72.isVerticalTickLabels();
        dateAxis72.setTickMarkOutsideLength((float) 10);
        boolean boolean77 = dateAxis72.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis();
        boolean boolean79 = dateAxis78.isPositiveArrowVisible();
        dateAxis78.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer82 = null;
        org.jfree.chart.plot.XYPlot xYPlot83 = new org.jfree.chart.plot.XYPlot(xYDataset71, (org.jfree.chart.axis.ValueAxis) dateAxis72, (org.jfree.chart.axis.ValueAxis) dateAxis78, xYItemRenderer82);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder84 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot83.setDatasetRenderingOrder(datasetRenderingOrder84);
        double double86 = xYPlot83.getRangeCrosshairValue();
        java.awt.Paint paint87 = xYPlot83.getRangeCrosshairPaint();
        xYPlot83.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D90 = xYPlot83.getQuadrantOrigin();
        categoryPlot55.zoomDomainAxes((double) (byte) 10, plotRenderingInfo70, point2D90, false);
        categoryPlot43.zoomRangeAxes((double) (short) 100, plotRenderingInfo54, point2D90);
        try {
            xYPlot12.zoomRangeAxes((double) 10.0f, plotRenderingInfo42, point2D90, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertNotNull(legendItemCollection40);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNull(valueAxis49);
        org.junit.Assert.assertNull(list50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder84);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNotNull(point2D90);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            categoryPlot0.drawBackground(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        boolean boolean2 = dateAxis0.isVerticalTickLabels();
        dateAxis0.setTickMarkOutsideLength((float) 10);
        boolean boolean5 = dateAxis0.isTickLabelsVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double8 = rectangleInsets6.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets6.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, 0.0d, 0.0d, 0.05d, (double) 3);
        dateAxis0.setTickLabelInsets(rectangleInsets14);
        double double16 = dateAxis0.getUpperMargin();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        boolean boolean21 = dateAxis19.isVerticalTickLabels();
        dateAxis19.setTickMarkOutsideLength((float) 10);
        boolean boolean24 = dateAxis19.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        boolean boolean26 = dateAxis25.isPositiveArrowVisible();
        dateAxis25.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot30.setDatasetRenderingOrder(datasetRenderingOrder31);
        double double33 = xYPlot30.getRangeCrosshairValue();
        java.awt.Paint paint34 = xYPlot30.getRangeCrosshairPaint();
        xYPlot30.setDomainCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        int int38 = xYPlot30.indexOf(xYDataset37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = xYPlot30.getRenderer();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace43 = dateAxis0.reserveSpace(graphics2D17, (org.jfree.chart.plot.Plot) xYPlot30, rectangle2D40, rectangleEdge41, axisSpace42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNull(xYItemRenderer39);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        xYPlot25.setRangeAxis(valueAxis32);
        xYPlot25.setWeight((int) '4');
        boolean boolean36 = xYPlot25.isDomainCrosshairVisible();
        java.awt.geom.Point2D point2D37 = xYPlot25.getQuadrantOrigin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(point2D37);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.util.Date date3 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isPositiveArrowVisible();
        java.awt.Stroke stroke6 = dateAxis4.getTickMarkStroke();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis4.setTickMarkStroke(stroke7);
        org.jfree.data.Range range9 = dateAxis4.getRange();
        dateAxis0.setRangeWithMargins(range9, false, true);
        dateAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str1.equals("TextAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        numberAxis0.removeChangeListener(axisChangeListener2);
        numberAxis0.setPositiveArrowVisible(false);
        numberAxis0.setAutoRangeMinimumSize((double) 500, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot0.setDomainAxis(100, categoryAxis11);
        boolean boolean13 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        double double18 = categoryPlot17.getAnchorValue();
        java.awt.Color color20 = java.awt.Color.WHITE;
        java.awt.Color color21 = java.awt.Color.getColor("", color20);
        categoryPlot17.setDomainGridlinePaint((java.awt.Paint) color20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot17.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot17.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot17.setFixedDomainAxisSpace(axisSpace26, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        double double33 = dateAxis32.getLabelAngle();
        boolean boolean34 = dateAxis32.isVerticalTickLabels();
        dateAxis32.setTickMarkOutsideLength((float) 10);
        boolean boolean37 = dateAxis32.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        boolean boolean39 = dateAxis38.isPositiveArrowVisible();
        dateAxis38.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer42);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder44 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot43.setDatasetRenderingOrder(datasetRenderingOrder44);
        boolean boolean46 = xYPlot43.isRangeCrosshairVisible();
        xYPlot43.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D49 = xYPlot43.getQuadrantOrigin();
        categoryPlot17.zoomRangeAxes((double) 100.0f, plotRenderingInfo30, point2D49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        double double55 = dateAxis54.getLabelAngle();
        boolean boolean56 = dateAxis54.isVerticalTickLabels();
        dateAxis54.setTickMarkOutsideLength((float) 10);
        boolean boolean59 = dateAxis54.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis();
        boolean boolean61 = dateAxis60.isPositiveArrowVisible();
        dateAxis60.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) dateAxis54, (org.jfree.chart.axis.ValueAxis) dateAxis60, xYItemRenderer64);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder66 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot65.setDatasetRenderingOrder(datasetRenderingOrder66);
        double double68 = xYPlot65.getRangeCrosshairValue();
        java.awt.Paint paint69 = xYPlot65.getRangeCrosshairPaint();
        xYPlot65.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D72 = xYPlot65.getQuadrantOrigin();
        categoryPlot17.zoomDomainAxes((double) '4', plotRenderingInfo52, point2D72, true);
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D72, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(point2D72);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot12.getDrawingSupplier();
        xYPlot12.setBackgroundImageAlpha((float) 1L);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        double double21 = dateAxis20.getLabelAngle();
        boolean boolean22 = dateAxis20.isVerticalTickLabels();
        dateAxis20.setTickMarkOutsideLength((float) 10);
        boolean boolean25 = dateAxis20.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = dateAxis26.isPositiveArrowVisible();
        dateAxis26.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot31.setDomainAxisLocation(axisLocation32);
        xYPlot12.setRangeAxisLocation(11, axisLocation32, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        double double39 = categoryPlot38.getAnchorValue();
        java.awt.Color color41 = java.awt.Color.WHITE;
        java.awt.Color color42 = java.awt.Color.getColor("", color41);
        categoryPlot38.setDomainGridlinePaint((java.awt.Paint) color41);
        org.jfree.chart.axis.ValueAxis valueAxis44 = categoryPlot38.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot38.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot38.setFixedDomainAxisSpace(axisSpace47, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        double double54 = dateAxis53.getLabelAngle();
        boolean boolean55 = dateAxis53.isVerticalTickLabels();
        dateAxis53.setTickMarkOutsideLength((float) 10);
        boolean boolean58 = dateAxis53.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis();
        boolean boolean60 = dateAxis59.isPositiveArrowVisible();
        dateAxis59.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset52, (org.jfree.chart.axis.ValueAxis) dateAxis53, (org.jfree.chart.axis.ValueAxis) dateAxis59, xYItemRenderer63);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder65 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot64.setDatasetRenderingOrder(datasetRenderingOrder65);
        boolean boolean67 = xYPlot64.isRangeCrosshairVisible();
        xYPlot64.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D70 = xYPlot64.getQuadrantOrigin();
        categoryPlot38.zoomRangeAxes((double) 100.0f, plotRenderingInfo51, point2D70);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        org.jfree.data.xy.XYDataset xYDataset74 = null;
        org.jfree.chart.axis.DateAxis dateAxis75 = new org.jfree.chart.axis.DateAxis();
        double double76 = dateAxis75.getLabelAngle();
        boolean boolean77 = dateAxis75.isVerticalTickLabels();
        dateAxis75.setTickMarkOutsideLength((float) 10);
        boolean boolean80 = dateAxis75.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis();
        boolean boolean82 = dateAxis81.isPositiveArrowVisible();
        dateAxis81.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset74, (org.jfree.chart.axis.ValueAxis) dateAxis75, (org.jfree.chart.axis.ValueAxis) dateAxis81, xYItemRenderer85);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder87 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot86.setDatasetRenderingOrder(datasetRenderingOrder87);
        double double89 = xYPlot86.getRangeCrosshairValue();
        java.awt.Paint paint90 = xYPlot86.getRangeCrosshairPaint();
        xYPlot86.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D93 = xYPlot86.getQuadrantOrigin();
        categoryPlot38.zoomDomainAxes((double) '4', plotRenderingInfo73, point2D93, true);
        xYPlot12.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo37, point2D93);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(point2D70);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(paint90);
        org.junit.Assert.assertNotNull(point2D93);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        xYPlot25.setRangeAxis(valueAxis32);
        boolean boolean34 = xYPlot25.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        xYPlot25.addChangeListener(plotChangeListener34);
        boolean boolean36 = xYPlot25.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        xYPlot12.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D18 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = null;
        xYPlot12.setDrawingSupplier(drawingSupplier19);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.resizeRange((double) 255, (-12.0d));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline5 = null;
        dateAxis4.setTimeline(timeline5);
        java.util.Date date7 = dateAxis4.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isPositiveArrowVisible();
        java.awt.Stroke stroke10 = dateAxis8.getTickMarkStroke();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis8.setTickMarkStroke(stroke11);
        org.jfree.data.Range range13 = dateAxis8.getRange();
        dateAxis4.setRangeWithMargins(range13, false, true);
        dateAxis0.setRange(range13);
        dateAxis0.configure();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1.0f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color6 = java.awt.Color.lightGray;
        categoryMarker5.setLabelPaint((java.awt.Paint) color6);
        java.lang.Object obj8 = categoryMarker5.clone();
        org.jfree.chart.text.TextAnchor textAnchor9 = categoryMarker5.getLabelTextAnchor();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryMarker5.setPaint((java.awt.Paint) color10);
        boolean boolean12 = unitType3.equals((java.lang.Object) categoryMarker5);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        categoryMarker5.setKey((java.lang.Comparable) day13);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.setDomainCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        int int4 = day0.getYear();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean5 = day2.equals((java.lang.Object) day4);
//        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day2);
//        categoryAxis1.setAxisLineVisible(true);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean12 = day9.equals((java.lang.Object) day11);
//        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) day9);
//        java.awt.geom.Rectangle2D rectangle2D16 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot17.clearDomainMarkers();
//        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot17.getDomainAxisEdge();
//        try {
//            double double20 = categoryAxis1.getCategoryEnd(255, (int) (byte) 100, rectangle2D16, rectangleEdge19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(rectangleEdge19);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        xYPlot12.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D18 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        float float21 = dateAxis19.getTickMarkInsideLength();
        int int22 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = xYPlot12.getInsets();
        boolean boolean24 = xYPlot12.isRangeGridlinesVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = xYPlot12.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        xYPlot25.zoom((double) '4');
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection36 = xYPlot25.getRangeMarkers((int) (short) 10, layer35);
        try {
            java.awt.Paint paint38 = xYPlot25.getQuadrantPaint((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (97) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNull(collection36);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (short) 10, "DatasetRenderingOrder.REVERSE");
        categoryAxis1.configure();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot0.setDataset(0, categoryDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        double double31 = xYPlot28.getRangeCrosshairValue();
        java.awt.Paint paint32 = xYPlot28.getRangeCrosshairPaint();
        xYPlot28.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D35 = xYPlot28.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo15, point2D35, false);
        int int38 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker41 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj42 = intervalMarker41.clone();
        double double43 = intervalMarker41.getStartValue();
        java.awt.Paint paint44 = null;
        intervalMarker41.setOutlinePaint(paint44);
        boolean boolean46 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker41);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = categoryPlot0.getRendererForDataset(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 9.0d + "'", double43 == 9.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(categoryItemRenderer48);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setNegativeArrowVisible(false);
        java.awt.Color color6 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean8 = color6.equals((java.lang.Object) textAnchor7);
        dateAxis0.setLabelPaint((java.awt.Paint) color6);
        double double10 = dateAxis0.getUpperMargin();
        try {
            dateAxis0.setRange((double) (short) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLabelAngle();
        boolean boolean4 = dateAxis2.isVerticalTickLabels();
        dateAxis2.setTickMarkOutsideLength((float) 10);
        boolean boolean7 = dateAxis2.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isPositiveArrowVisible();
        dateAxis8.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot13.setDomainGridlinePaint((java.awt.Paint) color16);
        int int18 = color16.getRed();
        java.awt.Stroke stroke19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        double double22 = dateAxis21.getLabelAngle();
        boolean boolean23 = dateAxis21.isVerticalTickLabels();
        dateAxis21.setTickMarkOutsideLength((float) 10);
        boolean boolean26 = dateAxis21.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = dateAxis27.isPositiveArrowVisible();
        dateAxis27.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer31);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot32.setDatasetRenderingOrder(datasetRenderingOrder33);
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color37 = java.awt.Color.lightGray;
        categoryMarker36.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = xYPlot32.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker36, layer39);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        categoryMarker36.notifyListeners(markerChangeEvent41);
        java.awt.Paint paint43 = categoryMarker36.getLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot44.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot44.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        double double51 = dateAxis50.getLabelAngle();
        boolean boolean52 = dateAxis50.isVerticalTickLabels();
        dateAxis50.setTickMarkOutsideLength((float) 10);
        boolean boolean55 = dateAxis50.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        boolean boolean57 = dateAxis56.isPositiveArrowVisible();
        dateAxis56.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis56, xYItemRenderer60);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder62 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot61.setDatasetRenderingOrder(datasetRenderingOrder62);
        double double64 = xYPlot61.getRangeCrosshairValue();
        java.awt.Paint paint65 = xYPlot61.getRangeCrosshairPaint();
        xYPlot61.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D68 = xYPlot61.getQuadrantOrigin();
        categoryPlot44.zoomDomainAxes((double) (-1L), plotRenderingInfo48, point2D68, true);
        categoryPlot44.configureDomainAxes();
        java.awt.Stroke stroke72 = categoryPlot44.getRangeGridlineStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker74 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", (java.awt.Paint) color16, stroke19, paint43, stroke72, (float) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(point2D68);
        org.junit.Assert.assertNotNull(stroke72);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        xYPlot12.markerChanged(markerChangeEvent13);
        xYPlot12.setDomainZeroBaselineVisible(false);
        boolean boolean17 = xYPlot12.isDomainGridlinesVisible();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        xYPlot12.axisChanged(axisChangeEvent18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis0.setAxisLineStroke(stroke3);
        double double5 = dateAxis0.getUpperMargin();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis0.getTimeline();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(timeline6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        boolean boolean3 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.plot.Plot plot4 = dateAxis0.getPlot();
        dateAxis0.setLowerMargin((double) 7);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis0.setTickUnit(dateTickUnit7);
        java.awt.Paint paint9 = dateAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        xYPlot12.markerChanged(markerChangeEvent13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot12.getDomainAxisEdge();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot12.getSeriesRenderingOrder();
        java.lang.String str17 = seriesRenderingOrder16.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str17.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getRangeMarkers(layer16);
        java.lang.Class<?> wildcardClass18 = xYPlot12.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        java.util.List list7 = categoryPlot0.getCategories();
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) (short) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            boolean boolean14 = categoryPlot0.removeAnnotation(categoryAnnotation12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNull(legendItemCollection11);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        double double16 = dateAxis15.getLabelAngle();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        dateAxis15.setTickMarkOutsideLength((float) 10);
        boolean boolean20 = dateAxis15.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
        dateAxis21.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot26.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean29 = xYPlot26.isRangeCrosshairVisible();
        xYPlot26.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo13, point2D32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        double double38 = dateAxis37.getLabelAngle();
        boolean boolean39 = dateAxis37.isVerticalTickLabels();
        dateAxis37.setTickMarkOutsideLength((float) 10);
        boolean boolean42 = dateAxis37.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean44 = dateAxis43.isPositiveArrowVisible();
        dateAxis43.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot48.setDatasetRenderingOrder(datasetRenderingOrder49);
        double double51 = xYPlot48.getRangeCrosshairValue();
        java.awt.Paint paint52 = xYPlot48.getRangeCrosshairPaint();
        xYPlot48.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D55 = xYPlot48.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) '4', plotRenderingInfo35, point2D55, true);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = categoryPlot0.getRendererForDataset(categoryDataset58);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = categoryPlot0.getRendererForDataset(categoryDataset60);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(point2D55);
        org.junit.Assert.assertNull(categoryItemRenderer59);
        org.junit.Assert.assertNull(categoryItemRenderer61);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = numberAxis0.getStandardTickUnits();
        java.text.NumberFormat numberFormat2 = null;
        numberAxis0.setNumberFormatOverride(numberFormat2);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.awt.Color color1 = java.awt.Color.WHITE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isPositiveArrowVisible();
        java.awt.Stroke stroke4 = dateAxis2.getTickMarkStroke();
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isPositiveArrowVisible();
        java.awt.Stroke stroke10 = dateAxis8.getTickMarkStroke();
        double double11 = dateAxis8.getUpperMargin();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis8.setTickMarkStroke(stroke12);
        categoryMarker7.setOutlineStroke(stroke12);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color1, stroke4, (java.awt.Paint) color5, stroke12, (float) (short) 1);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        double double22 = dateAxis17.getAutoRangeMinimumSize();
        java.awt.Font font23 = dateAxis17.getTickLabelFont();
        categoryMarker16.setLabelFont(font23);
        categoryMarker16.setKey((java.lang.Comparable) "ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat2 = null;
        numberAxis0.setNumberFormatOverride(numberFormat2);
        java.awt.Paint paint4 = numberAxis0.getTickLabelPaint();
        java.lang.Object obj5 = numberAxis0.clone();
        double double6 = numberAxis0.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) seriesRenderingOrder0);
        java.lang.String str2 = chartChangeEvent1.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent1.getType();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]"));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        int int32 = xYPlot25.getBackgroundImageAlignment();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        boolean boolean34 = dateAxis33.isPositiveArrowVisible();
        java.awt.Stroke stroke35 = dateAxis33.getTickMarkStroke();
        double double36 = dateAxis33.getUpperMargin();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis33.setTickMarkStroke(stroke37);
        xYPlot25.setDomainZeroBaselineStroke(stroke37);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot25.getRangeAxisEdge(9);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        try {
            xYPlot25.drawBackground(graphics2D42, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getLabelAngle();
        dateAxis0.setPositiveArrowVisible(true);
        dateAxis0.setFixedAutoRange((double) (byte) -1);
        double double6 = dateAxis0.getLowerMargin();
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot9.getRangeAxisEdge();
        try {
            double double12 = dateAxis0.dateToJava2D(date7, rectangle2D8, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        double double3 = dateAxis2.getLabelAngle();
        boolean boolean4 = dateAxis2.isVerticalTickLabels();
        dateAxis2.setTickMarkOutsideLength((float) 10);
        boolean boolean7 = dateAxis2.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isPositiveArrowVisible();
        dateAxis8.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot13.setDatasetRenderingOrder(datasetRenderingOrder14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot13.setDomainGridlinePaint((java.awt.Paint) color16);
        int int18 = color16.getRed();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray20 = null;
        float[] floatArray21 = color19.getRGBComponents(floatArray20);
        float[] floatArray22 = color16.getComponents(floatArray20);
        float[] floatArray23 = color0.getComponents(floatArray22);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color26 = java.awt.Color.lightGray;
        categoryMarker25.setLabelPaint((java.awt.Paint) color26);
        java.awt.color.ColorSpace colorSpace28 = color26.getColorSpace();
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray30 = null;
        float[] floatArray31 = color29.getRGBComponents(floatArray30);
        float[] floatArray32 = color0.getComponents(colorSpace28, floatArray30);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot25.setFixedRangeAxisSpace(axisSpace32, true);
        xYPlot25.setRangeCrosshairValue((double) 9);
        int int37 = xYPlot25.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        xYPlot25.drawAnnotations(graphics2D30, rectangle2D31, plotRenderingInfo32);
        xYPlot25.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        double double17 = dateAxis16.getLabelAngle();
        boolean boolean18 = dateAxis16.isVerticalTickLabels();
        dateAxis16.setTickMarkOutsideLength((float) 10);
        boolean boolean21 = dateAxis16.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = dateAxis22.isPositiveArrowVisible();
        dateAxis22.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot27.setDatasetRenderingOrder(datasetRenderingOrder28);
        double double30 = xYPlot27.getRangeCrosshairValue();
        java.awt.Paint paint31 = xYPlot27.getRangeCrosshairPaint();
        xYPlot27.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D34 = xYPlot27.getQuadrantOrigin();
        xYPlot12.setQuadrantOrigin(point2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke38 = categoryPlot37.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        double double42 = dateAxis41.getLabelAngle();
        boolean boolean43 = dateAxis41.isVerticalTickLabels();
        dateAxis41.setTickMarkOutsideLength((float) 10);
        boolean boolean46 = dateAxis41.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        boolean boolean48 = dateAxis47.isPositiveArrowVisible();
        dateAxis47.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer51);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot52.setDomainAxisLocation(axisLocation53);
        int int55 = xYPlot52.getWeight();
        int int56 = xYPlot52.getDomainAxisCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker59 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        java.awt.Color color60 = java.awt.Color.lightGray;
        categoryMarker59.setLabelPaint((java.awt.Paint) color60);
        java.lang.Object obj62 = categoryMarker59.clone();
        org.jfree.chart.text.TextAnchor textAnchor63 = categoryMarker59.getLabelTextAnchor();
        org.jfree.chart.util.Layer layer64 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot52.addRangeMarker(2019, (org.jfree.chart.plot.Marker) categoryMarker59, layer64);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker59.setLabelOffsetType(lengthAdjustmentType66);
        categoryMarker59.setKey((java.lang.Comparable) (short) 10);
        float float70 = categoryMarker59.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
        double double72 = categoryPlot71.getAnchorValue();
        java.awt.Color color74 = java.awt.Color.WHITE;
        java.awt.Color color75 = java.awt.Color.getColor("", color74);
        categoryPlot71.setDomainGridlinePaint((java.awt.Paint) color74);
        org.jfree.chart.axis.ValueAxis valueAxis77 = categoryPlot71.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = categoryPlot71.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.IntervalMarker intervalMarker83 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj84 = intervalMarker83.clone();
        double double85 = intervalMarker83.getStartValue();
        java.awt.Paint paint86 = null;
        intervalMarker83.setOutlinePaint(paint86);
        org.jfree.chart.util.Layer layer88 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot71.addRangeMarker(5, (org.jfree.chart.plot.Marker) intervalMarker83, layer88);
        boolean boolean90 = categoryPlot37.removeDomainMarker(0, (org.jfree.chart.plot.Marker) categoryMarker59, layer88);
        java.util.Collection collection91 = xYPlot12.getRangeMarkers((int) (byte) 0, layer88);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertNotNull(textAnchor63);
        org.junit.Assert.assertNotNull(layer64);
        org.junit.Assert.assertNotNull(lengthAdjustmentType66);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNull(valueAxis77);
        org.junit.Assert.assertNotNull(rectangleEdge79);
        org.junit.Assert.assertNotNull(obj84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 9.0d + "'", double85 == 9.0d);
        org.junit.Assert.assertNotNull(layer88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(collection91);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        categoryAxis1.setCategoryMargin((double) 10.0f);
        java.awt.Font font10 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 100.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot25.setRangeAxisLocation(0, axisLocation33, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj39 = intervalMarker38.clone();
        double double40 = intervalMarker38.getStartValue();
        java.awt.Paint paint41 = null;
        intervalMarker38.setOutlinePaint(paint41);
        xYPlot25.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder44 = xYPlot25.getDatasetRenderingOrder();
        java.lang.String str45 = datasetRenderingOrder44.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 9.0d + "'", double40 == 9.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str45.equals("DatasetRenderingOrder.REVERSE"));
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getRangeAxisLocation((int) '#');
        double double17 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets1.getLeft();
        double double4 = rectangleInsets1.trimHeight(0.0d);
        boolean boolean5 = categoryAnchor0.equals((java.lang.Object) double4);
        java.lang.String str6 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-6.0d) + "'", double4 == (-6.0d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CategoryAnchor.START" + "'", str6.equals("CategoryAnchor.START"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) seriesRenderingOrder0);
        java.lang.String str2 = chartChangeEvent1.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent1.setType(chartChangeEventType3);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent1.getChart();
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]"));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNull(jFreeChart5);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.lang.String str30 = xYPlot25.getPlotType();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        double double32 = categoryPlot31.getAnchorValue();
        java.awt.Color color34 = java.awt.Color.WHITE;
        java.awt.Color color35 = java.awt.Color.getColor("", color34);
        categoryPlot31.setDomainGridlinePaint((java.awt.Paint) color34);
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot31.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot31.getDomainAxisEdge((int) '4');
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        java.lang.Object obj44 = intervalMarker43.clone();
        double double45 = intervalMarker43.getStartValue();
        java.awt.Paint paint46 = null;
        intervalMarker43.setOutlinePaint(paint46);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot31.addRangeMarker(5, (org.jfree.chart.plot.Marker) intervalMarker43, layer48);
        java.util.Collection collection50 = xYPlot25.getDomainMarkers(layer48);
        java.lang.String str51 = xYPlot25.getPlotType();
        try {
            xYPlot25.setBackgroundImageAlpha((float) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "XY Plot" + "'", str30.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 9.0d + "'", double45 == 9.0d);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "XY Plot" + "'", str51.equals("XY Plot"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        double double16 = dateAxis15.getLabelAngle();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        dateAxis15.setTickMarkOutsideLength((float) 10);
        boolean boolean20 = dateAxis15.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isPositiveArrowVisible();
        dateAxis21.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot26.setDatasetRenderingOrder(datasetRenderingOrder27);
        boolean boolean29 = xYPlot26.isRangeCrosshairVisible();
        xYPlot26.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D32 = xYPlot26.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo13, point2D32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        double double38 = dateAxis37.getLabelAngle();
        boolean boolean39 = dateAxis37.isVerticalTickLabels();
        dateAxis37.setTickMarkOutsideLength((float) 10);
        boolean boolean42 = dateAxis37.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        boolean boolean44 = dateAxis43.isPositiveArrowVisible();
        dateAxis43.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot48.setDatasetRenderingOrder(datasetRenderingOrder49);
        double double51 = xYPlot48.getRangeCrosshairValue();
        java.awt.Paint paint52 = xYPlot48.getRangeCrosshairPaint();
        xYPlot48.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D55 = xYPlot48.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) '4', plotRenderingInfo35, point2D55, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis59.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color62 = java.awt.Color.cyan;
        categoryAxis59.setTickLabelPaint((java.awt.Paint) color62);
        double double64 = categoryAxis59.getLowerMargin();
        java.awt.Color color67 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor68 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean69 = color67.equals((java.lang.Object) textAnchor68);
        categoryAxis59.setLabelPaint((java.awt.Paint) color67);
        java.awt.Font font72 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis59.setTickLabelFont((java.lang.Comparable) 1.0d, font72);
        categoryPlot0.setNoDataMessageFont(font72);
        org.jfree.chart.axis.AxisSpace axisSpace75 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace75);
        try {
            categoryPlot0.zoom(100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(point2D55);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.05d + "'", double64 == 0.05d);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(textAnchor68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(font72);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean3 = day0.equals((java.lang.Object) day2);
//        java.util.Calendar calendar4 = null;
//        try {
//            day2.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        int int3 = objectList0.size();
        java.lang.Object obj4 = objectList0.clone();
        int int5 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        boolean boolean3 = dateAxis0.isTickLabelsVisible();
        double double4 = dateAxis0.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        java.awt.Paint paint17 = xYPlot12.getNoDataMessagePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100);
        categoryMarker19.setDrawAsLine(false);
        org.jfree.chart.text.TextAnchor textAnchor22 = categoryMarker19.getLabelTextAnchor();
        java.awt.Color color23 = java.awt.Color.black;
        categoryMarker19.setOutlinePaint((java.awt.Paint) color23);
        xYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker19);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(color23);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean5 = day2.equals((java.lang.Object) day4);
//        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day2);
//        categoryAxis1.setAxisLineVisible(true);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean12 = day9.equals((java.lang.Object) day11);
//        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) day9);
//        int int14 = day9.getYear();
//        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
//        boolean boolean16 = day9.equals((java.lang.Object) paint15);
//        int int17 = day9.getYear();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(paint15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot12.setRenderer(0, xYItemRenderer16);
        java.awt.Paint paint18 = null;
        xYPlot12.setDomainTickBandPaint(paint18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        java.awt.Color color15 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=SeriesRenderingOrder.REVERSE]", 1);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        boolean boolean17 = color15.equals((java.lang.Object) textAnchor16);
        dateAxis7.setAxisLinePaint((java.awt.Paint) color15);
        double double19 = dateAxis7.getLabelAngle();
        double double20 = dateAxis7.getLowerBound();
        java.awt.Stroke stroke21 = dateAxis7.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeGridlineStroke();
        boolean boolean2 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        java.awt.Color color4 = java.awt.Color.cyan;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        double double6 = categoryAxis1.getLowerMargin();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 5);
        java.lang.Object obj9 = categoryAxis1.clone();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        boolean boolean2 = sortOrder0.equals((java.lang.Object) day1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        double double5 = dateAxis4.getLabelAngle();
        boolean boolean6 = dateAxis4.isVerticalTickLabels();
        dateAxis4.setTickMarkOutsideLength((float) 10);
        boolean boolean9 = dateAxis4.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isPositiveArrowVisible();
        dateAxis10.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getLabelAngle();
        boolean boolean19 = dateAxis17.isVerticalTickLabels();
        dateAxis17.setTickMarkOutsideLength((float) 10);
        boolean boolean22 = dateAxis17.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isPositiveArrowVisible();
        dateAxis23.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = xYPlot28.getDrawingSupplier();
        dateAxis4.setPlot((org.jfree.chart.plot.Plot) xYPlot28);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = null;
        xYPlot28.setFixedLegendItems(legendItemCollection33);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot28.setRangeAxisLocation(0, axisLocation36, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray39 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot28.setDomainAxes(valueAxisArray39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        double double43 = dateAxis42.getLabelAngle();
        boolean boolean44 = dateAxis42.isVerticalTickLabels();
        dateAxis42.setTickMarkOutsideLength((float) 10);
        boolean boolean47 = dateAxis42.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        boolean boolean49 = dateAxis48.isPositiveArrowVisible();
        dateAxis48.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.axis.ValueAxis) dateAxis48, xYItemRenderer52);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot53.setDatasetRenderingOrder(datasetRenderingOrder54);
        double double56 = xYPlot53.getRangeCrosshairValue();
        java.awt.Paint paint57 = xYPlot53.getRangeCrosshairPaint();
        xYPlot53.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D60 = xYPlot53.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation61 = xYPlot53.getOrientation();
        xYPlot28.setOrientation(plotOrientation61);
        boolean boolean63 = day1.equals((java.lang.Object) plotOrientation61);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(drawingSupplier31);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(valueAxisArray39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(point2D60);
        org.junit.Assert.assertNotNull(plotOrientation61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        java.awt.Stroke stroke30 = xYPlot25.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot25.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        xYPlot25.setRangeAxis(valueAxis32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = xYPlot25.getFixedLegendItems();
        int int35 = xYPlot25.getWeight();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(legendItemCollection34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        categoryAxis1.setCategoryLabelPositionOffset(0);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        double double10 = categoryPlot9.getAnchorValue();
        java.awt.Color color12 = java.awt.Color.WHITE;
        java.awt.Color color13 = java.awt.Color.getColor("", color12);
        categoryPlot9.setDomainGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot9.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot9.getDomainAxisEdge((int) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot9.getRangeAxisEdge();
        try {
            java.util.List list19 = categoryAxis1.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge();
        try {
            java.util.List list8 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        double double15 = dateAxis14.getLabelAngle();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        dateAxis14.setTickMarkOutsideLength((float) 10);
        boolean boolean19 = dateAxis14.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        boolean boolean21 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot25.setDatasetRenderingOrder(datasetRenderingOrder26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = xYPlot25.getDrawingSupplier();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot25);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        xYPlot25.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.plot.Marker marker32 = null;
        boolean boolean33 = xYPlot25.removeDomainMarker(marker32);
        boolean boolean34 = xYPlot25.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) '4');
        org.jfree.chart.util.UnitType unitType9 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) 0, (double) 0.0f, (-12.0d), (double) (-1.0f));
        double double16 = rectangleInsets14.extendHeight((double) 10.0f);
        categoryPlot0.setAxisOffset(rectangleInsets14);
        categoryPlot0.clearDomainMarkers((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-2.0d) + "'", double16 == (-2.0d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.getAutoRangeIncludesZero();
        numberAxis3.setAutoRangeStickyZero(true);
        numberAxis3.setAutoRangeIncludesZero(true);
        categoryPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis3, true);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot0.getDataset();
        boolean boolean12 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer((int) '4', categoryItemRenderer14, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot0.getDomainAxisForDataset(5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryAxis18);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        boolean boolean15 = xYPlot12.isRangeCrosshairVisible();
        xYPlot12.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Point2D point2D18 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getLabelAngle();
        float float21 = dateAxis19.getTickMarkInsideLength();
        int int22 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        xYPlot12.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer(categoryItemRenderer14, false);
        java.awt.Color color17 = java.awt.Color.red;
        boolean boolean18 = categoryPlot0.equals((java.lang.Object) color17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        java.awt.Paint paint16 = xYPlot12.getRangeCrosshairPaint();
        xYPlot12.setDomainCrosshairLockedOnData(false);
        java.awt.geom.Point2D point2D19 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = xYPlot12.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        try {
            xYPlot12.setDomainAxisLocation(axisLocation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(plotOrientation20);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = xYPlot12.getDatasetRenderingOrder();
        xYPlot12.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot12.getRendererForDataset(xYDataset17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNull(xYItemRenderer18);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis6.setNumberFormatOverride(numberFormat8);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis6);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        double double16 = categoryPlot15.getAnchorValue();
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = java.awt.Color.getColor("", color18);
        categoryPlot15.setDomainGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot15.getRangeAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot15.getDomainAxisEdge((int) '4');
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot15.setFixedDomainAxisSpace(axisSpace24, true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot15.getRangeAxis();
        java.awt.Stroke stroke28 = categoryPlot15.getRangeCrosshairStroke();
        categoryPlot0.setDomainGridlineStroke(stroke28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(categoryAxis30);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3, false);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot0.getDomainMarkers(layer8);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 9, (double) (byte) -1);
        intervalMarker2.setStartValue(0.0d);
        intervalMarker2.setStartValue((double) 7);
        java.lang.Object obj7 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke2 = dateAxis0.getTickMarkStroke();
        double double3 = dateAxis0.getUpperMargin();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        dateAxis0.setTickMarkStroke(stroke4);
        java.text.DateFormat dateFormat6 = null;
        dateAxis0.setDateFormatOverride(dateFormat6);
        double double8 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.plot.Plot plot9 = dateAxis0.getPlot();
        boolean boolean10 = dateAxis0.isInverted();
        float float11 = dateAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        double double2 = dateAxis1.getLabelAngle();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setTickMarkOutsideLength((float) 10);
        boolean boolean6 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isPositiveArrowVisible();
        dateAxis7.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder13);
        double double15 = xYPlot12.getRangeCrosshairValue();
        xYPlot12.zoom(0.0d);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot12.removeChangeListener(plotChangeListener18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot12.setOutlineStroke(stroke20);
        java.awt.Paint paint22 = xYPlot12.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        int int2 = categoryPlot0.getWeight();
        int int3 = categoryPlot0.getWeight();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setDrawSharedDomainAxis(false);
        java.awt.Stroke stroke4 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            categoryPlot0.drawBackground(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(axisSpace5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.Timeline timeline1 = null;
        dateAxis0.setTimeline(timeline1);
        java.util.Date date3 = dateAxis0.getMinimumDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertNotNull(date3);
    }
}

