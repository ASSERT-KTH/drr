import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setMaximumItemAge((long) '4');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) "10-June-2019");
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10L, true);
        java.lang.String str16 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        java.lang.String str21 = year17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year17.previous();
        boolean boolean25 = year17.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100, "2019", "Value");
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.addAndOrUpdate(timeSeries28);
        timeSeries28.fireSeriesChanged();
        try {
            timeSeries28.delete(9999, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test2");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries4.removeAgedItems(false);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day7);
        java.util.Date date11 = day7.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, number13);
        int int15 = day0.compareTo((java.lang.Object) day12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test3() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test3");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.lang.Object obj5 = null;
        boolean boolean6 = month4.equals(obj5);
        java.lang.String str7 = month4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month4.next();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month4.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January 2019" + "'", str7.equals("January 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test4() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test4");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]", "Time");
        int int4 = timeSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test5() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test5");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
//        boolean boolean4 = timeSeriesDataItem3.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double7 = timeSeries6.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.addAndOrUpdate(timeSeries11);
//        boolean boolean14 = timeSeriesDataItem3.equals((java.lang.Object) timeSeries6);
//        boolean boolean16 = timeSeries6.equals((java.lang.Object) 9);
//        boolean boolean17 = timeSeries6.getNotify();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.util.Date date19 = year18.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        long long21 = fixedMillisecond20.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(1559372400000L);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.util.Date date26 = day25.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
//        long long29 = fixedMillisecond28.getLastMillisecond();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date33 = year30.getStart();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
//        java.lang.Object obj35 = null;
//        boolean boolean36 = month34.equals(obj35);
//        java.lang.String str37 = month34.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 24229L);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) month34);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560150000000L + "'", long29 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "January 2019" + "'", str37.equals("January 2019"));
//        org.junit.Assert.assertNotNull(timeSeries40);
//    }

    @Test
    public void test6() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test6");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
        int int3 = month0.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (byte) 10);
        int int8 = month0.getYearValue();
        long long9 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
    }

//    @Test
//    public void test7() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test7");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        long long6 = month5.getLastMillisecond();
//        java.lang.Class<?> wildcardClass7 = month5.getClass();
//        java.lang.String str8 = month5.toString();
//        org.jfree.data.time.Year year9 = month5.getYear();
//        java.lang.Number number10 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getDayOfMonth();
//        long long13 = day11.getSerialIndex();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1.0f));
//        boolean boolean19 = timeSeriesDataItem18.isSelected();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem18.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double23 = timeSeries22.getMaxY();
//        timeSeries22.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass28 = timePeriodFormatException27.getClass();
//        boolean boolean29 = timeSeries22.equals((java.lang.Object) timePeriodFormatException27);
//        boolean boolean30 = timeSeriesDataItem18.equals((java.lang.Object) timePeriodFormatException27);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo31 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem18, seriesChangeInfo31);
//        timeSeries1.add(timeSeriesDataItem18);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int35 = day34.getDayOfMonth();
//        long long36 = day34.getLastMillisecond();
//        int int37 = day34.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int37, "", "Value");
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        boolean boolean43 = month41.equals((java.lang.Object) "hi!");
//        int int44 = month41.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month41, (java.lang.Number) (byte) 0);
//        int int47 = month41.getYearValue();
//        long long48 = month41.getSerialIndex();
//        long long49 = month41.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month41, (double) 4);
//        timeSeries40.removeAgedItems(true);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries54 = timeSeries1.addAndOrUpdate(timeSeries40);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 24234L + "'", long48 == 24234L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1561964399999L + "'", long49 == 1561964399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//    }

    @Test
    public void test8() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test8");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560183638625L, "org.jfree.data.general.SeriesException: June 2019", "January 2019");
    }

//    @Test
//    public void test9() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test9");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
//        java.lang.String str3 = month0.toString();
//        boolean boolean5 = month0.equals((java.lang.Object) 10);
//        int int6 = month0.getYearValue();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod8, 10.0d);
//        java.lang.Class<?> wildcardClass11 = timeSeriesDataItem10.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.util.Date date13 = year12.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date13, timeZone15);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        timeSeries18.removeAgedItems(false);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.previous();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) day21);
//        java.util.Date date25 = day21.getStart();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25);
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date25, timeZone28);
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        int int31 = month0.compareTo((java.lang.Object) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double34 = timeSeries33.getMaxY();
//        boolean boolean35 = timeSeries33.isEmpty();
//        java.lang.String str36 = timeSeries33.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double39 = timeSeries38.getMaxY();
//        timeSeries38.clear();
//        java.lang.String str41 = timeSeries38.getRangeDescription();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        long long44 = day42.getLastMillisecond();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod46, 10.0d);
//        boolean boolean49 = day42.equals((java.lang.Object) 10.0d);
//        timeSeries38.setKey((java.lang.Comparable) 10.0d);
//        double double51 = timeSeries38.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener52 = null;
//        timeSeries38.removePropertyChangeListener(propertyChangeListener52);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year54.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year54, (double) (-1.0f));
//        boolean boolean58 = timeSeriesDataItem57.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries38.addOrUpdate(timeSeriesDataItem57);
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries33.addAndOrUpdate(timeSeries38);
//        timeSeries60.setNotify(false);
//        long long63 = timeSeries60.getMaximumItemAge();
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year64.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year64, (double) (-1.0f));
//        boolean boolean68 = timeSeriesDataItem67.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double71 = timeSeries70.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener72 = null;
//        timeSeries70.removePropertyChangeListener(propertyChangeListener72);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double76 = timeSeries75.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries70.addAndOrUpdate(timeSeries75);
//        boolean boolean78 = timeSeriesDataItem67.equals((java.lang.Object) timeSeries70);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener79 = null;
//        timeSeries70.addChangeListener(seriesChangeListener79);
//        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double83 = timeSeries82.getMaxY();
//        timeSeries82.clear();
//        java.lang.String str85 = timeSeries82.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries86 = timeSeries70.addAndOrUpdate(timeSeries82);
//        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries60.addAndOrUpdate(timeSeries86);
//        java.lang.String str88 = timeSeries60.getRangeDescription();
//        int int89 = timeSeries60.getItemCount();
//        boolean boolean90 = month0.equals((java.lang.Object) timeSeries60);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Value" + "'", str41.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 9223372036854775807L + "'", long63 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double76, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertEquals((double) double83, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "Value" + "'", str85.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries86);
//        org.junit.Assert.assertNotNull(timeSeries87);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "Value" + "'", str88.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//    }
//}

