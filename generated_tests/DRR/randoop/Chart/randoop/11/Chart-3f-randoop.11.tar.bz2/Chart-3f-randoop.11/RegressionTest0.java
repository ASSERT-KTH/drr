import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test010");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year3 = month0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test021");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        try {
            timeSeries1.delete((int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setMaximumItemAge((long) '4');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) "10-June-2019");
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10L, true);
        java.lang.Comparable comparable16 = null;
        try {
            timeSeries1.setKey(comparable16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        boolean boolean3 = timeSeries1.isEmpty();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) "10-June-2019");
        java.util.Date date7 = year4.getStart();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
        java.lang.String str3 = month0.toString();
        boolean boolean5 = month0.equals((java.lang.Object) 10);
        java.lang.String str6 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month0.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        java.lang.Number number8 = null;
        try {
            timeSeries1.update((int) ' ', number8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (-1.0f));
        java.lang.String str5 = year1.toString();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) '#', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        boolean boolean3 = timeSeries1.isEmpty();
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.addAndOrUpdate(timeSeries5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        try {
            timeSeries1.delete(9999, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.String str2 = timeSeries1.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.clear();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        java.lang.Object obj14 = timeSeriesDataItem13.clone();
        boolean boolean15 = year6.equals(obj14);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        long long14 = month7.getMiddleMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month7.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double16 = timeSeries15.getMaxY();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) "10-June-2019");
        java.util.Date date20 = year17.getStart();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        int int22 = month21.getYearValue();
        java.lang.Number number23 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, number23);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
//        org.jfree.data.time.Year year10 = month7.getYear();
//        java.lang.Number number11 = null;
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
//        java.lang.Object obj14 = timeSeries1.clone();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getSerialIndex();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day15, (-1.0d), false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("January 2019");
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        int int11 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 43626L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = null;
        java.util.Locale locale3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone2, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2019, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        timeSeriesDataItem3.setValue((java.lang.Number) 4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) (-1.0f));
        java.lang.Object obj8 = timeSeriesDataItem7.clone();
        boolean boolean9 = year0.equals(obj8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.TimeZone timeZone2 = null;
        java.util.Locale locale3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone2, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        java.lang.Object obj14 = timeSeries1.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            timeSeries1.add(regularTimePeriod15, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, (int) (short) -1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries6.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) (byte) 0);
//        long long14 = fixedMillisecond11.getFirstMillisecond();
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem(0);
        java.lang.Object obj16 = timeSeriesDataItem15.clone();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        java.lang.Number number12 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate(regularTimePeriod11, number12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getLastMillisecond();
        java.lang.String str4 = year0.toString();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries5.removeAgedItems(false);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day8);
        java.util.Date date12 = day8.getStart();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date12, timeZone13);
        java.util.TimeZone timeZone15 = null;
        java.util.Locale locale16 = null;
        try {
            org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date12, timeZone15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        try {
            java.lang.Number number12 = timeSeries1.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2, "10-June-2019", "hi!");
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (-1.0f));
        java.lang.String str5 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.previous();
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(9999, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable throwable5 = null;
        try {
            timePeriodFormatException3.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        double double5 = timeSeries1.getMinY();
        timeSeries1.setNotify(true);
        try {
            timeSeries1.delete(10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        double double14 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) "10-June-2019");
        java.util.Date date18 = year15.getStart();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        java.lang.Object obj20 = null;
        boolean boolean21 = month19.equals(obj20);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        int int4 = timeSeries1.getMaximumItemCount();
        double double5 = timeSeries1.getMinY();
        try {
            org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.createCopy((int) (short) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.lang.Object obj5 = null;
        boolean boolean6 = month4.equals(obj5);
        java.lang.String str7 = month4.toString();
        long long8 = month4.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January 2019" + "'", str7.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1547668799999L + "'", long8 == 1547668799999L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        boolean boolean18 = timeSeriesDataItem17.isSelected();
        try {
            timeSeries1.add(timeSeriesDataItem17);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.addAndOrUpdate(timeSeries11);
        boolean boolean14 = timeSeriesDataItem3.equals((java.lang.Object) timeSeries6);
        boolean boolean16 = timeSeries6.equals((java.lang.Object) 9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        long long20 = year17.getLastMillisecond();
        java.lang.String str21 = year17.toString();
        try {
            timeSeries6.update((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.lang.Object obj5 = null;
        boolean boolean6 = month4.equals(obj5);
        java.lang.String str7 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 24229L);
        boolean boolean10 = timeSeriesDataItem9.isSelected();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January 2019" + "'", str7.equals("January 2019"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            int int4 = timeSeries1.getIndex(regularTimePeriod3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        timeSeries2.removeAgedItems(false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries2.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = year0.getStart();
        long long7 = year0.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            year0.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.Calendar calendar5 = null;
        try {
            month4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        java.lang.Object obj14 = timeSeries1.clone();
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy(2019, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            timeSeries1.add(regularTimePeriod5, (double) (-1.0f), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) "10-June-2019");
        java.util.Date date12 = year9.getStart();
        int int13 = year9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year9.next();
        timeSeries1.add(regularTimePeriod14, (java.lang.Number) (short) 10);
        boolean boolean17 = timeSeries1.isEmpty();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        int int11 = timeSeries1.getMaximumItemCount();
        try {
            timeSeries1.delete((int) ' ', (int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560193199999L + "'", long4 == 1560193199999L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setMaximumItemAge((long) '4');
        long long8 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        timeSeries6.add(timeSeriesDataItem15, false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries6.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date8);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month11.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 9);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.String str6 = seriesChangeEvent4.toString();
        java.lang.Object obj7 = seriesChangeEvent4.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent4.getSummary();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str6.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(seriesChangeInfo8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        double double14 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        long long17 = year15.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year15);
        long long19 = year15.getLastMillisecond();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double5 = timeSeries4.getMaxY();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) "10-June-2019");
        java.util.Date date9 = year6.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        int int11 = month10.getYearValue();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, number12);
        long long14 = month10.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) (-9999));
        int int17 = month0.compareTo((java.lang.Object) month10);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month0.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24229L + "'", long14 == 24229L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        long long4 = month3.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = month3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        int int7 = day0.compareTo((java.lang.Object) wildcardClass5);
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date8, timeZone9);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str2.equals("org.jfree.data.general.SeriesException: 2019"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) "10-June-2019");
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        int int8 = month7.getYearValue();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number9);
        try {
            timeSeries1.update(2019, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        long long4 = month3.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = month3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        int int7 = day0.compareTo((java.lang.Object) wildcardClass5);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
//        int int5 = day3.getDayOfMonth();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.util.Date date7 = year6.getStart();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day3, (org.jfree.data.time.RegularTimePeriod) year8);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries9.getTimePeriod((int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeSeries9);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        double double5 = timeSeries1.getMinY();
        timeSeries1.setNotify(true);
        timeSeries1.setMaximumItemCount(9999);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.clear();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
        timeSeries1.removeAgedItems(true);
        boolean boolean8 = timeSeries1.getNotify();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        int int5 = month4.getYearValue();
        int int6 = month4.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            timeSeries1.delete(regularTimePeriod3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Date date8 = day4.getStart();
//        long long9 = day4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day4.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) "10-June-2019");
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        int int8 = month7.getYearValue();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number9);
        try {
            timeSeries1.setMaximumItemCount((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2, "10-June-2019", "hi!");
        double double6 = timeSeries5.getMinY();
        try {
            timeSeries5.update(7, (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        java.lang.Comparable comparable14 = timeSeries1.getKey();
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 10.0d + "'", comparable14.equals(10.0d));
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.String str2 = timeSeries1.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries1.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
        try {
            timeSeries1.add(regularTimePeriod7, (double) 1559372400000L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        java.util.List list17 = timeSeries15.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries15.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date5 = fixedMillisecond4.getTime();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5, "10-June-2019", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        java.lang.Object obj14 = timeSeriesDataItem13.clone();
        timeSeries8.setKey((java.lang.Comparable) timeSeriesDataItem13);
        try {
            timeSeries8.delete(0, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double5 = timeSeries4.getMaxY();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) "10-June-2019");
        java.util.Date date9 = year6.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        int int11 = month10.getYearValue();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, number12);
        long long14 = month10.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) (-9999));
        int int17 = month0.compareTo((java.lang.Object) month10);
        long long18 = month10.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24229L + "'", long14 == 24229L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1549007999999L + "'", long18 == 1549007999999L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getLastMillisecond();
        int int16 = month14.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month14, (double) 8);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month14.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setMaximumItemAge((long) '4');
        boolean boolean8 = timeSeries1.getNotify();
        try {
            java.lang.Number number10 = timeSeries1.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        double double5 = timeSeries1.getMinY();
        timeSeries1.setNotify(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        int int10 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.Object obj6 = seriesChangeEvent4.getSource();
        java.lang.Object obj7 = seriesChangeEvent4.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent4.getSummary();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(seriesChangeInfo8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.String str2 = timeSeries1.getDescription();
        timeSeries1.setDescription("January 2019");
        try {
            timeSeries1.delete(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
        java.lang.String str3 = month0.toString();
        boolean boolean5 = month0.equals((java.lang.Object) 10);
        int int6 = month0.getYearValue();
        java.util.Calendar calendar7 = null;
        try {
            month0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) "10-June-2019");
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        int int8 = month7.getYearValue();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number9);
        long long11 = month7.getSerialIndex();
        int int12 = month7.getYearValue();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 24229L + "'", long11 == 24229L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timeSeries1.add(regularTimePeriod8, (-1.0d));
        java.lang.Class<?> wildcardClass11 = timeSeries1.getClass();
        int int12 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setMaximumItemAge((long) 8);
        try {
            timeSeries1.delete(10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        timeSeries2.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date7 = fixedMillisecond6.getTime();
        long long8 = fixedMillisecond6.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException10.getSuppressed();
        int int12 = fixedMillisecond6.compareTo((java.lang.Object) timePeriodFormatException10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond6.previous();
        boolean boolean14 = timeSeries2.equals((java.lang.Object) regularTimePeriod13);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = regularTimePeriod1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2020" + "'", str2.equals("2020"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
        int int3 = month0.getYearValue();
        int int4 = month0.getMonth();
        java.util.Calendar calendar5 = null;
        try {
            month0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getLastMillisecond();
        int int16 = month14.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month14, (double) 8);
        boolean boolean19 = timeSeries1.getNotify();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        double double14 = timeSeries1.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
//        boolean boolean21 = timeSeriesDataItem20.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate(timeSeriesDataItem20);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        long long24 = month23.getLastMillisecond();
//        int int25 = month23.getMonth();
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double29 = timeSeries28.getMaxY();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date33 = year30.getStart();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
//        int int35 = month34.getYearValue();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, number36);
//        long long38 = month34.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (double) (-9999));
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries1.addOrUpdate(timeSeriesDataItem40);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 24229L + "'", long38 == 24229L);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double7 = timeSeries6.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener9);
//        java.lang.String str11 = timeSeries6.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        long long19 = day17.getLastMillisecond();
//        int int20 = day17.getMonth();
//        long long21 = day17.getLastMillisecond();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day17, (double) 1L);
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8);
        java.util.Calendar calendar11 = null;
        try {
            day10.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Comparable comparable9 = null;
        try {
            timeSeries1.setKey(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        double double14 = timeSeries1.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
//        boolean boolean21 = timeSeriesDataItem20.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate(timeSeriesDataItem20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getSerialIndex();
//        int int25 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day23);
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        boolean boolean3 = month1.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year4 = month1.getYear();
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(2147483647, year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.clear();
        java.lang.String str4 = timeSeries1.getDescription();
        try {
            timeSeries1.delete((int) (short) 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setMaximumItemAge((long) '4');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) "10-June-2019");
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10L, true);
        java.lang.String str16 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        java.lang.String str21 = year17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        java.util.Date date23 = year17.getStart();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        java.util.Calendar calendar4 = null;
        try {
            day0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        boolean boolean11 = year5.equals((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
//        int int13 = day0.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month9.previous();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = month9.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setMaximumItemAge((long) '4');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) "10-June-2019");
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10L, true);
        java.lang.String str16 = timeSeries1.getDomainDescription();
        try {
            timeSeries1.delete((int) (short) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        double double14 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        long long17 = year15.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year15);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod20, 10.0d);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries1.addOrUpdate(regularTimePeriod20, (double) 7);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        int int5 = month4.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) 1577865599999L);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        boolean boolean11 = year5.equals((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
//        int int13 = day0.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        java.util.Calendar calendar15 = null;
//        try {
//            month9.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(year14);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date3 = year0.getStart();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        timeSeries6.removeAgedItems(false);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        java.util.Date date13 = day9.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13);
//        boolean boolean17 = month4.equals((java.lang.Object) month16);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double20 = timeSeries19.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries19.removePropertyChangeListener(propertyChangeListener21);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double25 = timeSeries24.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries19.addAndOrUpdate(timeSeries24);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries24.removeChangeListener(seriesChangeListener27);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries24.addPropertyChangeListener(propertyChangeListener29);
//        timeSeries24.fireSeriesChanged();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        int int36 = day32.compareTo((java.lang.Object) regularTimePeriod35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) day32);
//        int int38 = month16.compareTo((java.lang.Object) timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        boolean boolean8 = year0.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100, "2019", "Value");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries11.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setMaximumItemAge((long) 8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries1.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setMaximumItemCount(0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.Year year5 = month0.getYear();
        long long6 = year5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getLastMillisecond();
        int int16 = month14.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month14, (double) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month14.next();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.addAndOrUpdate(timeSeries11);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries11.removeChangeListener(seriesChangeListener14);
        java.lang.String str16 = timeSeries11.getDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        timeSeries11.add(timeSeriesDataItem20, false);
        java.lang.Object obj23 = timeSeriesDataItem20.clone();
        timeSeries1.add(timeSeriesDataItem20, true);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getSerialIndex();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) (byte) 10, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double16 = timeSeries15.getMaxY();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        boolean boolean19 = year17.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date20 = year17.getStart();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
//        int int22 = month21.getYearValue();
//        java.lang.Number number23 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, number23);
//        long long25 = month21.getSerialIndex();
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries1.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24229L + "'", long25 == 24229L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        boolean boolean11 = year5.equals((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
//        int int13 = day0.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month9.previous();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double17 = timeSeries16.getMaxY();
//        timeSeries16.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass22 = timePeriodFormatException21.getClass();
//        boolean boolean23 = timeSeries16.equals((java.lang.Object) timePeriodFormatException21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) (byte) 0);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        boolean boolean31 = year29.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date32 = year29.getStart();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = month33.equals(obj34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.next();
//        timeSeries16.setKey((java.lang.Comparable) regularTimePeriod36);
//        int int38 = month9.compareTo((java.lang.Object) timeSeries16);
//        timeSeries16.setDomainDescription("");
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 4);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        double double14 = timeSeries1.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
//        boolean boolean21 = timeSeriesDataItem20.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate(timeSeriesDataItem20);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.previous();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo25 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod24, seriesChangeInfo25);
//        timeSeries1.delete(regularTimePeriod24);
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        int int5 = month4.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        boolean boolean6 = year0.equals((java.lang.Object) month4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) (byte) 0);
//        long long14 = fixedMillisecond11.getMiddleMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond11.getMiddleMillisecond(calendar15);
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, (int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.addAndOrUpdate(timeSeries11);
        boolean boolean14 = timeSeriesDataItem3.equals((java.lang.Object) timeSeries6);
        boolean boolean16 = timeSeries6.equals((java.lang.Object) 9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries6.addOrUpdate(timeSeriesDataItem17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        java.lang.Object obj14 = timeSeries1.clone();
        java.lang.String str15 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries16.setMaximumItemCount(0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double16 = timeSeries15.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries15.removeChangeListener(seriesChangeListener18);
        java.lang.String str20 = timeSeries15.getDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (-1.0f));
        timeSeries15.add(timeSeriesDataItem24, false);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day27.previous();
        boolean boolean30 = timeSeries15.equals((java.lang.Object) day27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
        java.util.Date date32 = day27.getEnd();
        java.util.TimeZone timeZone33 = null;
        try {
            org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32, timeZone33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem3);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries5.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-57600000L) + "'", long4 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        timeSeries6.add(timeSeriesDataItem15, false);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (-1.0f));
        java.lang.String str22 = year18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year18.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date27 = fixedMillisecond26.getTime();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        long long29 = day28.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) day28);
        try {
            timeSeries30.update((int) 'a', (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-57600000L) + "'", long29 == (-57600000L));
        org.junit.Assert.assertNotNull(timeSeries30);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        long long6 = day5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) "10-June-2019");
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        int int8 = month7.getYearValue();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number9);
        long long11 = month7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) (-9999));
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "org.jfree.data.general.SeriesException: 2019");
        try {
            timeSeries16.update(9, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 24229L + "'", long11 == 24229L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setMaximumItemAge((long) 8);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem9.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate(timeSeriesDataItem9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double14 = timeSeries13.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double19 = timeSeries18.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries13.addAndOrUpdate(timeSeries18);
        timeSeries20.setDomainDescription("June 2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond24.next();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries1.addOrUpdate(regularTimePeriod28, (double) 1560183621812L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getTime();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double6 = timeSeries5.getMaxY();
        timeSeries5.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
        boolean boolean12 = timeSeries5.equals((java.lang.Object) timePeriodFormatException10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double15 = timeSeries14.getMaxY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries5.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        long long19 = month18.getLastMillisecond();
        int int20 = month18.getMonth();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month18, (double) 8);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.addAndOrUpdate(timeSeries5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day9);
        java.util.Date date13 = day9.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13);
        boolean boolean17 = month4.equals((java.lang.Object) month16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date21 = fixedMillisecond20.getTime();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean23 = month16.equals((java.lang.Object) date21);
        java.util.Calendar calendar24 = null;
        try {
            month16.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2, "10-June-2019", "hi!");
        timeSeries5.clear();
        int int7 = timeSeries5.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.setMaximumItemCount((int) '4');
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.addAndOrUpdate(timeSeries11);
        boolean boolean14 = timeSeriesDataItem3.equals((java.lang.Object) timeSeries6);
        boolean boolean15 = timeSeriesDataItem3.isSelected();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.String str6 = seriesChangeEvent4.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = seriesChangeEvent4.getSummary();
        java.lang.String str8 = seriesChangeEvent4.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str6.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
        org.junit.Assert.assertNull(seriesChangeInfo7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str8.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        long long14 = month7.getMiddleMillisecond();
        long long15 = month7.getMiddleMillisecond();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        java.util.Date date17 = day16.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.next();
        boolean boolean21 = month7.equals((java.lang.Object) regularTimePeriod20);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560668399999L + "'", long15 == 1560668399999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries16.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem(0);
        timeSeries1.setMaximumItemCount(1);
        timeSeries1.setMaximumItemAge((long) 9);
        java.lang.String str20 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Date date8 = day4.getStart();
//        long long9 = day4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        int int11 = day4.getDayOfMonth();
//        int int13 = day4.compareTo((java.lang.Object) (short) 1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double16 = timeSeries15.getMaxY();
        timeSeries15.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double21 = timeSeries20.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double26 = timeSeries25.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries20.addAndOrUpdate(timeSeries25);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries25.removeChangeListener(seriesChangeListener28);
        java.lang.String str30 = timeSeries25.getDescription();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (-1.0f));
        timeSeries25.add(timeSeriesDataItem34, false);
        java.lang.Object obj37 = timeSeriesDataItem34.clone();
        timeSeries15.add(timeSeriesDataItem34, true);
        try {
            timeSeries1.add(timeSeriesDataItem34);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        double double14 = timeSeries1.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
//        boolean boolean21 = timeSeriesDataItem20.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate(timeSeriesDataItem20);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        long long24 = month23.getLastMillisecond();
//        int int25 = month23.getMonth();
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        java.lang.Comparable comparable29 = timeSeries28.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Date date32 = fixedMillisecond31.getTime();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date32, "10-June-2019", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries28.addAndOrUpdate(timeSeries35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (double) (-1.0f));
//        java.lang.Object obj41 = timeSeriesDataItem40.clone();
//        timeSeries35.setKey((java.lang.Comparable) timeSeriesDataItem40);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (double) (-1.0f));
//        java.lang.Object obj47 = timeSeriesDataItem46.clone();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries35.addOrUpdate(timeSeriesDataItem46);
//        try {
//            timeSeries1.add(timeSeriesDataItem46);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 100.0f + "'", comparable29.equals(100.0f));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(obj47);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.Object obj6 = seriesChangeEvent4.getSource();
        java.lang.Object obj7 = seriesChangeEvent4.getSource();
        java.lang.String str8 = seriesChangeEvent4.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str8.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, (int) '#');
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        try {
            java.lang.Number number10 = timeSeries1.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double6 = timeSeries5.getMaxY();
//        java.lang.String str7 = timeSeries5.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries5.removePropertyChangeListener(propertyChangeListener8);
//        timeSeries5.setMaximumItemAge((long) '4');
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        boolean boolean14 = year12.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date15 = year12.getStart();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 10L, true);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double22 = timeSeries21.getMaxY();
//        boolean boolean23 = timeSeries21.isEmpty();
//        java.lang.String str24 = timeSeries21.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double27 = timeSeries26.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries26.removePropertyChangeListener(propertyChangeListener28);
//        timeSeries26.setRangeDescription("");
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        timeSeries26.add(regularTimePeriod33, (-1.0d));
//        timeSeries21.add(regularTimePeriod33, (java.lang.Number) 4);
//        int int38 = month16.compareTo((java.lang.Object) timeSeries21);
//        boolean boolean39 = fixedMillisecond3.equals((java.lang.Object) int38);
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond3.getMiddleMillisecond(calendar40);
//        long long42 = fixedMillisecond3.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560150000000L + "'", long41 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560150000000L + "'", long42 == 1560150000000L);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setMaximumItemAge(0L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        timeSeries1.delete(regularTimePeriod8);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy(5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double16 = timeSeries15.getMaxY();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        boolean boolean19 = year17.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date20 = year17.getStart();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
//        int int22 = month21.getYearValue();
//        java.lang.Number number23 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, number23);
//        long long25 = month21.getSerialIndex();
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
//        long long27 = month21.getMiddleMillisecond();
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24229L + "'", long25 == 24229L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1547668799999L + "'", long27 == 1547668799999L);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        boolean boolean3 = timeSeries1.isEmpty();
//        java.lang.String str4 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double7 = timeSeries6.getMaxY();
//        timeSeries6.clear();
//        java.lang.String str9 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getLastMillisecond();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, 10.0d);
//        boolean boolean17 = day10.equals((java.lang.Object) 10.0d);
//        timeSeries6.setKey((java.lang.Comparable) 10.0d);
//        double double19 = timeSeries6.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (-1.0f));
//        boolean boolean26 = timeSeriesDataItem25.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries6.addOrUpdate(timeSeriesDataItem25);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries6);
//        timeSeries28.setNotify(false);
//        long long31 = timeSeries28.getMaximumItemAge();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (-1.0f));
//        boolean boolean36 = timeSeriesDataItem35.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double39 = timeSeries38.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries38.removePropertyChangeListener(propertyChangeListener40);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double44 = timeSeries43.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries38.addAndOrUpdate(timeSeries43);
//        boolean boolean46 = timeSeriesDataItem35.equals((java.lang.Object) timeSeries38);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
//        timeSeries38.addChangeListener(seriesChangeListener47);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double51 = timeSeries50.getMaxY();
//        timeSeries50.clear();
//        java.lang.String str53 = timeSeries50.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries38.addAndOrUpdate(timeSeries50);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries28.addAndOrUpdate(timeSeries54);
//        java.lang.String str56 = timeSeries28.getRangeDescription();
//        boolean boolean57 = timeSeries28.isEmpty();
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Value" + "'", str53.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Value" + "'", str56.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        boolean boolean12 = timeSeries10.isEmpty();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) "10-June-2019");
        java.util.Date date16 = year13.getStart();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        int int18 = month17.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod19, (double) 1577865599999L);
        java.lang.Class<?> wildcardClass22 = timeSeriesDataItem21.getClass();
        timeSeries10.add(timeSeriesDataItem21);
        timeSeries1.add(timeSeriesDataItem21);
        try {
            timeSeries1.delete(2, (int) (byte) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day9);
        java.util.Date date13 = day9.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13);
        boolean boolean17 = month4.equals((java.lang.Object) month16);
        int int18 = month16.getMonth();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        boolean boolean21 = month16.equals((java.lang.Object) timePeriodFormatException20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        timeSeries1.setMaximumItemCount(0);
        java.lang.String str16 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) (byte) 0);
//        long long14 = fixedMillisecond11.getMiddleMillisecond();
//        int int16 = fixedMillisecond11.compareTo((java.lang.Object) 1L);
//        java.util.Date date17 = fixedMillisecond11.getTime();
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.addAndOrUpdate(timeSeries11);
        boolean boolean14 = timeSeriesDataItem3.equals((java.lang.Object) timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries6.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double19 = timeSeries18.getMaxY();
        timeSeries18.clear();
        java.lang.String str21 = timeSeries18.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries6.addAndOrUpdate(timeSeries18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries6.addChangeListener(seriesChangeListener23);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double27 = timeSeries26.getMaxY();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) "10-June-2019");
        java.util.Date date31 = year28.getStart();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        int int33 = month32.getYearValue();
        java.lang.Number number34 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, number34);
        long long36 = month32.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (double) (-9999));
        boolean boolean39 = timeSeriesDataItem38.isSelected();
        timeSeries6.add(timeSeriesDataItem38, true);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        long long43 = month42.getLastMillisecond();
        java.lang.Class<?> wildcardClass44 = month42.getClass();
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries47.removeAgedItems(false);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        java.util.Date date51 = day50.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.previous();
        timeSeries47.delete((org.jfree.data.time.RegularTimePeriod) day50);
        java.util.Date date54 = day50.getStart();
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date54, timeZone55);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date54);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date54);
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day58, (double) 1560183621812L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24229L + "'", long36 == 24229L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1561964399999L + "'", long43 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNull(regularTimePeriod56);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass2 = month0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        timeSeries5.removeAgedItems(false);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day8);
//        java.util.Date date12 = day8.getStart();
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date12, timeZone13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
//        long long17 = day15.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day9);
        java.util.Date date13 = day9.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13);
        boolean boolean17 = month4.equals((java.lang.Object) month16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        boolean boolean22 = month16.equals((java.lang.Object) regularTimePeriod21);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = month16.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setMaximumItemAge((long) 8);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem9.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate(timeSeriesDataItem9);
        java.lang.Object obj12 = timeSeriesDataItem9.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.lang.String str3 = year2.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
//        long long5 = year2.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) 9);
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond0.previous();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond0.peg(calendar10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560183626845L + "'", long1 == 1560183626845L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double9 = timeSeries8.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener10);
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        boolean boolean16 = month14.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year17 = month14.getYear();
        java.lang.Number number18 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month14, number18, false);
        long long21 = month14.getMiddleMillisecond();
        boolean boolean22 = fixedMillisecond1.equals((java.lang.Object) month14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond1.next();
        long long24 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560668399999L + "'", long21 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.lang.String str6 = year5.toString();
//        long long7 = year5.getSerialIndex();
//        int int8 = day0.compareTo((java.lang.Object) year5);
//        long long9 = day0.getSerialIndex();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
//        int int14 = day10.compareTo((java.lang.Object) regularTimePeriod13);
//        java.lang.String str15 = day10.toString();
//        boolean boolean16 = day0.equals((java.lang.Object) str15);
//        java.util.Calendar calendar17 = null;
//        try {
//            day0.peg(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        boolean boolean11 = year5.equals((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
//        int int13 = day0.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month9.previous();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double17 = timeSeries16.getMaxY();
//        timeSeries16.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass22 = timePeriodFormatException21.getClass();
//        boolean boolean23 = timeSeries16.equals((java.lang.Object) timePeriodFormatException21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) (byte) 0);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        boolean boolean31 = year29.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date32 = year29.getStart();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = month33.equals(obj34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.next();
//        timeSeries16.setKey((java.lang.Comparable) regularTimePeriod36);
//        int int38 = month9.compareTo((java.lang.Object) timeSeries16);
//        try {
//            timeSeries16.update(100, (java.lang.Number) 1.0f);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day9);
        java.util.Date date13 = day9.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13);
        boolean boolean17 = month4.equals((java.lang.Object) month16);
        boolean boolean19 = month4.equals((java.lang.Object) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (short) 100 + "'", obj2.equals((short) 100));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (-1.0f));
        java.lang.Number number13 = timeSeriesDataItem12.getValue();
        timeSeriesDataItem12.setSelected(false);
        timeSeries8.add(timeSeriesDataItem12);
        java.lang.Number number17 = timeSeriesDataItem12.getValue();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-1.0d) + "'", number17.equals((-1.0d)));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) (byte) 0);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) "10-June-2019");
        java.util.Date date17 = year14.getStart();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        java.lang.Object obj19 = null;
        boolean boolean20 = month18.equals(obj19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries1.setKey((java.lang.Comparable) regularTimePeriod21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.previous();
        try {
            timeSeries1.add(regularTimePeriod25, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2, "10-June-2019", "hi!");
        timeSeries5.clear();
        java.lang.Comparable comparable7 = timeSeries5.getKey();
        try {
            timeSeries5.update(8, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(comparable7);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) "10-June-2019");
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        int int8 = month7.getYearValue();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number9);
        long long11 = month7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) (-9999));
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month7, "", "org.jfree.data.general.SeriesException: 2019");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries16.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 24229L + "'", long11 == 24229L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 1);
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) 'a', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = month0.getFirstMillisecond();
        long long6 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar3 = null;
        try {
            year2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        timeSeries1.setMaximumItemCount(0);
        try {
            timeSeries1.delete(3, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.addAndOrUpdate(timeSeries11);
        boolean boolean14 = timeSeriesDataItem3.equals((java.lang.Object) timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries6.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double19 = timeSeries18.getMaxY();
        timeSeries18.clear();
        java.lang.String str21 = timeSeries18.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries6.addAndOrUpdate(timeSeries18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.addChangeListener(seriesChangeListener23);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        java.lang.String str2 = year1.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = null;
        try {
            timeSeries17.add(regularTimePeriod18, (double) 0L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
        double double13 = timeSeries6.getMinY();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double16 = timeSeries15.getMaxY();
        timeSeries15.setDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double21 = timeSeries20.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double26 = timeSeries25.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries20.addAndOrUpdate(timeSeries25);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries25.removeChangeListener(seriesChangeListener28);
        java.lang.String str30 = timeSeries25.getDescription();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (-1.0f));
        timeSeries25.add(timeSeriesDataItem34, false);
        java.lang.Object obj37 = timeSeriesDataItem34.clone();
        timeSeries15.add(timeSeriesDataItem34, true);
        boolean boolean40 = timeSeries6.equals((java.lang.Object) timeSeries15);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries15.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
//        java.util.Date date8 = day4.getStart();
//        long long9 = day4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        int int11 = day4.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int11, "Value", "January 2019");
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 10-June-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 10-June-2019"));
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        java.lang.Comparable comparable2 = timeSeries1.getKey();
//        long long3 = timeSeries1.getMaximumItemAge();
//        java.lang.Comparable comparable4 = timeSeries1.getKey();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        long long10 = day8.getLastMillisecond();
//        long long11 = day8.getSerialIndex();
//        boolean boolean12 = day5.equals((java.lang.Object) long11);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day5, 10.0d, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day5.previous();
//        org.jfree.data.time.SerialDate serialDate17 = day5.getSerialDate();
//        long long18 = day5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 100.0f + "'", comparable4.equals(100.0f));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long3 = fixedMillisecond2.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double6 = timeSeries5.getMaxY();
//        java.lang.String str7 = timeSeries5.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries5.removePropertyChangeListener(propertyChangeListener8);
//        timeSeries5.setMaximumItemAge((long) '4');
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        boolean boolean14 = year12.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date15 = year12.getStart();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 10L, true);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double22 = timeSeries21.getMaxY();
//        boolean boolean23 = timeSeries21.isEmpty();
//        java.lang.String str24 = timeSeries21.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double27 = timeSeries26.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries26.removePropertyChangeListener(propertyChangeListener28);
//        timeSeries26.setRangeDescription("");
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        timeSeries26.add(regularTimePeriod33, (-1.0d));
//        timeSeries21.add(regularTimePeriod33, (java.lang.Number) 4);
//        int int38 = month16.compareTo((java.lang.Object) timeSeries21);
//        boolean boolean39 = fixedMillisecond3.equals((java.lang.Object) int38);
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond3.getMiddleMillisecond(calendar40);
//        long long42 = fixedMillisecond3.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560150000000L + "'", long41 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560150000000L + "'", long42 == 1560150000000L);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        int int11 = timeSeries1.getMaximumItemCount();
        int int12 = timeSeries1.getItemCount();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
        int int3 = month0.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries7.removeAgedItems(false);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day10.previous();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day10);
        java.lang.String str14 = timeSeries7.getRangeDescription();
        boolean boolean15 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getLastMillisecond();
        java.lang.Class<?> wildcardClass7 = month5.getClass();
        java.lang.String str8 = month5.toString();
        org.jfree.data.time.Year year9 = month5.getYear();
        org.jfree.data.time.Year year10 = month5.getYear();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month5);
        long long12 = month5.getSerialIndex();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str4 = year0.toString();
        long long5 = year0.getSerialIndex();
        java.lang.String str6 = year0.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (-1.0f));
        boolean boolean11 = timeSeriesDataItem10.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem10.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double15 = timeSeries14.getMaxY();
        timeSeries14.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException19.getClass();
        boolean boolean21 = timeSeries14.equals((java.lang.Object) timePeriodFormatException19);
        boolean boolean22 = timeSeriesDataItem10.equals((java.lang.Object) timePeriodFormatException19);
        boolean boolean23 = timeSeriesDataItem10.isSelected();
        timeSeries1.add(timeSeriesDataItem10);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        boolean boolean27 = timeSeriesDataItem10.equals((java.lang.Object) long26);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setMaximumItemAge((long) '4');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) "10-June-2019");
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10L, true);
        int int16 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem3);
        boolean boolean6 = timeSeriesDataItem3.isSelected();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        boolean boolean3 = timeSeries1.isEmpty();
//        java.lang.String str4 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double7 = timeSeries6.getMaxY();
//        timeSeries6.clear();
//        java.lang.String str9 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getLastMillisecond();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, 10.0d);
//        boolean boolean17 = day10.equals((java.lang.Object) 10.0d);
//        timeSeries6.setKey((java.lang.Comparable) 10.0d);
//        double double19 = timeSeries6.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (-1.0f));
//        boolean boolean26 = timeSeriesDataItem25.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries6.addOrUpdate(timeSeriesDataItem25);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries6);
//        timeSeries28.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double33 = timeSeries32.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries32.removePropertyChangeListener(propertyChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double38 = timeSeries37.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries32.addAndOrUpdate(timeSeries37);
//        timeSeries39.setDomainDescription("June 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Date date44 = fixedMillisecond43.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 4);
//        java.util.Calendar calendar47 = null;
//        fixedMillisecond43.peg(calendar47);
//        java.util.Calendar calendar49 = null;
//        fixedMillisecond43.peg(calendar49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond43.next();
//        int int52 = timeSeries28.getIndex(regularTimePeriod51);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        timeSeries54.removeAgedItems(false);
//        timeSeries54.setMaximumItemAge(0L);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        java.lang.String str60 = year59.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = year59.previous();
//        timeSeries54.delete(regularTimePeriod61);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries28.addOrUpdate(regularTimePeriod61, (double) (-9999));
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "2019" + "'", str60.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNull(timeSeriesDataItem64);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        boolean boolean11 = year5.equals((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
//        int int13 = day0.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
//        java.lang.Object obj16 = null;
//        int int17 = year14.compareTo(obj16);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        double double14 = timeSeries1.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
//        boolean boolean21 = timeSeriesDataItem20.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate(timeSeriesDataItem20);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double25 = timeSeries24.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries24.removePropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double30 = timeSeries29.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries24.addAndOrUpdate(timeSeries29);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries29.removeChangeListener(seriesChangeListener32);
//        java.lang.String str34 = timeSeries29.getDescription();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (double) (-1.0f));
//        timeSeries29.add(timeSeriesDataItem38, false);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.util.Date date42 = day41.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.previous();
//        boolean boolean44 = timeSeries29.equals((java.lang.Object) day41);
//        timeSeries29.clear();
//        long long46 = timeSeries29.getMaximumItemAge();
//        try {
//            int int47 = timeSeriesDataItem22.compareTo((java.lang.Object) long46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent4.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = seriesChangeEvent4.getSummary();
        java.lang.String str7 = seriesChangeEvent4.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
        org.junit.Assert.assertNull(seriesChangeInfo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]" + "'", str7.equals("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getLastMillisecond();
        long long5 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem3);
        try {
            timeSeries5.delete((int) ' ', 7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        long long3 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        timeSeries1.setNotify(false);
        boolean boolean7 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 100.0f + "'", comparable4.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getLastMillisecond();
        java.lang.Class<?> wildcardClass7 = month5.getClass();
        java.lang.String str8 = month5.toString();
        org.jfree.data.time.Year year9 = month5.getYear();
        org.jfree.data.time.Year year10 = month5.getYear();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month5);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month5.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(year10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) (short) 0);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getYear();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        boolean boolean11 = year5.equals((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
//        int int13 = day0.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month9.previous();
//        java.lang.String str15 = regularTimePeriod14.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "May 2019" + "'", str15.equals("May 2019"));
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        double double14 = timeSeries1.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
//        boolean boolean21 = timeSeriesDataItem20.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate(timeSeriesDataItem20);
//        int int23 = timeSeries1.getItemCount();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries1.getTimePeriod(10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.lang.Object obj5 = null;
        boolean boolean6 = month4.equals(obj5);
        java.lang.String str7 = month4.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 24229L);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month4.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January 2019" + "'", str7.equals("January 2019"));
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.lang.String str6 = year5.toString();
//        long long7 = year5.getSerialIndex();
//        int int8 = day0.compareTo((java.lang.Object) year5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 1.0f);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setMaximumItemAge((long) '4');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) "10-June-2019");
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10L, true);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double18 = timeSeries17.getMaxY();
        boolean boolean19 = timeSeries17.isEmpty();
        java.lang.String str20 = timeSeries17.getDescription();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double23 = timeSeries22.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries22.removePropertyChangeListener(propertyChangeListener24);
        timeSeries22.setRangeDescription("");
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        timeSeries22.add(regularTimePeriod29, (-1.0d));
        timeSeries17.add(regularTimePeriod29, (java.lang.Number) 4);
        int int34 = month12.compareTo((java.lang.Object) timeSeries17);
        java.lang.Class<?> wildcardClass35 = month12.getClass();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getYear();
//        java.util.Date date3 = day0.getStart();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        java.lang.String str5 = day4.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year3 = month0.getYear();
        java.lang.String str4 = year3.toString();
        java.util.Calendar calendar5 = null;
        try {
            year3.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double19 = timeSeries18.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double24 = timeSeries23.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries18.addAndOrUpdate(timeSeries23);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries23.removeChangeListener(seriesChangeListener26);
        java.lang.String str28 = timeSeries23.getDescription();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (double) (-1.0f));
        timeSeries23.add(timeSeriesDataItem32, false);
        timeSeries6.add(timeSeriesDataItem32, false);
        java.lang.Object obj37 = timeSeriesDataItem32.clone();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setMaximumItemAge((long) '4');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) "10-June-2019");
        java.util.Date date11 = year8.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10L, true);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double18 = timeSeries17.getMaxY();
        boolean boolean19 = timeSeries17.isEmpty();
        java.lang.String str20 = timeSeries17.getDescription();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double23 = timeSeries22.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries22.removePropertyChangeListener(propertyChangeListener24);
        timeSeries22.setRangeDescription("");
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
        timeSeries22.add(regularTimePeriod29, (-1.0d));
        timeSeries17.add(regularTimePeriod29, (java.lang.Number) 4);
        int int34 = month12.compareTo((java.lang.Object) timeSeries17);
        try {
            timeSeries17.delete((int) '4', (int) (byte) 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond2.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date5 = fixedMillisecond4.getTime();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5, "10-June-2019", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        java.lang.Object obj14 = timeSeriesDataItem13.clone();
        timeSeries8.setKey((java.lang.Comparable) timeSeriesDataItem13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate(timeSeriesDataItem19);
        double double22 = timeSeries8.getMinY();
        try {
            timeSeries8.delete((-9999), 12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-1.0d) + "'", double22 == (-1.0d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries8.setDomainDescription("June 2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 4);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double18 = timeSeries17.getMaxY();
        java.lang.String str19 = timeSeries17.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries17.removePropertyChangeListener(propertyChangeListener20);
        timeSeries17.setMaximumItemAge((long) '4');
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) "10-June-2019");
        java.util.Date date27 = year24.getStart();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 10L, true);
        try {
            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month28, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        java.lang.String str8 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
        try {
            timeSeries1.update(0, (java.lang.Number) Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
        int int3 = month0.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month0.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2, "10-June-2019", "hi!");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2);
        long long7 = day6.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        double double14 = timeSeries1.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
//        boolean boolean21 = timeSeriesDataItem20.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate(timeSeriesDataItem20);
//        int int23 = timeSeries1.getItemCount();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        java.lang.String str25 = year24.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
//        long long27 = year24.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) 9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem29.getPeriod();
//        try {
//            timeSeries1.add(timeSeriesDataItem29);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        int int11 = timeSeries1.getMaximumItemCount();
        java.lang.Number number13 = null;
        try {
            timeSeries1.update(2147483647, number13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.String str2 = timeSeries1.getDescription();
        timeSeries1.setDescription("January 2019");
        boolean boolean5 = timeSeries1.isEmpty();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        int int4 = year0.getYear();
        long long5 = year0.getFirstMillisecond();
        long long6 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.next();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond3.getMiddleMillisecond(calendar5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-1));
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        try {
            timeSeries1.update((int) (short) 0, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        long long3 = timeSeries1.getMaximumItemAge();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        timeSeries6.add(timeSeriesDataItem15, false);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (-1.0f));
        java.lang.String str22 = year18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year18.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date27 = fixedMillisecond26.getTime();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        long long29 = day28.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year18, (org.jfree.data.time.RegularTimePeriod) day28);
        timeSeries30.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-57600000L) + "'", long29 == (-57600000L));
        org.junit.Assert.assertNotNull(timeSeries30);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.lang.String str6 = year5.toString();
//        long long7 = year5.getSerialIndex();
//        int int8 = day0.compareTo((java.lang.Object) year5);
//        long long9 = day0.getSerialIndex();
//        long long10 = day0.getSerialIndex();
//        long long11 = day0.getFirstMillisecond();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day0.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem3.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double8 = timeSeries7.getMaxY();
        timeSeries7.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
        boolean boolean14 = timeSeries7.equals((java.lang.Object) timePeriodFormatException12);
        boolean boolean15 = timeSeriesDataItem3.equals((java.lang.Object) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException12.getSuppressed();
        java.lang.String str17 = timePeriodFormatException12.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.event.SeriesChangeEvent[source=Wed Dec 31 15:59:59 PST 1969]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        boolean boolean8 = year0.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100, "2019", "Value");
        boolean boolean12 = timeSeries11.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2, "10-June-2019", "hi!");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date2, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
        double double13 = timeSeries6.getMinY();
        try {
            java.lang.Number number15 = timeSeries6.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        long long3 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        try {
            timeSeries1.delete(1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 100.0f + "'", comparable4.equals(100.0f));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timeSeries1.add(regularTimePeriod8, (-1.0d));
        java.lang.Class<?> wildcardClass11 = timeSeries1.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        boolean boolean3 = timeSeries1.isEmpty();
//        java.lang.String str4 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double7 = timeSeries6.getMaxY();
//        timeSeries6.clear();
//        java.lang.String str9 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getLastMillisecond();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, 10.0d);
//        boolean boolean17 = day10.equals((java.lang.Object) 10.0d);
//        timeSeries6.setKey((java.lang.Comparable) 10.0d);
//        double double19 = timeSeries6.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (-1.0f));
//        boolean boolean26 = timeSeriesDataItem25.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries6.addOrUpdate(timeSeriesDataItem25);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        boolean boolean31 = year29.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date32 = year29.getStart();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.next();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 1561964399999L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = year0.getStart();
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        boolean boolean3 = timeSeries1.isEmpty();
        java.lang.String str4 = timeSeries1.getDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double9 = timeSeries8.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double14 = timeSeries13.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries8.addAndOrUpdate(timeSeries13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        java.lang.String str18 = timeSeries13.getDescription();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        timeSeries13.add(timeSeriesDataItem22, false);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.addAndOrUpdate(timeSeries13);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        java.lang.String str30 = year26.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year26.previous();
        java.util.Date date32 = year26.getStart();
        java.util.Date date33 = year26.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 1560183618003L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries13.addOrUpdate(regularTimePeriod36, (double) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, 10.0d);
//        boolean boolean7 = day0.equals((java.lang.Object) 10.0d);
//        long long8 = day0.getLastMillisecond();
//        int int9 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        boolean boolean11 = year5.equals((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
//        int int13 = day0.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.Year year14 = month9.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        long long17 = year14.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem3.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double8 = timeSeries7.getMaxY();
        timeSeries7.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
        boolean boolean14 = timeSeries7.equals((java.lang.Object) timePeriodFormatException12);
        boolean boolean15 = timeSeriesDataItem3.equals((java.lang.Object) timePeriodFormatException12);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem3, seriesChangeInfo16);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = seriesChangeEvent17.getSummary();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(seriesChangeInfo18);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        int int5 = month4.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) 1577865599999L);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        long long11 = year9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        java.util.Date date13 = year9.getEnd();
        boolean boolean14 = timeSeriesDataItem8.equals((java.lang.Object) date13);
        java.util.TimeZone timeZone15 = null;
        java.util.Locale locale16 = null;
        try {
            org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date13, timeZone15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNull(class18);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
        double double13 = timeSeries6.getMinY();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month14);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month14.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Object obj4 = timeSeriesDataItem3.clone();
        boolean boolean5 = timeSeriesDataItem3.isSelected();
        boolean boolean6 = timeSeriesDataItem3.isSelected();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = year0.getStart();
        java.util.Date date7 = year0.getStart();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            java.lang.Number number12 = timeSeries1.getValue(regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (-1.0f));
        java.lang.Number number13 = timeSeriesDataItem12.getValue();
        timeSeriesDataItem12.setSelected(false);
        timeSeries8.add(timeSeriesDataItem12);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries8.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem3.getPeriod();
        timeSeriesDataItem3.setSelected(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        boolean boolean3 = timeSeries1.isEmpty();
        timeSeries1.clear();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day5, (double) '4');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
        java.lang.Class<?> wildcardClass12 = timeSeriesDataItem11.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date14, timeZone16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date14);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month18, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        java.util.Date date8 = day4.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class<?> wildcardClass16 = obj15.getClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo17 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent(obj15, seriesChangeInfo17);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
        seriesChangeEvent18.setSummary(seriesChangeInfo19);
        int int21 = year10.compareTo((java.lang.Object) seriesChangeEvent18);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = seriesChangeEvent18.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo23 = null;
        seriesChangeEvent18.setSummary(seriesChangeInfo23);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(seriesChangeInfo22);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        timeSeries2.removeAgedItems(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = null;
        try {
            timeSeries2.add(timeSeriesDataItem5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        boolean boolean12 = timeSeries10.isEmpty();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) "10-June-2019");
        java.util.Date date16 = year13.getStart();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        int int18 = month17.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod19, (double) 1577865599999L);
        java.lang.Class<?> wildcardClass22 = timeSeriesDataItem21.getClass();
        timeSeries10.add(timeSeriesDataItem21);
        timeSeries1.add(timeSeriesDataItem21);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getStart();
        long long27 = year25.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year25);
        java.util.Calendar calendar29 = null;
        try {
            year25.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries8.setDomainDescription("June 2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 4);
        java.util.Calendar calendar16 = null;
        fixedMillisecond12.peg(calendar16);
        java.util.Calendar calendar18 = null;
        fixedMillisecond12.peg(calendar18);
        long long20 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries22.removeAgedItems(false);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.previous();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day25);
        java.lang.String str29 = timeSeries22.getRangeDescription();
        java.lang.String str30 = timeSeries22.getRangeDescription();
        int int31 = fixedMillisecond12.compareTo((java.lang.Object) str30);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Value" + "'", str30.equals("Value"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        boolean boolean8 = year0.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100, "2019", "Value");
        boolean boolean12 = timeSeries11.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        java.lang.Number number21 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeries16.setNotify(true);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(number21);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        int int4 = day0.getYear();
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getLastMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond1.getLastMillisecond(calendar11);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day4);
        java.util.Date date8 = day4.getStart();
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) "10-June-2019");
        java.util.Date date6 = year3.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        int int8 = month7.getYearValue();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem(0);
        try {
            java.lang.Number number17 = timeSeries1.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.lang.Object obj5 = null;
        boolean boolean6 = month4.equals(obj5);
        java.lang.String str7 = month4.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double10 = timeSeries9.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener11);
        timeSeries9.setRangeDescription("");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        timeSeries9.add(regularTimePeriod16, (-1.0d));
        java.lang.Class<?> wildcardClass19 = timeSeries9.getClass();
        timeSeries9.setMaximumItemAge(1560150000000L);
        boolean boolean22 = month4.equals((java.lang.Object) 1560150000000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January 2019" + "'", str7.equals("January 2019"));
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        java.lang.String str4 = timeSeries1.getDescription();
        try {
            java.lang.Number number6 = timeSeries1.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        java.lang.Comparable comparable12 = timeSeries6.getKey();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries6.removeChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener16);
        java.lang.Comparable comparable18 = timeSeries6.getKey();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100.0f + "'", comparable12.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100.0f + "'", comparable18.equals(100.0f));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) "hi!");
        int int3 = month0.getYearValue();
        int int4 = month0.getYearValue();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.String str9 = year5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year5.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.previous();
        int int12 = month0.compareTo((java.lang.Object) year5);
        java.lang.String str13 = month0.toString();
        java.util.Calendar calendar14 = null;
        try {
            month0.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, 10.0d);
        java.lang.Class<?> wildcardClass4 = timeSeriesDataItem3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date6, timeZone8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6);
        java.util.TimeZone timeZone11 = null;
        try {
            org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date6, timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double16 = timeSeries15.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double20 = timeSeries19.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries19.removePropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double25 = timeSeries24.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries19.addAndOrUpdate(timeSeries24);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries24.removeChangeListener(seriesChangeListener27);
        java.lang.String str29 = timeSeries24.getDescription();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (double) (-1.0f));
        timeSeries24.add(timeSeriesDataItem33, false);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.util.Date date37 = day36.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day36.previous();
        boolean boolean39 = timeSeries24.equals((java.lang.Object) day36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) day36);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries1.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = null;
        try {
            timeSeries1.update(regularTimePeriod42, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        try {
            timeSeries1.add(timeSeriesDataItem17, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setMaximumItemAge(0L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        timeSeries1.delete(regularTimePeriod8);
        java.lang.Class<?> wildcardClass10 = regularTimePeriod8.getClass();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        timeSeries6.setKey((java.lang.Comparable) regularTimePeriod11);
        timeSeries6.setNotify(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        int int4 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDomainDescription("June 2019");
        try {
            java.lang.Number number8 = timeSeries1.getValue(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        long long11 = year9.getFirstMillisecond();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        double double14 = timeSeries1.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
//        boolean boolean21 = timeSeriesDataItem20.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate(timeSeriesDataItem20);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        long long24 = month23.getLastMillisecond();
//        int int25 = month23.getMonth();
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month23);
//        java.lang.String str27 = timeSeries1.getRangeDescription();
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            timeSeries3.delete(regularTimePeriod4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
        double double13 = timeSeries6.getMinY();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries15.removeAgedItems(false);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.previous();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day18);
        java.util.Date date22 = day18.getStart();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) '4');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries6.addOrUpdate(timeSeriesDataItem26);
        java.util.Collection collection28 = timeSeries6.getTimePeriods();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(collection28);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.clear();
//        java.lang.String str4 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, 10.0d);
//        boolean boolean12 = day5.equals((java.lang.Object) 10.0d);
//        timeSeries1.setKey((java.lang.Comparable) 10.0d);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double16 = timeSeries15.getMaxY();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        boolean boolean19 = year17.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date20 = year17.getStart();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
//        int int22 = month21.getYearValue();
//        java.lang.Number number23 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, number23);
//        long long25 = month21.getSerialIndex();
//        int int26 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
//        int int27 = month21.getYearValue();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month21);
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24229L + "'", long25 == 24229L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        boolean boolean9 = timeSeriesDataItem8.isSelected();
        timeSeriesDataItem8.setSelected(false);
        timeSeries1.add(timeSeriesDataItem8);
        try {
            timeSeries1.delete(9999, 12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double9 = timeSeries8.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener10);
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        boolean boolean16 = month14.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year17 = month14.getYear();
        java.lang.Number number18 = null;
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month14, number18, false);
        long long21 = month14.getMiddleMillisecond();
        boolean boolean22 = fixedMillisecond1.equals((java.lang.Object) month14);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = month14.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560668399999L + "'", long21 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        boolean boolean11 = year5.equals((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
//        int int13 = day0.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month9.previous();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double17 = timeSeries16.getMaxY();
//        timeSeries16.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass22 = timePeriodFormatException21.getClass();
//        boolean boolean23 = timeSeries16.equals((java.lang.Object) timePeriodFormatException21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) (byte) 0);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        boolean boolean31 = year29.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date32 = year29.getStart();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = month33.equals(obj34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.next();
//        timeSeries16.setKey((java.lang.Comparable) regularTimePeriod36);
//        int int38 = month9.compareTo((java.lang.Object) timeSeries16);
//        int int39 = month9.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.clear();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
        timeSeries1.removeAgedItems(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year9.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        boolean boolean5 = day3.equals((java.lang.Object) Double.NaN);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getLastMillisecond();
        java.lang.String str4 = year0.toString();
        long long5 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year14);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double19 = timeSeries18.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double24 = timeSeries23.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries18.addAndOrUpdate(timeSeries23);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries23.removeChangeListener(seriesChangeListener26);
        java.lang.String str28 = timeSeries23.getDescription();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries23.addAndOrUpdate(timeSeries32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries13.addAndOrUpdate(timeSeries23);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries10);
        boolean boolean14 = timeSeries10.getNotify();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
//        int int6 = day0.compareTo((java.lang.Object) regularTimePeriod5);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) int6, seriesChangeInfo7);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getFirstMillisecond();
        int int4 = year0.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        long long5 = fixedMillisecond2.getMiddleMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond2.getMiddleMillisecond(calendar6);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560150000000L + "'", long7 == 1560150000000L);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        long long14 = month7.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException16.getSuppressed();
        boolean boolean18 = month7.equals((java.lang.Object) throwableArray17);
        int int19 = month7.getMonth();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getLastMillisecond();
        int int16 = month14.getMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month14, (double) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month14.previous();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        boolean boolean3 = timeSeries1.isEmpty();
//        java.lang.String str4 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double7 = timeSeries6.getMaxY();
//        timeSeries6.clear();
//        java.lang.String str9 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getLastMillisecond();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, 10.0d);
//        boolean boolean17 = day10.equals((java.lang.Object) 10.0d);
//        timeSeries6.setKey((java.lang.Comparable) 10.0d);
//        double double19 = timeSeries6.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (-1.0f));
//        boolean boolean26 = timeSeriesDataItem25.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries6.addOrUpdate(timeSeriesDataItem25);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries6);
//        timeSeries28.setNotify(false);
//        long long31 = timeSeries28.getMaximumItemAge();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (-1.0f));
//        boolean boolean36 = timeSeriesDataItem35.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double39 = timeSeries38.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries38.removePropertyChangeListener(propertyChangeListener40);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double44 = timeSeries43.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries38.addAndOrUpdate(timeSeries43);
//        boolean boolean46 = timeSeriesDataItem35.equals((java.lang.Object) timeSeries38);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
//        timeSeries38.addChangeListener(seriesChangeListener47);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double51 = timeSeries50.getMaxY();
//        timeSeries50.clear();
//        java.lang.String str53 = timeSeries50.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries38.addAndOrUpdate(timeSeries50);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries28.addAndOrUpdate(timeSeries54);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeries54.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Value" + "'", str53.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(timeSeries55);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        timeSeries1.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        boolean boolean12 = timeSeries10.isEmpty();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) "10-June-2019");
        java.util.Date date16 = year13.getStart();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        int int18 = month17.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod19, (double) 1577865599999L);
        java.lang.Class<?> wildcardClass22 = timeSeriesDataItem21.getClass();
        timeSeries10.add(timeSeriesDataItem21);
        timeSeries1.add(timeSeriesDataItem21);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double27 = timeSeries26.getMaxY();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        boolean boolean30 = year28.equals((java.lang.Object) "10-June-2019");
        java.util.Date date31 = year28.getStart();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        int int33 = month32.getYearValue();
        java.lang.Number number34 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, number34);
        boolean boolean36 = timeSeriesDataItem21.equals((java.lang.Object) number34);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("January 2019");
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
        timeSeries6.setMaximumItemCount(4);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double7 = timeSeries6.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener9);
//        java.lang.String str11 = timeSeries6.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "June 2019", "June 2019");
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries6.addAndOrUpdate(timeSeries15);
//        java.util.List list17 = timeSeries16.getItems();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double20 = timeSeries19.getMaxY();
//        timeSeries19.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass25 = timePeriodFormatException24.getClass();
//        boolean boolean26 = timeSeries19.equals((java.lang.Object) timePeriodFormatException24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.util.Date date28 = day27.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) (byte) 0);
//        long long32 = fixedMillisecond29.getMiddleMillisecond();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, 0.0d);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
//        int int37 = day35.getDayOfMonth();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        long long39 = month38.getLastMillisecond();
//        java.lang.Class<?> wildcardClass40 = month38.getClass();
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        int int42 = day35.compareTo((java.lang.Object) wildcardClass40);
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        boolean boolean44 = fixedMillisecond29.equals((java.lang.Object) class43);
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560150000000L + "'", long32 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        boolean boolean11 = year5.equals((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
//        int int13 = day0.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month9.previous();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double17 = timeSeries16.getMaxY();
//        timeSeries16.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass22 = timePeriodFormatException21.getClass();
//        boolean boolean23 = timeSeries16.equals((java.lang.Object) timePeriodFormatException21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) (byte) 0);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        boolean boolean31 = year29.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date32 = year29.getStart();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = month33.equals(obj34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.next();
//        timeSeries16.setKey((java.lang.Comparable) regularTimePeriod36);
//        int int38 = month9.compareTo((java.lang.Object) timeSeries16);
//        double double39 = timeSeries16.getMinY();
//        java.lang.String str40 = timeSeries16.getDescription();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019" + "'", str40.equals("2019"));
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day9);
        java.util.Date date13 = day9.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13);
        boolean boolean17 = month4.equals((java.lang.Object) month16);
        int int18 = month16.getMonth();
        int int19 = month16.getMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        long long3 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
        timeSeries6.fireSeriesChanged();
        timeSeries6.setDescription("May 2019");
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        java.lang.String str3 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
//        timeSeries1.setMaximumItemAge((long) '4');
//        boolean boolean8 = timeSeries1.getNotify();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        long long12 = fixedMillisecond11.getFirstMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getFirstMillisecond(calendar14);
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date5 = fixedMillisecond4.getTime();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5, "10-June-2019", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries8);
        java.lang.String str10 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.lang.String str6 = year5.toString();
//        long long7 = year5.getSerialIndex();
//        int int8 = day0.compareTo((java.lang.Object) year5);
//        long long9 = day0.getSerialIndex();
//        long long10 = day0.getSerialIndex();
//        long long11 = day0.getFirstMillisecond();
//        int int12 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Object obj4 = timeSeriesDataItem3.clone();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent(obj4, seriesChangeInfo6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo8);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo10);
        java.lang.Object obj12 = seriesChangeEvent7.getSource();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "10-June-2019");
        java.util.Date date4 = year1.getStart();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries6.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date5 = fixedMillisecond4.getTime();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5, "10-June-2019", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries8);
        java.lang.Class<?> wildcardClass10 = timeSeries1.getClass();
        int int11 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) "10-June-2019");
        java.util.Date date4 = year1.getStart();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date4, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.lang.String str6 = year5.toString();
//        long long7 = year5.getSerialIndex();
//        int int8 = day0.compareTo((java.lang.Object) year5);
//        java.lang.String str9 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.lang.String str6 = year5.toString();
//        long long7 = year5.getSerialIndex();
//        int int8 = day0.compareTo((java.lang.Object) year5);
//        long long9 = day0.getSerialIndex();
//        long long10 = day0.getSerialIndex();
//        long long11 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        boolean boolean9 = month7.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.Number number11 = null;
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, number11, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.getDataItem(0);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass2 = month0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        timeSeries5.removeAgedItems(false);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day8.previous();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day8);
//        java.util.Date date12 = day8.getStart();
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date12, timeZone13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date12);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        long long19 = fixedMillisecond16.getSerialIndex();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day20.next();
//        int int24 = fixedMillisecond16.compareTo((java.lang.Object) day20);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560150000000L + "'", long18 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560150000000L + "'", long19 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        long long7 = month6.getLastMillisecond();
        java.lang.Class<?> wildcardClass8 = month6.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries11.removeAgedItems(false);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.previous();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day14);
        java.util.Date date18 = day14.getStart();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date18, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries1.getDataItem(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
//        int int4 = day0.compareTo((java.lang.Object) regularTimePeriod3);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        boolean boolean11 = year5.equals((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month9.next();
//        int int13 = day0.compareTo((java.lang.Object) month9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month9.previous();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double17 = timeSeries16.getMaxY();
//        timeSeries16.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass22 = timePeriodFormatException21.getClass();
//        boolean boolean23 = timeSeries16.equals((java.lang.Object) timePeriodFormatException21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) (byte) 0);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        boolean boolean31 = year29.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date32 = year29.getStart();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        java.lang.Object obj34 = null;
//        boolean boolean35 = month33.equals(obj34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.next();
//        timeSeries16.setKey((java.lang.Comparable) regularTimePeriod36);
//        int int38 = month9.compareTo((java.lang.Object) timeSeries16);
//        java.lang.Object obj39 = timeSeries16.clone();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(obj39);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timeSeries1.add(regularTimePeriod8, (-1.0d));
        boolean boolean11 = timeSeries1.getNotify();
        boolean boolean12 = timeSeries1.getNotify();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        int int4 = timeSeries1.getMaximumItemCount();
        double double5 = timeSeries1.getMinY();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timeSeries1.getDomainDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = year0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1560236399999L);
        java.lang.Number number9 = timeSeriesDataItem8.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1560236399999L + "'", number9.equals(1560236399999L));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (-1.0f));
        int int5 = year1.getYear();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Number number4 = timeSeriesDataItem3.getValue();
        timeSeriesDataItem3.setSelected(false);
        java.lang.Object obj7 = timeSeriesDataItem3.clone();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        boolean boolean10 = month8.equals((java.lang.Object) "hi!");
        org.jfree.data.time.Year year11 = month8.getYear();
        int int12 = year11.getYear();
        int int13 = timeSeriesDataItem3.compareTo((java.lang.Object) int12);
        timeSeriesDataItem3.setSelected(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod1, seriesChangeInfo2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent3.setSummary(seriesChangeInfo4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date5 = fixedMillisecond4.getTime();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5, "10-June-2019", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries8);
        java.lang.Class<?> wildcardClass10 = timeSeries1.getClass();
        java.lang.String str11 = timeSeries1.getDescription();
        timeSeries1.removeAgedItems(1L, true);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "10-June-2019");
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        int int5 = month4.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) 1577865599999L);
        timeSeriesDataItem8.setSelected(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Object obj4 = timeSeriesDataItem3.clone();
        java.lang.Class<?> wildcardClass5 = obj4.getClass();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent(obj4, seriesChangeInfo6);
        java.lang.String str8 = seriesChangeEvent7.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, 10.0d);
//        boolean boolean7 = day0.equals((java.lang.Object) 10.0d);
//        long long8 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        int int7 = fixedMillisecond1.compareTo((java.lang.Object) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException5.getSuppressed();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.Class<?> wildcardClass3 = year0.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        long long3 = fixedMillisecond2.getLastMillisecond();
        java.util.Date date4 = fixedMillisecond2.getTime();
        long long5 = fixedMillisecond2.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond2.getLastMillisecond(calendar6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2020");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = seriesException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "hi!", "2019");
        try {
            java.lang.Number number7 = timeSeries5.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.util.List list4 = timeSeries1.getItems();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        try {
            timeSeries1.update((int) '#', (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        timeSeries1.setMaximumItemAge((long) '4');
        int int8 = timeSeries1.getMaximumItemCount();
        try {
            timeSeries1.update((int) (short) 100, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        long long4 = month3.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = month3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        int int7 = day0.compareTo((java.lang.Object) wildcardClass5);
//        java.lang.String str8 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
//        boolean boolean4 = timeSeriesDataItem3.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double7 = timeSeries6.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.addAndOrUpdate(timeSeries11);
//        boolean boolean14 = timeSeriesDataItem3.equals((java.lang.Object) timeSeries6);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries6.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double19 = timeSeries18.getMaxY();
//        timeSeries18.clear();
//        java.lang.String str21 = timeSeries18.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries6.addAndOrUpdate(timeSeries18);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries6.addChangeListener(seriesChangeListener23);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double27 = timeSeries26.getMaxY();
//        timeSeries26.clear();
//        java.lang.String str29 = timeSeries26.getRangeDescription();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        long long32 = day30.getLastMillisecond();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod34, 10.0d);
//        boolean boolean37 = day30.equals((java.lang.Object) 10.0d);
//        timeSeries26.setKey((java.lang.Comparable) 10.0d);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double41 = timeSeries40.getMaxY();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        boolean boolean44 = year42.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date45 = year42.getStart();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date45);
//        int int47 = month46.getYearValue();
//        java.lang.Number number48 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month46, number48);
//        long long50 = month46.getSerialIndex();
//        int int51 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) month46);
//        int int52 = month46.getYearValue();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month46, (java.lang.Number) (-57600000L));
//        boolean boolean55 = timeSeries6.getNotify();
//        long long56 = timeSeries6.getMaximumItemAge();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "10-June-2019" + "'", str31.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 24229L + "'", long50 == 24229L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 9223372036854775807L + "'", long56 == 9223372036854775807L);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException5.getSuppressed();
        java.lang.Class<?> wildcardClass9 = throwableArray8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.addAndOrUpdate(timeSeries11);
        boolean boolean14 = timeSeriesDataItem3.equals((java.lang.Object) timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries6.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double19 = timeSeries18.getMaxY();
        timeSeries18.clear();
        java.lang.String str21 = timeSeries18.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries6.addAndOrUpdate(timeSeries18);
        java.lang.String str23 = timeSeries18.getDescription();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (double) 24234L);
        java.lang.Object obj28 = timeSeries18.clone();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (double) (-1.0f));
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeriesDataItem32.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double37 = timeSeries36.getMaxY();
        timeSeries36.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass42 = timePeriodFormatException41.getClass();
        boolean boolean43 = timeSeries36.equals((java.lang.Object) timePeriodFormatException41);
        boolean boolean44 = timeSeriesDataItem32.equals((java.lang.Object) timePeriodFormatException41);
        java.lang.Object obj45 = timeSeriesDataItem32.clone();
        boolean boolean46 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = timeSeriesDataItem32.getPeriod();
        try {
            timeSeries18.add(timeSeriesDataItem32, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem3.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double8 = timeSeries7.getMaxY();
        timeSeries7.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
        boolean boolean14 = timeSeries7.equals((java.lang.Object) timePeriodFormatException12);
        boolean boolean15 = timeSeriesDataItem3.equals((java.lang.Object) timePeriodFormatException12);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem3, seriesChangeInfo16);
        java.lang.Class<?> wildcardClass18 = timeSeriesDataItem3.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone23);
        java.util.TimeZone timeZone25 = null;
        java.util.Locale locale26 = null;
        try {
            org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date21, timeZone25, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getStart();
        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        boolean boolean6 = day0.equals((java.lang.Object) serialDate4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date7, "10-June-2019", "hi!");
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Object obj16 = timeSeriesDataItem15.clone();
        timeSeries10.setKey((java.lang.Comparable) timeSeriesDataItem15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (-1.0f));
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries10.addOrUpdate(timeSeriesDataItem21);
        boolean boolean24 = month0.equals((java.lang.Object) timeSeriesDataItem23);
        java.util.Date date25 = month0.getEnd();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries27.removeAgedItems(false);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.previous();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day30);
        java.util.Date date34 = day30.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (double) '4');
        boolean boolean39 = month0.equals((java.lang.Object) timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 100.0f + "'", comparable4.equals(100.0f));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        boolean boolean3 = timeSeries1.isEmpty();
//        java.lang.String str4 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double7 = timeSeries6.getMaxY();
//        timeSeries6.clear();
//        java.lang.String str9 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getLastMillisecond();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, 10.0d);
//        boolean boolean17 = day10.equals((java.lang.Object) 10.0d);
//        timeSeries6.setKey((java.lang.Comparable) 10.0d);
//        double double19 = timeSeries6.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (-1.0f));
//        boolean boolean26 = timeSeriesDataItem25.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries6.addOrUpdate(timeSeriesDataItem25);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries6);
//        timeSeries6.setDomainDescription("Time");
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.previous();
//        java.lang.Number number33 = null;
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) month31, number33);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
//        long long5 = day4.getFirstMillisecond();
//        java.lang.String str6 = day4.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.addAndOrUpdate(timeSeries11);
        boolean boolean14 = timeSeriesDataItem3.equals((java.lang.Object) timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries6.addChangeListener(seriesChangeListener15);
        timeSeries6.removeAgedItems((long) 'a', true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            timeSeries6.delete(regularTimePeriod20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries6.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timeSeries6.getDomainDescription();
        java.lang.String str12 = timeSeries6.getRangeDescription();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem3.getPeriod();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem3, seriesChangeInfo6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries8.setDomainDescription("June 2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond12.next();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        boolean boolean3 = timeSeries1.isEmpty();
//        java.lang.String str4 = timeSeries1.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double7 = timeSeries6.getMaxY();
//        timeSeries6.clear();
//        java.lang.String str9 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getLastMillisecond();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, 10.0d);
//        boolean boolean17 = day10.equals((java.lang.Object) 10.0d);
//        timeSeries6.setKey((java.lang.Comparable) 10.0d);
//        double double19 = timeSeries6.getMinY();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (-1.0f));
//        boolean boolean26 = timeSeriesDataItem25.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries6.addOrUpdate(timeSeriesDataItem25);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries6);
//        timeSeries28.setNotify(false);
//        long long31 = timeSeries28.getMaximumItemAge();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (-1.0f));
//        boolean boolean36 = timeSeriesDataItem35.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double39 = timeSeries38.getMaxY();
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries38.removePropertyChangeListener(propertyChangeListener40);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double44 = timeSeries43.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries38.addAndOrUpdate(timeSeries43);
//        boolean boolean46 = timeSeriesDataItem35.equals((java.lang.Object) timeSeries38);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
//        timeSeries38.addChangeListener(seriesChangeListener47);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double51 = timeSeries50.getMaxY();
//        timeSeries50.clear();
//        java.lang.String str53 = timeSeries50.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries38.addAndOrUpdate(timeSeries50);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries28.addAndOrUpdate(timeSeries54);
//        try {
//            java.lang.Number number57 = timeSeries54.getValue((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
//        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Value" + "'", str53.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(timeSeries55);
//    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        java.lang.String str3 = timeSeries1.getDomainDescription();
//        java.lang.String str4 = timeSeries1.getDescription();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
//        boolean boolean9 = timeSeriesDataItem8.isSelected();
//        timeSeriesDataItem8.setSelected(false);
//        timeSeries1.add(timeSeriesDataItem8);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (-1.0f));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getLastMillisecond();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
//        long long22 = year19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) 9);
//        boolean boolean25 = fixedMillisecond17.equals((java.lang.Object) timeSeriesDataItem24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond17.previous();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year13, regularTimePeriod26);
//        java.lang.String str28 = timeSeries27.getDomainDescription();
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560183649773L + "'", long18 == 1560183649773L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2, "10-June-2019", "hi!");
        timeSeries5.clear();
        timeSeries5.fireSeriesChanged();
        timeSeries5.setMaximumItemCount(2147483647);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        timeSeries1.add(regularTimePeriod8, (-1.0d));
        java.lang.Class<?> wildcardClass11 = timeSeries1.getClass();
        try {
            timeSeries1.setMaximumItemAge((-57600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        int int4 = timeSeries1.getItemCount();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) int4, seriesChangeInfo5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = seriesChangeEvent6.getSummary();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(seriesChangeInfo7);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        boolean boolean5 = day3.equals((java.lang.Object) Double.NaN);
//        long long6 = day3.getSerialIndex();
//        int int7 = day3.getMonth();
//        int int8 = day3.getMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: 10-June-2019");
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.setDescription("2019");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) timePeriodFormatException6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) (byte) 0);
//        long long14 = fixedMillisecond11.getMiddleMillisecond();
//        int int16 = fixedMillisecond11.compareTo((java.lang.Object) 1L);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond11.getFirstMillisecond(calendar17);
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560150000000L + "'", long18 == 1560150000000L);
//    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        double double2 = timeSeries1.getMaxY();
//        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        long long6 = month5.getLastMillisecond();
//        java.lang.Class<?> wildcardClass7 = month5.getClass();
//        java.lang.String str8 = month5.toString();
//        org.jfree.data.time.Year year9 = month5.getYear();
//        java.lang.Number number10 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getDayOfMonth();
//        long long13 = day11.getSerialIndex();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day11);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        boolean boolean17 = year15.equals((java.lang.Object) "10-June-2019");
//        java.util.Date date18 = year15.getStart();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
//        java.lang.Object obj20 = null;
//        boolean boolean21 = month19.equals(obj20);
//        java.lang.String str22 = month19.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 24229L);
//        timeSeries1.add(timeSeriesDataItem24);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        long long27 = year26.getSerialIndex();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year26, (double) (byte) -1, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "January 2019" + "'", str22.equals("January 2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        java.lang.Comparable comparable2 = timeSeries1.getKey();
//        long long3 = timeSeries1.getMaximumItemAge();
//        java.lang.Comparable comparable4 = timeSeries1.getKey();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        long long10 = day8.getLastMillisecond();
//        long long11 = day8.getSerialIndex();
//        boolean boolean12 = day5.equals((java.lang.Object) long11);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day5, 10.0d, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day5.previous();
//        org.jfree.data.time.SerialDate serialDate17 = day5.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate17);
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 100.0f + "'", comparable4.equals(100.0f));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date1, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double11 = timeSeries10.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double16 = timeSeries15.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.addAndOrUpdate(timeSeries15);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries15.removeChangeListener(seriesChangeListener18);
        java.lang.String str20 = timeSeries15.getDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (-1.0f));
        timeSeries15.add(timeSeriesDataItem24, false);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day27.previous();
        boolean boolean30 = timeSeries15.equals((java.lang.Object) day27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
        java.util.Date date32 = day27.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.previous();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent37 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod35, seriesChangeInfo36);
        boolean boolean38 = year33.equals((java.lang.Object) seriesChangeEvent37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (double) (-1.0f));
        boolean boolean43 = timeSeriesDataItem42.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeriesDataItem42.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double47 = timeSeries46.getMaxY();
        timeSeries46.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass52 = timePeriodFormatException51.getClass();
        boolean boolean53 = timeSeries46.equals((java.lang.Object) timePeriodFormatException51);
        boolean boolean54 = timeSeriesDataItem42.equals((java.lang.Object) timePeriodFormatException51);
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException51.getSuppressed();
        boolean boolean56 = year33.equals((java.lang.Object) timePeriodFormatException51);
        java.lang.Throwable[] throwableArray57 = timePeriodFormatException51.getSuppressed();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(throwableArray57);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        int int7 = fixedMillisecond1.compareTo((java.lang.Object) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date12 = fixedMillisecond11.getTime();
        long long13 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        int int17 = fixedMillisecond11.compareTo((java.lang.Object) timePeriodFormatException15);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        int int4 = timeSeries1.getMaximumItemCount();
        double double5 = timeSeries1.getMinY();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) (-1.0f));
        java.lang.String str12 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.previous();
        java.util.Date date14 = year8.getStart();
        long long15 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 3);
        long long18 = year8.getFirstMillisecond();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double2 = timeSeries1.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double7 = timeSeries6.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries8.setDomainDescription("June 2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 4);
        java.util.Calendar calendar16 = null;
        fixedMillisecond12.peg(calendar16);
        long long18 = fixedMillisecond12.getSerialIndex();
        java.util.Calendar calendar19 = null;
        fixedMillisecond12.peg(calendar19);
        long long21 = fixedMillisecond12.getSerialIndex();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        long long24 = regularTimePeriod23.getMiddleMillisecond();
        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) long24);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1593676799999L + "'", long24 == 1593676799999L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.String str4 = year0.toString();
        long long5 = year0.getFirstMillisecond();
        long long6 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        timeSeries1.removeAgedItems(false);
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (-1.0f));
        boolean boolean11 = timeSeriesDataItem10.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem10.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double15 = timeSeries14.getMaxY();
        timeSeries14.setDescription("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException19.getClass();
        boolean boolean21 = timeSeries14.equals((java.lang.Object) timePeriodFormatException19);
        boolean boolean22 = timeSeriesDataItem10.equals((java.lang.Object) timePeriodFormatException19);
        boolean boolean23 = timeSeriesDataItem10.isSelected();
        timeSeries1.add(timeSeriesDataItem10);
        try {
            timeSeries1.delete((-9999), (int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        timeSeries2.removeAgedItems(false);
        try {
            java.lang.Number number6 = timeSeries2.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        long long5 = regularTimePeriod4.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate(regularTimePeriod4, (double) 1L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getLastMillisecond();
        java.lang.Class<?> wildcardClass10 = month8.getClass();
        java.lang.String str11 = month8.toString();
        org.jfree.data.time.Year year12 = month8.getYear();
        long long13 = month8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month8);
        try {
            java.lang.Number number16 = timeSeries1.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 100.0f + "'", comparable2.equals(100.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1593676799999L + "'", long5 == 1593676799999L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561964399999L + "'", long9 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getLastMillisecond();
        boolean boolean6 = year0.equals((java.lang.Object) month4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.next();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        double double10 = timeSeries9.getMaxY();
        timeSeries9.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        int int13 = month4.compareTo((java.lang.Object) timeSeries9);
        timeSeries9.removeAgedItems((long) (byte) 10, true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
        long long19 = year17.getFirstMillisecond();
        long long20 = year17.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 1560236399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }
}

