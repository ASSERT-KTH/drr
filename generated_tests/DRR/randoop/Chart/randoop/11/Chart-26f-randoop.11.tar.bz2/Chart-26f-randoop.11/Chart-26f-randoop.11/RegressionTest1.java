import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo2.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        plotRenderingInfo3.setPlotArea(rectangle2D4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        plotRenderingInfo3.setDataArea(rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        double double9 = categoryItemRendererState8.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection10 = categoryItemRendererState8.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot12.setDomainAxisLocation(1900, axisLocation14);
        java.awt.Stroke stroke16 = categoryPlot12.getRangeCrosshairStroke();
        categoryPlot12.setAnchorValue((double) 1560179855055L);
        int int19 = categoryPlot12.getDatasetCount();
        categoryPlot12.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke23 = categoryAxis22.getTickMarkStroke();
        categoryAxis22.setAxisLineVisible(true);
        java.awt.Paint paint26 = categoryAxis22.getTickLabelPaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection27 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection27);
        int int30 = taskSeriesCollection27.indexOf((java.lang.Comparable) 255);
        boolean boolean31 = categoryAxis22.equals((java.lang.Object) 255);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis33.setMinimumDate(date34);
        dateAxis33.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.Timeline timeline39 = null;
        dateAxis33.setTimeline(timeline39);
        dateAxis33.setRangeWithMargins((double) (short) 100, (double) 100L);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection44 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list45 = taskSeriesCollection44.getColumnKeys();
        int int47 = taskSeriesCollection44.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline48 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long51 = segmentedTimeline48.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        java.util.Date date53 = month52.getEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment54 = segmentedTimeline48.getSegment(date53);
        int int55 = taskSeriesCollection44.getColumnIndex((java.lang.Comparable) segment54);
        try {
            boxAndWhiskerRenderer0.drawHorizontalItem(graphics2D1, categoryItemRendererState8, rectangle2D11, categoryPlot12, categoryAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.data.category.CategoryDataset) taskSeriesCollection44, (-459), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.gantt.TaskSeriesCollection cannot be cast to org.jfree.data.statistics.BoxAndWhiskerCategoryDataset");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(segmentedTimeline48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(segment54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Category Plot", "30-June-2019", "255", "30-June-2019");
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint6 = lineBorder5.getPaint();
        java.awt.Stroke stroke7 = lineBorder5.getStroke();
        categoryPlot4.setDomainGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace9);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.LegendItemSource legendItemSource12 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement14 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle(legendItemSource12, (org.jfree.chart.block.Arrangement) columnArrangement13, (org.jfree.chart.block.Arrangement) centerArrangement14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle15.getLegendItemGraphicEdge();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace18 = dateAxis1.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) categoryPlot4, rectangle2D11, rectangleEdge16, axisSpace17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("CategoryLabelEntity: category=0.25, tooltip=, url=", "Range[0.0,0.0] version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Range[0.0,0.0]:None\nRange[0.0,0.0] LICENCE TERMS:\n", "Category Plot");
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer0.setMinimumBarLength((double) (short) 100);
        java.awt.Color color8 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke11 = categoryAxis10.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke11);
        statisticalBarRenderer0.setSeriesPaint((int) '4', (java.awt.Paint) color8);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D15 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color20 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets16, (java.awt.Paint) color20);
        lineRenderer3D15.setWallPaint((java.awt.Paint) color20);
        statisticalBarRenderer0.setSeriesPaint(0, (java.awt.Paint) color20, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = statisticalBarRenderer0.getPlot();
        java.awt.Stroke stroke28 = statisticalBarRenderer0.getItemStroke(4, (int) (short) -1);
        statisticalBarRenderer0.setItemMargin(0.25d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getLastBarPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) ' ', (float) (short) -1, (float) (-950399990L));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot1.setLabelShadowPaint(paint3);
        ringPlot1.setShadowXOffset(0.2d);
        java.awt.Stroke stroke7 = ringPlot1.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer9.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        double double15 = ringPlot14.getInnerSeparatorExtension();
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot14.setLabelShadowPaint(paint16);
        stackedAreaRenderer9.setBaseOutlinePaint(paint16, false);
        ringPlot1.setNoDataMessagePaint(paint16);
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot1.setLegendItemShape(shape21);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "TextBlockAnchor.CENTER_LEFT");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = lineRenderer3D0.getLegendItemURLGenerator();
        int int13 = lineRenderer3D0.getColumnCount();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo2.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        plotRenderingInfo3.setPlotArea(rectangle2D4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        plotRenderingInfo3.setDataArea(rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        double double9 = categoryItemRendererState8.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection10 = categoryItemRendererState8.getEntityCollection();
        double double11 = categoryItemRendererState8.getBarWidth();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot13.setDomainAxisLocation(1900, axisLocation15);
        java.awt.Stroke stroke17 = categoryPlot13.getRangeCrosshairStroke();
        categoryPlot13.setAnchorValue((double) 1560179855055L);
        categoryPlot13.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot13.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot13.getRangeAxisLocation(100);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke27 = categoryAxis26.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis26.getCategoryEnd((int) ' ', (-459), rectangle2D30, rectangleEdge31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis26.getLabelInsets();
        org.jfree.chart.event.AxisChangeListener axisChangeListener34 = null;
        categoryAxis26.addChangeListener(axisChangeListener34);
        float float36 = categoryAxis26.getMaximumCategoryLabelWidthRatio();
        java.awt.Font font37 = categoryAxis26.getLabelFont();
        boolean boolean38 = categoryAxis26.isTickLabelsVisible();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D39 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color44 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder45 = new org.jfree.chart.block.BlockBorder(rectangleInsets40, (java.awt.Paint) color44);
        lineRenderer3D39.setWallPaint((java.awt.Paint) color44);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = lineRenderer3D39.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem50 = lineRenderer3D39.getLegendItem(10, 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator51 = lineRenderer3D39.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot53.setDomainAxisLocation(1900, axisLocation55);
        java.awt.Stroke stroke57 = categoryPlot53.getRangeCrosshairStroke();
        categoryPlot53.setAnchorValue((double) 1560179855055L);
        int int60 = categoryPlot53.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis62.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand65 = numberAxis62.getMarkerBand();
        java.awt.Shape shape66 = numberAxis62.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        lineRenderer3D39.drawRangeGridline(graphics2D52, categoryPlot53, (org.jfree.chart.axis.ValueAxis) numberAxis62, rectangle2D67, (double) (short) -1);
        org.jfree.data.RangeType rangeType70 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection71 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number72 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection71);
        int int74 = taskSeriesCollection71.indexOf((java.lang.Comparable) 255);
        boolean boolean75 = rangeType70.equals((java.lang.Object) taskSeriesCollection71);
        try {
            statisticalBarRenderer0.drawItem(graphics2D1, categoryItemRendererState8, rectangle2D12, categoryPlot13, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis62, (org.jfree.data.category.CategoryDataset) taskSeriesCollection71, 205, (int) '#', 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires StatisticalCategoryDataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNull(categoryToolTipGenerator47);
        org.junit.Assert.assertNull(legendItem50);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNull(markerAxisBand65);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(rangeType70);
        org.junit.Assert.assertNull(number72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis12.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis12.setMarkerBand(markerAxisBand15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        boolean boolean18 = numberAxis12.isAutoRange();
        numberAxis12.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer21 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean25 = ringPlot23.equals((java.lang.Object) 'a');
        java.awt.Paint paint27 = null;
        ringPlot23.setSectionOutlinePaint((java.lang.Comparable) 'a', paint27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        java.awt.Font font35 = categoryAxis30.getLabelFont();
        ringPlot23.setLabelFont(font35);
        levelRenderer21.setSeriesItemLabelFont(0, font35);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer21);
        double double39 = levelRenderer21.getItemMargin();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        java.awt.Paint paint4 = null;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 'a', paint4);
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis9.setAxisLineVisible(true);
        java.awt.Paint paint13 = categoryAxis9.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font7, paint13);
        ringPlot0.setBackgroundPaint(paint13);
        java.awt.Paint paint16 = null;
        try {
            ringPlot0.setBaseSectionOutlinePaint(paint16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textBlock14);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentXOffset();
        blockContainer0.setPadding((double) '4', 1.0E-5d, (double) 0.0f, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
//        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
//        org.jfree.data.gantt.TaskSeries taskSeries3 = taskSeriesCollection0.getSeries((java.lang.Comparable) true);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int6 = segmentedTimeline5.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot7);
//        jFreeChart8.removeLegend();
//        jFreeChart8.clearSubtitles();
//        boolean boolean11 = segmentedTimeline5.equals((java.lang.Object) jFreeChart8);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline5.getSegment(0L);
//        segment13.dec((long) (short) 10);
//        boolean boolean16 = segment13.inExcludeSegments();
//        long long17 = segment13.getMillisecond();
//        try {
//            java.lang.Number number18 = taskSeriesCollection0.getValue((java.lang.Comparable) 0.0d, (java.lang.Comparable) long17);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(number1);
//        org.junit.Assert.assertNull(taskSeries3);
//        org.junit.Assert.assertNotNull(segmentedTimeline5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(segment13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-864000000L) + "'", long17 == (-864000000L));
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle3.getItemLabelPadding();
        legendTitle3.setNotify(true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        java.lang.Object obj9 = lineRenderer3D0.clone();
        java.awt.Font font10 = lineRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = lineRenderer3D0.getLegendItemToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke16 = categoryAxis15.getTickMarkStroke();
        ringPlot13.setLabelLinkStroke(stroke16);
        lineRenderer3D0.setBaseStroke(stroke16);
        java.lang.Boolean boolean20 = lineRenderer3D0.getSeriesLinesVisible(11);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(boolean20);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        stackedAreaRenderer1.setBaseItemLabelGenerator(categoryItemLabelGenerator5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot8.setDomainAxisLocation(1900, axisLocation10);
        java.awt.Stroke stroke12 = categoryPlot8.getRangeCrosshairStroke();
        categoryPlot8.setAnchorValue((double) 1560179855055L);
        java.awt.Font font15 = categoryPlot8.getNoDataMessageFont();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            stackedAreaRenderer1.drawOutline(graphics2D7, categoryPlot8, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo2.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        plotRenderingInfo3.setPlotArea(rectangle2D4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        plotRenderingInfo3.setDataArea(rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        double double9 = categoryItemRendererState8.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection10 = categoryItemRendererState8.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot12.setDomainAxisLocation(1900, axisLocation14);
        java.awt.Stroke stroke16 = categoryPlot12.getRangeCrosshairStroke();
        categoryPlot12.setAnchorValue((double) 1560179855055L);
        int int19 = categoryPlot12.getDatasetCount();
        categoryPlot12.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis22.setAxisLineVisible(true);
        categoryAxis22.setCategoryMargin((double) 10.0f);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis28.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis28.setMarkerBand(markerAxisBand31);
        org.jfree.data.Range range33 = numberAxis28.getDefaultAutoRange();
        numberAxis28.centerRange((double) 1559372400000L);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        try {
            boxAndWhiskerRenderer0.drawVerticalItem(graphics2D1, categoryItemRendererState8, rectangle2D11, categoryPlot12, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryDataset36, (-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot3D0.setBaseSectionOutlineStroke(stroke1);
        double double3 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        categoryPlot0.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) 0);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer4.setErrorIndicatorPaint(paint7);
        java.lang.Boolean boolean10 = statisticalBarRenderer4.getSeriesCreateEntities((int) (short) 1);
        java.awt.Paint paint12 = statisticalBarRenderer4.lookupSeriesFillPaint(10);
        multiplePiePlot0.setAggregatedItemsPaint(paint12);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = multiplePiePlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (short) 0 + "'", comparable3.equals((short) 0));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(legendItemCollection14);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) '#');
        org.jfree.data.RangeType rangeType6 = org.jfree.data.RangeType.FULL;
        numberAxis1.setRangeType(rangeType6);
        java.lang.String str8 = rangeType6.toString();
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RangeType.FULL" + "'", str8.equals("RangeType.FULL"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        plotRenderingInfo1.setPlotArea(rectangle2D2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        plotRenderingInfo1.setDataArea(rectangle2D4);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        boolean boolean8 = plotRenderingInfo1.equals((java.lang.Object) (-4503480));
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list2 = taskSeriesCollection1.getColumnKeys();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection3 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list4 = taskSeriesCollection3.getColumnKeys();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = null;
        taskSeriesCollection3.seriesChanged(seriesChangeEvent5);
        boolean boolean7 = taskSeriesCollection1.hasListener((java.util.EventListener) taskSeriesCollection3);
        try {
            java.lang.String str9 = standardCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) taskSeriesCollection1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            java.awt.Color color1 = java.awt.Color.decode("10-June-2019");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10-June-2019\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.Range range3 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str4 = range3.toString();
        double double5 = range3.getCentralValue();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(range3);
        java.util.Date date7 = dateRange6.getUpperDate();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint12 = statisticalBarRenderer9.getItemFillPaint(0, (int) '#');
        boolean boolean13 = lengthConstraintType8.equals((java.lang.Object) 0);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis16.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis16.setMarkerBand(markerAxisBand19);
        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
        boolean boolean22 = numberAxis16.isAutoRange();
        numberAxis16.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range25 = numberAxis16.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType26 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange6, lengthConstraintType8, 0.0d, range25, lengthConstraintType26);
        org.jfree.data.Range range28 = rectangleConstraint27.getWidthRange();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,0.0]" + "'", str4.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(lengthConstraintType26);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        double double6 = ringPlot5.getInnerSeparatorExtension();
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot5.setLabelShadowPaint(paint7);
        ringPlot5.setShadowXOffset(0.2d);
        java.awt.Stroke stroke11 = ringPlot5.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        double double19 = ringPlot18.getInnerSeparatorExtension();
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot18.setLabelShadowPaint(paint20);
        stackedAreaRenderer13.setBaseOutlinePaint(paint20, false);
        ringPlot5.setNoDataMessagePaint(paint20);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot5.setLegendItemShape(shape25);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        stackedAreaRenderer28.setBaseOutlinePaint(paint34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer28.setBasePaint((java.awt.Paint) color36, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint42 = statisticalBarRenderer39.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer44 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedAreaRenderer44.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double48 = itemLabelPosition47.getAngle();
        statisticalBarRenderer39.setBasePositiveItemLabelPosition(itemLabelPosition47);
        statisticalBarRenderer39.setIncludeBaseInRange(true);
        boolean boolean52 = statisticalBarRenderer39.getBaseSeriesVisible();
        java.awt.Stroke stroke53 = statisticalBarRenderer39.getBaseStroke();
        java.awt.Font font57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke60 = categoryAxis59.getTickMarkStroke();
        categoryAxis59.setAxisLineVisible(true);
        java.awt.Paint paint63 = categoryAxis59.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock64 = org.jfree.chart.text.TextUtilities.createTextBlock("", font57, paint63);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint68 = statisticalBarRenderer65.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock69 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font57, paint68);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer70 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint73 = statisticalBarRenderer70.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer70.setMinimumBarLength((double) (short) 100);
        java.awt.Color color78 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke81 = categoryAxis80.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color78, stroke81);
        statisticalBarRenderer70.setSeriesPaint((int) '4', (java.awt.Paint) color78);
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font57, (java.awt.Paint) color78);
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("WMAP_Plot", "CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP", "{0}", "30-June-2019", shape25, (java.awt.Paint) color36, stroke53, (java.awt.Paint) color78);
        int int86 = legendItem85.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(textBlock64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(textBlock69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dataPackageResources0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int2 = keyedObjects0.getIndex((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Range[0.0,0.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '4', (int) (byte) -1, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint2 = lineBorder1.getPaint();
        java.awt.Stroke stroke3 = lineBorder1.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo6.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = chartRenderingInfo8.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        plotRenderingInfo9.setPlotArea(rectangle2D10);
        plotRenderingInfo7.addSubplotInfo(plotRenderingInfo9);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis14.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis14.setMarkerBand(markerAxisBand17);
        boolean boolean19 = plotRenderingInfo7.equals((java.lang.Object) markerAxisBand17);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo7.getDataArea();
        try {
            categoryPlot0.drawBackground(graphics2D5, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
        org.junit.Assert.assertNotNull(plotRenderingInfo9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        dateAxis1.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.Timeline timeline7 = null;
        dateAxis1.setTimeline(timeline7);
        dateAxis1.setRangeWithMargins((double) (short) 100, (double) 100L);
        org.jfree.data.Range range14 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range17 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str18 = range17.toString();
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range14, range17);
        dateAxis1.setRange(range17);
        double double21 = range17.getUpperBound();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Range[0.0,0.0]" + "'", str18.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        ringPlot0.setForegroundAlpha((float) (short) -1);
        ringPlot0.setSectionDepth((double) 255);
        java.awt.Paint paint7 = ringPlot0.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) ' ');
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        java.awt.Stroke stroke2 = ringPlot0.getLabelOutlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) 0);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer4.setErrorIndicatorPaint(paint7);
        java.lang.Boolean boolean10 = statisticalBarRenderer4.getSeriesCreateEntities((int) (short) 1);
        java.awt.Paint paint12 = statisticalBarRenderer4.lookupSeriesFillPaint(10);
        multiplePiePlot0.setAggregatedItemsPaint(paint12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = multiplePiePlot0.getDataset();
        java.lang.Comparable comparable15 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot16);
        jFreeChart17.removeLegend();
        jFreeChart17.clearSubtitles();
        try {
            multiplePiePlot0.setPieChart(jFreeChart17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (short) 0 + "'", comparable3.equals((short) 0));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 0 + "'", comparable15.equals((short) 0));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.String[] strArray2 = dataPackageResources0.getStringArray("Category Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key Category Plot");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-459));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-571) + "'", int1 == (-571));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-459), shape1, "", "RectangleAnchor.TOP");
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) (short) -1, (double) 0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        boolean boolean7 = numberAxis1.isAutoRange();
        numberAxis1.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range12 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str13 = range12.toString();
        double double14 = range12.getCentralValue();
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(range12);
        numberAxis1.setRange(range12, true, true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[0.0,0.0]" + "'", str13.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        categoryAxis1.setLowerMargin(4.0d);
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement12 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle(legendItemSource10, (org.jfree.chart.block.Arrangement) columnArrangement11, (org.jfree.chart.block.Arrangement) centerArrangement12);
        org.jfree.chart.event.TitleChangeListener titleChangeListener14 = null;
        legendTitle13.removeChangeListener(titleChangeListener14);
        java.awt.Paint paint16 = legendTitle13.getBackgroundPaint();
        java.awt.Paint paint17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        legendTitle13.setItemPaint(paint17);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (-1), paint17);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        int int4 = taskSeriesCollection1.indexOf((java.lang.Comparable) 255);
        boolean boolean5 = rangeType0.equals((java.lang.Object) taskSeriesCollection1);
        java.util.List list6 = taskSeriesCollection1.getRowKeys();
        taskSeriesCollection1.removeAll();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis3.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis3.setMarkerBand(markerAxisBand6);
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        boolean boolean9 = numberAxis3.isAutoRange();
        boolean boolean10 = month0.equals((java.lang.Object) boolean9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Stroke stroke3 = ringPlot1.getSeparatorStroke();
        boolean boolean4 = ringPlot1.getIgnoreZeroValues();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        ringPlot0.setForegroundAlpha((float) (short) -1);
        ringPlot0.setSectionDepth((double) 255);
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        java.lang.Object obj8 = ringPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.isItemLabelVisible((int) '#', (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color1);
        java.awt.Color color3 = color1.darker();
        java.awt.color.ColorSpace colorSpace4 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Color color9 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint13 = statisticalBarRenderer10.getItemFillPaint(0, (int) '#');
        java.awt.Stroke stroke15 = statisticalBarRenderer10.lookupSeriesOutlineStroke(0);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 1, (java.awt.Paint) color9, stroke15);
        stackedAreaRenderer5.setSeriesPaint(0, (java.awt.Paint) color9, false);
        float[] floatArray25 = new float[] { 205, 1560668399999L, 6, 4, 7, (short) 1 };
        float[] floatArray26 = color9.getColorComponents(floatArray25);
        try {
            float[] floatArray27 = color1.getColorComponents(colorSpace4, floatArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.String[] strArray4 = new java.lang.String[] { "poly", "RectangleEdge.BOTTOM", "TextBlockAnchor.CENTER_LEFT", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" };
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[] numberArray8 = new java.lang.Number[] {};
        java.lang.Number[] numberArray9 = new java.lang.Number[] {};
        java.lang.Number[] numberArray10 = new java.lang.Number[] {};
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray7, numberArray8, numberArray9, numberArray10, numberArray11, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray13);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0E-5d, (byte) 10, (-1L), 10.0f, 0.25d, (-1L) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 1.0E-5d, (byte) 10, (-1L), 10.0f, 0.25d, (-1L) };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray21, numberArray28 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset30 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray4, numberArray13, numberArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, comparable4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) 255);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset7, (java.lang.Comparable) 10L, (double) 10.0f);
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle3.getItemLabelPadding();
        java.awt.Font font5 = null;
        try {
            legendTitle3.setItemFont(font5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint4 = statisticalBarRenderer1.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer1.setMinimumBarLength((double) (short) 100);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke12);
        statisticalBarRenderer1.setSeriesPaint((int) '4', (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D16 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, (java.awt.Paint) color21);
        lineRenderer3D16.setWallPaint((java.awt.Paint) color21);
        statisticalBarRenderer1.setSeriesPaint(0, (java.awt.Paint) color21, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = statisticalBarRenderer1.getPlot();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer1);
        statisticalBarRenderer1.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(categoryPlot26);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = levelRenderer0.getBaseURLGenerator();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator8 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "RectangleAnchor.TOP", "hi!");
        levelRenderer0.setSeriesURLGenerator(6, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = levelRenderer0.getBasePositiveItemLabelPosition();
        levelRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        java.awt.Shape shape14 = levelRenderer0.getBaseShape();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend((-1));
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = chartRenderingInfo4.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        plotRenderingInfo5.setPlotArea(rectangle2D6);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        plotRenderingInfo5.setDataArea(rectangle2D8);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
        double double11 = categoryItemRendererState10.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection12 = categoryItemRendererState10.getEntityCollection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo13.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo15.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        plotRenderingInfo16.setPlotArea(rectangle2D17);
        plotRenderingInfo14.addSubplotInfo(plotRenderingInfo16);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis21.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis21.setMarkerBand(markerAxisBand24);
        boolean boolean26 = plotRenderingInfo14.equals((java.lang.Object) markerAxisBand24);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo14.getDataArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setDomainAxisLocation(1900, axisLocation30);
        java.awt.Stroke stroke32 = categoryPlot28.getRangeCrosshairStroke();
        categoryPlot28.setAnchorValue((double) 1560179855055L);
        categoryPlot28.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot28.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke40 = categoryAxis39.getTickMarkStroke();
        categoryAxis39.setAxisLineVisible(true);
        java.awt.Paint paint43 = categoryAxis39.getAxisLinePaint();
        java.awt.Font font44 = categoryAxis39.getLabelFont();
        double double45 = categoryAxis39.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis47.setNegativeArrowVisible(true);
        numberAxis47.setFixedAutoRange((double) '#');
        org.jfree.data.RangeType rangeType52 = org.jfree.data.RangeType.FULL;
        numberAxis47.setRangeType(rangeType52);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection54 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list55 = taskSeriesCollection54.getColumnKeys();
        int int57 = taskSeriesCollection54.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable58 = null;
        org.jfree.data.general.PieDataset pieDataset59 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection54, comparable58);
        org.jfree.data.general.PieDataset pieDataset61 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection54, (java.lang.Comparable) 255);
        try {
            stackedBarRenderer3D0.drawItem(graphics2D3, categoryItemRendererState10, rectangle2D27, categoryPlot28, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis47, (org.jfree.data.category.CategoryDataset) taskSeriesCollection54, 500, (-459), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection12);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
        org.junit.Assert.assertNotNull(rangeType52);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(pieDataset59);
        org.junit.Assert.assertNotNull(pieDataset61);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedAreaRenderer1.getPositiveItemLabelPosition((int) (short) 10, 1);
        java.awt.Stroke stroke5 = stackedAreaRenderer1.getBaseStroke();
        java.awt.Stroke stroke6 = stackedAreaRenderer1.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = categoryLabelPosition0.getCategoryAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis3.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis3.setMarkerBand(markerAxisBand6);
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        boolean boolean9 = numberAxis3.isAutoRange();
        numberAxis3.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range12 = numberAxis3.getDefaultAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis3.setMarkerBand(markerAxisBand13);
        boolean boolean15 = rectangleAnchor1.equals((java.lang.Object) numberAxis3);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.validateObject();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Color color1 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        java.awt.Font font6 = valueMarker5.getLabelFont();
        valueMarker5.setValue((double) 6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        int int12 = lineRenderer3D0.getPassCount();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = ringPlot14.getSectionOutlinesVisible();
        double double16 = ringPlot14.getShadowXOffset();
        boolean boolean17 = lineRenderer3D0.equals((java.lang.Object) ringPlot14);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis20.setMarkerBand(markerAxisBand23);
        org.jfree.data.Range range25 = numberAxis20.getDefaultAutoRange();
        java.awt.Shape shape26 = numberAxis20.getDownArrow();
        lineRenderer3D0.setSeriesShape((int) '#', shape26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot29.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot29.getRenderer((int) (byte) 1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = chartRenderingInfo34.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = chartRenderingInfo36.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        plotRenderingInfo37.setPlotArea(rectangle2D38);
        plotRenderingInfo35.addSubplotInfo(plotRenderingInfo37);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis42.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis42.setMarkerBand(markerAxisBand45);
        boolean boolean47 = plotRenderingInfo35.equals((java.lang.Object) markerAxisBand45);
        java.awt.geom.Rectangle2D rectangle2D48 = plotRenderingInfo35.getDataArea();
        try {
            lineRenderer3D0.drawBackground(graphics2D28, categoryPlot29, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertNull(categoryItemRenderer33);
        org.junit.Assert.assertNotNull(plotRenderingInfo35);
        org.junit.Assert.assertNotNull(plotRenderingInfo37);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangle2D48);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("RangeType.FULL");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("30-June-2019");
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor2, categoryLabelWidthType3, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        double double5 = ringPlot4.getInnerSeparatorExtension();
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot4.setLabelShadowPaint(paint6);
        ringPlot4.setShadowXOffset(0.2d);
        java.awt.Stroke stroke10 = ringPlot4.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer12.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot(pieDataset16);
        double double18 = ringPlot17.getInnerSeparatorExtension();
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot17.setLabelShadowPaint(paint19);
        stackedAreaRenderer12.setBaseOutlinePaint(paint19, false);
        ringPlot4.setNoDataMessagePaint(paint19);
        java.lang.Class<?> wildcardClass24 = paint19.getClass();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection26 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number27 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection26);
        int int29 = taskSeriesCollection26.indexOf((java.lang.Comparable) 255);
        java.lang.Class<?> wildcardClass30 = taskSeriesCollection26.getClass();
        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("cyan", (java.lang.Class) wildcardClass30);
        boolean boolean32 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass30);
        java.lang.Object obj33 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Range[0.0,0.0]", (java.lang.Class) wildcardClass24, (java.lang.Class) wildcardClass30);
        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("poly", (java.lang.Class) wildcardClass30);
        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("PlotOrientation.VERTICAL", (java.lang.Class) wildcardClass30);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(obj33);
        org.junit.Assert.assertNull(uRL34);
        org.junit.Assert.assertNull(obj35);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 1L, 8.0d, (double) (byte) 100, 8.0d);
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke9 = categoryAxis8.getTickMarkStroke();
        categoryAxis8.setAxisLineVisible(true);
        java.awt.Paint paint12 = categoryAxis8.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint12);
        boolean boolean14 = blockBorder4.equals((java.lang.Object) textBlock13);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "TextBlockAnchor.CENTER_LEFT", "", "");
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        lineRenderer3D0.setDrawOutlines(true);
        lineRenderer3D0.setDrawOutlines(false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "ThreadContext", "poly");
        lineRenderer3D0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator10);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint2 = lineBorder1.getPaint();
        java.awt.Stroke stroke3 = lineBorder1.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer5 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer5.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = levelRenderer5.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = levelRenderer5.getBaseItemLabelGenerator();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer5, false);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot0.getDomainMarkers(11, layer13);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        java.awt.Paint paint4 = null;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 'a', paint4);
        ringPlot0.setPieIndex((int) ' ');
        java.awt.Font font8 = ringPlot0.getLabelFont();
        ringPlot0.setSectionOutlinesVisible(false);
        boolean boolean11 = ringPlot0.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset12 = ringPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(pieDataset12);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot0.getLegendItems();
        java.awt.Image image2 = null;
        piePlot0.setBackgroundImage(image2);
        piePlot0.setForegroundAlpha((float) 1900);
        java.lang.String str6 = piePlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Image image3 = ringPlot1.getBackgroundImage();
        java.awt.Paint paint4 = ringPlot1.getBaseSectionPaint();
        float float5 = ringPlot1.getForegroundAlpha();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint7 = lineBorder6.getPaint();
        java.awt.Stroke stroke8 = lineBorder6.getStroke();
        ringPlot1.setBaseSectionOutlineStroke(stroke8);
        ringPlot1.setForegroundAlpha((float) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        boolean boolean7 = numberAxis1.isAutoRange();
        numberAxis1.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range10 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        boolean boolean12 = ringPlot11.getIgnoreNullValues();
        ringPlot11.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        java.awt.Stroke stroke16 = ringPlot11.getLabelLinkStroke();
        numberAxis1.setTickMarkStroke(stroke16);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("GradientPaintTransformType.VERTICAL");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.TickUnit tickUnit1 = null;
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit(tickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset9, (java.lang.Comparable) 90.0d);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(pieDataset11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(range2);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        java.lang.Object obj8 = lineRenderer3D0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        java.awt.Paint paint10 = categoryMarker9.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker9);
        org.jfree.chart.plot.Marker marker12 = markerChangeEvent11.getMarker();
        org.jfree.chart.plot.Marker marker13 = markerChangeEvent11.getMarker();
        org.jfree.chart.plot.Marker marker14 = markerChangeEvent11.getMarker();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot(pieDataset16);
        double double18 = ringPlot17.getInnerSeparatorExtension();
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot17.setLabelShadowPaint(paint19);
        ringPlot17.setShadowXOffset(0.2d);
        java.awt.Stroke stroke23 = ringPlot17.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer25.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot(pieDataset29);
        double double31 = ringPlot30.getInnerSeparatorExtension();
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot30.setLabelShadowPaint(paint32);
        stackedAreaRenderer25.setBaseOutlinePaint(paint32, false);
        ringPlot17.setNoDataMessagePaint(paint32);
        java.lang.Class<?> wildcardClass37 = paint32.getClass();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection39 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection39);
        int int42 = taskSeriesCollection39.indexOf((java.lang.Comparable) 255);
        java.lang.Class<?> wildcardClass43 = taskSeriesCollection39.getClass();
        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("cyan", (java.lang.Class) wildcardClass43);
        boolean boolean45 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass43);
        java.lang.Object obj46 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Range[0.0,0.0]", (java.lang.Class) wildcardClass37, (java.lang.Class) wildcardClass43);
        try {
            java.util.EventListener[] eventListenerArray47 = marker14.getListeners((java.lang.Class) wildcardClass37);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(marker12);
        org.junit.Assert.assertNotNull(marker13);
        org.junit.Assert.assertNotNull(marker14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNull(number40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(obj46);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        boolean boolean7 = numberAxis1.isAutoRange();
        numberAxis1.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range10 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(markerAxisBand11);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 1.559372400008E12d);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D4 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean6 = lineRenderer3D4.getSeriesLinesVisible(100);
        boolean boolean7 = lineRenderer3D4.getBaseShapesVisible();
        java.lang.Boolean boolean9 = lineRenderer3D4.getSeriesVisibleInLegend(1900);
        lineRenderer3D4.setAutoPopulateSeriesPaint(true);
        java.awt.Stroke stroke12 = lineRenderer3D4.getBaseStroke();
        boolean boolean13 = defaultKeyedValues2D1.equals((java.lang.Object) lineRenderer3D4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range5 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str6 = range5.toString();
        org.jfree.data.Range range7 = org.jfree.data.Range.combine(range2, range5);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range7, (double) (short) -1);
        double double10 = range9.getCentralValue();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Range[0.0,0.0]" + "'", str6.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        ringPlot1.setLabelGenerator(pieSectionLabelGenerator4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        dateAxis1.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.Timeline timeline7 = null;
        dateAxis1.setTimeline(timeline7);
        dateAxis1.setRangeWithMargins((double) (short) 100, (double) 100L);
        org.jfree.data.Range range14 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range17 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str18 = range17.toString();
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range14, range17);
        dateAxis1.setRange(range17);
        java.awt.Shape shape21 = dateAxis1.getRightArrow();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Range[0.0,0.0]" + "'", str18.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        jFreeChart1.removeLegend();
        jFreeChart1.clearSubtitles();
        boolean boolean4 = jFreeChart1.isNotify();
        java.awt.Paint paint5 = jFreeChart1.getBorderPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        java.awt.Paint paint10 = categoryMarker9.getOutlinePaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = chartRenderingInfo11.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        plotRenderingInfo12.setPlotArea(rectangle2D13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        plotRenderingInfo12.setDataArea(rectangle2D15);
        boolean boolean17 = categoryMarker9.equals((java.lang.Object) rectangle2D15);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker9.setLabelFont(font18);
        org.jfree.chart.text.TextAnchor textAnchor20 = null;
        try {
            categoryMarker9.setLabelTextAnchor(textAnchor20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(plotRenderingInfo12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreNullValues();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        double double5 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean6 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        legendTitle3.removeChangeListener(titleChangeListener4);
        java.awt.Paint paint6 = legendTitle3.getBackgroundPaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        legendTitle3.setItemPaint(paint7);
        legendTitle3.setNotify(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo12.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        plotRenderingInfo15.setPlotArea(rectangle2D16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo15);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis20.setMarkerBand(markerAxisBand23);
        boolean boolean25 = plotRenderingInfo13.equals((java.lang.Object) markerAxisBand23);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo13.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str28 = rectangleAnchor27.toString();
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        try {
            legendTitle3.draw(graphics2D11, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleAnchor.TOP" + "'", str28.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D29);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (-1), 100.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.559372400008E12d, "RangeType.FULL", textAnchor2, textAnchor3, (-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor6 = numberTick5.getRotationAnchor();
        java.lang.Number number7 = numberTick5.getNumber();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.559372400008E12d + "'", number7.equals(1.559372400008E12d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        int int16 = color11.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font9, (java.awt.Paint) color11);
        java.awt.Paint paint18 = labelBlock17.getPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis20.setAxisLineVisible(true);
        categoryAxis20.setCategoryLabelPositionOffset(7);
        boolean boolean25 = labelBlock17.equals((java.lang.Object) categoryAxis20);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double29 = rectangleInsets27.calculateRightInset((double) 1L);
        double double31 = rectangleInsets27.extendHeight((double) 1559372400000L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = chartRenderingInfo32.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = chartRenderingInfo34.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        plotRenderingInfo35.setPlotArea(rectangle2D36);
        plotRenderingInfo33.addSubplotInfo(plotRenderingInfo35);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis40.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand43 = null;
        numberAxis40.setMarkerBand(markerAxisBand43);
        boolean boolean45 = plotRenderingInfo33.equals((java.lang.Object) markerAxisBand43);
        java.awt.geom.Rectangle2D rectangle2D46 = plotRenderingInfo33.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str48 = rectangleAnchor47.toString();
        java.awt.geom.Point2D point2D49 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets27.createInsetRectangle(rectangle2D46);
        try {
            labelBlock17.draw(graphics2D26, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.0d + "'", double29 == 8.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.559372400008E12d + "'", double31 == 1.559372400008E12d);
        org.junit.Assert.assertNotNull(plotRenderingInfo33);
        org.junit.Assert.assertNotNull(plotRenderingInfo35);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "RectangleAnchor.TOP" + "'", str48.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D49);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
//        jFreeChart3.removeLegend();
//        jFreeChart3.clearSubtitles();
//        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline0.getSegment(0L);
//        segment8.dec((long) (short) 10);
//        boolean boolean11 = segment8.inExcludeSegments();
//        boolean boolean12 = segment8.inExcludeSegments();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(segment8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        java.awt.Shape shape7 = numberAxis1.getDownArrow();
        boolean boolean8 = numberAxis1.isAutoRange();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        lineRenderer3D0.setDrawOutlines(true);
        lineRenderer3D0.setSeriesShapesVisible(15, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        try {
            lineRenderer3D0.setSeriesItemLabelGenerator((-4503480), categoryItemLabelGenerator9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis4.getTickMarkPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
        jFreeChart7.removeLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(rectangleInsets9, (java.awt.Paint) color13);
        double double15 = rectangleInsets9.getRight();
        jFreeChart7.setPadding(rectangleInsets9);
        boolean boolean17 = jFreeChart7.getAntiAlias();
        jFreeChart7.setNotify(true);
        boolean boolean20 = dateAxis4.equals((java.lang.Object) true);
        java.util.Date date21 = dateAxis4.getMaximumDate();
        dateAxis1.setMaximumDate(date21);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        int int5 = stackedAreaRenderer1.getPassCount();
        java.awt.Stroke stroke6 = stackedAreaRenderer1.getBaseOutlineStroke();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator7 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        stackedAreaRenderer1.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator7);
        stackedAreaRenderer1.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image3, "hi!", "", "");
        projectInfo7.setName("Range[0.0,0.0]");
        java.lang.String str10 = projectInfo7.getName();
        java.lang.String str11 = projectInfo7.getLicenceName();
        projectInfo7.setInfo("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str14 = projectInfo7.getName();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Range[0.0,0.0]" + "'", str10.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Range[0.0,0.0]" + "'", str14.equals("Range[0.0,0.0]"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot1.getFixedRangeAxisSpace();
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) categoryPlot1);
        try {
            keyedObjects0.removeValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, keyToGroupMap1);
        double double4 = range2.constrain((double) (short) 100);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("30-June-2019", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        categoryPlot0.setWeight((int) (short) 0);
        java.lang.Object obj9 = categoryPlot0.clone();
        org.jfree.chart.util.ShapeList shapeList10 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis12.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis12.setMarkerBand(markerAxisBand15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        java.awt.Font font18 = numberAxis12.getTickLabelFont();
        boolean boolean19 = shapeList10.equals((java.lang.Object) numberAxis12);
        java.awt.Shape shape20 = numberAxis12.getUpArrow();
        numberAxis12.configure();
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.clone(shape23);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity27 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0.25d, shape24, "", "");
        numberAxis12.setDownArrow(shape24);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis30.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis30.setMarkerBand(markerAxisBand33);
        org.jfree.data.Range range35 = numberAxis30.getDefaultAutoRange();
        boolean boolean36 = numberAxis30.isTickLabelsVisible();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray37 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis30 };
        categoryPlot0.setRangeAxes(valueAxisArray37);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(valueAxisArray37);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 5, (java.lang.Number) 1.0f, (java.lang.Number) 100, (java.lang.Number) 1.0E-8d, (java.lang.Number) 0.4d, (java.lang.Number) 2, (java.lang.Number) (-459), (java.lang.Number) (byte) 10, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMaxRegularValue();
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo();
        boolean boolean13 = boxAndWhiskerItem10.equals((java.lang.Object) projectInfo12);
        java.lang.String str14 = projectInfo12.getLicenceName();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2 + "'", number11.equals(2));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 3, 1.0d);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list12 = taskSeriesCollection11.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem13 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 5, (java.lang.Number) 1.0f, (java.lang.Number) 100, (java.lang.Number) 1.0E-8d, (java.lang.Number) 0.4d, (java.lang.Number) 2, (java.lang.Number) (-459), (java.lang.Number) (byte) 10, list12);
        boolean boolean14 = size2D2.equals((java.lang.Object) 5);
        size2D2.width = 10L;
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color9 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color9);
        double double11 = rectangleInsets5.getRight();
        double double13 = rectangleInsets5.calculateBottomInset((double) 2);
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets5);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle3.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list3 = taskSeriesCollection2.getColumnKeys();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = null;
        taskSeriesCollection2.seriesChanged(seriesChangeEvent4);
        boolean boolean6 = taskSeriesCollection0.hasListener((java.util.EventListener) taskSeriesCollection2);
        try {
            org.jfree.data.gantt.TaskSeries taskSeries8 = taskSeriesCollection0.getSeries((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        int int16 = color11.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font9, (java.awt.Paint) color11);
        java.awt.Paint paint18 = labelBlock17.getPaint();
        labelBlock17.setURLText("SortOrder.ASCENDING");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer0.getPadding();
        java.lang.String str3 = rectangleInsets2.toString();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color10 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke11 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint5, stroke6, (java.awt.Paint) color10, stroke11, 1.0f);
        java.awt.Paint paint14 = categoryMarker13.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker13);
        org.jfree.chart.plot.Marker marker16 = markerChangeEvent15.getMarker();
        boolean boolean17 = rectangleInsets2.equals((java.lang.Object) marker16);
        java.lang.String str18 = rectangleInsets2.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(marker16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str18.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        java.text.DateFormat dateFormat3 = null;
        dateAxis1.setDateFormatOverride(dateFormat3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot6.getRenderer((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets11.calculateRightInset((double) 1L);
        double double15 = rectangleInsets11.extendHeight((double) 1559372400000L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = chartRenderingInfo16.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = chartRenderingInfo18.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        plotRenderingInfo19.setPlotArea(rectangle2D20);
        plotRenderingInfo17.addSubplotInfo(plotRenderingInfo19);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis24.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand27 = null;
        numberAxis24.setMarkerBand(markerAxisBand27);
        boolean boolean29 = plotRenderingInfo17.equals((java.lang.Object) markerAxisBand27);
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo17.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str32 = rectangleAnchor31.toString();
        java.awt.geom.Point2D point2D33 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D30, rectangleAnchor31);
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets11.createInsetRectangle(rectangle2D30);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace37 = dateAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot6, rectangle2D34, rectangleEdge35, axisSpace36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.559372400008E12d + "'", double15 == 1.559372400008E12d);
        org.junit.Assert.assertNotNull(plotRenderingInfo17);
        org.junit.Assert.assertNotNull(plotRenderingInfo19);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleAnchor.TOP" + "'", str32.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D33);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot0.getDomainMarkers((int) ' ', layer10);
        java.lang.Object obj12 = categoryPlot0.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(categoryItemRenderer13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = ganttRenderer0.getURLGenerator((int) (byte) 1, 2);
        double double4 = ganttRenderer0.getBase();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = ganttRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer8.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        java.awt.Paint paint14 = stackedAreaRenderer8.getItemOutlinePaint(4, (int) '#');
        ganttRenderer0.setSeriesItemLabelPaint(15, paint14, true);
        org.jfree.chart.block.CenterArrangement centerArrangement17 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.Arrangement arrangement18 = null;
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0, (org.jfree.chart.block.Arrangement) centerArrangement17, arrangement18);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        int int2 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = ganttRenderer0.getPositiveItemLabelPositionFallback();
        ganttRenderer0.setStartPercent((double) 100.0f);
        org.junit.Assert.assertNull(itemLabelPosition3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = legendTitle3.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = legendTitle3.getItemLabelPadding();
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(1900, axisLocation6);
        categoryPlot4.setRangeCrosshairValue(1.0E-5d, false);
        boolean boolean11 = taskSeriesCollection0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = statisticalBarRenderer0.getSeriesToolTipGenerator(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition5);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        java.lang.Object obj9 = lineRenderer3D0.clone();
        java.awt.Font font10 = lineRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = lineRenderer3D0.getLegendItemToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke16 = categoryAxis15.getTickMarkStroke();
        ringPlot13.setLabelLinkStroke(stroke16);
        lineRenderer3D0.setBaseStroke(stroke16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint23 = statisticalBarRenderer20.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer25.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double29 = itemLabelPosition28.getAngle();
        statisticalBarRenderer20.setBasePositiveItemLabelPosition(itemLabelPosition28);
        lineRenderer3D0.setSeriesPositiveItemLabelPosition(12, itemLabelPosition28);
        java.awt.Paint paint34 = lineRenderer3D0.getItemLabelPaint((int) (short) -1, 2);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        categoryPlot0.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation(100);
        boolean boolean12 = categoryPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint13 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder15 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setRowRenderingOrder(sortOrder15);
        java.lang.String str17 = sortOrder15.toString();
        categoryPlot0.setRowRenderingOrder(sortOrder15);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "SortOrder.ASCENDING" + "'", str17.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer5.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        double double11 = ringPlot10.getInnerSeparatorExtension();
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot10.setLabelShadowPaint(paint12);
        stackedAreaRenderer5.setBaseOutlinePaint(paint12, false);
        stackedAreaRenderer5.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean19 = stackedAreaRenderer5.getSeriesVisible((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = stackedAreaRenderer5.getBaseNegativeItemLabelPosition();
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition20, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer23.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer23.setErrorIndicatorPaint(paint26);
        java.lang.Boolean boolean29 = statisticalBarRenderer23.getSeriesCreateEntities((int) (short) 1);
        boolean boolean30 = statisticalBarRenderer23.getIncludeBaseInRange();
        boolean boolean31 = lineRenderer3D0.equals((java.lang.Object) boolean30);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(boolean29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        legendTitle3.removeChangeListener(titleChangeListener4);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment7, verticalAlignment8, (double) (byte) 100, (double) 10);
        blockContainer6.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement11);
        legendTitle3.setWrapper(blockContainer6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.extendHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
//        jFreeChart3.removeLegend();
//        jFreeChart3.clearSubtitles();
//        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline0.getSegment(0L);
//        segment8.dec((long) (short) 10);
//        boolean boolean11 = segment8.inExcludeSegments();
//        long long12 = segment8.getMillisecond();
//        segment8.inc();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(segment8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-864000000L) + "'", long12 == (-864000000L));
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        boolean boolean7 = numberAxis1.isAutoRange();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setTickMarkOutsideLength((float) (-459));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Image image3 = ringPlot1.getBackgroundImage();
        java.awt.Paint paint4 = ringPlot1.getBaseSectionPaint();
        boolean boolean6 = ringPlot1.equals((java.lang.Object) '4');
        int int7 = ringPlot1.getPieIndex();
        float float8 = ringPlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean4 = ringPlot2.equals((java.lang.Object) 'a');
        java.awt.Paint paint6 = null;
        ringPlot2.setSectionOutlinePaint((java.lang.Comparable) 'a', paint6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        categoryAxis9.setAxisLineVisible(true);
        java.awt.Paint paint13 = categoryAxis9.getAxisLinePaint();
        java.awt.Font font14 = categoryAxis9.getLabelFont();
        ringPlot2.setLabelFont(font14);
        levelRenderer0.setSeriesItemLabelFont(0, font14);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = levelRenderer0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(drawingSupplier17);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        int int12 = lineRenderer3D0.getPassCount();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = ringPlot14.getSectionOutlinesVisible();
        double double16 = ringPlot14.getShadowXOffset();
        boolean boolean17 = lineRenderer3D0.equals((java.lang.Object) ringPlot14);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis20.setMarkerBand(markerAxisBand23);
        org.jfree.data.Range range25 = numberAxis20.getDefaultAutoRange();
        java.awt.Shape shape26 = numberAxis20.getDownArrow();
        lineRenderer3D0.setSeriesShape((int) '#', shape26);
        lineRenderer3D0.setBaseItemLabelsVisible(false, false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        java.awt.Paint paint6 = null;
        boolean boolean7 = org.jfree.chart.util.PaintUtilities.equal(paint5, paint6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSectionOutlinesVisible();
        double double3 = ringPlot1.getLabelGap();
        ringPlot1.setInnerSeparatorExtension(3600000.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long7 = segmentedTimeline4.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline4.getSegment(date9);
        int int11 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) segment10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int13 = segmentedTimeline12.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot14);
        jFreeChart15.removeLegend();
        jFreeChart15.clearSubtitles();
        boolean boolean18 = segmentedTimeline12.equals((java.lang.Object) jFreeChart15);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment20 = segmentedTimeline12.getSegment(0L);
        segment20.dec((long) (short) 10);
        boolean boolean23 = segment10.before(segment20);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(segmentedTimeline12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(segment20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockFrame blockFrame1 = blockContainer0.getFrame();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement2);
        blockContainer0.setPadding((double) (-864000000L), 3.0d, 0.0d, 0.0d);
        org.junit.Assert.assertNotNull(blockFrame1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str1.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot1.setLabelShadowPaint(paint3);
        ringPlot1.setShadowXOffset(0.2d);
        java.awt.Stroke stroke7 = ringPlot1.getSeparatorStroke();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = ringPlot11.equals((java.lang.Object) 'a');
        java.awt.Paint paint15 = null;
        ringPlot11.setSectionOutlinePaint((java.lang.Comparable) 'a', paint15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setAxisLineVisible(true);
        java.awt.Paint paint22 = categoryAxis18.getAxisLinePaint();
        java.awt.Font font23 = categoryAxis18.getLabelFont();
        ringPlot11.setLabelFont(font23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        ringPlot11.setBaseSectionOutlinePaint((java.awt.Paint) color25);
        boolean boolean27 = stackedBarRenderer3D10.equals((java.lang.Object) ringPlot11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = chartRenderingInfo29.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = chartRenderingInfo31.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        plotRenderingInfo32.setPlotArea(rectangle2D33);
        plotRenderingInfo30.addSubplotInfo(plotRenderingInfo32);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState36 = ringPlot1.initialise(graphics2D8, rectangle2D9, (org.jfree.chart.plot.PiePlot) ringPlot11, (java.lang.Integer) 6, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo30);
        org.junit.Assert.assertNotNull(plotRenderingInfo32);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart3.removeLegend();
        jFreeChart3.clearSubtitles();
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double10 = rectangleInsets8.calculateRightInset((double) 1L);
        double double12 = rectangleInsets8.extendHeight((double) 1559372400000L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo13.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo15.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        plotRenderingInfo16.setPlotArea(rectangle2D17);
        plotRenderingInfo14.addSubplotInfo(plotRenderingInfo16);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis21.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis21.setMarkerBand(markerAxisBand24);
        boolean boolean26 = plotRenderingInfo14.equals((java.lang.Object) markerAxisBand24);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo14.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str29 = rectangleAnchor28.toString();
        java.awt.geom.Point2D point2D30 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor28);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets8.createInsetRectangle(rectangle2D27);
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27, "30-June-2019");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = chartRenderingInfo34.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection36 = null;
        chartRenderingInfo34.setEntityCollection(entityCollection36);
        java.lang.Object obj38 = chartRenderingInfo34.clone();
        try {
            jFreeChart3.draw(graphics2D7, rectangle2D27, chartRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.0d + "'", double10 == 8.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.559372400008E12d + "'", double12 == 1.559372400008E12d);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleAnchor.TOP" + "'", str29.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(plotRenderingInfo35);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone2);
        dateAxis1.setTimeZone(timeZone2);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 100.0f, (java.lang.Number) 1L);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        boolean boolean4 = ringPlot3.getIgnoreNullValues();
        ringPlot3.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        java.awt.Stroke stroke8 = ringPlot3.getLabelLinkStroke();
        boolean boolean9 = meanAndStandardDeviation2.equals((java.lang.Object) stroke8);
        java.lang.Number number10 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1L + "'", number10.equals(1L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        java.lang.Object obj9 = lineRenderer3D0.clone();
        java.awt.Font font10 = lineRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boolean boolean12 = lineRenderer3D0.equals((java.lang.Object) standardCategorySeriesLabelGenerator11);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection13 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.KeyToGroupMap keyToGroupMap14 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection13, keyToGroupMap14);
        try {
            java.lang.String str17 = standardCategorySeriesLabelGenerator11.generateLabel((org.jfree.data.category.CategoryDataset) taskSeriesCollection13, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockFrame blockFrame1 = blockContainer0.getFrame();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double7 = rectangleInsets5.calculateRightInset((double) 1L);
        double double9 = rectangleInsets5.extendHeight((double) 1559372400000L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = chartRenderingInfo10.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo12.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        plotRenderingInfo13.setPlotArea(rectangle2D14);
        plotRenderingInfo11.addSubplotInfo(plotRenderingInfo13);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis18.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = null;
        numberAxis18.setMarkerBand(markerAxisBand21);
        boolean boolean23 = plotRenderingInfo11.equals((java.lang.Object) markerAxisBand21);
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo11.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str26 = rectangleAnchor25.toString();
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor25);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets5.createInsetRectangle(rectangle2D24);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24, "30-June-2019");
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color37 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke38 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint32, stroke33, (java.awt.Paint) color37, stroke38, 1.0f);
        java.awt.Paint paint41 = categoryMarker40.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent42 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker40);
        org.jfree.chart.plot.Marker marker43 = markerChangeEvent42.getMarker();
        try {
            java.lang.Object obj44 = blockContainer0.draw(graphics2D4, rectangle2D24, (java.lang.Object) marker43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockFrame1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.559372400008E12d + "'", double9 == 1.559372400008E12d);
        org.junit.Assert.assertNotNull(plotRenderingInfo11);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleAnchor.TOP" + "'", str26.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(marker43);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = levelRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = levelRenderer0.getBaseItemLabelGenerator();
        boolean boolean6 = levelRenderer0.equals((java.lang.Object) 255);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image3, "hi!", "", "");
        projectInfo7.setName("Range[0.0,0.0]");
        java.lang.String str10 = projectInfo7.getName();
        java.lang.String str11 = projectInfo7.getLicenceName();
        projectInfo7.setInfo("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str14 = projectInfo7.toString();
        projectInfo7.setCopyright("Range[0.0,0.0]");
        projectInfo7.setInfo("255");
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Range[0.0,0.0]" + "'", str10.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Range[0.0,0.0] version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Range[0.0,0.0]:None\nRange[0.0,0.0] LICENCE TERMS:\n" + "'", str14.equals("Range[0.0,0.0] version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Range[0.0,0.0]:None\nRange[0.0,0.0] LICENCE TERMS:\n"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues2D0.getRowKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = null;
        java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleAnchor.TOP", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray4 = new float[] { 0.5f, 2, 205 };
        try {
            float[] floatArray5 = color0.getRGBComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        legendTitle3.removeChangeListener(titleChangeListener4);
        java.awt.Paint paint6 = legendTitle3.getBackgroundPaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        legendTitle3.setItemPaint(paint7);
        legendTitle3.setNotify(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double13 = rectangleInsets11.calculateRightInset((double) 1L);
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets11);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.0d + "'", double13 == 8.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue(11, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 1L, (-1.0d), 97.0d, (double) (byte) 0, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) '#');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        numberAxis1.setRightArrow(shape6);
        double double9 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        java.awt.Font font7 = numberAxis1.getTickLabelFont();
        numberAxis1.setFixedAutoRange((double) '#');
        numberAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.plot.Plot plot4 = categoryAxis1.getPlot();
        categoryAxis1.setCategoryLabelPositionOffset((int) ' ');
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        double double8 = ringPlot7.getStartAngle();
        boolean boolean9 = categoryAxis1.hasListener((java.util.EventListener) ringPlot7);
        double double10 = ringPlot7.getShadowXOffset();
        java.awt.Paint paint11 = ringPlot7.getLabelOutlinePaint();
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(paint11);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        long long5 = segmentedTimeline2.getExceptionSegmentCount((long) 'a', 0L);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.util.Date date7 = month6.getEnd();
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline2.getSegment(date7);
//        boolean boolean9 = segment8.inIncludeSegments();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        java.lang.Comparable[] comparableArray13 = new java.lang.Comparable[] { 8, "PlotOrientation.HORIZONTAL", segment8, 12.0d, year11 };
//        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date16 = dateAxis15.getMaximumDate();
//        java.lang.Comparable[] comparableArray18 = new java.lang.Comparable[] { date16, "SortOrder.ASCENDING" };
//        java.lang.Number[] numberArray21 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray22 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray23 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray24 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray25 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray26 = new java.lang.Number[] {};
//        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray21, numberArray22, numberArray23, numberArray24, numberArray25, numberArray26 };
//        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray27);
//        java.lang.Number[] numberArray31 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray32 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray33 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray34 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray35 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray36 = new java.lang.Number[] {};
//        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray31, numberArray32, numberArray33, numberArray34, numberArray35, numberArray36 };
//        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray37);
//        try {
//            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset39 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray13, comparableArray18, numberArray27, numberArray37);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of series keys does not match the number of series in the data.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(segmentedTimeline2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(segment8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertNotNull(comparableArray13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(comparableArray18);
//        org.junit.Assert.assertNotNull(numberArray21);
//        org.junit.Assert.assertNotNull(numberArray22);
//        org.junit.Assert.assertNotNull(numberArray23);
//        org.junit.Assert.assertNotNull(numberArray24);
//        org.junit.Assert.assertNotNull(numberArray25);
//        org.junit.Assert.assertNotNull(numberArray26);
//        org.junit.Assert.assertNotNull(numberArray27);
//        org.junit.Assert.assertNotNull(categoryDataset28);
//        org.junit.Assert.assertNotNull(numberArray31);
//        org.junit.Assert.assertNotNull(numberArray32);
//        org.junit.Assert.assertNotNull(numberArray33);
//        org.junit.Assert.assertNotNull(numberArray34);
//        org.junit.Assert.assertNotNull(numberArray35);
//        org.junit.Assert.assertNotNull(numberArray36);
//        org.junit.Assert.assertNotNull(numberArray37);
//        org.junit.Assert.assertNotNull(categoryDataset38);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        legendTitle3.removeChangeListener(titleChangeListener4);
        java.awt.Paint paint6 = legendTitle3.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle3.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range12 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str13 = range12.toString();
        double double14 = range12.getCentralValue();
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(range12);
        java.util.Date date16 = dateRange15.getUpperDate();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint21 = statisticalBarRenderer18.getItemFillPaint(0, (int) '#');
        boolean boolean22 = lengthConstraintType17.equals((java.lang.Object) 0);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis25.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis25.setMarkerBand(markerAxisBand28);
        org.jfree.data.Range range30 = numberAxis25.getDefaultAutoRange();
        boolean boolean31 = numberAxis25.isAutoRange();
        numberAxis25.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range34 = numberAxis25.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType35 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange15, lengthConstraintType17, 0.0d, range34, lengthConstraintType35);
        try {
            org.jfree.chart.util.Size2D size2D37 = legendTitle3.arrange(graphics2D8, rectangleConstraint36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[0.0,0.0]" + "'", str13.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(lengthConstraintType35);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("255");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setErrorIndicatorPaint(paint3);
        java.lang.Boolean boolean6 = statisticalBarRenderer0.getSeriesCreateEntities((int) (short) 1);
        java.awt.Paint paint8 = statisticalBarRenderer0.lookupSeriesFillPaint(10);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        double double15 = ringPlot14.getInnerSeparatorExtension();
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot14.setLabelShadowPaint(paint16);
        ringPlot14.setShadowXOffset(0.2d);
        java.awt.Stroke stroke20 = ringPlot14.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer22.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot(pieDataset26);
        double double28 = ringPlot27.getInnerSeparatorExtension();
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot27.setLabelShadowPaint(paint29);
        stackedAreaRenderer22.setBaseOutlinePaint(paint29, false);
        ringPlot14.setNoDataMessagePaint(paint29);
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot14.setLegendItemShape(shape34);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke40 = categoryAxis39.getTickMarkStroke();
        categoryAxis39.setAxisLineVisible(true);
        java.awt.Paint paint43 = categoryAxis39.getAxisLinePaint();
        stackedAreaRenderer37.setBaseOutlinePaint(paint43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer37.setBasePaint((java.awt.Paint) color45, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint51 = statisticalBarRenderer48.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer53 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = stackedAreaRenderer53.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double57 = itemLabelPosition56.getAngle();
        statisticalBarRenderer48.setBasePositiveItemLabelPosition(itemLabelPosition56);
        statisticalBarRenderer48.setIncludeBaseInRange(true);
        boolean boolean61 = statisticalBarRenderer48.getBaseSeriesVisible();
        java.awt.Stroke stroke62 = statisticalBarRenderer48.getBaseStroke();
        java.awt.Font font66 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke69 = categoryAxis68.getTickMarkStroke();
        categoryAxis68.setAxisLineVisible(true);
        java.awt.Paint paint72 = categoryAxis68.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock73 = org.jfree.chart.text.TextUtilities.createTextBlock("", font66, paint72);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer74 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint77 = statisticalBarRenderer74.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock78 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font66, paint77);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer79 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint82 = statisticalBarRenderer79.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer79.setMinimumBarLength((double) (short) 100);
        java.awt.Color color87 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis89 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke90 = categoryAxis89.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker91 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color87, stroke90);
        statisticalBarRenderer79.setSeriesPaint((int) '4', (java.awt.Paint) color87);
        org.jfree.chart.block.LabelBlock labelBlock93 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font66, (java.awt.Paint) color87);
        org.jfree.chart.LegendItem legendItem94 = new org.jfree.chart.LegendItem("WMAP_Plot", "CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP", "{0}", "30-June-2019", shape34, (java.awt.Paint) color45, stroke62, (java.awt.Paint) color87);
        java.awt.Stroke stroke95 = legendItem94.getOutlineStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke95, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(itemLabelPosition56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(textBlock73);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNotNull(textBlock78);
        org.junit.Assert.assertNotNull(paint82);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(stroke90);
        org.junit.Assert.assertNotNull(stroke95);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint2 = lineBorder1.getPaint();
        java.awt.Stroke stroke3 = lineBorder1.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke15 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint9, stroke10, (java.awt.Paint) color14, stroke15, 1.0f);
        java.awt.Paint paint18 = categoryMarker17.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker17);
        java.lang.Comparable comparable20 = categoryMarker17.getKey();
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 0.2d + "'", comparable20.equals(0.2d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("30-June-2019", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.TickUnit tickUnit1 = null;
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getLargerTickUnit(tickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Color color4 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint8 = statisticalBarRenderer5.getItemFillPaint(0, (int) '#');
        java.awt.Stroke stroke10 = statisticalBarRenderer5.lookupSeriesOutlineStroke(0);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 1, (java.awt.Paint) color4, stroke10);
        stackedAreaRenderer0.setSeriesPaint(0, (java.awt.Paint) color4, false);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType14 = stackedAreaRenderer0.getEndType();
        boolean boolean17 = stackedAreaRenderer0.getItemVisible(15, (int) (short) 10);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(areaRendererEndType14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.5f, (float) ' ', 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 500, (double) 1560179855055L, Double.NaN, (double) 255);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0f, "Range[0.0,0.0]", textAnchor2, textAnchor3, (double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        boolean boolean7 = numberTick5.equals((java.lang.Object) rectangleAnchor6);
        java.lang.Number number8 = numberTick5.getNumber();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0f + "'", number8.equals(0.0f));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        boolean boolean7 = numberAxis1.isAutoRange();
        numberAxis1.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range10 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis1.setMarkerBand(markerAxisBand11);
        numberAxis1.setFixedDimension((double) 255);
        double double15 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        double double4 = statisticalBarRenderer0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer6 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer6.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = levelRenderer6.getBaseURLGenerator();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        categoryAxis11.setAxisLineVisible(true);
        java.awt.Paint paint15 = categoryAxis11.getAxisLinePaint();
        java.awt.Font font16 = categoryAxis11.getLabelFont();
        levelRenderer6.setBaseItemLabelFont(font16);
        java.awt.Color color19 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke22 = categoryAxis21.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke22);
        java.awt.Font font24 = valueMarker23.getLabelFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) valueMarker23);
        org.jfree.chart.JFreeChart jFreeChart26 = rendererChangeEvent25.getChart();
        levelRenderer6.notifyListeners(rendererChangeEvent25);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer30 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = stackedAreaRenderer30.getPositiveItemLabelPosition((int) (short) 10, 1);
        levelRenderer6.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition33, false);
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition33);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNull(jFreeChart26);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) 'a');
        ringPlot4.setForegroundAlpha((float) (short) -1);
        ringPlot4.setSectionDepth((double) 255);
        java.awt.Paint paint11 = ringPlot4.getLabelShadowPaint();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) (short) 0, (double) 1559372400000L, (double) (-864000000L), paint11);
        java.awt.Paint paint13 = blockBorder12.getPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        java.awt.Paint paint7 = stackedAreaRenderer1.getItemOutlinePaint(4, (int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint10 = lineBorder9.getPaint();
        java.awt.Stroke stroke11 = lineBorder9.getStroke();
        categoryPlot8.setDomainGridlineStroke(stroke11);
        stackedAreaRenderer1.setPlot(categoryPlot8);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer15 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer15.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = levelRenderer15.getBaseURLGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = stackedAreaRenderer21.getPositiveItemLabelPosition((int) (short) 10, 1);
        levelRenderer15.setSeriesNegativeItemLabelPosition(2, itemLabelPosition24);
        try {
            stackedAreaRenderer1.setSeriesPositiveItemLabelPosition((-4503480), itemLabelPosition24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedAreaRenderer5.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double9 = itemLabelPosition8.getAngle();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = statisticalBarRenderer0.getPlot();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(categoryPlot11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.String[] strArray3 = new java.lang.String[] { "30-June-2019", "Category Plot", "Range[0.0,0.0]" };
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[] numberArray8 = new java.lang.Number[] {};
        java.lang.Number[] numberArray9 = new java.lang.Number[] {};
        java.lang.Number[] numberArray10 = new java.lang.Number[] {};
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray7, numberArray8, numberArray9, numberArray10, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray12);
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (-1.0d), 1.0f, 500, 7, (short) 1 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1.0d), 1.0f, 500, 7, (short) 1 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (-1.0d), 1.0f, 500, 7, (short) 1 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (-1.0d), 1.0f, 500, 7, (short) 1 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (-1.0d), 1.0f, 500, 7, (short) 1 };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray19, numberArray25, numberArray31, numberArray37, numberArray43 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset45 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray3, numberArray12, numberArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint4 = statisticalBarRenderer1.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer1.setMinimumBarLength((double) (short) 100);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke12);
        statisticalBarRenderer1.setSeriesPaint((int) '4', (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D16 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, (java.awt.Paint) color21);
        lineRenderer3D16.setWallPaint((java.awt.Paint) color21);
        statisticalBarRenderer1.setSeriesPaint(0, (java.awt.Paint) color21, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = statisticalBarRenderer1.getPlot();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer1);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(categoryPlot26);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreNullValues();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot5);
        jFreeChart6.removeLegend();
        java.awt.image.BufferedImage bufferedImage10 = jFreeChart6.createBufferedImage(1900, (int) ' ');
        ringPlot0.setBackgroundImage((java.awt.Image) bufferedImage10);
        ringPlot0.setIgnoreZeroValues(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(bufferedImage10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryEnd((int) ' ', (-459), rectangle2D5, rectangleEdge6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        org.jfree.chart.event.AxisChangeListener axisChangeListener9 = null;
        categoryAxis1.addChangeListener(axisChangeListener9);
        java.awt.Stroke stroke11 = categoryAxis1.getAxisLineStroke();
        categoryAxis1.setTickMarkInsideLength((float) 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        ringPlot0.setForegroundAlpha((float) (short) -1);
        java.awt.Paint paint5 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator6);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = null;
        ringPlot0.setLabelGenerator(pieSectionLabelGenerator8);
        double double10 = ringPlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-5d + "'", double10 == 1.0E-5d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        double double2 = piePlot3D0.getDepthFactor();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        piePlot3D0.setLabelBackgroundPaint((java.awt.Paint) color3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        int int12 = lineRenderer3D0.getPassCount();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = ringPlot14.getSectionOutlinesVisible();
        double double16 = ringPlot14.getShadowXOffset();
        boolean boolean17 = lineRenderer3D0.equals((java.lang.Object) ringPlot14);
        ringPlot14.setNoDataMessage("");
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor20 = null;
        try {
            ringPlot14.setLabelDistributor(abstractPieLabelDistributor20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown((double) (short) 10);
        axisState0.cursorLeft(4.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent4);
        try {
            org.jfree.data.gantt.TaskSeries taskSeries7 = taskSeriesCollection0.getSeries(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot12.equals((java.lang.Object) 'a');
        java.awt.Paint paint16 = null;
        ringPlot12.setSectionOutlinePaint((java.lang.Comparable) 'a', paint16);
        ringPlot12.setPieIndex((int) ' ');
        java.awt.Font font20 = ringPlot12.getLabelFont();
        java.awt.Color color22 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke25 = categoryAxis24.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke25);
        int int27 = color22.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font20, (java.awt.Paint) color22);
        java.awt.Font font29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        labelBlock28.setFont(font29);
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color37 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke38 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint32, stroke33, (java.awt.Paint) color37, stroke38, 1.0f);
        org.jfree.chart.text.TextBlock textBlock41 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font29, (java.awt.Paint) color37);
        org.jfree.chart.text.TextMeasurer textMeasurer44 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock45 = org.jfree.chart.text.TextUtilities.createTextBlock("ThreadContext", font9, (java.awt.Paint) color37, (float) 1, 255, textMeasurer44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 255 + "'", int27 == 255);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(textBlock41);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("PlotOrientation.HORIZONTAL", graphics2D1, (float) (byte) 100, (float) (short) 1, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection2);
        int int5 = taskSeriesCollection2.indexOf((java.lang.Comparable) 255);
        boolean boolean6 = rangeType1.equals((java.lang.Object) taskSeriesCollection2);
        int int8 = taskSeriesCollection2.getColumnIndex((java.lang.Comparable) (byte) 0);
        org.jfree.data.KeyToGroupMap keyToGroupMap10 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (short) 10);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection2, keyToGroupMap10);
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, (org.jfree.data.general.Dataset) taskSeriesCollection2, (java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        dateAxis1.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource7);
        java.awt.Font font9 = dateAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        categoryAxis5.setAxisLineVisible(true);
        java.awt.Paint paint9 = categoryAxis5.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint14 = statisticalBarRenderer11.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font3, paint14);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint19 = statisticalBarRenderer16.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer16.setMinimumBarLength((double) (short) 100);
        java.awt.Color color24 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke27 = categoryAxis26.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color24, stroke27);
        statisticalBarRenderer16.setSeriesPaint((int) '4', (java.awt.Paint) color24);
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font3, (java.awt.Paint) color24);
        double double31 = labelBlock30.getContentXOffset();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        labelBlock30.setPaint((java.awt.Paint) color32);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        java.lang.Object obj9 = lineRenderer3D0.clone();
        java.awt.Font font10 = lineRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = lineRenderer3D0.getLegendItemToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke16 = categoryAxis15.getTickMarkStroke();
        ringPlot13.setLabelLinkStroke(stroke16);
        lineRenderer3D0.setBaseStroke(stroke16);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint23 = statisticalBarRenderer20.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = stackedAreaRenderer25.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double29 = itemLabelPosition28.getAngle();
        statisticalBarRenderer20.setBasePositiveItemLabelPosition(itemLabelPosition28);
        lineRenderer3D0.setSeriesPositiveItemLabelPosition(12, itemLabelPosition28);
        lineRenderer3D0.setSeriesShapesFilled(15, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setBaseCreateEntities(true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot4.getDataset();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        boolean boolean8 = ringPlot7.getSectionOutlinesVisible();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list10 = taskSeriesCollection9.getColumnKeys();
        int int12 = taskSeriesCollection9.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable13 = null;
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection9, comparable13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) boolean8, (org.jfree.data.general.Dataset) taskSeriesCollection9);
        multiplePiePlot4.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        org.jfree.data.Range range17 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        int int19 = taskSeriesCollection9.getRowIndex((java.lang.Comparable) 0.0f);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        org.jfree.chart.axis.Axis axis7 = axisChangeEvent6.getAxis();
        org.jfree.chart.axis.Axis axis8 = axisChangeEvent6.getAxis();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axis7);
        org.junit.Assert.assertNotNull(axis8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (-1), (double) '#');
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RangeType.FULL");
        taskSeries1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement7 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource5, (org.jfree.chart.block.Arrangement) columnArrangement6, (org.jfree.chart.block.Arrangement) centerArrangement7);
        boolean boolean9 = legendTitle8.getNotify();
        boolean boolean10 = taskSeries1.equals((java.lang.Object) boolean9);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer3 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = ganttRenderer3.getURLGenerator((int) (byte) 1, 2);
        double double7 = ganttRenderer3.getBase();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = ganttRenderer3.getLegendItemURLGenerator();
        ganttRenderer3.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = ganttRenderer3.getToolTipGenerator((int) (short) -1, 0);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer18.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        java.awt.Paint paint24 = stackedAreaRenderer18.getItemOutlinePaint(4, (int) '#');
        ganttRenderer3.setSeriesPaint((int) (byte) 10, paint24, false);
        ringPlot0.setLabelLinkPaint(paint24);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        boolean boolean7 = ringPlot5.equals((java.lang.Object) 'a');
        ringPlot5.setForegroundAlpha((float) (short) -1);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer11.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot(pieDataset15);
        double double17 = ringPlot16.getInnerSeparatorExtension();
        java.awt.Paint paint18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setLabelShadowPaint(paint18);
        stackedAreaRenderer11.setBaseOutlinePaint(paint18, false);
        ringPlot5.setSeparatorPaint(paint18);
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot5);
        boolean boolean24 = ringPlot5.isCircular();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getEnd();
        int int5 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) date4);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) 5);
        int int10 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        blockContainer0.setPadding(rectangleInsets1);
        org.jfree.chart.block.FlowArrangement flowArrangement3 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockContainer4.getPadding();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer9.setBaseCreateEntities(true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset13 = multiplePiePlot12.getDataset();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
        boolean boolean16 = ringPlot15.getSectionOutlinesVisible();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection17 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list18 = taskSeriesCollection17.getColumnKeys();
        int int20 = taskSeriesCollection17.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable21 = null;
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection17, comparable21);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) boolean16, (org.jfree.data.general.Dataset) taskSeriesCollection17);
        multiplePiePlot12.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection17);
        org.jfree.data.Range range25 = stackedAreaRenderer9.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection17);
        org.jfree.data.Range range29 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str30 = range29.toString();
        double double31 = range29.getCentralValue();
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange(range29);
        java.util.Date date33 = dateRange32.getUpperDate();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint38 = statisticalBarRenderer35.getItemFillPaint(0, (int) '#');
        boolean boolean39 = lengthConstraintType34.equals((java.lang.Object) 0);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis42.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis42.setMarkerBand(markerAxisBand45);
        org.jfree.data.Range range47 = numberAxis42.getDefaultAutoRange();
        boolean boolean48 = numberAxis42.isAutoRange();
        numberAxis42.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range51 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType52 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange32, lengthConstraintType34, 0.0d, range51, lengthConstraintType52);
        org.jfree.data.Range range57 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.time.DateRange dateRange58 = new org.jfree.data.time.DateRange(range57);
        java.util.Date date59 = dateRange58.getLowerDate();
        org.jfree.data.Range range63 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range66 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str67 = range66.toString();
        org.jfree.data.Range range68 = org.jfree.data.Range.combine(range63, range66);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint69 = new org.jfree.chart.block.RectangleConstraint((double) 1, range68);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType70 = rectangleConstraint69.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint71 = new org.jfree.chart.block.RectangleConstraint(0.0d, range25, lengthConstraintType52, (double) 7, (org.jfree.data.Range) dateRange58, lengthConstraintType70);
        org.jfree.chart.util.Size2D size2D72 = flowArrangement3.arrange(blockContainer4, graphics2D6, rectangleConstraint71);
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer4);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Range[0.0,0.0]" + "'", str30.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(lengthConstraintType52);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Range[0.0,0.0]" + "'", str67.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertNotNull(lengthConstraintType70);
        org.junit.Assert.assertNotNull(size2D72);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "{0}");
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.Range range3 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range6 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str7 = range6.toString();
        org.jfree.data.Range range8 = org.jfree.data.Range.combine(range3, range6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 1, range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint9.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toUnconstrainedWidth();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,0.0]" + "'", str7.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (byte) 0, (int) (byte) 100, (int) (short) -1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedAreaRenderer5.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double9 = itemLabelPosition8.getAngle();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition8);
        statisticalBarRenderer0.setIncludeBaseInRange(true);
        boolean boolean13 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMaximumBarWidth((double) (short) 100);
        java.awt.Font font17 = statisticalBarRenderer0.getSeriesItemLabelFont(7);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(font17);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        java.lang.String str2 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str2.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.4d, (double) 10);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot3.equals((java.lang.Object) 'a');
        ringPlot3.setForegroundAlpha((float) (short) -1);
        java.awt.Paint paint8 = ringPlot3.getSeparatorPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = null;
        ringPlot3.setLegendLabelURLGenerator(pieURLGenerator9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = null;
        ringPlot3.setLabelGenerator(pieSectionLabelGenerator11);
        boolean boolean13 = size2D2.equals((java.lang.Object) ringPlot3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        org.jfree.chart.event.ChartChangeListener chartChangeListener2 = null;
        try {
            jFreeChart1.removeChangeListener(chartChangeListener2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis1.setMinimumDate(date2);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
//        java.lang.String str5 = serialDate4.toString();
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis7.setMinimumDate(date8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate4.getEndOfCurrentMonth(serialDate10);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int14 = segmentedTimeline13.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot15);
//        jFreeChart16.removeLegend();
//        jFreeChart16.clearSubtitles();
//        boolean boolean19 = segmentedTimeline13.equals((java.lang.Object) jFreeChart16);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment21 = segmentedTimeline13.getSegment(0L);
//        segment21.dec((long) (short) 10);
//        boolean boolean24 = segment21.inExcludeSegments();
//        java.lang.Comparable[] comparableArray28 = new java.lang.Comparable[] { serialDate10, "GradientPaintTransformType.VERTICAL", boolean24, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", 1560179855055L, 1 };
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Comparable[] comparableArray34 = new java.lang.Comparable[] { (short) -1, 0L, month31, "255", month33 };
//        double[] doubleArray38 = new double[] { 500, 1561964399999L, 500 };
//        double[] doubleArray42 = new double[] { 500, 1561964399999L, 500 };
//        double[] doubleArray46 = new double[] { 500, 1561964399999L, 500 };
//        double[] doubleArray50 = new double[] { 500, 1561964399999L, 500 };
//        double[] doubleArray54 = new double[] { 500, 1561964399999L, 500 };
//        double[] doubleArray58 = new double[] { 500, 1561964399999L, 500 };
//        double[][] doubleArray59 = new double[][] { doubleArray38, doubleArray42, doubleArray46, doubleArray50, doubleArray54, doubleArray58 };
//        try {
//            org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray28, comparableArray34, doubleArray59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Duplicate items in 'columnKeys'.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(segmentedTimeline13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 7 + "'", int14 == 7);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(segment21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(comparableArray28);
//        org.junit.Assert.assertNotNull(comparableArray34);
//        org.junit.Assert.assertNotNull(doubleArray38);
//        org.junit.Assert.assertNotNull(doubleArray42);
//        org.junit.Assert.assertNotNull(doubleArray46);
//        org.junit.Assert.assertNotNull(doubleArray50);
//        org.junit.Assert.assertNotNull(doubleArray54);
//        org.junit.Assert.assertNotNull(doubleArray58);
//        org.junit.Assert.assertNotNull(doubleArray59);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getBackgroundPaint();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        double double7 = ringPlot6.getInnerSeparatorExtension();
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot6.setLabelShadowPaint(paint8);
        stackedAreaRenderer1.setBaseOutlinePaint(paint8, false);
        stackedAreaRenderer1.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean15 = stackedAreaRenderer1.getSeriesVisible((int) 'a');
        int int16 = stackedAreaRenderer1.getPassCount();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, false);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        int int12 = lineRenderer3D0.getPassCount();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = ringPlot14.getSectionOutlinesVisible();
        double double16 = ringPlot14.getShadowXOffset();
        boolean boolean17 = lineRenderer3D0.equals((java.lang.Object) ringPlot14);
        boolean boolean20 = lineRenderer3D0.getItemShapeFilled(100, 3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineRenderer3D0.getNegativeItemLabelPosition(10, 7);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot0.getDomainMarkers((int) ' ', layer10);
        double double12 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.560179855055E12d + "'", double12 == 1.560179855055E12d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) (short) 10, (float) (-950399990L), (float) '#');
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.jfree.data.Range range9 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(range9);
        numberAxis1.setDefaultAutoRange(range9);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        legendTitle3.removeChangeListener(titleChangeListener4);
        java.awt.Paint paint6 = legendTitle3.getBackgroundPaint();
        java.awt.Paint paint7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        legendTitle3.setItemPaint(paint7);
        legendTitle3.setNotify(true);
        double double11 = legendTitle3.getHeight();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer2.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        int int6 = stackedAreaRenderer2.getPassCount();
        java.awt.Stroke stroke7 = stackedAreaRenderer2.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D11 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets12, (java.awt.Paint) color16);
        lineRenderer3D11.setWallPaint((java.awt.Paint) color16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = lineRenderer3D11.getSeriesPositiveItemLabelPosition((int) 'a');
        stackedAreaRenderer9.setSeriesNegativeItemLabelPosition(0, itemLabelPosition20, false);
        stackedAreaRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition20, true);
        boolean boolean25 = paintList0.equals((java.lang.Object) itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setErrorIndicatorPaint(paint3);
        java.lang.Boolean boolean6 = statisticalBarRenderer0.getSeriesCreateEntities((int) (short) 1);
        java.awt.Paint paint8 = statisticalBarRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator9, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalBarRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        java.awt.Paint paint10 = categoryMarker9.getOutlinePaint();
        categoryMarker9.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = categoryMarker9.getLabelOffsetType();
        java.awt.Font font14 = categoryMarker9.getLabelFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke6);
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        valueMarker7.setOutlinePaint((java.awt.Paint) color11);
        org.jfree.chart.util.Layer layer13 = null;
        try {
            xYPlot0.addDomainMarker(6, (org.jfree.chart.plot.Marker) valueMarker7, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend((-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = stackedBarRenderer3D0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint2 = lineBorder1.getPaint();
        java.awt.Stroke stroke3 = lineBorder1.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke8 = categoryAxis7.getTickMarkStroke();
        categoryAxis7.setAxisLineVisible(true);
        java.awt.Paint paint11 = categoryAxis7.getAxisLinePaint();
        java.awt.Font font12 = categoryAxis7.getLabelFont();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke20 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint14, stroke15, (java.awt.Paint) color19, stroke20, 1.0f);
        categoryAxis7.setTickMarkStroke(stroke15);
        categoryPlot0.setDomainAxis((int) '#', categoryAxis7, true);
        categoryAxis7.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = multiplePiePlot6.getDataset();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        multiplePiePlot6.setAggregatedItemsPaint((java.awt.Paint) color8);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Color color15 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint19 = statisticalBarRenderer16.getItemFillPaint(0, (int) '#');
        java.awt.Stroke stroke21 = statisticalBarRenderer16.lookupSeriesOutlineStroke(0);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 1, (java.awt.Paint) color15, stroke21);
        stackedAreaRenderer11.setSeriesPaint(0, (java.awt.Paint) color15, false);
        float[] floatArray31 = new float[] { 205, 1560668399999L, 6, 4, 7, (short) 1 };
        float[] floatArray32 = color15.getColorComponents(floatArray31);
        float[] floatArray33 = color8.getColorComponents(floatArray31);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryDataset7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getEnd();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        java.awt.Stroke stroke5 = ringPlot4.getSeparatorStroke();
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) month1, stroke5);
        long long7 = month1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot3);
        jFreeChart4.removeLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color10 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(rectangleInsets6, (java.awt.Paint) color10);
        double double12 = rectangleInsets6.getRight();
        jFreeChart4.setPadding(rectangleInsets6);
        boolean boolean14 = jFreeChart4.getAntiAlias();
        jFreeChart4.setNotify(true);
        boolean boolean17 = dateAxis1.equals((java.lang.Object) true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color18);
        java.text.DateFormat dateFormat20 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateFormat20);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.Range range3 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range6 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str7 = range6.toString();
        org.jfree.data.Range range8 = org.jfree.data.Range.combine(range3, range6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 1, range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint9.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint9.getHeightConstraintType();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[0.0,0.0]" + "'", str7.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image3, "hi!", "", "");
        projectInfo7.setName("Range[0.0,0.0]");
        java.lang.String str10 = projectInfo7.getName();
        java.lang.String str11 = projectInfo7.getLicenceName();
        projectInfo7.setInfo("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str14 = projectInfo7.toString();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        boolean boolean16 = ringPlot15.getIgnoreNullValues();
        ringPlot15.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot20 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot20);
        jFreeChart21.removeLegend();
        java.awt.image.BufferedImage bufferedImage25 = jFreeChart21.createBufferedImage(1900, (int) ' ');
        ringPlot15.setBackgroundImage((java.awt.Image) bufferedImage25);
        projectInfo7.setLogo((java.awt.Image) bufferedImage25);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Range[0.0,0.0]" + "'", str10.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Range[0.0,0.0] version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Range[0.0,0.0]:None\nRange[0.0,0.0] LICENCE TERMS:\n" + "'", str14.equals("Range[0.0,0.0] version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Range[0.0,0.0]:None\nRange[0.0,0.0] LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(bufferedImage25);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) itemLabelAnchor3);
        int int5 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 1.559372400008E12d, "RangeType.FULL", textAnchor2, textAnchor3, (-1.0d));
        java.lang.Number number6 = numberTick5.getNumber();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.559372400008E12d + "'", number6.equals(1.559372400008E12d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        java.awt.Shape shape7 = numberAxis1.getDownArrow();
        numberAxis1.setInverted(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ChartChangeEventType.NEW_DATASET", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setBaseCreateEntities(true);
        stackedAreaRenderer1.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image11, "hi!", "", "");
        java.lang.String str16 = projectInfo15.getCopyright();
        org.jfree.data.KeyedObject keyedObject17 = new org.jfree.data.KeyedObject((java.lang.Comparable) "Range[0.0,0.0]", (java.lang.Object) str16);
        boolean boolean18 = stackedAreaRenderer1.equals((java.lang.Object) str16);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        blockContainer0.setPadding(rectangleInsets2);
        java.lang.String str4 = blockContainer0.getID();
        blockContainer0.clear();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Color color1 = java.awt.Color.GREEN;
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color1, false);
        stackedBarRenderer3D0.setItemLabelAnchorOffset((double) 2);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer7.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        double double13 = ringPlot12.getInnerSeparatorExtension();
        java.awt.Paint paint14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot12.setLabelShadowPaint(paint14);
        stackedAreaRenderer7.setBaseOutlinePaint(paint14, false);
        stackedAreaRenderer7.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean21 = stackedAreaRenderer7.getSeriesVisible((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = stackedAreaRenderer7.getBaseNegativeItemLabelPosition();
        boolean boolean23 = stackedBarRenderer3D0.equals((java.lang.Object) itemLabelPosition22);
        org.jfree.chart.text.TextAnchor textAnchor24 = itemLabelPosition22.getTextAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        numberAxis1.centerRange((double) 1559372400000L);
        org.jfree.data.Range range11 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str12 = range11.toString();
        double double13 = range11.getCentralValue();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange(range11);
        java.util.Date date15 = dateRange14.getUpperDate();
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange14, (double) 0);
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange14);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Range[0.0,0.0]" + "'", str12.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) itemLabelAnchor3);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int6 = segmentedTimeline5.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot7);
        jFreeChart8.removeLegend();
        jFreeChart8.clearSubtitles();
        boolean boolean11 = segmentedTimeline5.equals((java.lang.Object) jFreeChart8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline5.getSegment(0L);
        segment13.dec((long) (short) 10);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) segment13);
        boolean boolean19 = segment13.contained((long) 100, (long) (byte) -1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(segment13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.lang.Object obj2 = dataPackageResources0.handleGetObject("hi!");
        java.util.Enumeration<java.lang.String> strEnumeration3 = dataPackageResources0.getKeys();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(strEnumeration3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getXOffset();
        boolean boolean2 = lineRenderer3D0.getBaseShapesFilled();
        boolean boolean3 = lineRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        int int4 = lineRenderer3D0.getPassCount();
        java.awt.Color color5 = java.awt.Color.gray;
        lineRenderer3D0.setBasePaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        java.lang.Boolean boolean13 = lineRenderer3D0.getSeriesLinesVisible((int) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot1.getFixedRangeAxisSpace();
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) categoryPlot1);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        boolean boolean7 = ringPlot6.getSectionOutlinesVisible();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getColumnKeys();
        int int11 = taskSeriesCollection8.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection8, comparable12);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) boolean7, (org.jfree.data.general.Dataset) taskSeriesCollection8);
        org.jfree.data.general.Dataset dataset15 = datasetChangeEvent14.getDataset();
        categoryPlot1.datasetChanged(datasetChangeEvent14);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertNotNull(dataset15);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        piePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.Plot plot3 = piePlot0.getRootPlot();
        piePlot0.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(plot3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.setAxisLineVisible(true);
        java.awt.Paint paint6 = categoryAxis2.getTickLabelPaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection7);
        int int10 = taskSeriesCollection7.indexOf((java.lang.Comparable) 255);
        boolean boolean11 = categoryAxis2.equals((java.lang.Object) 255);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        categoryAxis13.setAxisLineVisible(true);
        java.awt.Paint paint17 = categoryAxis13.getAxisLinePaint();
        java.awt.Font font18 = categoryAxis13.getLabelFont();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke26 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint20, stroke21, (java.awt.Paint) color25, stroke26, 1.0f);
        categoryAxis13.setTickMarkStroke(stroke21);
        categoryAxis2.setAxisLineStroke(stroke21);
        categoryAxis2.setTickMarkInsideLength(0.5f);
        boolean boolean33 = lengthAdjustmentType0.equals((java.lang.Object) 0.5f);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedAreaRenderer1.getPositiveItemLabelPosition((int) (short) 10, 1);
        boolean boolean6 = stackedAreaRenderer1.isSeriesItemLabelsVisible(5);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (short) 10);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D3.removeColumn((java.lang.Comparable) 1.559372400008E12d);
        boolean boolean6 = keyToGroupMap1.equals((java.lang.Object) 1.559372400008E12d);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date9 = dateAxis8.getMaximumDate();
        java.lang.Comparable comparable10 = keyToGroupMap1.getGroup((java.lang.Comparable) date9);
        java.lang.Object obj11 = keyToGroupMap1.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        categoryPlot0.setWeight((int) (short) 0);
        java.awt.Paint paint9 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation11, plotOrientation12);
        categoryPlot0.setRangeAxisLocation((int) '4', axisLocation11);
        java.awt.Stroke stroke15 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        boolean boolean7 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis1.setMinimumDate(date2);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
//        java.lang.String str5 = serialDate4.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate7 = serialDate4.getPreviousDayOfWeek(1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Image image3 = ringPlot1.getBackgroundImage();
        java.awt.Paint paint4 = ringPlot1.getBaseSectionPaint();
        boolean boolean6 = ringPlot1.equals((java.lang.Object) '4');
        int int7 = ringPlot1.getPieIndex();
        ringPlot1.setCircular(true, false);
        ringPlot1.setBackgroundImageAlignment((int) (byte) 1);
        java.awt.Paint paint14 = ringPlot1.getSectionOutlinePaint((java.lang.Comparable) 12.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        double double2 = blockContainer1.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        blockContainer1.setPadding(rectangleInsets3);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement7 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource5, (org.jfree.chart.block.Arrangement) columnArrangement6, (org.jfree.chart.block.Arrangement) centerArrangement7);
        org.jfree.chart.event.TitleChangeListener titleChangeListener9 = null;
        legendTitle8.removeChangeListener(titleChangeListener9);
        java.awt.Paint paint11 = legendTitle8.getBackgroundPaint();
        blockContainer1.add((org.jfree.chart.block.Block) legendTitle8);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.Range range17 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range20 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str21 = range20.toString();
        org.jfree.data.Range range22 = org.jfree.data.Range.combine(range17, range20);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) 1, range22);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = rectangleConstraint23.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D25 = flowArrangement0.arrange(blockContainer1, graphics2D13, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Range[0.0,0.0]" + "'", str21.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedAreaRenderer5.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double9 = itemLabelPosition8.getAngle();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition8);
        statisticalBarRenderer0.setIncludeBaseInRange(true);
        boolean boolean13 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = statisticalBarRenderer0.getItemLabelGenerator((int) (short) 10, 7);
        java.awt.Font font17 = statisticalBarRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        java.lang.Object obj9 = lineRenderer3D0.clone();
        java.awt.Font font10 = lineRenderer3D0.getBaseItemLabelFont();
        lineRenderer3D0.setDrawOutlines(true);
        lineRenderer3D0.setBaseShapesVisible(true);
        double double15 = lineRenderer3D0.getYOffset();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.setAxisLineVisible(true);
        java.awt.Paint paint7 = categoryAxis3.getAxisLinePaint();
        stackedAreaRenderer1.setBaseOutlinePaint(paint7);
        stackedAreaRenderer1.setRenderAsPercentages(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = stackedAreaRenderer1.getBaseURLGenerator();
        stackedAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryURLGenerator11);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockFrame blockFrame1 = blockContainer0.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        blockContainer0.setPadding(rectangleInsets2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) 'a');
        ringPlot4.setForegroundAlpha((float) (short) -1);
        ringPlot4.setSectionDepth((double) 255);
        ringPlot4.setSectionOutlinesVisible(false);
        java.awt.Paint paint13 = ringPlot4.getSeparatorPaint();
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(rectangleInsets2, paint13);
        org.junit.Assert.assertNotNull(blockFrame1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int3 = defaultKeyedValues2D2.getRowCount();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getEnd();
        int int6 = defaultKeyedValues2D2.getColumnIndex((java.lang.Comparable) date5);
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("2019", date5, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        int int12 = lineRenderer3D0.getPassCount();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = ringPlot14.getSectionOutlinesVisible();
        double double16 = ringPlot14.getShadowXOffset();
        boolean boolean17 = lineRenderer3D0.equals((java.lang.Object) ringPlot14);
        ringPlot14.setNoDataMessage("");
        int int20 = ringPlot14.getPieIndex();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        ringPlot1.setDataset(pieDataset4);
        boolean boolean6 = ringPlot1.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Color color7 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint11 = statisticalBarRenderer8.getItemFillPaint(0, (int) '#');
        java.awt.Stroke stroke13 = statisticalBarRenderer8.lookupSeriesOutlineStroke(0);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 1, (java.awt.Paint) color7, stroke13);
        stackedAreaRenderer3.setSeriesPaint(0, (java.awt.Paint) color7, false);
        float[] floatArray23 = new float[] { 205, 1560668399999L, 6, 4, 7, (short) 1 };
        float[] floatArray24 = color7.getColorComponents(floatArray23);
        float[] floatArray25 = java.awt.Color.RGBtoHSB(15, (int) (short) 1, 2, floatArray24);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedAreaRenderer1.getPositiveItemLabelPosition((int) (short) 10, 1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        stackedAreaRenderer1.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = stackedAreaRenderer1.getItemLabelGenerator((int) (short) 1, (-1));
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        boolean boolean12 = stackedAreaRenderer1.equals((java.lang.Object) "TextAnchor.CENTER");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets13.getUnitType();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer15 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke18 = categoryAxis17.getTickMarkStroke();
        categoryAxis17.setAxisLineVisible(true);
        java.awt.Paint paint21 = categoryAxis17.getTickLabelPaint();
        levelRenderer15.setBaseItemLabelPaint(paint21, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator24 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        levelRenderer15.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator24);
        boolean boolean26 = unitType14.equals((java.lang.Object) standardCategorySeriesLabelGenerator24);
        stackedAreaRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator24);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer2 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke5 = categoryAxis4.getTickMarkStroke();
        categoryAxis4.setAxisLineVisible(true);
        java.awt.Paint paint8 = categoryAxis4.getTickLabelPaint();
        levelRenderer2.setBaseItemLabelPaint(paint8, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        levelRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator11);
        boolean boolean13 = unitType1.equals((java.lang.Object) standardCategorySeriesLabelGenerator11);
        java.lang.String str14 = unitType1.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UnitType.ABSOLUTE" + "'", str14.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration2 = dataPackageResources0.getKeys();
        java.lang.Object obj4 = dataPackageResources0.handleGetObject("ChartChangeEventType.NEW_DATASET");
        try {
            java.lang.Object obj6 = dataPackageResources0.getObject("poly");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key poly");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strEnumeration2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(tickUnitSource2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        java.awt.Paint paint10 = categoryMarker9.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker9);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryMarker9.setLabelOffset(rectangleInsets12);
        double double15 = rectangleInsets12.calculateLeftOutset((double) 12);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseSeriesVisibleInLegend(false);
        java.awt.Paint paint3 = ganttRenderer0.getCompletePaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-459), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        chartEntity1.setToolTipText("hi!");
        java.lang.String str4 = chartEntity1.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        jFreeChart1.removeLegend();
        jFreeChart1.setTextAntiAlias(true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        int int16 = color11.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font9, (java.awt.Paint) color11);
        java.awt.Paint paint18 = labelBlock17.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = labelBlock17.getPadding();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) '#');
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color7);
        lineRenderer3D2.setWallPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = lineRenderer3D2.getBaseToolTipGenerator();
        java.lang.Object obj11 = lineRenderer3D2.clone();
        java.awt.Font font12 = lineRenderer3D2.getBaseItemLabelFont();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        boolean boolean14 = lineRenderer3D2.equals((java.lang.Object) standardCategorySeriesLabelGenerator13);
        boolean boolean17 = lineRenderer3D2.getItemShapeVisible(0, 1900);
        boolean boolean18 = stackedAreaRenderer1.equals((java.lang.Object) 1900);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
//        jFreeChart3.removeLegend();
//        jFreeChart3.clearSubtitles();
//        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long8 = segmentedTimeline0.getTime(date7);
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.util.Date date11 = month10.getEnd();
//        boolean boolean12 = segmentedTimeline0.containsDomainRange(date9, date11);
//        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
//        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        org.jfree.chart.axis.NumberTick numberTick19 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0f, "Range[0.0,0.0]", textAnchor16, textAnchor17, (double) 10);
//        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.CENTER;
//        org.jfree.chart.axis.DateTick dateTick22 = new org.jfree.chart.axis.DateTick(date9, "255", textAnchor16, textAnchor20, 8.0d);
//        java.util.Date date23 = dateTick22.getDate();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560179855055L + "'", long8 == 1560179855055L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(textAnchor16);
//        org.junit.Assert.assertNotNull(textAnchor17);
//        org.junit.Assert.assertNotNull(textAnchor20);
//        org.junit.Assert.assertNotNull(date23);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        categoryAxis1.setLowerMargin(4.0d);
        categoryAxis1.setCategoryMargin(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        int int2 = stackedBarRenderer1.getPassCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis2.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis2.setMarkerBand(markerAxisBand5);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        java.awt.Font font8 = numberAxis2.getTickLabelFont();
        boolean boolean9 = shapeList0.equals((java.lang.Object) numberAxis2);
        java.awt.Shape shape10 = numberAxis2.getUpArrow();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "Range[0.0,0.0]", "2019");
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedAreaRenderer5.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double9 = itemLabelPosition8.getAngle();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition8);
        statisticalBarRenderer0.setIncludeBaseInRange(true);
        boolean boolean13 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Stroke stroke14 = statisticalBarRenderer0.getBaseStroke();
        double double15 = statisticalBarRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image3, "hi!", "", "");
        projectInfo7.setName("Range[0.0,0.0]");
        java.awt.Image image10 = projectInfo7.getLogo();
        java.lang.String str11 = projectInfo7.toString();
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Range[0.0,0.0] version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Range[0.0,0.0]:None\nRange[0.0,0.0] LICENCE TERMS:\n" + "'", str11.equals("Range[0.0,0.0] version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Range[0.0,0.0]:None\nRange[0.0,0.0] LICENCE TERMS:\n"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot3D0.setBaseSectionOutlineStroke(stroke1);
        java.lang.String str3 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie 3D Plot" + "'", str3.equals("Pie 3D Plot"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint2 = lineBorder1.getPaint();
        java.awt.Stroke stroke3 = lineBorder1.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint8, stroke9, (java.awt.Paint) color13, stroke14, 1.0f);
        java.awt.Paint paint17 = categoryMarker16.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker16);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryMarker16.setLabelOffset(rectangleInsets19);
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker16, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = lineRenderer3D0.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setDomainAxisLocation(1900, axisLocation16);
        java.awt.Stroke stroke18 = categoryPlot14.getRangeCrosshairStroke();
        categoryPlot14.setAnchorValue((double) 1560179855055L);
        int int21 = categoryPlot14.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis23.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = numberAxis23.getMarkerBand();
        java.awt.Shape shape27 = numberAxis23.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        lineRenderer3D0.drawRangeGridline(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) numberAxis23, rectangle2D28, (double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis32.setMinimumDate(date33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date33);
        java.lang.String str36 = serialDate35.getDescription();
        boolean boolean37 = categoryPlot14.equals((java.lang.Object) serialDate35);
        org.jfree.chart.axis.AxisSpace axisSpace38 = categoryPlot14.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(markerAxisBand26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(axisSpace38);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        double double6 = ringPlot5.getInnerSeparatorExtension();
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot5.setLabelShadowPaint(paint7);
        ringPlot5.setShadowXOffset(0.2d);
        java.awt.Stroke stroke11 = ringPlot5.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        double double19 = ringPlot18.getInnerSeparatorExtension();
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot18.setLabelShadowPaint(paint20);
        stackedAreaRenderer13.setBaseOutlinePaint(paint20, false);
        ringPlot5.setNoDataMessagePaint(paint20);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot5.setLegendItemShape(shape25);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        stackedAreaRenderer28.setBaseOutlinePaint(paint34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer28.setBasePaint((java.awt.Paint) color36, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint42 = statisticalBarRenderer39.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer44 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedAreaRenderer44.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double48 = itemLabelPosition47.getAngle();
        statisticalBarRenderer39.setBasePositiveItemLabelPosition(itemLabelPosition47);
        statisticalBarRenderer39.setIncludeBaseInRange(true);
        boolean boolean52 = statisticalBarRenderer39.getBaseSeriesVisible();
        java.awt.Stroke stroke53 = statisticalBarRenderer39.getBaseStroke();
        java.awt.Font font57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke60 = categoryAxis59.getTickMarkStroke();
        categoryAxis59.setAxisLineVisible(true);
        java.awt.Paint paint63 = categoryAxis59.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock64 = org.jfree.chart.text.TextUtilities.createTextBlock("", font57, paint63);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint68 = statisticalBarRenderer65.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock69 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font57, paint68);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer70 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint73 = statisticalBarRenderer70.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer70.setMinimumBarLength((double) (short) 100);
        java.awt.Color color78 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke81 = categoryAxis80.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color78, stroke81);
        statisticalBarRenderer70.setSeriesPaint((int) '4', (java.awt.Paint) color78);
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font57, (java.awt.Paint) color78);
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("WMAP_Plot", "CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP", "{0}", "30-June-2019", shape25, (java.awt.Paint) color36, stroke53, (java.awt.Paint) color78);
        java.awt.Shape shape86 = legendItem85.getShape();
        java.awt.Stroke stroke87 = legendItem85.getLineStroke();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(textBlock64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(textBlock69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(shape86);
        org.junit.Assert.assertNotNull(stroke87);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint4 = statisticalBarRenderer1.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer1.setMinimumBarLength((double) (short) 100);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke12);
        statisticalBarRenderer1.setSeriesPaint((int) '4', (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D16 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, (java.awt.Paint) color21);
        lineRenderer3D16.setWallPaint((java.awt.Paint) color21);
        statisticalBarRenderer1.setSeriesPaint(0, (java.awt.Paint) color21, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = statisticalBarRenderer1.getPlot();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = chartRenderingInfo30.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = chartRenderingInfo32.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        plotRenderingInfo33.setPlotArea(rectangle2D34);
        plotRenderingInfo31.addSubplotInfo(plotRenderingInfo33);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis38.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = null;
        numberAxis38.setMarkerBand(markerAxisBand41);
        boolean boolean43 = plotRenderingInfo31.equals((java.lang.Object) markerAxisBand41);
        java.awt.geom.Rectangle2D rectangle2D44 = plotRenderingInfo31.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = null;
        java.awt.geom.Point2D point2D47 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D45, rectangleAnchor46);
        categoryPlot0.zoomDomainAxes((double) '4', 10.0d, plotRenderingInfo31, point2D47);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection50 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number51 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection50);
        categoryPlot0.setDataset(1900, (org.jfree.data.category.CategoryDataset) taskSeriesCollection50);
        org.jfree.data.Range range55 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.time.DateRange dateRange56 = new org.jfree.data.time.DateRange(range55);
        java.util.Date date57 = dateRange56.getLowerDate();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        java.lang.String str59 = year58.toString();
        try {
            java.lang.Number number61 = taskSeriesCollection50.getPercentComplete((java.lang.Comparable) date57, (java.lang.Comparable) str59, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(categoryPlot26);
        org.junit.Assert.assertNotNull(plotRenderingInfo31);
        org.junit.Assert.assertNotNull(plotRenderingInfo33);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(rectangle2D44);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 0.0d + "'", number51.equals(0.0d));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2019" + "'", str59.equals("2019"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend((-1));
        stackedBarRenderer3D0.setBase((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedAreaRenderer1.getPositiveItemLabelPosition((int) (short) 10, 1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        stackedAreaRenderer1.notifyListeners(rendererChangeEvent5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        double double9 = ringPlot8.getInnerSeparatorExtension();
        java.awt.Image image10 = ringPlot8.getBackgroundImage();
        java.awt.Paint paint11 = ringPlot8.getBaseSectionPaint();
        stackedAreaRenderer1.setBaseItemLabelPaint(paint11, false);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis15.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = numberAxis15.getMarkerBand();
        numberAxis15.resizeRange((double) (-459), (double) 255);
        boolean boolean22 = stackedAreaRenderer1.equals((java.lang.Object) numberAxis15);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(markerAxisBand18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Image image3 = ringPlot1.getBackgroundImage();
        java.awt.Font font4 = ringPlot1.getLabelFont();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range5 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str6 = range5.toString();
        org.jfree.data.Range range7 = org.jfree.data.Range.combine(range2, range5);
        boolean boolean10 = range7.intersects((double) 255, 8.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Range[0.0,0.0]" + "'", str6.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Pie 3D Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline0.getSegment(date5);
        java.util.List list7 = segmentedTimeline0.getExceptionSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer1.getPadding();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer6.setBaseCreateEntities(true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        boolean boolean13 = ringPlot12.getSectionOutlinesVisible();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection14 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list15 = taskSeriesCollection14.getColumnKeys();
        int int17 = taskSeriesCollection14.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable18 = null;
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection14, comparable18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) boolean13, (org.jfree.data.general.Dataset) taskSeriesCollection14);
        multiplePiePlot9.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        org.jfree.data.Range range22 = stackedAreaRenderer6.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection14);
        org.jfree.data.Range range26 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str27 = range26.toString();
        double double28 = range26.getCentralValue();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange(range26);
        java.util.Date date30 = dateRange29.getUpperDate();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint35 = statisticalBarRenderer32.getItemFillPaint(0, (int) '#');
        boolean boolean36 = lengthConstraintType31.equals((java.lang.Object) 0);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis39.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis39.setMarkerBand(markerAxisBand42);
        org.jfree.data.Range range44 = numberAxis39.getDefaultAutoRange();
        boolean boolean45 = numberAxis39.isAutoRange();
        numberAxis39.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range48 = numberAxis39.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType49 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange29, lengthConstraintType31, 0.0d, range48, lengthConstraintType49);
        org.jfree.data.Range range54 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.time.DateRange dateRange55 = new org.jfree.data.time.DateRange(range54);
        java.util.Date date56 = dateRange55.getLowerDate();
        org.jfree.data.Range range60 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range63 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str64 = range63.toString();
        org.jfree.data.Range range65 = org.jfree.data.Range.combine(range60, range63);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = new org.jfree.chart.block.RectangleConstraint((double) 1, range65);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType67 = rectangleConstraint66.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = new org.jfree.chart.block.RectangleConstraint(0.0d, range22, lengthConstraintType49, (double) 7, (org.jfree.data.Range) dateRange55, lengthConstraintType67);
        org.jfree.chart.util.Size2D size2D69 = flowArrangement0.arrange(blockContainer1, graphics2D3, rectangleConstraint68);
        size2D69.width = 10;
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Range[0.0,0.0]" + "'", str27.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(lengthConstraintType49);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Range[0.0,0.0]" + "'", str64.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertNotNull(lengthConstraintType67);
        org.junit.Assert.assertNotNull(size2D69);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1560179855055L, 100.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getFirstTextFragment();
        org.junit.Assert.assertNull(textFragment1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = statisticalBarRenderer0.getSeriesToolTipGenerator(100);
        boolean boolean5 = statisticalBarRenderer0.isSeriesItemLabelsVisible((-571));
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean4 = ringPlot2.equals((java.lang.Object) 'a');
        java.awt.Paint paint6 = null;
        ringPlot2.setSectionOutlinePaint((java.lang.Comparable) 'a', paint6);
        ringPlot2.setPieIndex((int) ' ');
        java.awt.Font font10 = ringPlot2.getLabelFont();
        java.awt.Color color12 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke15 = categoryAxis14.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        int int17 = color12.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font10, (java.awt.Paint) color12);
        java.awt.Font font19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        labelBlock18.setFont(font19);
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke28 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint22, stroke23, (java.awt.Paint) color27, stroke28, 1.0f);
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font19, (java.awt.Paint) color27);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment33 = null;
        textLine32.removeFragment(textFragment33);
        textBlock31.addLine(textLine32);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(textBlock31);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        java.awt.Color color2 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke5 = categoryAxis4.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color2, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        valueMarker6.notifyListeners(markerChangeEvent7);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER;
        valueMarker6.setLabelTextAnchor(textAnchor9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor9);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer1.getFrame();
        double double3 = blockContainer1.getContentYOffset();
        double double4 = blockContainer1.getContentXOffset();
        blockContainer1.setHeight((double) 1560668399999L);
        boolean boolean7 = categoryLabelPositions0.equals((java.lang.Object) 1560668399999L);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        jFreeChart1.removeLegend();
        jFreeChart1.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart1.getLegend(3);
        java.awt.Paint paint6 = jFreeChart1.getBackgroundPaint();
        org.junit.Assert.assertNull(legendTitle5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.setAxisLineVisible(true);
        java.awt.Paint paint7 = categoryAxis3.getAxisLinePaint();
        stackedAreaRenderer1.setBaseOutlinePaint(paint7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color9, false);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        double double14 = ringPlot13.getInnerSeparatorExtension();
        java.awt.Paint paint15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot13.setLabelShadowPaint(paint15);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot17);
        jFreeChart18.removeLegend();
        jFreeChart18.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart18.getLegend(3);
        ringPlot13.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart18);
        boolean boolean24 = stackedAreaRenderer1.equals((java.lang.Object) jFreeChart18);
        try {
            java.awt.image.BufferedImage bufferedImage27 = jFreeChart18.createBufferedImage(0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (5) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(legendTitle22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSectionOutlinesVisible();
        double double3 = ringPlot1.getOuterSeparatorExtension();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        chartEntity1.setToolTipText("hi!");
        java.awt.Shape shape4 = chartEntity1.getArea();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, 12.0d, (float) 500, (float) 10);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list2 = taskSeriesCollection1.getColumnKeys();
        int int4 = taskSeriesCollection1.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection1, comparable5);
        double double7 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset6);
        boolean boolean8 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) pieDataset6);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D9 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color14);
        lineRenderer3D9.setWallPaint((java.awt.Paint) color14);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = lineRenderer3D9.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem20 = lineRenderer3D9.getLegendItem(10, 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator21 = lineRenderer3D9.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot23.setDomainAxisLocation(1900, axisLocation25);
        java.awt.Stroke stroke27 = categoryPlot23.getRangeCrosshairStroke();
        categoryPlot23.setAnchorValue((double) 1560179855055L);
        int int30 = categoryPlot23.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis32.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = numberAxis32.getMarkerBand();
        java.awt.Shape shape36 = numberAxis32.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        lineRenderer3D9.drawRangeGridline(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis32, rectangle2D37, (double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date42 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis41.setMinimumDate(date42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date42);
        java.lang.String str45 = serialDate44.getDescription();
        boolean boolean46 = categoryPlot23.equals((java.lang.Object) serialDate44);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline47 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int48 = segmentedTimeline47.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot49 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot49);
        jFreeChart50.removeLegend();
        jFreeChart50.clearSubtitles();
        boolean boolean53 = segmentedTimeline47.equals((java.lang.Object) jFreeChart50);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment55 = segmentedTimeline47.getSegment(0L);
        segment55.dec((long) (short) 10);
        java.lang.Number number58 = defaultBoxAndWhiskerCategoryDataset0.getMinOutlier((java.lang.Comparable) boolean46, (java.lang.Comparable) (short) 10);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(markerAxisBand35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 7 + "'", int48 == 7);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(segment55);
        org.junit.Assert.assertNull(number58);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearRangeMarkers(15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        plotRenderingInfo6.setPlotArea(rectangle2D7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        plotRenderingInfo6.setDataArea(rectangle2D9);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo12.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        plotRenderingInfo15.setPlotArea(rectangle2D16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo15);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis20.setMarkerBand(markerAxisBand23);
        boolean boolean25 = plotRenderingInfo13.equals((java.lang.Object) markerAxisBand23);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo13.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str28 = rectangleAnchor27.toString();
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        xYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D29);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot0.getDomainMarkers((int) (byte) 0, layer32);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleAnchor.TOP" + "'", str28.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(collection33);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo2.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        plotRenderingInfo3.setPlotArea(rectangle2D4);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo3);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis8.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis8.setMarkerBand(markerAxisBand11);
        boolean boolean13 = plotRenderingInfo1.equals((java.lang.Object) markerAxisBand11);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo1.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str16 = rectangleAnchor15.toString();
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D14, rectangleAnchor15);
        java.io.ObjectOutputStream objectOutputStream18 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D17, objectOutputStream18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleAnchor.TOP" + "'", str16.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D17);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot0.getDomainMarkers((int) ' ', layer10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot0.getLegendItems();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer13.setAutoPopulateSeriesStroke(true);
        boolean boolean16 = legendItemCollection12.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        java.awt.Paint paint4 = null;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 'a', paint4);
        ringPlot0.setPieIndex((int) ' ');
        ringPlot0.setLabelGap((double) (-1L));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        ringPlot0.notifyListeners(plotChangeEvent10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
//        jFreeChart3.removeLegend();
//        jFreeChart3.clearSubtitles();
//        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline0.getSegment(0L);
//        segment8.dec((long) (short) 10);
//        boolean boolean11 = segment8.inExcludeSegments();
//        long long12 = segment8.getMillisecond();
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segment8.copy();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(segment8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-864000000L) + "'", long12 == (-864000000L));
//        org.junit.Assert.assertNotNull(segment13);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearAnnotations();
        boolean boolean3 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getDomainTickBandPaint();
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        boolean boolean6 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = new org.jfree.chart.axis.AxisState();
        axisState5.setCursor((double) 3600000L);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D8, rectangleEdge9);
        numberAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer1 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer1.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = levelRenderer1.getBaseURLGenerator();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator9 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "RectangleAnchor.TOP", "hi!");
        levelRenderer1.setSeriesURLGenerator(6, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        levelRenderer1.setBaseItemLabelGenerator(categoryItemLabelGenerator11, true);
        boolean boolean14 = rectangleAnchor0.equals((java.lang.Object) categoryItemLabelGenerator11);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearAnnotations();
        boolean boolean3 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getDomainTickBandPaint();
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        xYPlot0.setDomainCrosshairValue((double) (short) 0);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        double double6 = ringPlot5.getInnerSeparatorExtension();
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot5.setLabelShadowPaint(paint7);
        ringPlot5.setShadowXOffset(0.2d);
        java.awt.Stroke stroke11 = ringPlot5.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        double double19 = ringPlot18.getInnerSeparatorExtension();
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot18.setLabelShadowPaint(paint20);
        stackedAreaRenderer13.setBaseOutlinePaint(paint20, false);
        ringPlot5.setNoDataMessagePaint(paint20);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot5.setLegendItemShape(shape25);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        stackedAreaRenderer28.setBaseOutlinePaint(paint34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer28.setBasePaint((java.awt.Paint) color36, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint42 = statisticalBarRenderer39.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer44 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedAreaRenderer44.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double48 = itemLabelPosition47.getAngle();
        statisticalBarRenderer39.setBasePositiveItemLabelPosition(itemLabelPosition47);
        statisticalBarRenderer39.setIncludeBaseInRange(true);
        boolean boolean52 = statisticalBarRenderer39.getBaseSeriesVisible();
        java.awt.Stroke stroke53 = statisticalBarRenderer39.getBaseStroke();
        java.awt.Font font57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke60 = categoryAxis59.getTickMarkStroke();
        categoryAxis59.setAxisLineVisible(true);
        java.awt.Paint paint63 = categoryAxis59.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock64 = org.jfree.chart.text.TextUtilities.createTextBlock("", font57, paint63);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint68 = statisticalBarRenderer65.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock69 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font57, paint68);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer70 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint73 = statisticalBarRenderer70.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer70.setMinimumBarLength((double) (short) 100);
        java.awt.Color color78 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke81 = categoryAxis80.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color78, stroke81);
        statisticalBarRenderer70.setSeriesPaint((int) '4', (java.awt.Paint) color78);
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font57, (java.awt.Paint) color78);
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("WMAP_Plot", "CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP", "{0}", "30-June-2019", shape25, (java.awt.Paint) color36, stroke53, (java.awt.Paint) color78);
        java.lang.Class<?> wildcardClass86 = color36.getClass();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(textBlock64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(textBlock69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(wildcardClass86);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        java.lang.Object obj5 = stackedAreaRenderer1.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 100.0f, 1.559372400008E12d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        double double6 = ringPlot5.getInnerSeparatorExtension();
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot5.setLabelShadowPaint(paint7);
        ringPlot5.setShadowXOffset(0.2d);
        java.awt.Stroke stroke11 = ringPlot5.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        double double19 = ringPlot18.getInnerSeparatorExtension();
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot18.setLabelShadowPaint(paint20);
        stackedAreaRenderer13.setBaseOutlinePaint(paint20, false);
        ringPlot5.setNoDataMessagePaint(paint20);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot5.setLegendItemShape(shape25);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        stackedAreaRenderer28.setBaseOutlinePaint(paint34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer28.setBasePaint((java.awt.Paint) color36, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint42 = statisticalBarRenderer39.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer44 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedAreaRenderer44.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double48 = itemLabelPosition47.getAngle();
        statisticalBarRenderer39.setBasePositiveItemLabelPosition(itemLabelPosition47);
        statisticalBarRenderer39.setIncludeBaseInRange(true);
        boolean boolean52 = statisticalBarRenderer39.getBaseSeriesVisible();
        java.awt.Stroke stroke53 = statisticalBarRenderer39.getBaseStroke();
        java.awt.Font font57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke60 = categoryAxis59.getTickMarkStroke();
        categoryAxis59.setAxisLineVisible(true);
        java.awt.Paint paint63 = categoryAxis59.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock64 = org.jfree.chart.text.TextUtilities.createTextBlock("", font57, paint63);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint68 = statisticalBarRenderer65.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock69 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font57, paint68);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer70 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint73 = statisticalBarRenderer70.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer70.setMinimumBarLength((double) (short) 100);
        java.awt.Color color78 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke81 = categoryAxis80.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color78, stroke81);
        statisticalBarRenderer70.setSeriesPaint((int) '4', (java.awt.Paint) color78);
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font57, (java.awt.Paint) color78);
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("WMAP_Plot", "CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP", "{0}", "30-June-2019", shape25, (java.awt.Paint) color36, stroke53, (java.awt.Paint) color78);
        java.awt.Stroke stroke86 = legendItem85.getOutlineStroke();
        org.jfree.data.general.Dataset dataset87 = legendItem85.getDataset();
        java.lang.Comparable comparable88 = legendItem85.getSeriesKey();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(textBlock64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(textBlock69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNull(dataset87);
        org.junit.Assert.assertNull(comparable88);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        java.awt.Paint paint10 = categoryMarker9.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker9);
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke19 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint13, stroke14, (java.awt.Paint) color18, stroke19, 1.0f);
        java.awt.Paint paint22 = categoryMarker21.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.chart.plot.Marker marker24 = markerChangeEvent23.getMarker();
        org.jfree.chart.plot.Marker marker25 = markerChangeEvent23.getMarker();
        org.jfree.chart.JFreeChart jFreeChart26 = markerChangeEvent23.getChart();
        categoryMarker9.notifyListeners(markerChangeEvent23);
        java.awt.Stroke stroke28 = categoryMarker9.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(marker24);
        org.junit.Assert.assertNotNull(marker25);
        org.junit.Assert.assertNull(jFreeChart26);
        org.junit.Assert.assertNull(stroke28);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        int int12 = lineRenderer3D0.getPassCount();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = ringPlot14.getSectionOutlinesVisible();
        double double16 = ringPlot14.getShadowXOffset();
        boolean boolean17 = lineRenderer3D0.equals((java.lang.Object) ringPlot14);
        boolean boolean20 = lineRenderer3D0.getItemShapeFilled(100, 3);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer23 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = stackedAreaRenderer23.getPositiveItemLabelPosition((int) (short) 10, 1);
        try {
            lineRenderer3D0.setSeriesNegativeItemLabelPosition((-459), itemLabelPosition26, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        dateAxis1.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer7.setBaseSeriesVisibleInLegend(false);
        ganttRenderer7.setEndPercent((double) 205);
        boolean boolean12 = dateAxis1.equals((java.lang.Object) 205);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 100, (double) 10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        plotRenderingInfo6.setPlotArea(rectangle2D7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        plotRenderingInfo6.setDataArea(rectangle2D9);
        boolean boolean11 = columnArrangement4.equals((java.lang.Object) rectangle2D9);
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis10.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis10.setMarkerBand(markerAxisBand13);
        org.jfree.data.Range range15 = numberAxis10.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis10.getTickUnit();
        categoryPlot0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis10);
        numberAxis10.zoomRange(0.0d, 3600000.0d);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(numberTickUnit16);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        java.awt.Shape shape5 = numberAxis1.getDownArrow();
        org.jfree.data.Range range8 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range11 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range14 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str15 = range14.toString();
        org.jfree.data.Range range16 = org.jfree.data.Range.combine(range11, range14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(range8, range14);
        numberAxis1.setDefaultAutoRange(range8);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Range[0.0,0.0]" + "'", str15.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range16);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis2.setMinimumDate(date3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str6 = serialDate5.toString();
//        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis8.setMinimumDate(date9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
//        org.jfree.data.time.SerialDate serialDate12 = serialDate5.getEndOfCurrentMonth(serialDate11);
//        try {
//            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) '4', serialDate5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image4, "hi!", "", "");
        java.lang.String str9 = projectInfo8.getCopyright();
        org.jfree.data.KeyedObject keyedObject10 = new org.jfree.data.KeyedObject((java.lang.Comparable) "Range[0.0,0.0]", (java.lang.Object) str9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection19 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list20 = taskSeriesCollection19.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem21 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 5, (java.lang.Number) 1.0f, (java.lang.Number) 100, (java.lang.Number) 1.0E-8d, (java.lang.Number) 0.4d, (java.lang.Number) 2, (java.lang.Number) (-459), (java.lang.Number) (byte) 10, list20);
        java.lang.Number number22 = boxAndWhiskerItem21.getMaxRegularValue();
        org.jfree.chart.ui.ProjectInfo projectInfo23 = new org.jfree.chart.ui.ProjectInfo();
        boolean boolean24 = boxAndWhiskerItem21.equals((java.lang.Object) projectInfo23);
        boolean boolean25 = keyedObject10.equals((java.lang.Object) projectInfo23);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 2 + "'", number22.equals(2));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        java.awt.Paint paint4 = null;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 'a', paint4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke8 = categoryAxis7.getTickMarkStroke();
        categoryAxis7.setAxisLineVisible(true);
        java.awt.Paint paint11 = categoryAxis7.getAxisLinePaint();
        java.awt.Font font12 = categoryAxis7.getLabelFont();
        ringPlot0.setLabelFont(font12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Color color15 = java.awt.Color.blue;
        ringPlot0.setShadowPaint((java.awt.Paint) color15);
        ringPlot0.setCircular(false);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot(pieDataset19);
        ringPlot20.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        ringPlot20.setDataset(pieDataset23);
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot20.setBackgroundPaint(paint25);
        ringPlot0.setLabelBackgroundPaint(paint25);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        int int5 = stackedAreaRenderer1.getPassCount();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = chartRenderingInfo7.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        plotRenderingInfo8.setPlotArea(rectangle2D9);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        plotRenderingInfo8.setDataArea(rectangle2D11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo8);
        double double14 = categoryItemRendererState13.getBarWidth();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo15.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = chartRenderingInfo17.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        plotRenderingInfo18.setPlotArea(rectangle2D19);
        plotRenderingInfo16.addSubplotInfo(plotRenderingInfo18);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis23.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis23.setMarkerBand(markerAxisBand26);
        boolean boolean28 = plotRenderingInfo16.equals((java.lang.Object) markerAxisBand26);
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo16.getDataArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot30.setDomainAxisLocation(1900, axisLocation32);
        java.awt.Stroke stroke34 = categoryPlot30.getRangeCrosshairStroke();
        categoryPlot30.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder37 = categoryPlot30.getColumnRenderingOrder();
        java.awt.Stroke stroke38 = categoryPlot30.getOutlineStroke();
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = categoryPlot30.getDomainMarkers((int) ' ', layer40);
        int int42 = categoryPlot30.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke45 = categoryAxis44.getTickMarkStroke();
        categoryAxis44.setAxisLineVisible(true);
        java.awt.Paint paint48 = categoryAxis44.getTickLabelPaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection49 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number50 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection49);
        int int52 = taskSeriesCollection49.indexOf((java.lang.Comparable) 255);
        boolean boolean53 = categoryAxis44.equals((java.lang.Object) 255);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke56 = categoryAxis55.getTickMarkStroke();
        categoryAxis55.setAxisLineVisible(true);
        java.awt.Paint paint59 = categoryAxis55.getAxisLinePaint();
        java.awt.Font font60 = categoryAxis55.getLabelFont();
        java.awt.Paint paint62 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke63 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color67 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke68 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker70 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint62, stroke63, (java.awt.Paint) color67, stroke68, 1.0f);
        categoryAxis55.setTickMarkStroke(stroke63);
        categoryAxis44.setAxisLineStroke(stroke63);
        org.jfree.chart.axis.NumberAxis numberAxis74 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis74.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand77 = null;
        numberAxis74.setMarkerBand(markerAxisBand77);
        org.jfree.data.Range range79 = numberAxis74.getDefaultAutoRange();
        java.awt.Shape shape80 = numberAxis74.getDownArrow();
        org.jfree.data.category.CategoryDataset categoryDataset81 = null;
        try {
            stackedAreaRenderer1.drawItem(graphics2D6, categoryItemRendererState13, rectangle2D29, categoryPlot30, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis74, categoryDataset81, (int) '4', (-459), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(plotRenderingInfo8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertNotNull(plotRenderingInfo18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(sortOrder37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(number50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertNotNull(shape80);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        plotRenderingInfo1.setPlotArea(rectangle2D2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        plotRenderingInfo1.setDataArea(rectangle2D4);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        double double7 = categoryItemRendererState6.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection8 = categoryItemRendererState6.getEntityCollection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(1900, axisLocation12);
        java.awt.Stroke stroke14 = categoryPlot10.getRangeCrosshairStroke();
        categoryPlot10.setAnchorValue((double) 1560179855055L);
        categoryPlot10.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot10.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot10.getRangeAxisLocation(100);
        boolean boolean22 = categoryPlot10.isRangeCrosshairLockedOnData();
        java.awt.Paint paint23 = categoryPlot10.getRangeCrosshairPaint();
        boolean boolean24 = chartRenderingInfo9.equals((java.lang.Object) paint23);
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RangeType.FULL");
        taskSeries1.fireSeriesChanged();
        java.lang.Comparable comparable3 = taskSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "RangeType.FULL" + "'", comparable3.equals("RangeType.FULL"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, 100.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration2 = dataPackageResources0.getKeys();
        java.lang.Object obj4 = dataPackageResources0.handleGetObject("ChartChangeEventType.NEW_DATASET");
        java.lang.Object[][] objArray5 = dataPackageResources0.getContents();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strEnumeration2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke8 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint2, stroke3, (java.awt.Paint) color7, stroke8, 1.0f);
        java.awt.Paint paint11 = categoryMarker10.getOutlinePaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo12.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        plotRenderingInfo13.setPlotArea(rectangle2D14);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        plotRenderingInfo13.setDataArea(rectangle2D16);
        boolean boolean18 = categoryMarker10.equals((java.lang.Object) rectangle2D16);
        java.lang.Comparable comparable19 = categoryMarker10.getKey();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = categoryMarker10.getLabelAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str22 = textBlockAnchor21.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor20, textBlockAnchor21);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType24 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor21, categoryLabelWidthType24, (float) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 0.2d + "'", comparable19.equals(0.2d));
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str22.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.NEGATIVE" + "'", str1.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        double double4 = ringPlot3.getInnerSeparatorExtension();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot3.setLabelShadowPaint(paint5);
        ringPlot3.setShadowXOffset(0.2d);
        java.awt.Stroke stroke9 = ringPlot3.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer11.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot(pieDataset15);
        double double17 = ringPlot16.getInnerSeparatorExtension();
        java.awt.Paint paint18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setLabelShadowPaint(paint18);
        stackedAreaRenderer11.setBaseOutlinePaint(paint18, false);
        ringPlot3.setNoDataMessagePaint(paint18);
        java.lang.Class<?> wildcardClass23 = paint18.getClass();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection25 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection25);
        int int28 = taskSeriesCollection25.indexOf((java.lang.Comparable) 255);
        java.lang.Class<?> wildcardClass29 = taskSeriesCollection25.getClass();
        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("cyan", (java.lang.Class) wildcardClass29);
        boolean boolean31 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass29);
        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Range[0.0,0.0]", (java.lang.Class) wildcardClass23, (java.lang.Class) wildcardClass29);
        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResource("VerticalAlignment.BOTTOM", (java.lang.Class) wildcardClass23);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNull(uRL33);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) 0);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        java.lang.Comparable comparable4 = multiplePiePlot0.getAggregatedItemsKey();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (short) 0 + "'", comparable3.equals((short) 0));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 0 + "'", comparable4.equals((short) 0));
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline0.getSegment(date5);
        segment6.dec();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(segment6);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        java.awt.Paint paint10 = categoryMarker9.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker9);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = categoryMarker9.getLabelOffsetType();
        java.lang.String str13 = lengthAdjustmentType12.toString();
        java.lang.String str14 = lengthAdjustmentType12.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "EXPAND" + "'", str13.equals("EXPAND"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "EXPAND" + "'", str14.equals("EXPAND"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        categoryPlot0.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D10 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean12 = lineRenderer3D10.getSeriesLinesVisible(100);
        boolean boolean13 = lineRenderer3D10.getBaseShapesVisible();
        java.lang.Boolean boolean15 = lineRenderer3D10.getSeriesVisibleInLegend(1900);
        lineRenderer3D10.setAutoPopulateSeriesPaint(true);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot19.setDomainAxisLocation(1900, axisLocation21);
        java.awt.Stroke stroke23 = categoryPlot19.getRangeCrosshairStroke();
        categoryPlot19.setAnchorValue((double) 1560179855055L);
        int int26 = categoryPlot19.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis28.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis28.setMarkerBand(markerAxisBand31);
        org.jfree.data.Range range33 = numberAxis28.getDefaultAutoRange();
        boolean boolean34 = numberAxis28.isAutoRange();
        numberAxis28.setNegativeArrowVisible(false);
        java.awt.Paint paint38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color43 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke44 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint38, stroke39, (java.awt.Paint) color43, stroke44, 1.0f);
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        lineRenderer3D10.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis28, (org.jfree.chart.plot.Marker) categoryMarker46, rectangle2D47);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker46);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        int int4 = taskSeriesCollection1.indexOf((java.lang.Comparable) 255);
        boolean boolean5 = rangeType0.equals((java.lang.Object) taskSeriesCollection1);
        try {
            java.lang.Comparable comparable7 = taskSeriesCollection1.getSeriesKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setErrorIndicatorPaint(paint3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = statisticalBarRenderer0.getGradientPaintTransformer();
        java.awt.Color color7 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.Font font12 = valueMarker11.getLabelFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) valueMarker11);
        org.jfree.chart.JFreeChart jFreeChart14 = rendererChangeEvent13.getChart();
        statisticalBarRenderer0.notifyListeners(rendererChangeEvent13);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(jFreeChart14);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        dateAxis1.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.Timeline timeline7 = null;
        dateAxis1.setTimeline(timeline7);
        dateAxis1.setRangeWithMargins((double) (short) 100, (double) 100L);
        org.jfree.data.Range range14 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range17 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str18 = range17.toString();
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range14, range17);
        dateAxis1.setRange(range17);
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range26 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range29 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str30 = range29.toString();
        org.jfree.data.Range range31 = org.jfree.data.Range.combine(range26, range29);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(range23, range29);
        dateAxis1.setRangeWithMargins(range29, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition36 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = null;
        dateAxis1.setTickUnit(dateTickUnit37, false, true);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Range[0.0,0.0]" + "'", str18.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Range[0.0,0.0]" + "'", str30.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(dateTickMarkPosition36);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        java.awt.Paint paint4 = null;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 'a', paint4);
        ringPlot0.setPieIndex((int) ' ');
        java.awt.Font font8 = ringPlot0.getLabelFont();
        java.awt.Stroke stroke9 = ringPlot0.getLabelOutlineStroke();
        double double10 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint2 = lineBorder1.getPaint();
        java.awt.Stroke stroke3 = lineBorder1.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getLeft();
        categoryPlot0.setInsets(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = ganttRenderer0.getURLGenerator((int) (byte) 1, 2);
        double double4 = ganttRenderer0.getBase();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = ganttRenderer0.getLegendItemURLGenerator();
        ganttRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false, false);
        java.awt.Stroke stroke11 = ganttRenderer0.lookupSeriesOutlineStroke(0);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getXOffset();
        boolean boolean2 = lineRenderer3D0.getBaseShapesFilled();
        boolean boolean3 = lineRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = lineRenderer3D0.getBaseItemLabelGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo6.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        plotRenderingInfo7.setPlotArea(rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        plotRenderingInfo7.setDataArea(rectangle2D10);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo7);
        double double13 = categoryItemRendererState12.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection14 = categoryItemRendererState12.getEntityCollection();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double17 = rectangleInsets15.calculateRightInset((double) 1L);
        double double19 = rectangleInsets15.extendHeight((double) 1559372400000L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo20.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = chartRenderingInfo22.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        plotRenderingInfo23.setPlotArea(rectangle2D24);
        plotRenderingInfo21.addSubplotInfo(plotRenderingInfo23);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis28.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis28.setMarkerBand(markerAxisBand31);
        boolean boolean33 = plotRenderingInfo21.equals((java.lang.Object) markerAxisBand31);
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo21.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str36 = rectangleAnchor35.toString();
        java.awt.geom.Point2D point2D37 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D34, rectangleAnchor35);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets15.createInsetRectangle(rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot39.setDomainAxisLocation(1900, axisLocation41);
        java.awt.Stroke stroke43 = categoryPlot39.getRangeCrosshairStroke();
        categoryPlot39.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder46 = categoryPlot39.getColumnRenderingOrder();
        java.awt.Stroke stroke47 = categoryPlot39.getOutlineStroke();
        org.jfree.chart.util.Layer layer49 = null;
        java.util.Collection collection50 = categoryPlot39.getDomainMarkers((int) ' ', layer49);
        java.lang.Object obj51 = categoryPlot39.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition55 = dateAxis54.getTickMarkPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot56 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart57 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot56);
        jFreeChart57.removeLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color63 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder64 = new org.jfree.chart.block.BlockBorder(rectangleInsets59, (java.awt.Paint) color63);
        double double65 = rectangleInsets59.getRight();
        jFreeChart57.setPadding(rectangleInsets59);
        boolean boolean67 = jFreeChart57.getAntiAlias();
        jFreeChart57.setNotify(true);
        boolean boolean70 = dateAxis54.equals((java.lang.Object) true);
        java.util.Date date71 = dateAxis54.getMaximumDate();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection72 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number73 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection72);
        java.lang.Number number74 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection72);
        org.jfree.chart.plot.PlotOrientation plotOrientation75 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent76 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) plotOrientation75);
        taskSeriesCollection72.seriesChanged(seriesChangeEvent76);
        org.jfree.data.general.DatasetGroup datasetGroup78 = taskSeriesCollection72.getGroup();
        try {
            lineRenderer3D0.drawItem(graphics2D5, categoryItemRendererState12, rectangle2D34, categoryPlot39, categoryAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis54, (org.jfree.data.category.CategoryDataset) taskSeriesCollection72, 1900, (int) '4', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.559372400008E12d + "'", double19 == 1.559372400008E12d);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(plotRenderingInfo23);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "RectangleAnchor.TOP" + "'", str36.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(sortOrder46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(dateTickMarkPosition55);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNull(number73);
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + 0.0d + "'", number74.equals(0.0d));
        org.junit.Assert.assertNotNull(plotOrientation75);
        org.junit.Assert.assertNotNull(datasetGroup78);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(1900);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection3 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list4 = taskSeriesCollection3.getColumnKeys();
        int int6 = taskSeriesCollection3.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection3, comparable7);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        objectList1.set(11, (java.lang.Object) pieDataset8);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setCursor((double) 3600000L);
        double double3 = axisState0.getCursor();
        double double4 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3600000.0d + "'", double3 == 3600000.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint4 = statisticalBarRenderer1.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer1.setMinimumBarLength((double) (short) 100);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke12);
        statisticalBarRenderer1.setSeriesPaint((int) '4', (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D16 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, (java.awt.Paint) color21);
        lineRenderer3D16.setWallPaint((java.awt.Paint) color21);
        statisticalBarRenderer1.setSeriesPaint(0, (java.awt.Paint) color21, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = statisticalBarRenderer1.getPlot();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = chartRenderingInfo30.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        plotRenderingInfo31.setPlotArea(rectangle2D32);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        plotRenderingInfo31.setDataArea(rectangle2D34);
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot0.zoomDomainAxes((double) (short) -1, 10.0d, plotRenderingInfo31, point2D36);
        java.awt.Paint paint38 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(categoryPlot26);
        org.junit.Assert.assertNotNull(plotRenderingInfo31);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str3 = range2.toString();
        double double4 = range2.getCentralValue();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range2);
        boolean boolean8 = dateRange5.intersects((double) 'a', (double) 6);
        java.lang.String str9 = dateRange5.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str9.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot3);
        jFreeChart4.removeLegend();
        java.awt.image.BufferedImage bufferedImage8 = jFreeChart4.createBufferedImage(1900, (int) ' ');
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("UnitType.ABSOLUTE", "", "ChartChangeEventType.NEW_DATASET", (java.awt.Image) bufferedImage8, "Pie 3D Plot", "VerticalAlignment.BOTTOM", "Category Plot");
        java.lang.String str13 = projectInfo12.getInfo();
        org.junit.Assert.assertNotNull(bufferedImage8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str13.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint8, stroke9, (java.awt.Paint) color13, stroke14, 1.0f);
        categoryAxis1.setTickMarkStroke(stroke9);
        float float18 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setTickMarkInsideLength((float) '4');
        categoryAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) 0);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis4.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis4.getMarkerBand();
        boolean boolean8 = meanAndStandardDeviation2.equals((java.lang.Object) numberAxis4);
        java.awt.Shape shape9 = numberAxis4.getLeftArrow();
        java.awt.Color color10 = java.awt.Color.YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape9, (java.awt.Paint) color10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        legendGraphic11.setOutlineStroke(stroke12);
        boolean boolean14 = legendGraphic11.isShapeVisible();
        boolean boolean15 = legendGraphic11.isShapeOutlineVisible();
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("SortOrder.ASCENDING");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name SortOrder.ASCENDING, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        boolean boolean12 = lineRenderer3D0.getAutoPopulateSeriesPaint();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis14.setNegativeArrowVisible(true);
        numberAxis14.setFixedAutoRange((double) '#');
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot19);
        jFreeChart20.removeLegend();
        jFreeChart20.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle24 = jFreeChart20.getLegend(3);
        org.jfree.chart.event.ChartProgressListener chartProgressListener25 = null;
        jFreeChart20.addProgressListener(chartProgressListener25);
        boolean boolean27 = numberAxis14.hasListener((java.util.EventListener) jFreeChart20);
        java.awt.Stroke stroke28 = jFreeChart20.getBorderStroke();
        lineRenderer3D0.setBaseStroke(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(legendTitle24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        double double4 = ringPlot3.getInnerSeparatorExtension();
        java.awt.Image image5 = ringPlot3.getBackgroundImage();
        java.awt.Paint paint6 = ringPlot3.getBaseSectionPaint();
        try {
            org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        java.awt.Paint paint7 = stackedAreaRenderer1.getItemOutlinePaint(4, (int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint10 = lineBorder9.getPaint();
        java.awt.Stroke stroke11 = lineBorder9.getStroke();
        categoryPlot8.setDomainGridlineStroke(stroke11);
        stackedAreaRenderer1.setPlot(categoryPlot8);
        int int14 = stackedAreaRenderer1.getPassCount();
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        boolean boolean16 = stackedAreaRenderer1.equals((java.lang.Object) paint15);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        categoryAxis1.setUpperMargin(0.0d);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(100);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) serialDate9);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.setAxisLineVisible(true);
        java.awt.Paint paint7 = categoryAxis3.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = textBlock8.calculateDimensions(graphics2D9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textBlock8.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textBlock8.getLineAlignment();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = textBlock8.calculateDimensions(graphics2D13);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(size2D14);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot1.getFixedRangeAxisSpace();
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) categoryPlot1);
        java.lang.Object obj6 = keyedObjects0.getObject((-1));
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.awt.Color color1 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        java.awt.Font font6 = valueMarker5.getLabelFont();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis8.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis8.setMarkerBand(markerAxisBand11);
        org.jfree.data.Range range13 = numberAxis8.getDefaultAutoRange();
        java.awt.Font font14 = numberAxis8.getTickLabelFont();
        valueMarker5.setLabelFont(font14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color20 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets16, (java.awt.Paint) color20);
        double double23 = rectangleInsets16.extendHeight((double) 'a');
        org.jfree.chart.util.UnitType unitType24 = rectangleInsets16.getUnitType();
        double double26 = rectangleInsets16.extendWidth((double) 15);
        double double27 = rectangleInsets16.getRight();
        valueMarker5.setLabelOffset(rectangleInsets16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 97.0d + "'", double23 == 97.0d);
        org.junit.Assert.assertNotNull(unitType24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 15.0d + "'", double26 == 15.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("WMAP_Plot", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearRangeMarkers(15);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        ringPlot5.setOutlineVisible(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint12 = statisticalBarRenderer9.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer9.setMinimumBarLength((double) (short) 100);
        java.awt.Color color17 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke20 = categoryAxis19.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color17, stroke20);
        statisticalBarRenderer9.setSeriesPaint((int) '4', (java.awt.Paint) color17);
        ringPlot5.setSectionOutlinePaint((java.lang.Comparable) 100.0d, (java.awt.Paint) color17);
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color17);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone4;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone4;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement5 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource3, (org.jfree.chart.block.Arrangement) columnArrangement4, (org.jfree.chart.block.Arrangement) centerArrangement5);
        org.jfree.chart.event.TitleChangeListener titleChangeListener7 = null;
        legendTitle6.removeChangeListener(titleChangeListener7);
        java.awt.Paint paint9 = legendTitle6.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = legendTitle6.getLegendItemGraphicEdge();
        boolean boolean11 = ganttRenderer0.equals((java.lang.Object) legendTitle6);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis14.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = numberAxis14.getMarkerBand();
        numberAxis14.resizeRange((double) (-459), (double) 255);
        boolean boolean21 = numberAxis14.isAutoTickUnitSelection();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis24.setMinimumDate(date25);
        dateAxis24.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double33 = rectangleInsets31.calculateRightInset((double) 1L);
        double double35 = rectangleInsets31.extendHeight((double) 1559372400000L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = chartRenderingInfo36.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = chartRenderingInfo38.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        plotRenderingInfo39.setPlotArea(rectangle2D40);
        plotRenderingInfo37.addSubplotInfo(plotRenderingInfo39);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis44.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis44.setMarkerBand(markerAxisBand47);
        boolean boolean49 = plotRenderingInfo37.equals((java.lang.Object) markerAxisBand47);
        java.awt.geom.Rectangle2D rectangle2D50 = plotRenderingInfo37.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str52 = rectangleAnchor51.toString();
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor51);
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets31.createInsetRectangle(rectangle2D50);
        org.jfree.chart.entity.ChartEntity chartEntity56 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D50, "30-June-2019");
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis24.valueToJava2D((double) 7, rectangle2D50, rectangleEdge57);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str60 = rectangleEdge59.toString();
        double double61 = numberAxis14.java2DToValue((double) (-1.0f), rectangle2D50, rectangleEdge59);
        try {
            legendTitle6.draw(graphics2D12, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(markerAxisBand17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 8.0d + "'", double33 == 8.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.559372400008E12d + "'", double35 == 1.559372400008E12d);
        org.junit.Assert.assertNotNull(plotRenderingInfo37);
        org.junit.Assert.assertNotNull(plotRenderingInfo39);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleAnchor.TOP" + "'", str52.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "RectangleEdge.BOTTOM" + "'", str60.equals("RectangleEdge.BOTTOM"));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.NEGATIVE_INFINITY + "'", double61 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        dateAxis1.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.Timeline timeline7 = null;
        dateAxis1.setTimeline(timeline7);
        dateAxis1.setRangeWithMargins((double) (short) 100, (double) 100L);
        org.jfree.data.Range range14 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range17 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str18 = range17.toString();
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range14, range17);
        dateAxis1.setRange(range17);
        boolean boolean21 = dateAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Range[0.0,0.0]" + "'", str18.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearAnnotations();
        boolean boolean3 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis5.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis5.setMarkerBand(markerAxisBand8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.centerRange((double) 1559372400000L);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint19 = statisticalBarRenderer16.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer16.setMinimumBarLength((double) (short) 100);
        java.awt.Color color24 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke27 = categoryAxis26.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color24, stroke27);
        statisticalBarRenderer16.setSeriesPaint((int) '4', (java.awt.Paint) color24);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D31 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color36 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder(rectangleInsets32, (java.awt.Paint) color36);
        lineRenderer3D31.setWallPaint((java.awt.Paint) color36);
        statisticalBarRenderer16.setSeriesPaint(0, (java.awt.Paint) color36, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = statisticalBarRenderer16.getPlot();
        categoryPlot15.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer16);
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot15.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot15.getDomainAxisLocation((int) '4');
        try {
            xYPlot0.setRangeAxisLocation((int) (short) -1, axisLocation46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(categoryPlot41);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = ganttRenderer0.getURLGenerator((int) (byte) 1, 2);
        double double4 = ganttRenderer0.getBase();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = ganttRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer8.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        java.awt.Paint paint14 = stackedAreaRenderer8.getItemOutlinePaint(4, (int) '#');
        ganttRenderer0.setSeriesItemLabelPaint(15, paint14, true);
        double double17 = ganttRenderer0.getItemMargin();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test417");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
//        jFreeChart3.removeLegend();
//        jFreeChart3.clearSubtitles();
//        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long8 = segmentedTimeline0.getTime(date7);
//        int int9 = segmentedTimeline0.getSegmentsExcluded();
//        segmentedTimeline0.setStartTime(86400000L);
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot();
//        multiplePiePlot12.setAggregatedItemsKey((java.lang.Comparable) (short) 0);
//        java.lang.Comparable comparable15 = multiplePiePlot12.getAggregatedItemsKey();
//        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//        statisticalBarRenderer16.setAutoPopulateSeriesStroke(true);
//        java.awt.Paint paint19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
//        statisticalBarRenderer16.setErrorIndicatorPaint(paint19);
//        java.lang.Boolean boolean22 = statisticalBarRenderer16.getSeriesCreateEntities((int) (short) 1);
//        java.awt.Paint paint24 = statisticalBarRenderer16.lookupSeriesFillPaint(10);
//        multiplePiePlot12.setAggregatedItemsPaint(paint24);
//        org.jfree.data.category.CategoryDataset categoryDataset26 = multiplePiePlot12.getDataset();
//        boolean boolean27 = segmentedTimeline0.equals((java.lang.Object) multiplePiePlot12);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline28 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int29 = segmentedTimeline28.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot30 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot30);
//        jFreeChart31.removeLegend();
//        jFreeChart31.clearSubtitles();
//        boolean boolean34 = segmentedTimeline28.equals((java.lang.Object) jFreeChart31);
//        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long36 = segmentedTimeline28.getTime(date35);
//        org.jfree.data.KeyToGroupMap keyToGroupMap38 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (short) 10);
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D40 = new org.jfree.data.DefaultKeyedValues2D(true);
//        defaultKeyedValues2D40.removeColumn((java.lang.Comparable) 1.559372400008E12d);
//        boolean boolean43 = keyToGroupMap38.equals((java.lang.Object) 1.559372400008E12d);
//        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date46 = dateAxis45.getMaximumDate();
//        java.lang.Comparable comparable47 = keyToGroupMap38.getGroup((java.lang.Comparable) date46);
//        try {
//            boolean boolean48 = segmentedTimeline0.containsDomainRange(date35, date46);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (1) < domainValueStart (1560179855055)");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560179855055L + "'", long8 == 1560179855055L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 0 + "'", comparable15.equals((short) 0));
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertNull(boolean22);
//        org.junit.Assert.assertNotNull(paint24);
//        org.junit.Assert.assertNull(categoryDataset26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560179855055L + "'", long36 == 1560179855055L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + (short) 10 + "'", comparable47.equals((short) 10));
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) '#');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        numberAxis1.setRightArrow(shape6);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation11 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) 0);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis13.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis13.getMarkerBand();
        boolean boolean17 = meanAndStandardDeviation11.equals((java.lang.Object) numberAxis13);
        java.awt.Shape shape18 = numberAxis13.getLeftArrow();
        java.awt.Color color19 = java.awt.Color.YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        legendGraphic20.setOutlineStroke(stroke21);
        numberAxis1.setAxisLineStroke(stroke21);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(markerAxisBand16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedAreaRenderer1.getPositiveItemLabelPosition((int) (short) 10, 1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        stackedAreaRenderer1.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = stackedAreaRenderer1.getItemLabelGenerator((int) (short) 1, (-1));
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        boolean boolean12 = stackedAreaRenderer1.equals((java.lang.Object) "TextAnchor.CENTER");
        stackedAreaRenderer1.setSeriesItemLabelsVisible(255, true);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = chartRenderingInfo17.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        plotRenderingInfo18.setPlotArea(rectangle2D19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        plotRenderingInfo18.setDataArea(rectangle2D21);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState23 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo18);
        double double24 = categoryItemRendererState23.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection25 = categoryItemRendererState23.getEntityCollection();
        double double26 = categoryItemRendererState23.getBarWidth();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot28.setDomainAxisLocation(1900, axisLocation30);
        java.awt.Stroke stroke32 = categoryPlot28.getRangeCrosshairStroke();
        categoryPlot28.setAnchorValue((double) 1560179855055L);
        categoryPlot28.setWeight((int) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke39 = categoryAxis38.getTickMarkStroke();
        categoryAxis38.setAxisLineVisible(true);
        java.awt.Paint paint42 = categoryAxis38.getAxisLinePaint();
        java.awt.Font font43 = categoryAxis38.getLabelFont();
        categoryAxis38.setLowerMargin(4.0d);
        double double46 = categoryAxis38.getLabelAngle();
        categoryAxis38.setMaximumCategoryLabelWidthRatio((float) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis50.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = null;
        numberAxis50.setMarkerBand(markerAxisBand53);
        org.jfree.data.Range range55 = numberAxis50.getDefaultAutoRange();
        boolean boolean56 = numberAxis50.isAutoRange();
        numberAxis50.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range59 = numberAxis50.getDefaultAutoRange();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection60 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list61 = taskSeriesCollection60.getColumnKeys();
        try {
            stackedAreaRenderer1.drawItem(graphics2D16, categoryItemRendererState23, rectangle2D27, categoryPlot28, categoryAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.data.category.CategoryDataset) taskSeriesCollection60, 500, (int) (short) -1, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(list61);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(true, true);
        org.junit.Assert.assertNull(itemLabelPosition1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image3, "hi!", "", "");
        projectInfo7.setName("Range[0.0,0.0]");
        projectInfo7.setVersion("");
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot1.setLabelShadowPaint(paint3);
        ringPlot1.setShadowXOffset(0.2d);
        java.awt.Stroke stroke7 = ringPlot1.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer9.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        double double15 = ringPlot14.getInnerSeparatorExtension();
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot14.setLabelShadowPaint(paint16);
        stackedAreaRenderer9.setBaseOutlinePaint(paint16, false);
        ringPlot1.setNoDataMessagePaint(paint16);
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot1.setLegendItemShape(shape21);
        ringPlot1.setShadowYOffset((double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, keyToGroupMap1);
        java.util.List list3 = keyToGroupMap1.getGroups();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.plot.Plot plot7 = numberAxis1.getPlot();
        org.jfree.data.Range range11 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str12 = range11.toString();
        double double13 = range11.getCentralValue();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange(range11);
        java.util.Date date15 = dateRange14.getUpperDate();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint20 = statisticalBarRenderer17.getItemFillPaint(0, (int) '#');
        boolean boolean21 = lengthConstraintType16.equals((java.lang.Object) 0);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis24.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand27 = null;
        numberAxis24.setMarkerBand(markerAxisBand27);
        org.jfree.data.Range range29 = numberAxis24.getDefaultAutoRange();
        boolean boolean30 = numberAxis24.isAutoRange();
        numberAxis24.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range33 = numberAxis24.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange14, lengthConstraintType16, 0.0d, range33, lengthConstraintType34);
        double double36 = range33.getLength();
        numberAxis1.setRange(range33);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Range[0.0,0.0]" + "'", str12.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot1.getFixedRangeAxisSpace();
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets6.getUnitType();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer8 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke11 = categoryAxis10.getTickMarkStroke();
        categoryAxis10.setAxisLineVisible(true);
        java.awt.Paint paint14 = categoryAxis10.getTickLabelPaint();
        levelRenderer8.setBaseItemLabelPaint(paint14, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        levelRenderer8.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        boolean boolean19 = unitType7.equals((java.lang.Object) standardCategorySeriesLabelGenerator17);
        keyedObjects0.setObject((java.lang.Comparable) (short) 100, (java.lang.Object) unitType7);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets(unitType7, Double.NaN, (double) ' ', (double) 2, (double) (-1));
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getBackgroundPaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder2 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        boolean boolean3 = textTitle0.equals((java.lang.Object) datasetRenderingOrder2);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis1.getTickUnit();
        java.awt.Font font8 = numberAxis1.getTickLabelFont();
        java.lang.Object obj9 = numberAxis1.clone();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeAxes();
        boolean boolean2 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getBackgroundPaint();
        java.awt.Shape shape6 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint10 = statisticalBarRenderer7.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer7.setMinimumBarLength((double) (short) 100);
        java.awt.Paint paint13 = statisticalBarRenderer7.getBaseItemLabelPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("VerticalAlignment.BOTTOM", "", "ChartChangeEventType.NEW_DATASET", "poly", shape6, paint13);
        textTitle0.setPaint(paint13);
        java.lang.Object obj16 = textTitle0.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle0.getTextAlignment();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearRangeMarkers(15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        plotRenderingInfo6.setPlotArea(rectangle2D7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        plotRenderingInfo6.setDataArea(rectangle2D9);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo12.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        plotRenderingInfo15.setPlotArea(rectangle2D16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo15);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis20.setMarkerBand(markerAxisBand23);
        boolean boolean25 = plotRenderingInfo13.equals((java.lang.Object) markerAxisBand23);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo13.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str28 = rectangleAnchor27.toString();
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        xYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D29);
        java.awt.Image image31 = xYPlot0.getBackgroundImage();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleAnchor.TOP" + "'", str28.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNull(image31);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("30-June-2019");
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 8.0d, (double) 1);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double8 = rectangleInsets6.calculateRightInset((double) 1L);
        double double10 = rectangleInsets6.extendHeight((double) 1559372400000L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = chartRenderingInfo11.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo13.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        plotRenderingInfo14.setPlotArea(rectangle2D15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo14);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis19.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis19.setMarkerBand(markerAxisBand22);
        boolean boolean24 = plotRenderingInfo12.equals((java.lang.Object) markerAxisBand22);
        java.awt.geom.Rectangle2D rectangle2D25 = plotRenderingInfo12.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str27 = rectangleAnchor26.toString();
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets6.createInsetRectangle(rectangle2D25);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D25, "30-June-2019");
        try {
            blockBorder4.draw(graphics2D5, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.0d + "'", double8 == 8.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.559372400008E12d + "'", double10 == 1.559372400008E12d);
        org.junit.Assert.assertNotNull(plotRenderingInfo12);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleAnchor.TOP" + "'", str27.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        categoryAxis1.setLowerMargin(4.0d);
        float float9 = categoryAxis1.getTickMarkInsideLength();
        java.awt.Paint paint10 = categoryAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        categoryPlot0.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation(100);
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.Range range3 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str4 = range3.toString();
        double double5 = range3.getCentralValue();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(range3);
        java.util.Date date7 = dateRange6.getUpperDate();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint12 = statisticalBarRenderer9.getItemFillPaint(0, (int) '#');
        boolean boolean13 = lengthConstraintType8.equals((java.lang.Object) 0);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis16.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis16.setMarkerBand(markerAxisBand19);
        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
        boolean boolean22 = numberAxis16.isAutoRange();
        numberAxis16.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range25 = numberAxis16.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType26 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange6, lengthConstraintType8, 0.0d, range25, lengthConstraintType26);
        java.lang.String str28 = rectangleConstraint27.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,0.0]" + "'", str4.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(lengthConstraintType26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str28.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) 'a', 0L);
        boolean boolean4 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Stroke stroke2 = ringPlot1.getSeparatorStroke();
        try {
            ringPlot1.setInteriorGap((double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (97.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("10-June-2019", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 4.0d, (java.lang.Number) (-4503480));
        defaultKeyedValue2.setValue((java.lang.Number) (short) 100);
        java.lang.Number number5 = defaultKeyedValue2.getValue();
        defaultKeyedValue2.setValue((java.lang.Number) 1);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("SortOrder.ASCENDING");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) 0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline0.getSegment(date5);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = segmentedTimeline0.getBaseTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertNull(segmentedTimeline7);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace2 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNull(categoryItemRenderer4);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint3 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) 0);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis4.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis4.getMarkerBand();
        boolean boolean8 = meanAndStandardDeviation2.equals((java.lang.Object) numberAxis4);
        java.awt.Shape shape9 = numberAxis4.getLeftArrow();
        java.awt.Color color10 = java.awt.Color.YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape9, (java.awt.Paint) color10);
        java.awt.Color color12 = java.awt.Color.blue;
        legendGraphic11.setLinePaint((java.awt.Paint) color12);
        java.awt.Paint paint14 = legendGraphic11.getLinePaint();
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test448");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
//        jFreeChart3.removeLegend();
//        jFreeChart3.clearSubtitles();
//        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long8 = segmentedTimeline0.getTime(date7);
//        segmentedTimeline0.setStartTime((long) 4);
//        segmentedTimeline0.addException((long) (byte) 1, (long) ' ');
//        java.lang.Object obj14 = segmentedTimeline0.clone();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560179855055L + "'", long8 == 1560179855055L);
//        org.junit.Assert.assertNotNull(obj14);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Color color3 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke6);
        java.lang.String str8 = org.jfree.chart.util.PaintUtilities.colorToString(color3);
        multiplePiePlot0.setBackgroundPaint((java.awt.Paint) color3);
        java.awt.Color color10 = java.awt.Color.blue;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = multiplePiePlot0.getLegendItems();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "cyan" + "'", str8.equals("cyan"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(legendItemCollection12);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) '#');
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
        jFreeChart7.removeLegend();
        jFreeChart7.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(3);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart7.addProgressListener(chartProgressListener12);
        boolean boolean14 = numberAxis1.hasListener((java.util.EventListener) jFreeChart7);
        java.awt.Stroke stroke15 = jFreeChart7.getBorderStroke();
        jFreeChart7.setBackgroundImageAlignment((-459));
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke22 = categoryAxis21.getTickMarkStroke();
        categoryAxis21.setAxisLineVisible(true);
        java.awt.Paint paint25 = categoryAxis21.getAxisLinePaint();
        stackedAreaRenderer19.setBaseOutlinePaint(paint25);
        jFreeChart7.setBorderPaint(paint25);
        org.junit.Assert.assertNull(legendTitle11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer5.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        double double11 = ringPlot10.getInnerSeparatorExtension();
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot10.setLabelShadowPaint(paint12);
        stackedAreaRenderer5.setBaseOutlinePaint(paint12, false);
        stackedAreaRenderer5.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean19 = stackedAreaRenderer5.getSeriesVisible((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = stackedAreaRenderer5.getBaseNegativeItemLabelPosition();
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition20, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = lineRenderer3D0.getBaseToolTipGenerator();
        java.lang.Number[] numberArray27 = new java.lang.Number[] {};
        java.lang.Number[] numberArray28 = new java.lang.Number[] {};
        java.lang.Number[] numberArray29 = new java.lang.Number[] {};
        java.lang.Number[] numberArray30 = new java.lang.Number[] {};
        java.lang.Number[] numberArray31 = new java.lang.Number[] {};
        java.lang.Number[] numberArray32 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray27, numberArray28, numberArray29, numberArray30, numberArray31, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis37.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand40 = null;
        numberAxis37.setMarkerBand(markerAxisBand40);
        org.jfree.data.Range range42 = numberAxis37.getDefaultAutoRange();
        boolean boolean43 = numberAxis37.isAutoRange();
        numberAxis37.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer46 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        boolean boolean50 = ringPlot48.equals((java.lang.Object) 'a');
        java.awt.Paint paint52 = null;
        ringPlot48.setSectionOutlinePaint((java.lang.Comparable) 'a', paint52);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke56 = categoryAxis55.getTickMarkStroke();
        categoryAxis55.setAxisLineVisible(true);
        java.awt.Paint paint59 = categoryAxis55.getAxisLinePaint();
        java.awt.Font font60 = categoryAxis55.getLabelFont();
        ringPlot48.setLabelFont(font60);
        levelRenderer46.setSeriesItemLabelFont(0, font60);
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D35, (org.jfree.chart.axis.ValueAxis) numberAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer46);
        java.awt.Shape shape64 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape65 = org.jfree.chart.util.ShapeUtilities.clone(shape64);
        java.awt.Shape shape69 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape64, (double) (-1), (float) (byte) 100, 1.0f);
        levelRenderer46.setBaseShape(shape69);
        lineRenderer3D0.setSeriesShape(4, shape69);
        java.awt.Paint paint74 = lineRenderer3D0.getItemLabelPaint((int) (byte) 100, (int) (byte) 100);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNull(categoryToolTipGenerator23);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNotNull(paint74);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        int int2 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) "Pie 3D Plot");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int7 = month5.compareTo((java.lang.Object) "cyan");
        defaultKeyedValues2D3.removeValue((java.lang.Comparable) 10.0d, (java.lang.Comparable) month5);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (java.lang.Comparable) 10.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(pieDataset9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.getIgnoreNullValues();
        boolean boolean3 = standardGradientPaintTransformer0.equals((java.lang.Object) ringPlot1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        double double6 = ringPlot5.getInnerSeparatorExtension();
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot5.setLabelShadowPaint(paint7);
        ringPlot5.setShadowXOffset(0.2d);
        java.awt.Stroke stroke11 = ringPlot5.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        double double19 = ringPlot18.getInnerSeparatorExtension();
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot18.setLabelShadowPaint(paint20);
        stackedAreaRenderer13.setBaseOutlinePaint(paint20, false);
        ringPlot5.setNoDataMessagePaint(paint20);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot5.setLegendItemShape(shape25);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        stackedAreaRenderer28.setBaseOutlinePaint(paint34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer28.setBasePaint((java.awt.Paint) color36, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint42 = statisticalBarRenderer39.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer44 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedAreaRenderer44.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double48 = itemLabelPosition47.getAngle();
        statisticalBarRenderer39.setBasePositiveItemLabelPosition(itemLabelPosition47);
        statisticalBarRenderer39.setIncludeBaseInRange(true);
        boolean boolean52 = statisticalBarRenderer39.getBaseSeriesVisible();
        java.awt.Stroke stroke53 = statisticalBarRenderer39.getBaseStroke();
        java.awt.Font font57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke60 = categoryAxis59.getTickMarkStroke();
        categoryAxis59.setAxisLineVisible(true);
        java.awt.Paint paint63 = categoryAxis59.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock64 = org.jfree.chart.text.TextUtilities.createTextBlock("", font57, paint63);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint68 = statisticalBarRenderer65.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock69 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font57, paint68);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer70 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint73 = statisticalBarRenderer70.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer70.setMinimumBarLength((double) (short) 100);
        java.awt.Color color78 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke81 = categoryAxis80.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color78, stroke81);
        statisticalBarRenderer70.setSeriesPaint((int) '4', (java.awt.Paint) color78);
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font57, (java.awt.Paint) color78);
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("WMAP_Plot", "CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP", "{0}", "30-June-2019", shape25, (java.awt.Paint) color36, stroke53, (java.awt.Paint) color78);
        java.awt.Stroke stroke86 = legendItem85.getOutlineStroke();
        boolean boolean87 = legendItem85.isLineVisible();
        java.awt.Paint paint88 = legendItem85.getFillPaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(textBlock64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(textBlock69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(paint88);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int4 = month2.compareTo((java.lang.Object) "cyan");
        defaultKeyedValues2D0.removeValue((java.lang.Comparable) 10.0d, (java.lang.Comparable) month2);
        java.util.List list6 = defaultKeyedValues2D0.getRowKeys();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryEnd((int) ' ', (-459), rectangle2D5, rectangleEdge6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot8);
        jFreeChart9.removeLegend();
        jFreeChart9.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart9.getLegend(3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str15 = chartChangeEventType14.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ' ', jFreeChart9, chartChangeEventType14);
        jFreeChart9.fireChartChanged();
        jFreeChart9.setTitle("TextAnchor.CENTER");
        jFreeChart9.setTextAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart9.addProgressListener(chartProgressListener22);
        float float24 = jFreeChart9.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str15.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.5f + "'", float24 == 0.5f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.setAxisLineVisible(true);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.removeChangeListener(plotChangeListener7);
        org.jfree.chart.plot.Plot plot9 = piePlot6.getRootPlot();
        categoryAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot6);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Color color14 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint18 = statisticalBarRenderer15.getItemFillPaint(0, (int) '#');
        java.awt.Stroke stroke20 = statisticalBarRenderer15.lookupSeriesOutlineStroke(0);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 1, (java.awt.Paint) color14, stroke20);
        piePlot6.setBaseSectionPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) (short) 10);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D3.removeColumn((java.lang.Comparable) 1.559372400008E12d);
        boolean boolean6 = keyToGroupMap1.equals((java.lang.Object) 1.559372400008E12d);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date9 = dateAxis8.getMaximumDate();
        java.lang.Comparable comparable10 = keyToGroupMap1.getGroup((java.lang.Comparable) date9);
        int int11 = keyToGroupMap1.getGroupCount();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(6, (int) ' ');
        java.util.Date date15 = month14.getStart();
        java.lang.Comparable comparable16 = keyToGroupMap1.getGroup((java.lang.Comparable) month14);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (short) 10 + "'", comparable16.equals((short) 10));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setInnerSeparatorExtension((double) (byte) 100);
        java.awt.Shape shape4 = ringPlot1.getLegendItemShape();
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearAnnotations();
        boolean boolean3 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getDomainTickBandPaint();
        java.awt.Stroke stroke5 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = ganttRenderer0.getURLGenerator((int) (byte) 1, 2);
        double double4 = ganttRenderer0.getBase();
        java.awt.Stroke stroke6 = ganttRenderer0.lookupSeriesStroke(3);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        dateAxis1.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.Timeline timeline7 = null;
        dateAxis1.setTimeline(timeline7);
        dateAxis1.setRangeWithMargins((double) (short) 100, (double) 100L);
        org.jfree.data.Range range14 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range17 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str18 = range17.toString();
        org.jfree.data.Range range19 = org.jfree.data.Range.combine(range14, range17);
        dateAxis1.setRange(range17);
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range26 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range29 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str30 = range29.toString();
        org.jfree.data.Range range31 = org.jfree.data.Range.combine(range26, range29);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(range23, range29);
        dateAxis1.setRangeWithMargins(range29, false, true);
        org.jfree.data.Range range38 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range41 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str42 = range41.toString();
        org.jfree.data.Range range43 = org.jfree.data.Range.combine(range38, range41);
        org.jfree.data.Range range45 = org.jfree.data.Range.shift(range43, (double) (short) -1);
        dateAxis1.setRange(range45);
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = null;
        try {
            java.util.Date date48 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Range[0.0,0.0]" + "'", str18.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Range[0.0,0.0]" + "'", str30.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Range[0.0,0.0]" + "'", str42.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.data.resources.DataPackageResources dataPackageResources2 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet3 = dataPackageResources2.keySet();
        try {
            objectList0.set((-459), (java.lang.Object) strSet3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) 'a', 0L);
        long long4 = segmentedTimeline0.getSegmentsExcludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 172800000L + "'", long4 == 172800000L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image3, "hi!", "", "");
        projectInfo7.setName("Range[0.0,0.0]");
        java.lang.String str10 = projectInfo7.getName();
        java.lang.String str11 = projectInfo7.getLicenceName();
        projectInfo7.setInfo("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        projectInfo7.setLicenceName("ThreadContext");
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Range[0.0,0.0]" + "'", str10.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = categoryLabelPosition0.getCategoryAnchor();
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryLabelPosition0.getRotationAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint8, stroke9, (java.awt.Paint) color13, stroke14, 1.0f);
        categoryAxis1.setTickMarkStroke(stroke9);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        boolean boolean20 = ringPlot19.getIgnoreNullValues();
        ringPlot19.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        boolean boolean24 = categoryLabelPositions18.equals((java.lang.Object) (short) -1);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        double double6 = blockContainer5.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockContainer5.getPadding();
        legendTitle3.setWrapper(blockContainer5);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Stroke stroke3 = ringPlot1.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer1 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.chart.LegendItem legendItem4 = boxAndWhiskerRenderer1.getLegendItem(500, (int) (short) 1);
        boolean boolean5 = lengthConstraintType0.equals((java.lang.Object) 500);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNull(legendItem4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.LegendItem legendItem5 = lineAndShapeRenderer2.getLegendItem((-1), (int) (short) 10);
        org.junit.Assert.assertNull(legendItem5);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 500, 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("RangeType.FULL");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double2 = layeredBarRenderer0.getSeriesBarWidth(12);
        layeredBarRenderer0.setMinimumBarLength(90.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent2);
        java.lang.String str4 = waferMapPlot1.getPlotType();
        java.lang.String str5 = waferMapPlot1.getPlotType();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = chartRenderingInfo8.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        plotRenderingInfo9.setPlotArea(rectangle2D10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        plotRenderingInfo9.setDataArea(rectangle2D12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint18 = statisticalBarRenderer15.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer15.setMinimumBarLength((double) (short) 100);
        java.awt.Color color23 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke26);
        statisticalBarRenderer15.setSeriesPaint((int) '4', (java.awt.Paint) color23);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D30 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color35 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder(rectangleInsets31, (java.awt.Paint) color35);
        lineRenderer3D30.setWallPaint((java.awt.Paint) color35);
        statisticalBarRenderer15.setSeriesPaint(0, (java.awt.Paint) color35, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = statisticalBarRenderer15.getPlot();
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = chartRenderingInfo44.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = chartRenderingInfo46.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        plotRenderingInfo47.setPlotArea(rectangle2D48);
        plotRenderingInfo45.addSubplotInfo(plotRenderingInfo47);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis52.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis52.setMarkerBand(markerAxisBand55);
        boolean boolean57 = plotRenderingInfo45.equals((java.lang.Object) markerAxisBand55);
        java.awt.geom.Rectangle2D rectangle2D58 = plotRenderingInfo45.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = null;
        java.awt.geom.Point2D point2D61 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D59, rectangleAnchor60);
        categoryPlot14.zoomDomainAxes((double) '4', 10.0d, plotRenderingInfo45, point2D61);
        int int63 = plotRenderingInfo9.getSubplotIndex(point2D61);
        org.jfree.chart.plot.PlotState plotState64 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo65 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = chartRenderingInfo65.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo67 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = chartRenderingInfo67.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        plotRenderingInfo68.setPlotArea(rectangle2D69);
        plotRenderingInfo66.addSubplotInfo(plotRenderingInfo68);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis73.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand76 = null;
        numberAxis73.setMarkerBand(markerAxisBand76);
        boolean boolean78 = plotRenderingInfo66.equals((java.lang.Object) markerAxisBand76);
        java.awt.geom.Rectangle2D rectangle2D79 = plotRenderingInfo66.getPlotArea();
        try {
            waferMapPlot1.draw(graphics2D6, rectangle2D7, point2D61, plotState64, plotRenderingInfo66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "WMAP_Plot" + "'", str5.equals("WMAP_Plot"));
        org.junit.Assert.assertNotNull(plotRenderingInfo9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNull(categoryPlot40);
        org.junit.Assert.assertNotNull(plotRenderingInfo45);
        org.junit.Assert.assertNotNull(plotRenderingInfo47);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(rectangle2D58);
        org.junit.Assert.assertNotNull(point2D61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(plotRenderingInfo66);
        org.junit.Assert.assertNotNull(plotRenderingInfo68);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(rectangle2D79);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RangeType.FULL");
        taskSeries1.fireSeriesChanged();
        taskSeries1.fireSeriesChanged();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        double double7 = ringPlot6.getInnerSeparatorExtension();
        java.awt.Image image8 = ringPlot6.getBackgroundImage();
        java.awt.Paint paint9 = ringPlot6.getBaseSectionPaint();
        boolean boolean10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color4, paint9);
        boolean boolean11 = taskSeries1.equals((java.lang.Object) paint9);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot0.getDomainMarkers((int) ' ', layer10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot0.getLegendItems();
        java.lang.Object obj13 = legendItemCollection12.clone();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        int int12 = lineRenderer3D0.getPassCount();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = ringPlot14.getSectionOutlinesVisible();
        double double16 = ringPlot14.getShadowXOffset();
        boolean boolean17 = lineRenderer3D0.equals((java.lang.Object) ringPlot14);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis20.setMarkerBand(markerAxisBand23);
        org.jfree.data.Range range25 = numberAxis20.getDefaultAutoRange();
        java.awt.Shape shape26 = numberAxis20.getDownArrow();
        lineRenderer3D0.setSeriesShape((int) '#', shape26);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection28 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list29 = taskSeriesCollection28.getColumnKeys();
        int int31 = taskSeriesCollection28.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable32 = null;
        org.jfree.data.general.PieDataset pieDataset33 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection28, comparable32);
        org.jfree.data.general.PieDataset pieDataset35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection28, (java.lang.Comparable) 255);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '#', (org.jfree.data.general.Dataset) taskSeriesCollection28);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(pieDataset33);
        org.junit.Assert.assertNotNull(pieDataset35);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) ' ');
        java.util.Calendar calendar3 = null;
        try {
            month2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(range2);
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range2, 90.0d);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        ringPlot0.setForegroundAlpha((float) (short) -1);
        ringPlot0.setSectionDepth((double) 255);
        double double7 = ringPlot0.getInteriorGap();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.25d + "'", double7 == 0.25d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Color color3 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke6);
        java.lang.String str8 = org.jfree.chart.util.PaintUtilities.colorToString(color3);
        multiplePiePlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.JFreeChart jFreeChart10 = multiplePiePlot0.getPieChart();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "cyan" + "'", str8.equals("cyan"));
        org.junit.Assert.assertNotNull(jFreeChart10);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getXOffset();
        boolean boolean2 = lineRenderer3D0.getBaseShapesFilled();
        boolean boolean5 = lineRenderer3D0.getItemLineVisible((int) (byte) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        java.lang.Object obj3 = defaultKeyedValues2D1.clone();
        java.util.List list4 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.util.Collection collection5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number7 = taskSeriesCollection0.getPercentComplete(6, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getXOffset();
        boolean boolean2 = lineRenderer3D0.getBaseShapesFilled();
        boolean boolean3 = lineRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean4 = lineRenderer3D0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation3 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) 0);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis5.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = numberAxis5.getMarkerBand();
        boolean boolean9 = meanAndStandardDeviation3.equals((java.lang.Object) numberAxis5);
        java.awt.Shape shape10 = numberAxis5.getLeftArrow();
        java.awt.Color color11 = java.awt.Color.YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic12 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color11);
        waferMapPlot0.setNoDataMessagePaint((java.awt.Paint) color11);
        org.junit.Assert.assertNull(markerAxisBand8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-459), shape1, "", "RectangleAnchor.TOP");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape1);
        org.jfree.data.general.Dataset dataset7 = legendItemEntity6.getDataset();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        int int10 = year8.getYear();
        long long11 = year8.getSerialIndex();
        boolean boolean12 = legendItemEntity6.equals((java.lang.Object) year8);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearAnnotations();
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(axisSpace1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearRangeMarkers(15);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder5 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot4.setRowRenderingOrder(sortOrder5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(1900, axisLocation11);
        java.awt.Stroke stroke13 = categoryPlot9.getRangeCrosshairStroke();
        categoryPlot9.setAnchorValue((double) 1560179855055L);
        categoryPlot9.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot9.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation19, plotOrientation20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation18, plotOrientation20);
        java.lang.String str23 = plotOrientation20.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation7, plotOrientation20);
        xYPlot0.setOrientation(plotOrientation20);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str23.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }
}

