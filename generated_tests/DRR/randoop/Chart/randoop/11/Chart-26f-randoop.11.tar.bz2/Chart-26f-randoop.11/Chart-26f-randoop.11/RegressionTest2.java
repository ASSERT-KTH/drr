import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearAnnotations();
        xYPlot0.clearRangeMarkers();
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot0.getDataset(0);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(xYDataset5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        int int16 = color11.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font9, (java.awt.Paint) color11);
        java.awt.Paint paint18 = labelBlock17.getPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis20.setAxisLineVisible(true);
        categoryAxis20.setCategoryLabelPositionOffset(7);
        boolean boolean25 = labelBlock17.equals((java.lang.Object) categoryAxis20);
        java.awt.Font font26 = labelBlock17.getFont();
        java.lang.Object obj27 = labelBlock17.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-4503480));
        java.lang.Object obj2 = null;
        boolean boolean3 = valueMarker1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        int int5 = stackedAreaRenderer1.getPassCount();
        java.lang.Class<?> wildcardClass6 = stackedAreaRenderer1.getClass();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 5, (java.lang.Number) 1.0f, (java.lang.Number) 100, (java.lang.Number) 1.0E-8d, (java.lang.Number) 0.4d, (java.lang.Number) 2, (java.lang.Number) (-459), (java.lang.Number) (byte) 10, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMaxRegularValue();
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo();
        boolean boolean13 = boxAndWhiskerItem10.equals((java.lang.Object) projectInfo12);
        projectInfo12.addOptionalLibrary("GradientPaintTransformType.VERTICAL");
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2 + "'", number11.equals(2));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        double double6 = ringPlot5.getInnerSeparatorExtension();
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot5.setLabelShadowPaint(paint7);
        ringPlot5.setShadowXOffset(0.2d);
        java.awt.Stroke stroke11 = ringPlot5.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        double double19 = ringPlot18.getInnerSeparatorExtension();
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot18.setLabelShadowPaint(paint20);
        stackedAreaRenderer13.setBaseOutlinePaint(paint20, false);
        ringPlot5.setNoDataMessagePaint(paint20);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot5.setLegendItemShape(shape25);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        stackedAreaRenderer28.setBaseOutlinePaint(paint34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer28.setBasePaint((java.awt.Paint) color36, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint42 = statisticalBarRenderer39.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer44 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedAreaRenderer44.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double48 = itemLabelPosition47.getAngle();
        statisticalBarRenderer39.setBasePositiveItemLabelPosition(itemLabelPosition47);
        statisticalBarRenderer39.setIncludeBaseInRange(true);
        boolean boolean52 = statisticalBarRenderer39.getBaseSeriesVisible();
        java.awt.Stroke stroke53 = statisticalBarRenderer39.getBaseStroke();
        java.awt.Font font57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke60 = categoryAxis59.getTickMarkStroke();
        categoryAxis59.setAxisLineVisible(true);
        java.awt.Paint paint63 = categoryAxis59.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock64 = org.jfree.chart.text.TextUtilities.createTextBlock("", font57, paint63);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint68 = statisticalBarRenderer65.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock69 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font57, paint68);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer70 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint73 = statisticalBarRenderer70.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer70.setMinimumBarLength((double) (short) 100);
        java.awt.Color color78 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke81 = categoryAxis80.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color78, stroke81);
        statisticalBarRenderer70.setSeriesPaint((int) '4', (java.awt.Paint) color78);
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font57, (java.awt.Paint) color78);
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("WMAP_Plot", "CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP", "{0}", "30-June-2019", shape25, (java.awt.Paint) color36, stroke53, (java.awt.Paint) color78);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer86 = legendItem85.getFillPaintTransformer();
        org.jfree.data.Range range89 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str90 = range89.toString();
        double double91 = range89.getCentralValue();
        org.jfree.data.time.DateRange dateRange92 = new org.jfree.data.time.DateRange(range89);
        java.util.Date date93 = dateRange92.getUpperDate();
        legendItem85.setSeriesKey((java.lang.Comparable) date93);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(textBlock64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(textBlock69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(gradientPaintTransformer86);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "Range[0.0,0.0]" + "'", str90.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertNotNull(date93);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearRangeMarkers(15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        plotRenderingInfo6.setPlotArea(rectangle2D7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        plotRenderingInfo6.setDataArea(rectangle2D9);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo12.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        plotRenderingInfo15.setPlotArea(rectangle2D16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo15);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis20.setMarkerBand(markerAxisBand23);
        boolean boolean25 = plotRenderingInfo13.equals((java.lang.Object) markerAxisBand23);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo13.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str28 = rectangleAnchor27.toString();
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        xYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D29);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis33.setNegativeArrowVisible(true);
        numberAxis33.setFixedAutoRange((double) '#');
        org.jfree.data.RangeType rangeType38 = org.jfree.data.RangeType.FULL;
        numberAxis33.setRangeType(rangeType38);
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis33, true);
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace42);
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation46 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation45, plotOrientation46);
        xYPlot0.setRangeAxisLocation((int) ' ', axisLocation45);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleAnchor.TOP" + "'", str28.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNotNull(rangeType38);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(plotOrientation46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearAnnotations();
        boolean boolean3 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = xYPlot0.getRangeAxisEdge((int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot0.getRendererForDataset(xYDataset6);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNull(xYItemRenderer7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        stackedAreaRenderer1.setSeriesVisible(100, (java.lang.Boolean) false, false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("RangeType.FULL");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("RangeType.FULL");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("RangeType.FULL");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) 0);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis4.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis4.getMarkerBand();
        boolean boolean8 = meanAndStandardDeviation2.equals((java.lang.Object) numberAxis4);
        java.awt.Shape shape9 = numberAxis4.getLeftArrow();
        java.io.ObjectOutputStream objectOutputStream10 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape9, objectOutputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent2);
        java.lang.String str4 = waferMapPlot1.getPlotType();
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot1.setDataset(waferMapDataset5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) plotOrientation3);
        taskSeriesCollection0.seriesChanged(seriesChangeEvent4);
        try {
            org.jfree.data.gantt.TaskSeries taskSeries7 = taskSeriesCollection0.getSeries(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
        org.junit.Assert.assertNotNull(plotOrientation3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("255", "2019", "Range[0.0,0.0]", "ClassContext", "UnitType.ABSOLUTE");
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        java.awt.Paint paint10 = categoryMarker9.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker9);
        org.jfree.chart.plot.Marker marker12 = markerChangeEvent11.getMarker();
        org.jfree.chart.plot.Marker marker13 = markerChangeEvent11.getMarker();
        org.jfree.chart.JFreeChart jFreeChart14 = markerChangeEvent11.getChart();
        java.lang.Object obj15 = markerChangeEvent11.getSource();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(marker12);
        org.junit.Assert.assertNotNull(marker13);
        org.junit.Assert.assertNull(jFreeChart14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getBackgroundPaint();
        java.awt.Shape shape6 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint10 = statisticalBarRenderer7.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer7.setMinimumBarLength((double) (short) 100);
        java.awt.Paint paint13 = statisticalBarRenderer7.getBaseItemLabelPaint();
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("VerticalAlignment.BOTTOM", "", "ChartChangeEventType.NEW_DATASET", "poly", shape6, paint13);
        textTitle0.setPaint(paint13);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = textTitle0.arrange(graphics2D16, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot1.getFixedRangeAxisSpace();
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) categoryPlot1);
        java.lang.Object obj6 = keyedObjects0.getObject((-1));
        java.lang.Object obj8 = keyedObjects0.getObject(4);
        java.util.List list9 = keyedObjects0.getKeys();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(list9);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test021");
//        java.awt.Image image4 = null;
//        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image4, "hi!", "", "");
//        java.lang.String str9 = projectInfo8.getCopyright();
//        org.jfree.data.KeyedObject keyedObject10 = new org.jfree.data.KeyedObject((java.lang.Comparable) "Range[0.0,0.0]", (java.lang.Object) str9);
//        java.lang.Object obj11 = keyedObject10.clone();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int13 = segmentedTimeline12.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot14);
//        jFreeChart15.removeLegend();
//        jFreeChart15.clearSubtitles();
//        boolean boolean18 = segmentedTimeline12.equals((java.lang.Object) jFreeChart15);
//        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long20 = segmentedTimeline12.getTime(date19);
//        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        java.util.Date date23 = month22.getEnd();
//        boolean boolean24 = segmentedTimeline12.containsDomainRange(date21, date23);
//        int int25 = segmentedTimeline12.getGroupSegmentCount();
//        java.util.List list26 = segmentedTimeline12.getExceptionSegments();
//        keyedObject10.setObject((java.lang.Object) segmentedTimeline12);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(segmentedTimeline12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560179855055L + "'", long20 == 1560179855055L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
//        org.junit.Assert.assertNotNull(list26);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.plot.Plot plot4 = categoryAxis1.getPlot();
        categoryAxis1.setCategoryLabelPositionOffset((int) ' ');
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        double double8 = ringPlot7.getStartAngle();
        boolean boolean9 = categoryAxis1.hasListener((java.util.EventListener) ringPlot7);
        double double10 = ringPlot7.getShadowXOffset();
        boolean boolean11 = ringPlot7.getIgnoreZeroValues();
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = null;
        boolean boolean2 = standardCategorySeriesLabelGenerator0.equals(obj1);
        java.lang.Object obj3 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) 0);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment2, (double) 1560668399999L, 0.0d);
        flowArrangement8.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        double double4 = ringPlot3.getInnerSeparatorExtension();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot3.setLabelShadowPaint(paint5);
        ringPlot3.setShadowXOffset(0.2d);
        java.awt.Stroke stroke9 = ringPlot3.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer11.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot(pieDataset15);
        double double17 = ringPlot16.getInnerSeparatorExtension();
        java.awt.Paint paint18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setLabelShadowPaint(paint18);
        stackedAreaRenderer11.setBaseOutlinePaint(paint18, false);
        ringPlot3.setNoDataMessagePaint(paint18);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace24 = xYPlot23.getFixedRangeAxisSpace();
        xYPlot23.clearAnnotations();
        boolean boolean26 = xYPlot23.isDomainZeroBaselineVisible();
        java.awt.Paint paint27 = xYPlot23.getDomainTickBandPaint();
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint29 = lineBorder28.getPaint();
        java.awt.Stroke stroke30 = lineBorder28.getStroke();
        xYPlot23.setDomainZeroBaselineStroke(stroke30);
        java.awt.Paint paint32 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint36 = statisticalBarRenderer33.getItemFillPaint(0, (int) '#');
        java.awt.Stroke stroke38 = statisticalBarRenderer33.lookupSeriesOutlineStroke(0);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, (double) '4', paint18, stroke30, paint32, stroke38, (float) (byte) 1);
        intervalMarker40.setEndValue((double) 86400000L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.setLabelToolTip("");
        boolean boolean9 = categoryAxis6.isAxisLineVisible();
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis6);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getColumnRenderingOrder();
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        double double13 = ringPlot12.getInnerSeparatorExtension();
        java.awt.Paint paint14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot12.setLabelShadowPaint(paint14);
        ringPlot12.setShadowXOffset(0.2d);
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot12.setLabelOutlinePaint(paint18);
        categoryPlot0.setDomainGridlinePaint(paint18);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis2.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis2.setMarkerBand(markerAxisBand5);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        java.awt.Font font8 = numberAxis2.getTickLabelFont();
        boolean boolean9 = shapeList0.equals((java.lang.Object) numberAxis2);
        shapeList0.clear();
        java.awt.Shape shape12 = shapeList0.getShape(8);
        java.lang.Number[] numberArray16 = new java.lang.Number[] {};
        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
        java.lang.Number[] numberArray18 = new java.lang.Number[] {};
        java.lang.Number[] numberArray19 = new java.lang.Number[] {};
        java.lang.Number[] numberArray20 = new java.lang.Number[] {};
        java.lang.Number[] numberArray21 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray16, numberArray17, numberArray18, numberArray19, numberArray20, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis26.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis26.setMarkerBand(markerAxisBand29);
        org.jfree.data.Range range31 = numberAxis26.getDefaultAutoRange();
        boolean boolean32 = numberAxis26.isAutoRange();
        numberAxis26.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer35 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        boolean boolean39 = ringPlot37.equals((java.lang.Object) 'a');
        java.awt.Paint paint41 = null;
        ringPlot37.setSectionOutlinePaint((java.lang.Comparable) 'a', paint41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke45 = categoryAxis44.getTickMarkStroke();
        categoryAxis44.setAxisLineVisible(true);
        java.awt.Paint paint48 = categoryAxis44.getAxisLinePaint();
        java.awt.Font font49 = categoryAxis44.getLabelFont();
        ringPlot37.setLabelFont(font49);
        levelRenderer35.setSeriesItemLabelFont(0, font49);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D24, (org.jfree.chart.axis.ValueAxis) numberAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer35);
        java.awt.Shape shape53 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.clone(shape53);
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape53, (double) (-1), (float) (byte) 100, 1.0f);
        levelRenderer35.setBaseShape(shape58);
        shapeList0.setShape(3, shape58);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(shape58);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 10.0d, (double) (-1), rectangleAnchor3);
        double double5 = size2D0.height;
        double double6 = size2D0.width;
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        waterfallBarRenderer0.setItemMargin(1.559372400008E12d);
        java.awt.Paint paint3 = null;
        try {
            waterfallBarRenderer0.setFirstBarPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(100);
        java.lang.String str2 = serialDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getPreviousDayOfWeek(7);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.awt.Color color2 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint6 = statisticalBarRenderer3.getItemFillPaint(0, (int) '#');
        java.awt.Stroke stroke8 = statisticalBarRenderer3.lookupSeriesOutlineStroke(0);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 1, (java.awt.Paint) color2, stroke8);
        java.lang.String str10 = color2.toString();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str10.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        double double7 = ringPlot6.getInnerSeparatorExtension();
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot6.setLabelShadowPaint(paint8);
        stackedAreaRenderer1.setBaseOutlinePaint(paint8, false);
        stackedAreaRenderer1.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean15 = stackedAreaRenderer1.getSeriesVisible((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedAreaRenderer1.getBaseNegativeItemLabelPosition();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer1.getPositiveItemLabelPosition(11, 255);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(500);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-338) + "'", int1 == (-338));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, (double) 100.0f);
        boolean boolean4 = stackedBarRenderer3D2.isSeriesVisibleInLegend(0);
        double double5 = stackedBarRenderer3D2.getXOffset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RangeType.FULL");
        taskSeries1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener3);
        java.util.List list5 = taskSeries1.getTasks();
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.setAxisLineVisible(true);
        java.awt.Paint paint7 = categoryAxis3.getAxisLinePaint();
        stackedAreaRenderer1.setBaseOutlinePaint(paint7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color9, false);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis13.setMinimumDate(date14);
        dateAxis13.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.Timeline timeline19 = null;
        dateAxis13.setTimeline(timeline19);
        dateAxis13.setRangeWithMargins((double) (short) 100, (double) 100L);
        org.jfree.data.Range range26 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range29 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str30 = range29.toString();
        org.jfree.data.Range range31 = org.jfree.data.Range.combine(range26, range29);
        dateAxis13.setRange(range29);
        org.jfree.data.Range range35 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range38 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range41 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str42 = range41.toString();
        org.jfree.data.Range range43 = org.jfree.data.Range.combine(range38, range41);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint(range35, range41);
        dateAxis13.setRangeWithMargins(range41, false, true);
        boolean boolean48 = stackedAreaRenderer1.equals((java.lang.Object) range41);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Range[0.0,0.0]" + "'", str30.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Range[0.0,0.0]" + "'", str42.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getMiddleMillisecond();
        org.jfree.data.KeyToGroupMap keyToGroupMap3 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) month1);
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("ChartChangeEventType.NEW_DATASET", (org.jfree.data.time.TimePeriod) month1);
        task4.setPercentComplete((java.lang.Double) 0.2d);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) (-4503480), (int) (short) -1, (int) '4');
        try {
            segmentedTimeline0.setBaseTimeline(segmentedTimeline7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: baseTimeline.getSegmentSize() is smaller than segmentSize");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 2);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis3.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis3.setMarkerBand(markerAxisBand6);
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        java.awt.Font font9 = numberAxis3.getTickLabelFont();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis11.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis11.setMarkerBand(markerAxisBand14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis11.getTickUnit();
        numberAxis3.setTickUnit(numberTickUnit17);
        java.lang.String str20 = numberTickUnit17.valueToString((double) 255);
        try {
            org.jfree.chart.axis.TickUnit tickUnit21 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "255" + "'", str20.equals("255"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke9 = categoryAxis8.getTickMarkStroke();
        categoryAxis8.setAxisLineVisible(true);
        java.awt.Paint paint12 = categoryAxis8.getAxisLinePaint();
        java.awt.Font font13 = categoryAxis8.getLabelFont();
        ringPlot1.setLabelFont(font13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        ringPlot1.setBaseSectionOutlinePaint((java.awt.Paint) color15);
        boolean boolean17 = stackedBarRenderer3D0.equals((java.lang.Object) ringPlot1);
        java.awt.Stroke stroke18 = ringPlot1.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        int int16 = color11.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font9, (java.awt.Paint) color11);
        java.awt.Paint paint18 = labelBlock17.getPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis20.setAxisLineVisible(true);
        categoryAxis20.setCategoryLabelPositionOffset(7);
        boolean boolean25 = labelBlock17.equals((java.lang.Object) categoryAxis20);
        java.awt.Font font26 = labelBlock17.getFont();
        labelBlock17.setURLText("TextBlockAnchor.CENTER_LEFT");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        java.awt.Paint paint10 = categoryMarker9.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryMarker9.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = categoryMarker9.getLabelAnchor();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        blockContainer15.setPadding(rectangleInsets16);
        java.lang.Object obj18 = blockContainer15.clone();
        boolean boolean19 = categoryMarker9.equals((java.lang.Object) blockContainer15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot1.setLabelShadowPaint(paint3);
        ringPlot1.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        categoryPlot0.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation(100);
        boolean boolean12 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke15 = categoryAxis14.getTickMarkStroke();
        categoryAxis14.setAxisLineVisible(true);
        java.util.List list18 = categoryPlot0.getCategoriesForAxis(categoryAxis14);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(list18);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test050");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
//        jFreeChart3.removeLegend();
//        jFreeChart3.clearSubtitles();
//        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long8 = segmentedTimeline0.getTime(date7);
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.util.Date date11 = month10.getEnd();
//        boolean boolean12 = segmentedTimeline0.containsDomainRange(date9, date11);
//        int int13 = segmentedTimeline0.getGroupSegmentCount();
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment15 = segmentedTimeline0.getSegment(1561964399999L);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560179855055L + "'", long8 == 1560179855055L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
//        org.junit.Assert.assertNotNull(segment15);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        java.awt.Stroke stroke2 = lineBorder0.getStroke();
        java.awt.Paint paint3 = lineBorder0.getPaint();
        java.awt.Stroke stroke4 = lineBorder0.getStroke();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        ringPlot6.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        ringPlot6.setDataset(pieDataset9);
        ringPlot6.setNoDataMessage("255");
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint14 = lineBorder13.getPaint();
        java.awt.Stroke stroke15 = lineBorder13.getStroke();
        java.awt.Paint paint16 = lineBorder13.getPaint();
        ringPlot6.setBaseSectionOutlinePaint(paint16);
        boolean boolean18 = lineBorder0.equals((java.lang.Object) ringPlot6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        dateAxis1.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.Timeline timeline7 = null;
        dateAxis1.setTimeline(timeline7);
        dateAxis1.resizeRange(0.0d, (double) 0);
        try {
            boolean boolean13 = dateAxis1.isHiddenValue(172800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        boolean boolean3 = taskSeriesCollection0.equals((java.lang.Object) projectInfo2);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isLowFarOut();
        org.jfree.chart.renderer.Outlier outlier2 = null;
        boolean boolean3 = outlierListCollection0.add(outlier2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(Double.NEGATIVE_INFINITY, 100.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.setAxisLineVisible(true);
        java.awt.Paint paint7 = categoryAxis3.getAxisLinePaint();
        stackedAreaRenderer1.setBaseOutlinePaint(paint7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer1.setBasePaint((java.awt.Paint) color9, false);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        double double14 = ringPlot13.getInnerSeparatorExtension();
        java.awt.Paint paint15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot13.setLabelShadowPaint(paint15);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot17);
        jFreeChart18.removeLegend();
        jFreeChart18.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart18.getLegend(3);
        ringPlot13.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart18);
        boolean boolean24 = stackedAreaRenderer1.equals((java.lang.Object) jFreeChart18);
        jFreeChart18.setBorderVisible(false);
        java.awt.RenderingHints renderingHints27 = jFreeChart18.getRenderingHints();
        jFreeChart18.setBackgroundImageAlpha((float) 500);
        try {
            org.jfree.chart.title.Title title31 = jFreeChart18.getSubtitle(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(legendTitle22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(renderingHints27);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str3 = range2.toString();
        double double4 = range2.getCentralValue();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) range2);
        double double6 = range2.getLowerBound();
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range2, (double) 24234L);
        double double9 = range2.getLowerBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 4.0d, (java.lang.Number) (-4503480));
        defaultKeyedValue2.setValue((java.lang.Number) 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[] numberArray16 = new java.lang.Number[] {};
        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray12, numberArray13, numberArray14, numberArray15, numberArray16, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray18);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray8, numberArray18);
        java.util.List list21 = defaultIntervalCategoryDataset20.getColumnKeys();
        int int23 = defaultIntervalCategoryDataset20.getSeriesIndex((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        try {
            java.lang.Comparable comparable25 = defaultIntervalCategoryDataset20.getSeriesKey((-338));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No such series : -338");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        boolean boolean7 = numberAxis1.isAutoRange();
        numberAxis1.resizeRange((double) 1559372400000L);
        boolean boolean10 = numberAxis1.getAutoRangeStickyZero();
        numberAxis1.setLowerBound((double) (short) 10);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearAnnotations();
        boolean boolean3 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Paint paint4 = xYPlot0.getDomainTickBandPaint();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockFrame blockFrame8 = blockContainer7.getFrame();
        blockContainer6.add((org.jfree.chart.block.Block) blockContainer7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = chartRenderingInfo10.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo12.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        plotRenderingInfo13.setPlotArea(rectangle2D14);
        plotRenderingInfo11.addSubplotInfo(plotRenderingInfo13);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis18.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = null;
        numberAxis18.setMarkerBand(markerAxisBand21);
        boolean boolean23 = plotRenderingInfo11.equals((java.lang.Object) markerAxisBand21);
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo11.getDataArea();
        blockContainer7.setBounds(rectangle2D24);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection34 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list35 = taskSeriesCollection34.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem36 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 5, (java.lang.Number) 1.0f, (java.lang.Number) 100, (java.lang.Number) 1.0E-8d, (java.lang.Number) 0.4d, (java.lang.Number) 2, (java.lang.Number) (-459), (java.lang.Number) (byte) 10, list35);
        xYPlot0.drawDomainTickBands(graphics2D5, rectangle2D24, list35);
        org.jfree.chart.axis.AxisLocation axisLocation39 = null;
        xYPlot0.setRangeAxisLocation(1, axisLocation39);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(blockFrame8);
        org.junit.Assert.assertNotNull(plotRenderingInfo11);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = chartRenderingInfo3.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        plotRenderingInfo4.setPlotArea(rectangle2D5);
        plotRenderingInfo2.addSubplotInfo(plotRenderingInfo4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis9.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis9.setMarkerBand(markerAxisBand12);
        boolean boolean14 = plotRenderingInfo2.equals((java.lang.Object) markerAxisBand12);
        boolean boolean15 = textLine0.equals((java.lang.Object) boolean14);
        org.jfree.chart.text.TextFragment textFragment16 = textLine0.getFirstTextFragment();
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(plotRenderingInfo4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(textFragment16);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("VerticalAlignment.BOTTOM");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis3.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis3.setMarkerBand(markerAxisBand6);
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        numberAxis3D1.setDefaultAutoRange(range8);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleAnchor.TOP");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedAreaRenderer5.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double9 = itemLabelPosition8.getAngle();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition8);
        statisticalBarRenderer0.setIncludeBaseInRange(true);
        boolean boolean15 = statisticalBarRenderer0.getItemCreateEntity(12, 0);
        java.awt.Paint paint17 = statisticalBarRenderer0.lookupSeriesOutlinePaint(0);
        double double18 = statisticalBarRenderer0.getLowerClip();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot1.getFixedRangeAxisSpace();
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) categoryPlot1);
        categoryPlot1.setBackgroundAlpha((float) (short) -1);
        java.lang.String str7 = categoryPlot1.getPlotType();
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range5 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range8 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str9 = range8.toString();
        org.jfree.data.Range range10 = org.jfree.data.Range.combine(range5, range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range2, range8);
        double double12 = range2.getLowerBound();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Range[0.0,0.0]" + "'", str9.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis10.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis10.setMarkerBand(markerAxisBand13);
        org.jfree.data.Range range15 = numberAxis10.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis10.getTickUnit();
        categoryPlot0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (-4503480));
        org.jfree.chart.util.Layer layer20 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker19, layer20);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(numberTickUnit16);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.awt.Color color1 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        java.awt.Font font6 = valueMarker5.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor7 = valueMarker5.getLabelTextAnchor();
        double double8 = valueMarker5.getValue();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment11, (double) (byte) 1, (double) 0);
        org.jfree.chart.block.FlowArrangement flowArrangement17 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment11, (double) 1560668399999L, 0.0d);
        boolean boolean18 = valueMarker5.equals((java.lang.Object) flowArrangement17);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        double double7 = numberAxis1.getUpperBound();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        legendTitle3.removeChangeListener(titleChangeListener4);
        java.awt.Paint paint6 = legendTitle3.getBackgroundPaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer8.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        java.awt.Paint paint14 = stackedAreaRenderer8.getItemOutlinePaint(4, (int) '#');
        legendTitle3.setItemPaint(paint14);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis2.getCategoryEnd((int) ' ', (-459), rectangle2D6, rectangleEdge7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis2.getLabelInsets();
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        categoryAxis2.addChangeListener(axisChangeListener10);
        float float12 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        java.awt.Font font13 = categoryAxis2.getLabelFont();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer15 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedAreaRenderer15.getPositiveItemLabelPosition((int) (short) 10, 1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        stackedAreaRenderer15.notifyListeners(rendererChangeEvent19);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot(pieDataset21);
        double double23 = ringPlot22.getInnerSeparatorExtension();
        java.awt.Image image24 = ringPlot22.getBackgroundImage();
        java.awt.Paint paint25 = ringPlot22.getBaseSectionPaint();
        stackedAreaRenderer15.setBaseItemLabelPaint(paint25, false);
        java.awt.Paint paint28 = stackedAreaRenderer15.getBaseItemLabelPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer31 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock32 = org.jfree.chart.text.TextUtilities.createTextBlock("ChartChangeEventType.NEW_DATASET", font13, paint28, (float) 4, (int) (short) 0, textMeasurer31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint3 = lineBorder2.getPaint();
        java.awt.Stroke stroke4 = lineBorder2.getStroke();
        categoryPlot1.setDomainGridlineStroke(stroke4);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer6 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer6.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = levelRenderer6.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = levelRenderer6.getBaseItemLabelGenerator();
        categoryPlot1.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer6, false);
        boolean boolean13 = categoryPlot1.isRangeZoomable();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis16.setMinimumDate(date17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection20 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list21 = taskSeriesCollection20.getColumnKeys();
        int int23 = taskSeriesCollection20.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable24 = null;
        org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection20, comparable24);
        org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection20, (java.lang.Comparable) 255);
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) serialDate19, (org.jfree.data.KeyedValues) pieDataset27);
        categoryPlot1.setDataset(0, categoryDataset28);
        boolean boolean30 = defaultDrawingSupplier0.equals((java.lang.Object) categoryDataset28);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(pieDataset25);
        org.junit.Assert.assertNotNull(pieDataset27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = lineRenderer3D0.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setDomainAxisLocation(1900, axisLocation16);
        java.awt.Stroke stroke18 = categoryPlot14.getRangeCrosshairStroke();
        categoryPlot14.setAnchorValue((double) 1560179855055L);
        int int21 = categoryPlot14.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis23.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = numberAxis23.getMarkerBand();
        java.awt.Shape shape27 = numberAxis23.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        lineRenderer3D0.drawRangeGridline(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) numberAxis23, rectangle2D28, (double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis32.setMinimumDate(date33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date33);
        java.lang.String str36 = serialDate35.getDescription();
        boolean boolean37 = categoryPlot14.equals((java.lang.Object) serialDate35);
        categoryPlot14.clearRangeAxes();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(markerAxisBand26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        java.awt.Paint paint4 = null;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 'a', paint4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke8 = categoryAxis7.getTickMarkStroke();
        categoryAxis7.setAxisLineVisible(true);
        java.awt.Paint paint11 = categoryAxis7.getAxisLinePaint();
        java.awt.Font font12 = categoryAxis7.getLabelFont();
        ringPlot0.setLabelFont(font12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean17 = ringPlot0.equals((java.lang.Object) stroke16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearAnnotations();
        boolean boolean3 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[] numberArray16 = new java.lang.Number[] {};
        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray12, numberArray13, numberArray14, numberArray15, numberArray16, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray18);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray8, numberArray18);
        java.util.List list21 = defaultIntervalCategoryDataset20.getColumnKeys();
        int int23 = defaultIntervalCategoryDataset20.getSeriesIndex((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        try {
            java.lang.Number number26 = defaultIntervalCategoryDataset20.getEndValue(11, (-338));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        boolean boolean12 = lineRenderer3D0.getAutoPopulateSeriesPaint();
        lineRenderer3D0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot2.setDomainAxisLocation(1900, axisLocation4);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer8 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer8.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = levelRenderer8.getBaseURLGenerator();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator16 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "RectangleAnchor.TOP", "hi!");
        levelRenderer8.setSeriesURLGenerator(6, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = levelRenderer8.getBasePositiveItemLabelPosition();
        stackedAreaRenderer7.setBasePositiveItemLabelPosition(itemLabelPosition18, false);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockFrame blockFrame23 = blockContainer22.getFrame();
        blockContainer21.add((org.jfree.chart.block.Block) blockContainer22);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = chartRenderingInfo25.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = chartRenderingInfo27.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        plotRenderingInfo28.setPlotArea(rectangle2D29);
        plotRenderingInfo26.addSubplotInfo(plotRenderingInfo28);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis33.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis33.setMarkerBand(markerAxisBand36);
        boolean boolean38 = plotRenderingInfo26.equals((java.lang.Object) markerAxisBand36);
        java.awt.geom.Rectangle2D rectangle2D39 = plotRenderingInfo26.getDataArea();
        blockContainer22.setBounds(rectangle2D39);
        stackedAreaRenderer7.setBaseShape((java.awt.Shape) rectangle2D39);
        try {
            lineRenderer3D0.drawBackground(graphics2D1, categoryPlot2, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(blockFrame23);
        org.junit.Assert.assertNotNull(plotRenderingInfo26);
        org.junit.Assert.assertNotNull(plotRenderingInfo28);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth(255, (double) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        layeredBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("WMAP_Plot", graphics2D1, (float) 11, (float) (short) 0, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        double double7 = ringPlot6.getInnerSeparatorExtension();
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot6.setLabelShadowPaint(paint8);
        stackedAreaRenderer1.setBaseOutlinePaint(paint8, false);
        stackedAreaRenderer1.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = statisticalBarRenderer14.getToolTipGenerator((int) (byte) 10, (int) (short) -1);
        java.awt.Paint paint18 = statisticalBarRenderer14.getErrorIndicatorPaint();
        stackedAreaRenderer1.setBaseFillPaint(paint18);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        java.awt.Color color3 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke6);
        org.jfree.chart.util.Layer layer8 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker7, layer8);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long6 = segmentedTimeline3.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline3.getSegment(date8);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (java.lang.Comparable) date8);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(segment9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue(205, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 205, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = lineRenderer3D0.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setDomainAxisLocation(1900, axisLocation16);
        java.awt.Stroke stroke18 = categoryPlot14.getRangeCrosshairStroke();
        categoryPlot14.setAnchorValue((double) 1560179855055L);
        int int21 = categoryPlot14.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis23.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = numberAxis23.getMarkerBand();
        java.awt.Shape shape27 = numberAxis23.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        lineRenderer3D0.drawRangeGridline(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) numberAxis23, rectangle2D28, (double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis32.setMinimumDate(date33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date33);
        java.lang.String str36 = serialDate35.getDescription();
        boolean boolean37 = categoryPlot14.equals((java.lang.Object) serialDate35);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        categoryPlot14.setFixedDomainAxisSpace(axisSpace38);
        java.lang.String str40 = categoryPlot14.getPlotType();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(markerAxisBand26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Category Plot" + "'", str40.equals("Category Plot"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setBaseCreateEntities(true);
        stackedAreaRenderer1.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Paint paint8 = stackedAreaRenderer1.lookupSeriesOutlinePaint((int) 'a');
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[] numberArray16 = new java.lang.Number[] {};
        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray12, numberArray13, numberArray14, numberArray15, numberArray16, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray18);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray8, numberArray18);
        int int21 = defaultIntervalCategoryDataset20.getColumnCount();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        categoryPlot0.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation(100);
        categoryPlot0.mapDatasetToRangeAxis(0, 2);
        categoryPlot0.setAnchorValue((double) (-864000000L));
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint2 = lineBorder1.getPaint();
        java.awt.Stroke stroke3 = lineBorder1.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = chartRenderingInfo8.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = chartRenderingInfo10.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        plotRenderingInfo11.setPlotArea(rectangle2D12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo11);
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomRangeAxes((double) 3600000L, plotRenderingInfo9, point2D15);
        int int17 = plotRenderingInfo9.getSubplotCount();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(plotRenderingInfo9);
        org.junit.Assert.assertNotNull(plotRenderingInfo11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) '#');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        numberAxis1.setRightArrow(shape6);
        java.lang.Object obj9 = numberAxis1.clone();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) plotOrientation6);
        taskSeriesCollection0.seriesChanged(seriesChangeEvent7);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(plotOrientation6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        double double6 = ringPlot5.getInnerSeparatorExtension();
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot5.setLabelShadowPaint(paint7);
        ringPlot5.setShadowXOffset(0.2d);
        java.awt.Stroke stroke11 = ringPlot5.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        double double19 = ringPlot18.getInnerSeparatorExtension();
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot18.setLabelShadowPaint(paint20);
        stackedAreaRenderer13.setBaseOutlinePaint(paint20, false);
        ringPlot5.setNoDataMessagePaint(paint20);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot5.setLegendItemShape(shape25);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        stackedAreaRenderer28.setBaseOutlinePaint(paint34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer28.setBasePaint((java.awt.Paint) color36, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint42 = statisticalBarRenderer39.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer44 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedAreaRenderer44.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double48 = itemLabelPosition47.getAngle();
        statisticalBarRenderer39.setBasePositiveItemLabelPosition(itemLabelPosition47);
        statisticalBarRenderer39.setIncludeBaseInRange(true);
        boolean boolean52 = statisticalBarRenderer39.getBaseSeriesVisible();
        java.awt.Stroke stroke53 = statisticalBarRenderer39.getBaseStroke();
        java.awt.Font font57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke60 = categoryAxis59.getTickMarkStroke();
        categoryAxis59.setAxisLineVisible(true);
        java.awt.Paint paint63 = categoryAxis59.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock64 = org.jfree.chart.text.TextUtilities.createTextBlock("", font57, paint63);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint68 = statisticalBarRenderer65.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock69 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font57, paint68);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer70 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint73 = statisticalBarRenderer70.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer70.setMinimumBarLength((double) (short) 100);
        java.awt.Color color78 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke81 = categoryAxis80.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color78, stroke81);
        statisticalBarRenderer70.setSeriesPaint((int) '4', (java.awt.Paint) color78);
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font57, (java.awt.Paint) color78);
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("WMAP_Plot", "CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP", "{0}", "30-June-2019", shape25, (java.awt.Paint) color36, stroke53, (java.awt.Paint) color78);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer86 = legendItem85.getFillPaintTransformer();
        boolean boolean87 = legendItem85.isLineVisible();
        java.text.AttributedString attributedString88 = legendItem85.getAttributedLabel();
        legendItem85.setSeriesIndex((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(textBlock64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(textBlock69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(gradientPaintTransformer86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNull(attributedString88);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, (double) 100.0f);
        boolean boolean4 = stackedBarRenderer3D2.isSeriesVisibleInLegend(0);
        double double5 = stackedBarRenderer3D2.getYOffset();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 5, (java.lang.Number) 1.0f, (java.lang.Number) 100, (java.lang.Number) 1.0E-8d, (java.lang.Number) 0.4d, (java.lang.Number) 2, (java.lang.Number) (-459), (java.lang.Number) (byte) 10, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMaxRegularValue();
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo();
        boolean boolean13 = boxAndWhiskerItem10.equals((java.lang.Object) projectInfo12);
        java.lang.Number number14 = boxAndWhiskerItem10.getMaxOutlier();
        java.lang.Number number15 = boxAndWhiskerItem10.getMedian();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2 + "'", number11.equals(2));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (byte) 10 + "'", number14.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0f + "'", number15.equals(1.0f));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot0.markerChanged(markerChangeEvent7);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator7 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "RectangleAnchor.TOP", "hi!");
        levelRenderer0.setSeriesURLGenerator((int) '4', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator7, true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, (double) 100.0f);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D14 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, (java.awt.Paint) color19);
        lineRenderer3D14.setWallPaint((java.awt.Paint) color19);
        stackedBarRenderer3D13.setWallPaint((java.awt.Paint) color19);
        levelRenderer0.setSeriesItemLabelPaint(11, (java.awt.Paint) color19);
        boolean boolean25 = levelRenderer0.isSeriesVisible(10);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = levelRenderer0.getBaseURLGenerator();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        categoryAxis5.setAxisLineVisible(true);
        java.awt.Paint paint9 = categoryAxis5.getAxisLinePaint();
        java.awt.Font font10 = categoryAxis5.getLabelFont();
        levelRenderer0.setBaseItemLabelFont(font10);
        java.awt.Color color13 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke16 = categoryAxis15.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke16);
        java.awt.Font font18 = valueMarker17.getLabelFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) valueMarker17);
        org.jfree.chart.JFreeChart jFreeChart20 = rendererChangeEvent19.getChart();
        levelRenderer0.notifyListeners(rendererChangeEvent19);
        levelRenderer0.setMaximumItemWidth(0.0d);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(jFreeChart20);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setMinimumDate(date6);
        dateAxis5.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.Timeline timeline11 = null;
        dateAxis5.setTimeline(timeline11);
        dateAxis5.setRangeWithMargins((double) (short) 100, (double) 100L);
        org.jfree.data.Range range18 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str19 = range18.toString();
        dateAxis5.setRange(range18);
        categoryPlot0.setRangeAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) dateAxis5, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = categoryAxis25.getCategoryEnd((int) ' ', (-459), rectangle2D29, rectangleEdge30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryAxis25.getLabelInsets();
        java.awt.Paint paint34 = categoryAxis25.getTickLabelPaint((java.lang.Comparable) 1L);
        try {
            categoryPlot0.setDomainAxis((int) (byte) -1, categoryAxis25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[0.0,0.0]" + "'", str19.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint2 = lineBorder1.getPaint();
        java.awt.Stroke stroke3 = lineBorder1.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxisForDataset(0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RangeType.FULL");
        taskSeries1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        taskSeries1.addPropertyChangeListener(propertyChangeListener3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        taskSeries1.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = null;
        try {
            taskSeries1.setKey(comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint4 = statisticalBarRenderer1.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer1.setMinimumBarLength((double) (short) 100);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke12);
        statisticalBarRenderer1.setSeriesPaint((int) '4', (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D16 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, (java.awt.Paint) color21);
        lineRenderer3D16.setWallPaint((java.awt.Paint) color21);
        statisticalBarRenderer1.setSeriesPaint(0, (java.awt.Paint) color21, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = statisticalBarRenderer1.getPlot();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = chartRenderingInfo30.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = chartRenderingInfo32.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        plotRenderingInfo33.setPlotArea(rectangle2D34);
        plotRenderingInfo31.addSubplotInfo(plotRenderingInfo33);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis38.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = null;
        numberAxis38.setMarkerBand(markerAxisBand41);
        boolean boolean43 = plotRenderingInfo31.equals((java.lang.Object) markerAxisBand41);
        java.awt.geom.Rectangle2D rectangle2D44 = plotRenderingInfo31.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = null;
        java.awt.geom.Point2D point2D47 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D45, rectangleAnchor46);
        categoryPlot0.zoomDomainAxes((double) '4', 10.0d, plotRenderingInfo31, point2D47);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection50 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number51 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection50);
        categoryPlot0.setDataset(1900, (org.jfree.data.category.CategoryDataset) taskSeriesCollection50);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke55 = categoryAxis54.getTickMarkStroke();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor56 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        boolean boolean57 = categoryAxis54.equals((java.lang.Object) itemLabelAnchor56);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline58 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int59 = segmentedTimeline58.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot60 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart61 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot60);
        jFreeChart61.removeLegend();
        jFreeChart61.clearSubtitles();
        boolean boolean64 = segmentedTimeline58.equals((java.lang.Object) jFreeChart61);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment66 = segmentedTimeline58.getSegment(0L);
        segment66.dec((long) (short) 10);
        categoryAxis54.removeCategoryLabelToolTip((java.lang.Comparable) segment66);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis71.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand74 = null;
        numberAxis71.setMarkerBand(markerAxisBand74);
        org.jfree.data.Range range76 = numberAxis71.getDefaultAutoRange();
        boolean boolean77 = numberAxis71.isAutoRange();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer78 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer78.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint81 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer78.setErrorIndicatorPaint(paint81);
        java.lang.Boolean boolean84 = statisticalBarRenderer78.getSeriesCreateEntities((int) (short) 1);
        java.awt.Paint paint86 = statisticalBarRenderer78.lookupSeriesFillPaint(10);
        org.jfree.chart.plot.CategoryPlot categoryPlot87 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection50, categoryAxis54, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer78);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(categoryPlot26);
        org.junit.Assert.assertNotNull(plotRenderingInfo31);
        org.junit.Assert.assertNotNull(plotRenderingInfo33);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(rectangle2D44);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 0.0d + "'", number51.equals(0.0d));
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(itemLabelAnchor56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 7 + "'", int59 == 7);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(segment66);
        org.junit.Assert.assertNotNull(range76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNull(boolean84);
        org.junit.Assert.assertNotNull(paint86);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean4 = ringPlot2.equals((java.lang.Object) 'a');
        ringPlot2.setForegroundAlpha((float) (short) -1);
        ringPlot2.setSectionDepth((double) 255);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer9 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer9.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = levelRenderer9.getBaseURLGenerator();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke15 = categoryAxis14.getTickMarkStroke();
        categoryAxis14.setAxisLineVisible(true);
        java.awt.Paint paint18 = categoryAxis14.getAxisLinePaint();
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        levelRenderer9.setBaseItemLabelFont(font19);
        ringPlot2.setNoDataMessageFont(font19);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font19);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) paint23);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("RectangleAnchor.CENTER", font19, paint23);
        org.jfree.chart.text.TextFragment textFragment26 = textLine25.getFirstTextFragment();
        java.awt.Paint paint27 = textFragment26.getPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(textFragment26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean6 = ringPlot4.equals((java.lang.Object) 'a');
        java.awt.Paint paint8 = null;
        ringPlot4.setSectionOutlinePaint((java.lang.Comparable) 'a', paint8);
        ringPlot4.setPieIndex((int) ' ');
        java.awt.Font font12 = ringPlot4.getLabelFont();
        statisticalBarRenderer0.setSeriesItemLabelFont((int) (byte) 100, font12, true);
        java.awt.Shape shape16 = statisticalBarRenderer0.lookupSeriesShape(7);
        boolean boolean19 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 1, 11);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list2 = taskSeriesCollection1.getColumnKeys();
        int int4 = taskSeriesCollection1.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection1, comparable5);
        double double7 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset6);
        boolean boolean8 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) pieDataset6);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis11.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis11.setMarkerBand(markerAxisBand14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        java.awt.Font font17 = numberAxis11.getTickLabelFont();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis19.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis19.setMarkerBand(markerAxisBand22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = numberAxis19.getTickUnit();
        numberAxis11.setTickUnit(numberTickUnit25);
        java.lang.String str28 = numberTickUnit25.valueToString((double) 255);
        java.lang.Number number29 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) "Pie 3D Plot", (java.lang.Comparable) str28);
        try {
            java.util.List list32 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((-338), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(numberTickUnit25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "255" + "'", str28.equals("255"));
        org.junit.Assert.assertNull(number29);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        java.awt.Shape shape7 = numberAxis1.getDownArrow();
        numberAxis1.setUpperMargin(10.0d);
        double double10 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image3, "hi!", "", "");
        projectInfo7.setName("Range[0.0,0.0]");
        java.lang.String str10 = projectInfo7.getName();
        java.lang.String str11 = projectInfo7.getLicenceName();
        projectInfo7.setInfo("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.String str14 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Range[0.0,0.0]" + "'", str10.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        java.lang.Object obj3 = defaultKeyedValues2D1.clone();
        defaultKeyedValues2D1.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int4 = month2.compareTo((java.lang.Object) "cyan");
        defaultKeyedValues2D0.removeValue((java.lang.Comparable) 10.0d, (java.lang.Comparable) month2);
        java.util.List list6 = defaultKeyedValues2D0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        numberAxis1.setAutoRangeStickyZero(true);
        boolean boolean8 = numberAxis1.isVisible();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot1.setLabelShadowPaint(paint3);
        ringPlot1.setShadowXOffset(0.2d);
        java.awt.Paint paint7 = ringPlot1.getBackgroundPaint();
        ringPlot1.setOuterSeparatorExtension((double) (-1.0f));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer10.setAutoPopulateSeriesStroke(true);
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[] numberArray16 = new java.lang.Number[] {};
        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
        java.lang.Number[] numberArray18 = new java.lang.Number[] {};
        java.lang.Number[] numberArray19 = new java.lang.Number[] {};
        java.lang.Number[] numberArray20 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray15, numberArray16, numberArray17, numberArray18, numberArray19, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray21);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis25.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis25.setMarkerBand(markerAxisBand28);
        org.jfree.data.Range range30 = numberAxis25.getDefaultAutoRange();
        boolean boolean31 = numberAxis25.isAutoRange();
        numberAxis25.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer34 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        boolean boolean38 = ringPlot36.equals((java.lang.Object) 'a');
        java.awt.Paint paint40 = null;
        ringPlot36.setSectionOutlinePaint((java.lang.Comparable) 'a', paint40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke44 = categoryAxis43.getTickMarkStroke();
        categoryAxis43.setAxisLineVisible(true);
        java.awt.Paint paint47 = categoryAxis43.getAxisLinePaint();
        java.awt.Font font48 = categoryAxis43.getLabelFont();
        ringPlot36.setLabelFont(font48);
        levelRenderer34.setSeriesItemLabelFont(0, font48);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, (org.jfree.chart.axis.ValueAxis) numberAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer34);
        org.jfree.chart.util.SortOrder sortOrder52 = categoryPlot51.getRowRenderingOrder();
        java.awt.Stroke stroke53 = categoryPlot51.getRangeCrosshairStroke();
        java.awt.Paint paint54 = categoryPlot51.getRangeCrosshairPaint();
        statisticalBarRenderer10.setErrorIndicatorPaint(paint54);
        ringPlot1.setSeparatorPaint(paint54);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(sortOrder52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Range[0.0,0.0] version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY Range[0.0,0.0]:None\nRange[0.0,0.0] LICENCE TERMS:\n");
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        java.awt.Stroke stroke3 = ringPlot2.getSeparatorStroke();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) ringPlot2);
        ringPlot2.setSeparatorsVisible(false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockFrame blockFrame1 = blockContainer0.getFrame();
        double double2 = blockContainer0.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockContainer0.getPadding();
        org.jfree.data.gantt.TaskSeries taskSeries5 = new org.jfree.data.gantt.TaskSeries("RangeType.FULL");
        boolean boolean6 = rectangleInsets3.equals((java.lang.Object) "RangeType.FULL");
        org.junit.Assert.assertNotNull(blockFrame1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart3.removeLegend();
        jFreeChart3.clearSubtitles();
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline0.getSegment(0L);
        segment8.dec((long) (short) 10);
        long long11 = segment8.getSegmentStart();
        long long12 = segment8.getSegmentEnd();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-950399990L) + "'", long11 == (-950399990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-863999991L) + "'", long12 == (-863999991L));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis1.getTickUnit();
        java.awt.Font font8 = numberAxis1.getTickLabelFont();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis10.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis10.setMarkerBand(markerAxisBand13);
        org.jfree.data.Range range15 = numberAxis10.getDefaultAutoRange();
        java.awt.Font font16 = numberAxis10.getTickLabelFont();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis18.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = null;
        numberAxis18.setMarkerBand(markerAxisBand21);
        org.jfree.data.Range range23 = numberAxis18.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = numberAxis18.getTickUnit();
        numberAxis10.setTickUnit(numberTickUnit24);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D26 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder(rectangleInsets27, (java.awt.Paint) color31);
        lineRenderer3D26.setWallPaint((java.awt.Paint) color31);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = lineRenderer3D26.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem37 = lineRenderer3D26.getLegendItem(10, 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator38 = lineRenderer3D26.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot40.setDomainAxisLocation(1900, axisLocation42);
        java.awt.Stroke stroke44 = categoryPlot40.getRangeCrosshairStroke();
        categoryPlot40.setAnchorValue((double) 1560179855055L);
        int int47 = categoryPlot40.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis49.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand52 = numberAxis49.getMarkerBand();
        java.awt.Shape shape53 = numberAxis49.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        lineRenderer3D26.drawRangeGridline(graphics2D39, categoryPlot40, (org.jfree.chart.axis.ValueAxis) numberAxis49, rectangle2D54, (double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date59 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis58.setMinimumDate(date59);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date59);
        java.lang.String str62 = serialDate61.getDescription();
        boolean boolean63 = categoryPlot40.equals((java.lang.Object) serialDate61);
        org.jfree.chart.axis.AxisSpace axisSpace64 = null;
        categoryPlot40.setFixedDomainAxisSpace(axisSpace64);
        int int66 = numberTickUnit24.compareTo((java.lang.Object) categoryPlot40);
        numberAxis1.setTickUnit(numberTickUnit24);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(categoryToolTipGenerator34);
        org.junit.Assert.assertNull(legendItem37);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator38);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNull(markerAxisBand52);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        piePlot0.removeChangeListener(plotChangeListener1);
        piePlot0.setExplodePercent((java.lang.Comparable) 1900, 0.2d);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) piePlot0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        boolean boolean7 = numberAxis1.isAutoRange();
        numberAxis1.resizeRange((double) 1559372400000L);
        boolean boolean10 = numberAxis1.getAutoRangeStickyZero();
        java.awt.Shape shape11 = numberAxis1.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis13.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis13.setMarkerBand(markerAxisBand16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        java.awt.Font font19 = numberAxis13.getTickLabelFont();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis21.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis21.setMarkerBand(markerAxisBand24);
        org.jfree.data.Range range26 = numberAxis21.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = numberAxis21.getTickUnit();
        numberAxis13.setTickUnit(numberTickUnit27);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D29 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color34 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder(rectangleInsets30, (java.awt.Paint) color34);
        lineRenderer3D29.setWallPaint((java.awt.Paint) color34);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = lineRenderer3D29.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem40 = lineRenderer3D29.getLegendItem(10, 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator41 = lineRenderer3D29.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot43.setDomainAxisLocation(1900, axisLocation45);
        java.awt.Stroke stroke47 = categoryPlot43.getRangeCrosshairStroke();
        categoryPlot43.setAnchorValue((double) 1560179855055L);
        int int50 = categoryPlot43.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis52.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = numberAxis52.getMarkerBand();
        java.awt.Shape shape56 = numberAxis52.getDownArrow();
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        lineRenderer3D29.drawRangeGridline(graphics2D42, categoryPlot43, (org.jfree.chart.axis.ValueAxis) numberAxis52, rectangle2D57, (double) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date62 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis61.setMinimumDate(date62);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date62);
        java.lang.String str65 = serialDate64.getDescription();
        boolean boolean66 = categoryPlot43.equals((java.lang.Object) serialDate64);
        org.jfree.chart.axis.AxisSpace axisSpace67 = null;
        categoryPlot43.setFixedDomainAxisSpace(axisSpace67);
        int int69 = numberTickUnit27.compareTo((java.lang.Object) categoryPlot43);
        org.jfree.data.KeyedObjects keyedObjects70 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot71.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace73 = categoryPlot71.getFixedRangeAxisSpace();
        boolean boolean74 = keyedObjects70.equals((java.lang.Object) categoryPlot71);
        categoryPlot71.setBackgroundAlpha((float) (short) -1);
        org.jfree.data.general.DatasetGroup datasetGroup77 = categoryPlot71.getDatasetGroup();
        boolean boolean78 = numberTickUnit27.equals((java.lang.Object) datasetGroup77);
        numberAxis1.setTickUnit(numberTickUnit27);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(numberTickUnit27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
        org.junit.Assert.assertNull(legendItem40);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator41);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNull(markerAxisBand55);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNull(axisSpace73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(datasetGroup77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Color color6 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint10 = statisticalBarRenderer7.getItemFillPaint(0, (int) '#');
        java.awt.Stroke stroke12 = statisticalBarRenderer7.lookupSeriesOutlineStroke(0);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 1, (java.awt.Paint) color6, stroke12);
        stackedAreaRenderer2.setSeriesPaint(0, (java.awt.Paint) color6, false);
        float[] floatArray22 = new float[] { 205, 1560668399999L, 6, 4, 7, (short) 1 };
        float[] floatArray23 = color6.getColorComponents(floatArray22);
        keyedObjects0.setObject((java.lang.Comparable) 1.0E-8d, (java.lang.Object) floatArray23);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.Number[] numberArray1 = new java.lang.Number[] { 0.4d };
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 0.4d };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 0.4d };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 0.4d };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0.4d };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray1, numberArray3, numberArray5, numberArray7, numberArray9 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[] numberArray16 = new java.lang.Number[] {};
        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
        java.lang.Number[] numberArray18 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray13, numberArray14, numberArray15, numberArray16, numberArray17, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray19);
        java.lang.Number[] numberArray23 = new java.lang.Number[] {};
        java.lang.Number[] numberArray24 = new java.lang.Number[] {};
        java.lang.Number[] numberArray25 = new java.lang.Number[] {};
        java.lang.Number[] numberArray26 = new java.lang.Number[] {};
        java.lang.Number[] numberArray27 = new java.lang.Number[] {};
        java.lang.Number[] numberArray28 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray23, numberArray24, numberArray25, numberArray26, numberArray27, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray29);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset31 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray19, numberArray29);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset32 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray10, numberArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.lang.Boolean boolean5 = lineRenderer3D0.getSeriesVisibleInLegend(1900);
        lineRenderer3D0.setAutoPopulateSeriesPaint(true);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(1900, axisLocation11);
        java.awt.Stroke stroke13 = categoryPlot9.getRangeCrosshairStroke();
        categoryPlot9.setAnchorValue((double) 1560179855055L);
        int int16 = categoryPlot9.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis18.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = null;
        numberAxis18.setMarkerBand(markerAxisBand21);
        org.jfree.data.Range range23 = numberAxis18.getDefaultAutoRange();
        boolean boolean24 = numberAxis18.isAutoRange();
        numberAxis18.setNegativeArrowVisible(false);
        java.awt.Paint paint28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color33 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke34 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint28, stroke29, (java.awt.Paint) color33, stroke34, 1.0f);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        lineRenderer3D0.drawRangeMarker(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis18, (org.jfree.chart.plot.Marker) categoryMarker36, rectangle2D37);
        lineRenderer3D0.setSeriesShapesVisible(0, false);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator43 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.Object obj44 = standardCategoryToolTipGenerator43.clone();
        java.lang.String str45 = standardCategoryToolTipGenerator43.getLabelFormat();
        lineRenderer3D0.setSeriesToolTipGenerator(5, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator43, true);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "({0}, {1}) = {2}" + "'", str45.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        categoryAxis5.setAxisLineVisible(true);
        java.awt.Paint paint9 = categoryAxis5.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, paint9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint14 = statisticalBarRenderer11.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font3, paint14);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint19 = statisticalBarRenderer16.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer16.setMinimumBarLength((double) (short) 100);
        java.awt.Color color24 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke27 = categoryAxis26.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color24, stroke27);
        statisticalBarRenderer16.setSeriesPaint((int) '4', (java.awt.Paint) color24);
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font3, (java.awt.Paint) color24);
        labelBlock30.setToolTipText("Range[0.0,0.0]");
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int3 = segmentedTimeline2.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot4);
        jFreeChart5.removeLegend();
        jFreeChart5.clearSubtitles();
        boolean boolean8 = segmentedTimeline2.equals((java.lang.Object) jFreeChart5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline2.getSegment(0L);
        segment10.dec((long) (short) 10);
        boolean boolean13 = segment10.inExcludeSegments();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        int int16 = year14.getYear();
        defaultCategoryDataset0.addValue(number1, (java.lang.Comparable) segment10, (java.lang.Comparable) int16);
        int int19 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 5);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis12.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis12.setMarkerBand(markerAxisBand15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        boolean boolean18 = numberAxis12.isAutoRange();
        numberAxis12.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer21 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean25 = ringPlot23.equals((java.lang.Object) 'a');
        java.awt.Paint paint27 = null;
        ringPlot23.setSectionOutlinePaint((java.lang.Comparable) 'a', paint27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        java.awt.Font font35 = categoryAxis30.getLabelFont();
        ringPlot23.setLabelFont(font35);
        levelRenderer21.setSeriesItemLabelFont(0, font35);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer21);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot38.getRowRenderingOrder();
        categoryPlot38.setDrawSharedDomainAxis(true);
        org.jfree.chart.text.TextAnchor textAnchor44 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.NumberTick numberTick47 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0f, "Range[0.0,0.0]", textAnchor44, textAnchor45, (double) 10);
        boolean boolean48 = categoryPlot38.equals((java.lang.Object) 10);
        categoryPlot38.configureDomainAxes();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double53 = rectangleInsets51.calculateRightInset((double) 1L);
        double double55 = rectangleInsets51.extendHeight((double) 1559372400000L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = chartRenderingInfo56.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = chartRenderingInfo58.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        plotRenderingInfo59.setPlotArea(rectangle2D60);
        plotRenderingInfo57.addSubplotInfo(plotRenderingInfo59);
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis64.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand67 = null;
        numberAxis64.setMarkerBand(markerAxisBand67);
        boolean boolean69 = plotRenderingInfo57.equals((java.lang.Object) markerAxisBand67);
        java.awt.geom.Rectangle2D rectangle2D70 = plotRenderingInfo57.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str72 = rectangleAnchor71.toString();
        java.awt.geom.Point2D point2D73 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D70, rectangleAnchor71);
        java.awt.geom.Rectangle2D rectangle2D74 = rectangleInsets51.createInsetRectangle(rectangle2D70);
        try {
            categoryPlot38.drawBackground(graphics2D50, rectangle2D74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(textAnchor44);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 8.0d + "'", double53 == 8.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.559372400008E12d + "'", double55 == 1.559372400008E12d);
        org.junit.Assert.assertNotNull(plotRenderingInfo57);
        org.junit.Assert.assertNotNull(plotRenderingInfo59);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "RectangleAnchor.TOP" + "'", str72.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D73);
        org.junit.Assert.assertNotNull(rectangle2D74);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        categoryPlot0.setRangeCrosshairValue(1.0E-5d, false);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis9.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis9.setMarkerBand(markerAxisBand12);
        org.jfree.data.Range range14 = numberAxis9.getDefaultAutoRange();
        numberAxis9.centerRange((double) 1559372400000L);
        categoryPlot0.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis9, false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        xYPlot0.setDataset(0, xYDataset2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long7 = segmentedTimeline4.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline4.getSegment(date9);
        int int11 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) segment10);
        try {
            java.lang.Number number14 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 1900, (java.lang.Comparable) 1560179855055L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryPlot0.markerChanged(markerChangeEvent7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart3.removeLegend();
        jFreeChart3.clearSubtitles();
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = chartRenderingInfo11.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        plotRenderingInfo12.setPlotArea(rectangle2D13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        plotRenderingInfo12.setDataArea(rectangle2D15);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        double double18 = categoryItemRendererState17.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection19 = categoryItemRendererState17.getEntityCollection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        try {
            java.awt.image.BufferedImage bufferedImage22 = jFreeChart3.createBufferedImage(0, (int) (byte) 100, (-1.0d), (double) 255, chartRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (100) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection19);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dataPackageResources0);
        java.util.Set<java.lang.String> strSet2 = dataPackageResources0.keySet();
        java.lang.Object obj4 = dataPackageResources0.handleGetObject("Category Plot");
        try {
            java.lang.String str6 = dataPackageResources0.getString("PlotOrientation.HORIZONTAL");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key PlotOrientation.HORIZONTAL");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = levelRenderer0.getBaseURLGenerator();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator8 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "RectangleAnchor.TOP", "hi!");
        levelRenderer0.setSeriesURLGenerator(6, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        levelRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator10, true);
        boolean boolean13 = levelRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = ganttRenderer0.getPositiveItemLabelPositionFallback();
        ganttRenderer0.setMaximumBarWidth((double) 100.0f);
        java.awt.Paint paint6 = ganttRenderer0.getCompletePaint();
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) 6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint2 = lineBorder1.getPaint();
        java.awt.Stroke stroke3 = lineBorder1.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer5 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer5.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = levelRenderer5.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = levelRenderer5.getBaseItemLabelGenerator();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer5, false);
        boolean boolean12 = categoryPlot0.isRangeZoomable();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke17 = categoryAxis16.getTickMarkStroke();
        ringPlot14.setLabelLinkStroke(stroke17);
        double double19 = ringPlot14.getShadowYOffset();
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        boolean boolean22 = ringPlot20.equals((java.lang.Object) 'a');
        java.awt.Paint paint24 = null;
        ringPlot20.setSectionOutlinePaint((java.lang.Comparable) 'a', paint24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke28 = categoryAxis27.getTickMarkStroke();
        categoryAxis27.setAxisLineVisible(true);
        java.awt.Paint paint31 = categoryAxis27.getAxisLinePaint();
        java.awt.Font font32 = categoryAxis27.getLabelFont();
        ringPlot20.setLabelFont(font32);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot20);
        ringPlot14.notifyListeners(plotChangeEvent34);
        categoryPlot0.notifyListeners(plotChangeEvent34);
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape38);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity42 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-459), shape38, "", "RectangleAnchor.TOP");
        java.lang.String str43 = categoryLabelEntity42.getShapeType();
        boolean boolean44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) plotChangeEvent34, (java.lang.Object) categoryLabelEntity42);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryURLGenerator8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "poly" + "'", str43.equals("poly"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryEnd((int) ' ', (-459), rectangle2D5, rectangleEdge6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot8);
        jFreeChart9.removeLegend();
        jFreeChart9.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart9.getLegend(3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str15 = chartChangeEventType14.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ' ', jFreeChart9, chartChangeEventType14);
        jFreeChart9.fireChartChanged();
        jFreeChart9.setTitle("TextAnchor.CENTER");
        java.awt.Image image20 = jFreeChart9.getBackgroundImage();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        boolean boolean23 = ringPlot21.equals((java.lang.Object) 'a');
        java.awt.Paint paint25 = null;
        ringPlot21.setSectionOutlinePaint((java.lang.Comparable) 'a', paint25);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        categoryAxis28.setAxisLineVisible(true);
        java.awt.Paint paint32 = categoryAxis28.getAxisLinePaint();
        java.awt.Font font33 = categoryAxis28.getLabelFont();
        ringPlot21.setLabelFont(font33);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent35 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        jFreeChart9.plotChanged(plotChangeEvent35);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str15.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getBackgroundPaint();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot2.getLegendItems();
        java.awt.Image image4 = null;
        piePlot2.setBackgroundImage(image4);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        java.awt.Color color10 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint14 = statisticalBarRenderer11.getItemFillPaint(0, (int) '#');
        java.awt.Stroke stroke16 = statisticalBarRenderer11.lookupSeriesOutlineStroke(0);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 1, (java.awt.Paint) color10, stroke16);
        stackedAreaRenderer6.setSeriesPaint(0, (java.awt.Paint) color10, false);
        piePlot2.setOutlinePaint((java.awt.Paint) color10);
        textTitle0.setPaint((java.awt.Paint) color10);
        java.awt.Font font22 = textTitle0.getFont();
        org.jfree.chart.axis.AxisCollection axisCollection23 = new org.jfree.chart.axis.AxisCollection();
        boolean boolean24 = textTitle0.equals((java.lang.Object) axisCollection23);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) 255);
        java.lang.Class<?> wildcardClass4 = taskSeriesCollection0.getClass();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int7 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) 2019L);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearAnnotations();
        boolean boolean3 = xYPlot0.isDomainZeroBaselineVisible();
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[] numberArray8 = new java.lang.Number[] {};
        java.lang.Number[] numberArray9 = new java.lang.Number[] {};
        java.lang.Number[] numberArray10 = new java.lang.Number[] {};
        java.lang.Number[] numberArray11 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray7, numberArray8, numberArray9, numberArray10, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray12);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis16.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis16.setMarkerBand(markerAxisBand19);
        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
        boolean boolean22 = numberAxis16.isAutoRange();
        numberAxis16.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer25 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        boolean boolean29 = ringPlot27.equals((java.lang.Object) 'a');
        java.awt.Paint paint31 = null;
        ringPlot27.setSectionOutlinePaint((java.lang.Comparable) 'a', paint31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke35 = categoryAxis34.getTickMarkStroke();
        categoryAxis34.setAxisLineVisible(true);
        java.awt.Paint paint38 = categoryAxis34.getAxisLinePaint();
        java.awt.Font font39 = categoryAxis34.getLabelFont();
        ringPlot27.setLabelFont(font39);
        levelRenderer25.setSeriesItemLabelFont(0, font39);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer25);
        int int43 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis16);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = chartRenderingInfo3.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        plotRenderingInfo4.setPlotArea(rectangle2D5);
        plotRenderingInfo2.addSubplotInfo(plotRenderingInfo4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis9.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis9.setMarkerBand(markerAxisBand12);
        boolean boolean14 = plotRenderingInfo2.equals((java.lang.Object) markerAxisBand12);
        boolean boolean15 = textLine0.equals((java.lang.Object) boolean14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = textLine0.calculateDimensions(graphics2D16);
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(plotRenderingInfo4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(size2D17);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart3.removeLegend();
        jFreeChart3.clearSubtitles();
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline0.getSegment(0L);
        long long10 = segment8.calculateSegmentNumber((-864000000L));
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-11L) + "'", long10 == (-11L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long6 = segmentedTimeline3.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline3.getSegment(date8);
        boolean boolean10 = segment9.inIncludeSegments();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        boolean boolean13 = ringPlot11.equals((java.lang.Object) 'a');
        java.awt.Paint paint15 = null;
        ringPlot11.setSectionOutlinePaint((java.lang.Comparable) 'a', paint15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setAxisLineVisible(true);
        java.awt.Paint paint22 = categoryAxis18.getAxisLinePaint();
        java.awt.Font font23 = categoryAxis18.getLabelFont();
        ringPlot11.setLabelFont(font23);
        boolean boolean25 = segment9.equals((java.lang.Object) font23);
        defaultKeyedValues2D1.addValue((java.lang.Number) 1, (java.lang.Comparable) segment9, (java.lang.Comparable) (-1L));
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[] numberArray16 = new java.lang.Number[] {};
        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray12, numberArray13, numberArray14, numberArray15, numberArray16, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray18);
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray8, numberArray18);
        try {
            java.lang.Comparable comparable22 = defaultIntervalCategoryDataset20.getColumnKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearRangeMarkers(15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        plotRenderingInfo6.setPlotArea(rectangle2D7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        plotRenderingInfo6.setDataArea(rectangle2D9);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo12.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        plotRenderingInfo15.setPlotArea(rectangle2D16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo15);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis20.setMarkerBand(markerAxisBand23);
        boolean boolean25 = plotRenderingInfo13.equals((java.lang.Object) markerAxisBand23);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo13.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str28 = rectangleAnchor27.toString();
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        xYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D29);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot(pieDataset31);
        ringPlot32.setOutlineVisible(true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer36 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = stackedAreaRenderer36.getPositiveItemLabelPosition((int) (short) 10, 1);
        java.awt.Stroke stroke40 = stackedAreaRenderer36.getBaseStroke();
        ringPlot32.setSeparatorStroke(stroke40);
        xYPlot0.setRangeCrosshairStroke(stroke40);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        xYPlot0.setDataset((int) (short) 1, xYDataset44);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray46 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setDomainAxes(valueAxisArray46);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleAnchor.TOP" + "'", str28.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(valueAxisArray46);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNotNull(timeZone0);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test154");
//        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
//        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
//        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
//        java.lang.Number[] numberArray12 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray13 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray16 = new java.lang.Number[] {};
//        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
//        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray12, numberArray13, numberArray14, numberArray15, numberArray16, numberArray17 };
//        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray18);
//        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray8, numberArray18);
//        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis22.setMinimumDate(date23);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
//        java.lang.String str26 = serialDate25.toString();
//        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis28.setMinimumDate(date29);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
//        org.jfree.data.time.SerialDate serialDate32 = serialDate25.getEndOfCurrentMonth(serialDate31);
//        int int33 = defaultIntervalCategoryDataset20.getColumnIndex((java.lang.Comparable) serialDate32);
//        org.junit.Assert.assertNotNull(numberArray2);
//        org.junit.Assert.assertNotNull(numberArray3);
//        org.junit.Assert.assertNotNull(numberArray4);
//        org.junit.Assert.assertNotNull(numberArray5);
//        org.junit.Assert.assertNotNull(numberArray6);
//        org.junit.Assert.assertNotNull(numberArray7);
//        org.junit.Assert.assertNotNull(numberArray8);
//        org.junit.Assert.assertNotNull(categoryDataset9);
//        org.junit.Assert.assertNotNull(numberArray12);
//        org.junit.Assert.assertNotNull(numberArray13);
//        org.junit.Assert.assertNotNull(numberArray14);
//        org.junit.Assert.assertNotNull(numberArray15);
//        org.junit.Assert.assertNotNull(numberArray16);
//        org.junit.Assert.assertNotNull(numberArray17);
//        org.junit.Assert.assertNotNull(numberArray18);
//        org.junit.Assert.assertNotNull(categoryDataset19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(7, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth(255, (double) '4');
        boolean boolean4 = layeredBarRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        layeredBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator6, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart3.removeLegend();
        jFreeChart3.clearSubtitles();
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline0.getSegment(0L);
        java.util.List list9 = segmentedTimeline0.getExceptionSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearRangeMarkers(15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        plotRenderingInfo6.setPlotArea(rectangle2D7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        plotRenderingInfo6.setDataArea(rectangle2D9);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo12.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        plotRenderingInfo15.setPlotArea(rectangle2D16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo15);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis20.setMarkerBand(markerAxisBand23);
        boolean boolean25 = plotRenderingInfo13.equals((java.lang.Object) markerAxisBand23);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo13.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str28 = rectangleAnchor27.toString();
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        xYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D29);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis33.setNegativeArrowVisible(true);
        numberAxis33.setFixedAutoRange((double) '#');
        org.jfree.data.RangeType rangeType38 = org.jfree.data.RangeType.FULL;
        numberAxis33.setRangeType(rangeType38);
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis33, true);
        java.awt.Paint paint42 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleAnchor.TOP" + "'", str28.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNotNull(rangeType38);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot(pieDataset4);
        double double6 = ringPlot5.getInnerSeparatorExtension();
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot5.setLabelShadowPaint(paint7);
        ringPlot5.setShadowXOffset(0.2d);
        java.awt.Stroke stroke11 = ringPlot5.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        double double19 = ringPlot18.getInnerSeparatorExtension();
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot18.setLabelShadowPaint(paint20);
        stackedAreaRenderer13.setBaseOutlinePaint(paint20, false);
        ringPlot5.setNoDataMessagePaint(paint20);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        ringPlot5.setLegendItemShape(shape25);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        stackedAreaRenderer28.setBaseOutlinePaint(paint34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer28.setBasePaint((java.awt.Paint) color36, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint42 = statisticalBarRenderer39.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer44 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = stackedAreaRenderer44.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double48 = itemLabelPosition47.getAngle();
        statisticalBarRenderer39.setBasePositiveItemLabelPosition(itemLabelPosition47);
        statisticalBarRenderer39.setIncludeBaseInRange(true);
        boolean boolean52 = statisticalBarRenderer39.getBaseSeriesVisible();
        java.awt.Stroke stroke53 = statisticalBarRenderer39.getBaseStroke();
        java.awt.Font font57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke60 = categoryAxis59.getTickMarkStroke();
        categoryAxis59.setAxisLineVisible(true);
        java.awt.Paint paint63 = categoryAxis59.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock64 = org.jfree.chart.text.TextUtilities.createTextBlock("", font57, paint63);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint68 = statisticalBarRenderer65.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock69 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font57, paint68);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer70 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint73 = statisticalBarRenderer70.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer70.setMinimumBarLength((double) (short) 100);
        java.awt.Color color78 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke81 = categoryAxis80.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color78, stroke81);
        statisticalBarRenderer70.setSeriesPaint((int) '4', (java.awt.Paint) color78);
        org.jfree.chart.block.LabelBlock labelBlock84 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font57, (java.awt.Paint) color78);
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("WMAP_Plot", "CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP", "{0}", "30-June-2019", shape25, (java.awt.Paint) color36, stroke53, (java.awt.Paint) color78);
        java.awt.Stroke stroke86 = legendItem85.getOutlineStroke();
        boolean boolean87 = legendItem85.isLineVisible();
        legendItem85.setSeriesIndex((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(textBlock64);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(textBlock69);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getEnd();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        java.awt.Stroke stroke5 = ringPlot4.getSeparatorStroke();
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) month1, stroke5);
        piePlot3D0.setSectionOutlinesVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator9 = null;
        piePlot3D0.setURLGenerator(pieURLGenerator9);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot();
        boolean boolean4 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) waferMapPlot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long7 = segmentedTimeline4.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline4.getSegment(date9);
        int int11 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) segment10);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.Year year15 = month13.getYear();
        try {
            java.lang.Number number16 = taskSeriesCollection0.getStartValue((java.lang.Comparable) (-864000000L), (java.lang.Comparable) month13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
        org.junit.Assert.assertNotNull(year15);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis2.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis2.setMarkerBand(markerAxisBand5);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        java.awt.Font font8 = numberAxis2.getTickLabelFont();
        boolean boolean9 = shapeList0.equals((java.lang.Object) numberAxis2);
        java.awt.Shape shape10 = numberAxis2.getUpArrow();
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("poly");
        java.awt.Font font13 = textFragment12.getFont();
        numberAxis2.setTickLabelFont(font13);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.awt.Color color1 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        java.awt.Font font6 = valueMarker5.getLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint8, stroke9, (java.awt.Paint) color13, stroke14, 1.0f);
        java.awt.Paint paint17 = categoryMarker16.getOutlinePaint();
        categoryMarker16.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = categoryMarker16.getLabelOffsetType();
        valueMarker5.setLabelOffsetType(lengthAdjustmentType20);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement3 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource1, (org.jfree.chart.block.Arrangement) columnArrangement2, (org.jfree.chart.block.Arrangement) centerArrangement3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.removeChangeListener(titleChangeListener5);
        blockContainer0.add((org.jfree.chart.block.Block) legendTitle4);
        java.awt.geom.Rectangle2D rectangle2D8 = legendTitle4.getBounds();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockFrame blockFrame10 = blockContainer9.getFrame();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        blockContainer9.setPadding(rectangleInsets11);
        boolean boolean13 = legendTitle4.equals((java.lang.Object) rectangleInsets11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str15 = rectangleAnchor14.toString();
        legendTitle4.setLegendItemGraphicAnchor(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(blockFrame10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleAnchor.TOP" + "'", str15.equals("RectangleAnchor.TOP"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1559372400000L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 5, (java.lang.Number) 1.0f, (java.lang.Number) 100, (java.lang.Number) 1.0E-8d, (java.lang.Number) 0.4d, (java.lang.Number) 2, (java.lang.Number) (-459), (java.lang.Number) (byte) 10, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMaxRegularValue();
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo();
        boolean boolean13 = boxAndWhiskerItem10.equals((java.lang.Object) projectInfo12);
        java.lang.Number number14 = boxAndWhiskerItem10.getMean();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2 + "'", number11.equals(2));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 5 + "'", number14.equals(5));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 5, (java.lang.Number) 1.0f, (java.lang.Number) 100, (java.lang.Number) 1.0E-8d, (java.lang.Number) 0.4d, (java.lang.Number) 2, (java.lang.Number) (-459), (java.lang.Number) (byte) 10, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMaxRegularValue();
        java.lang.String str12 = boxAndWhiskerItem10.toString();
        java.lang.Number number13 = boxAndWhiskerItem10.getMaxOutlier();
        java.util.List list14 = boxAndWhiskerItem10.getOutliers();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2 + "'", number11.equals(2));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (byte) 10 + "'", number13.equals((byte) 10));
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearRangeMarkers(15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        plotRenderingInfo6.setPlotArea(rectangle2D7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        plotRenderingInfo6.setDataArea(rectangle2D9);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState11 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = chartRenderingInfo12.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = chartRenderingInfo14.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        plotRenderingInfo15.setPlotArea(rectangle2D16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo15);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis20.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis20.setMarkerBand(markerAxisBand23);
        boolean boolean25 = plotRenderingInfo13.equals((java.lang.Object) markerAxisBand23);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo13.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str28 = rectangleAnchor27.toString();
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        xYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo6, point2D29);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis33.setNegativeArrowVisible(true);
        numberAxis33.setFixedAutoRange((double) '#');
        org.jfree.data.RangeType rangeType38 = org.jfree.data.RangeType.FULL;
        numberAxis33.setRangeType(rangeType38);
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis33, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder44 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot43.setRowRenderingOrder(sortOrder44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot43.setDomainAxisLocation(axisLocation46);
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation48, plotOrientation49);
        categoryPlot43.setRangeAxisLocation(axisLocation48, false);
        try {
            xYPlot0.setDomainAxisLocation((-4503480), axisLocation48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
        org.junit.Assert.assertNotNull(plotRenderingInfo13);
        org.junit.Assert.assertNotNull(plotRenderingInfo15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleAnchor.TOP" + "'", str28.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D29);
        org.junit.Assert.assertNotNull(rangeType38);
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) 0);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis4.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis4.getMarkerBand();
        boolean boolean8 = meanAndStandardDeviation2.equals((java.lang.Object) numberAxis4);
        java.awt.Shape shape9 = numberAxis4.getLeftArrow();
        java.awt.Color color10 = java.awt.Color.YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape9, (java.awt.Paint) color10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        legendGraphic11.setOutlineStroke(stroke12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        boolean boolean15 = ringPlot14.getIgnoreNullValues();
        ringPlot14.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        java.awt.Stroke stroke19 = ringPlot14.getLabelLinkStroke();
        legendGraphic11.setOutlineStroke(stroke19);
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        int int12 = lineRenderer3D0.getPassCount();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = ringPlot14.getSectionOutlinesVisible();
        double double16 = ringPlot14.getShadowXOffset();
        boolean boolean17 = lineRenderer3D0.equals((java.lang.Object) ringPlot14);
        boolean boolean20 = lineRenderer3D0.getItemShapeFilled(100, 3);
        boolean boolean21 = lineRenderer3D0.getDrawOutlines();
        java.lang.Object obj22 = lineRenderer3D0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        ringPlot0.setForegroundAlpha((float) (short) -1);
        ringPlot0.setSectionDepth((double) 255);
        double double7 = ringPlot0.getOuterSeparatorExtension();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean11 = ringPlot9.equals((java.lang.Object) 'a');
        java.awt.Paint paint13 = null;
        ringPlot9.setSectionOutlinePaint((java.lang.Comparable) 'a', paint13);
        ringPlot9.setPieIndex((int) ' ');
        java.awt.Font font17 = ringPlot9.getLabelFont();
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = piePlot18.getLegendItems();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = piePlot18.getLegendLabelToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("CategoryLabelEntity: category=0.25, tooltip=, url=", font17, (org.jfree.chart.plot.Plot) piePlot18, true);
        ringPlot0.setLabelFont(font17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNull(pieSectionLabelGenerator20);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D1 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean3 = lineRenderer3D1.getSeriesLinesVisible(100);
        boolean boolean4 = lineRenderer3D1.getBaseShapesVisible();
        java.lang.Boolean boolean6 = lineRenderer3D1.getSeriesVisibleInLegend(1900);
        lineRenderer3D1.setAutoPopulateSeriesPaint(true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(1900, axisLocation12);
        java.awt.Stroke stroke14 = categoryPlot10.getRangeCrosshairStroke();
        categoryPlot10.setAnchorValue((double) 1560179855055L);
        int int17 = categoryPlot10.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis19.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis19.setMarkerBand(markerAxisBand22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        boolean boolean25 = numberAxis19.isAutoRange();
        numberAxis19.setNegativeArrowVisible(false);
        java.awt.Paint paint29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color34 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke35 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint29, stroke30, (java.awt.Paint) color34, stroke35, 1.0f);
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        lineRenderer3D1.drawRangeMarker(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.plot.Marker) categoryMarker37, rectangle2D38);
        numberAxis19.configure();
        org.jfree.chart.plot.RingPlot ringPlot42 = new org.jfree.chart.plot.RingPlot();
        boolean boolean44 = ringPlot42.equals((java.lang.Object) 'a');
        java.awt.Paint paint46 = null;
        ringPlot42.setSectionOutlinePaint((java.lang.Comparable) 'a', paint46);
        ringPlot42.setPieIndex((int) ' ');
        java.awt.Font font50 = ringPlot42.getLabelFont();
        java.awt.Color color52 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke55 = categoryAxis54.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color52, stroke55);
        int int57 = color52.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock58 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font50, (java.awt.Paint) color52);
        numberAxis19.setLabelFont(font50);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color64 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder65 = new org.jfree.chart.block.BlockBorder(rectangleInsets60, (java.awt.Paint) color64);
        org.jfree.chart.text.TextFragment textFragment66 = new org.jfree.chart.text.TextFragment("UnitType.ABSOLUTE", font50, (java.awt.Paint) color64);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 255 + "'", int57 == 255);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(color64);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        ringPlot0.setExplodePercent((java.lang.Comparable) regularTimePeriod4, 4.0d);
        org.jfree.chart.util.Rotation rotation7 = null;
        try {
            ringPlot0.setDirection(rotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) 'a', 0L);
        java.util.Date date5 = segmentedTimeline0.getDate(1L);
        long long6 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604800000L + "'", long6 == 604800000L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        dateAxis1.setRange(0.0d, (double) (short) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource7);
        java.util.Date date9 = dateAxis1.getMaximumDate();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test180");
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis2.setMinimumDate(date3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str6 = serialDate5.toString();
//        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis8.setMinimumDate(date9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
//        org.jfree.data.time.SerialDate serialDate12 = serialDate5.getEndOfCurrentMonth(serialDate11);
//        java.lang.String str13 = serialDate12.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate12);
//        serialDate14.setDescription("ThreadContext");
//        try {
//            org.jfree.data.time.SerialDate serialDate18 = serialDate14.getNearestDayOfWeek(1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "30-June-2019" + "'", str13.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) 0);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis4.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis4.getMarkerBand();
        boolean boolean8 = meanAndStandardDeviation2.equals((java.lang.Object) numberAxis4);
        java.awt.Shape shape9 = numberAxis4.getLeftArrow();
        java.awt.Color color10 = java.awt.Color.YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape9, (java.awt.Paint) color10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        double double14 = ringPlot13.getInnerSeparatorExtension();
        java.awt.Paint paint15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot13.setLabelShadowPaint(paint15);
        ringPlot13.setShadowXOffset(0.2d);
        java.awt.Stroke stroke19 = ringPlot13.getSeparatorStroke();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot13.setOutlinePaint((java.awt.Paint) color20);
        java.awt.Shape shape22 = ringPlot13.getLegendItemShape();
        legendGraphic11.setLine(shape22);
        java.awt.Paint paint24 = legendGraphic11.getFillPaint();
        java.awt.Paint paint25 = legendGraphic11.getFillPaint();
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str3 = range2.toString();
        double double4 = range2.getCentralValue();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range2);
        java.util.Date date6 = dateRange5.getUpperDate();
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange5, (double) 0);
        org.jfree.data.Range range10 = org.jfree.data.Range.shift(range8, (double) (short) 1);
        boolean boolean12 = range10.contains((double) 1559372400000L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot3);
        jFreeChart4.removeLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color10 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(rectangleInsets6, (java.awt.Paint) color10);
        double double12 = rectangleInsets6.getRight();
        jFreeChart4.setPadding(rectangleInsets6);
        boolean boolean14 = jFreeChart4.getAntiAlias();
        jFreeChart4.setNotify(true);
        boolean boolean17 = dateAxis1.equals((java.lang.Object) true);
        java.util.Date date18 = dateAxis1.getMaximumDate();
        java.lang.Object obj19 = dateAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot20.setDomainAxisLocation(1900, axisLocation22);
        java.awt.Stroke stroke24 = categoryPlot20.getRangeCrosshairStroke();
        categoryPlot20.setAnchorValue((double) 1560179855055L);
        java.awt.Font font27 = categoryPlot20.getNoDataMessageFont();
        dateAxis1.setTickLabelFont(font27);
        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) '#');
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        numberAxis1.setRightArrow(shape6);
        numberAxis1.setFixedDimension((double) 6);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = xYPlot0.getRangeMarkers((int) (short) 0, layer3);
        java.lang.String str5 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "XY Plot" + "'", str5.equals("XY Plot"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.setLabelToolTip("");
        boolean boolean9 = categoryAxis6.isAxisLineVisible();
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis6);
        double double11 = categoryAxis6.getLabelAngle();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int4 = taskSeriesCollection0.getColumnCount();
        try {
            int int7 = taskSeriesCollection0.getSubIntervalCount((java.lang.Comparable) (byte) 0, (java.lang.Comparable) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis12.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis12.setMarkerBand(markerAxisBand15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        boolean boolean18 = numberAxis12.isAutoRange();
        numberAxis12.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer21 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean25 = ringPlot23.equals((java.lang.Object) 'a');
        java.awt.Paint paint27 = null;
        ringPlot23.setSectionOutlinePaint((java.lang.Comparable) 'a', paint27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        java.awt.Font font35 = categoryAxis30.getLabelFont();
        ringPlot23.setLabelFont(font35);
        levelRenderer21.setSeriesItemLabelFont(0, font35);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer21);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot38.getRowRenderingOrder();
        java.awt.Paint paint41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color46 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke47 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint41, stroke42, (java.awt.Paint) color46, stroke47, 1.0f);
        java.awt.Paint paint50 = categoryMarker49.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent51 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker49);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType52 = categoryMarker49.getLabelOffsetType();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot53 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot53);
        java.awt.Color color56 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke59 = categoryAxis58.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color56, stroke59);
        java.lang.String str61 = org.jfree.chart.util.PaintUtilities.colorToString(color56);
        multiplePiePlot53.setBackgroundPaint((java.awt.Paint) color56);
        categoryMarker49.setOutlinePaint((java.awt.Paint) color56);
        org.jfree.chart.text.TextAnchor textAnchor64 = categoryMarker49.getLabelTextAnchor();
        java.awt.Paint paint65 = categoryMarker49.getOutlinePaint();
        categoryPlot38.addDomainMarker(categoryMarker49);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(lengthAdjustmentType52);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "cyan" + "'", str61.equals("cyan"));
        org.junit.Assert.assertNotNull(textAnchor64);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.2d, "hi!", textAnchor2, textAnchor3, 0.0d);
        double double6 = numberTick5.getValue();
        java.lang.Number number7 = numberTick5.getNumber();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick5.getTextAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.2d + "'", number7.equals(0.2d));
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP");
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getEnd();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        java.awt.Stroke stroke5 = ringPlot4.getSeparatorStroke();
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) month1, stroke5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double10 = rectangleInsets8.calculateRightInset((double) 1L);
        double double12 = rectangleInsets8.extendHeight((double) 1559372400000L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo13.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo15.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        plotRenderingInfo16.setPlotArea(rectangle2D17);
        plotRenderingInfo14.addSubplotInfo(plotRenderingInfo16);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis21.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis21.setMarkerBand(markerAxisBand24);
        boolean boolean26 = plotRenderingInfo14.equals((java.lang.Object) markerAxisBand24);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo14.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str29 = rectangleAnchor28.toString();
        java.awt.geom.Point2D point2D30 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor28);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets8.createInsetRectangle(rectangle2D27);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = null;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        org.jfree.chart.plot.PlotState plotState35 = new org.jfree.chart.plot.PlotState();
        java.util.Map map36 = plotState35.getSharedAxisStates();
        java.util.Map map37 = plotState35.getSharedAxisStates();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = chartRenderingInfo38.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        plotRenderingInfo39.setPlotArea(rectangle2D40);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        plotRenderingInfo39.setDataArea(rectangle2D42);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState44 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo39);
        double double45 = categoryItemRendererState44.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection46 = categoryItemRendererState44.getEntityCollection();
        double double47 = categoryItemRendererState44.getBarWidth();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = categoryItemRendererState44.getInfo();
        try {
            piePlot3D0.draw(graphics2D7, rectangle2D27, point2D34, plotState35, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.0d + "'", double10 == 8.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.559372400008E12d + "'", double12 == 1.559372400008E12d);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleAnchor.TOP" + "'", str29.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertNotNull(map36);
        org.junit.Assert.assertNotNull(map37);
        org.junit.Assert.assertNotNull(plotRenderingInfo39);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(plotRenderingInfo48);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str3 = range2.toString();
        double double4 = range2.getCentralValue();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range2);
        double double6 = dateRange5.getCentralValue();
        java.lang.String str7 = dateRange5.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color4 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color4);
        double double7 = rectangleInsets0.extendHeight((double) 'a');
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets0.getUnitType();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        ringPlot9.setBaseSectionPaint((java.awt.Paint) color10);
        java.awt.Color color12 = color10.darker();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double17 = rectangleInsets15.calculateRightInset((double) 1L);
        double double19 = rectangleInsets15.extendHeight((double) 1559372400000L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo20.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = chartRenderingInfo22.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        plotRenderingInfo23.setPlotArea(rectangle2D24);
        plotRenderingInfo21.addSubplotInfo(plotRenderingInfo23);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis28.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis28.setMarkerBand(markerAxisBand31);
        boolean boolean33 = plotRenderingInfo21.equals((java.lang.Object) markerAxisBand31);
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo21.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str36 = rectangleAnchor35.toString();
        java.awt.geom.Point2D point2D37 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D34, rectangleAnchor35);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets15.createInsetRectangle(rectangle2D34);
        java.awt.geom.AffineTransform affineTransform39 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer41 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke44 = categoryAxis43.getTickMarkStroke();
        categoryAxis43.setAxisLineVisible(true);
        java.awt.Paint paint47 = categoryAxis43.getAxisLinePaint();
        stackedAreaRenderer41.setBaseOutlinePaint(paint47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        stackedAreaRenderer41.setBasePaint((java.awt.Paint) color49, false);
        org.jfree.data.general.PieDataset pieDataset52 = null;
        org.jfree.chart.plot.RingPlot ringPlot53 = new org.jfree.chart.plot.RingPlot(pieDataset52);
        double double54 = ringPlot53.getInnerSeparatorExtension();
        java.awt.Paint paint55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot53.setLabelShadowPaint(paint55);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot57 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart58 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot57);
        jFreeChart58.removeLegend();
        jFreeChart58.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle62 = jFreeChart58.getLegend(3);
        ringPlot53.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart58);
        boolean boolean64 = stackedAreaRenderer41.equals((java.lang.Object) jFreeChart58);
        jFreeChart58.setBorderVisible(false);
        java.awt.RenderingHints renderingHints67 = jFreeChart58.getRenderingHints();
        java.awt.PaintContext paintContext68 = color10.createContext(colorModel13, rectangle14, rectangle2D38, affineTransform39, renderingHints67);
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets0.createInsetRectangle(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.0d + "'", double17 == 8.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.559372400008E12d + "'", double19 == 1.559372400008E12d);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(plotRenderingInfo23);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "RectangleAnchor.TOP" + "'", str36.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertNotNull(point2D37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.2d + "'", double54 == 0.2d);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNull(legendTitle62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(renderingHints67);
        org.junit.Assert.assertNotNull(paintContext68);
        org.junit.Assert.assertNotNull(rectangle2D69);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        org.jfree.chart.entity.EntityCollection entityCollection2 = chartRenderingInfo0.getEntityCollection();
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
        org.junit.Assert.assertNotNull(entityCollection2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment2 = null;
        textLine1.removeFragment(textFragment2);
        org.jfree.chart.text.TextFragment textFragment4 = null;
        textLine1.removeFragment(textFragment4);
        boolean boolean6 = rangeType0.equals((java.lang.Object) textFragment4);
        java.lang.String str7 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RangeType.POSITIVE" + "'", str7.equals("RangeType.POSITIVE"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.setAxisLineVisible(true);
        java.awt.Paint paint7 = categoryAxis3.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = textBlock8.getLineAlignment();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.awt.Shape shape17 = textBlock8.calculateBounds(graphics2D10, (float) 1L, (float) 8, textBlockAnchor13, (float) 100L, (float) (-950399990L), (double) 1);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        textBlock8.draw(graphics2D18, (float) (byte) 100, (-1.0f), textBlockAnchor21);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-459), shape1, "", "RectangleAnchor.TOP");
        java.awt.Shape shape6 = categoryLabelEntity5.getArea();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        legendTitle3.removeChangeListener(titleChangeListener4);
        java.awt.Paint paint6 = legendTitle3.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle3.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle3.getItemLabelPadding();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }
}

