import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = null;
        java.awt.Paint paint9 = null;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Paint paint14 = null;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "", "", "hi!", false, shape5, false, paint7, false, paint9, stroke10, true, shape12, stroke13, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (short) -1, (double) 100.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Paint paint2 = null;
        try {
            categoryAxis1.setTickLabelPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) 0L, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("", font1, paint2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Paint paint0 = null;
        java.awt.Paint paint1 = null;
        boolean boolean2 = org.jfree.chart.util.PaintUtilities.equal(paint0, paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        try {
            org.jfree.data.Range range2 = statisticalBarRenderer0.findRangeBounds(categoryDataset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = null;
        try {
            blockContainer0.setMargin(rectangleInsets1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            blockContainer0.setBounds(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "", categoryDataset3, (java.lang.Comparable) 0.0d, (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        org.jfree.chart.text.TextFragment textFragment3 = null;
        textLine0.removeFragment(textFragment3);
        org.jfree.chart.text.TextFragment textFragment5 = null;
        textLine0.removeFragment(textFragment5);
        try {
            java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) textFragment5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange(range0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setErrorIndicatorPaint(paint3);
        try {
            statisticalBarRenderer0.setSeriesCreateEntities((-1), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        piePlot0.removeChangeListener(plotChangeListener1);
        org.jfree.chart.plot.Plot plot3 = piePlot0.getRootPlot();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            piePlot0.drawOutline(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plot3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 1L, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, 10.0d, (float) (short) 1, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            ringPlot1.drawOutline(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getStartValue((java.lang.Comparable) (-1.0d), (java.lang.Comparable) 10.0d, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        double double3 = lineRenderer3D0.getYOffset();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) 7, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentXOffset();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = blockContainer0.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleAnchor.TOP", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Color color1 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        java.awt.Font font6 = valueMarker5.getLabelFont();
        org.jfree.chart.text.TextAnchor textAnchor7 = valueMarker5.getLabelTextAnchor();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) textAnchor7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection6 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection6);
        int int9 = taskSeriesCollection6.indexOf((java.lang.Comparable) 255);
        boolean boolean10 = categoryAxis1.equals((java.lang.Object) 255);
        java.awt.Paint paint11 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.TOP", graphics2D1, 0.0f, (float) '4', textAnchor4, (double) 10.0f, (float) (short) 100, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke10 = categoryAxis9.getTickMarkStroke();
        ringPlot7.setLabelLinkStroke(stroke10);
        java.awt.Color color12 = java.awt.Color.CYAN;
        try {
            org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "hi!", "Range[0.0,0.0]", "", shape4, paint5, stroke10, (java.awt.Paint) color12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        ringPlot1.setLabelLinkStroke(stroke4);
        ringPlot1.setIgnoreNullValues(true);
        try {
            ringPlot1.setInteriorGap(1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0f);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 10.0f + "'", obj2.equals(10.0f));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = statisticalBarRenderer0.initialise(graphics2D1, rectangle2D2, categoryPlot3, (-459), plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.setAxisLineVisible(true);
        java.awt.Paint paint6 = categoryAxis2.getTickLabelPaint();
        levelRenderer0.setBaseItemLabelPaint(paint6, true);
        java.awt.Font font10 = levelRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState16 = levelRenderer0.initialise(graphics2D11, rectangle2D12, categoryPlot13, (int) (short) 10, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(font10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.setAxisLineVisible(true);
        java.awt.Paint paint6 = categoryAxis2.getAxisLinePaint();
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint8, stroke9, (java.awt.Paint) color13, stroke14, 1.0f);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke20 = categoryAxis19.getTickMarkStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "Range[0.0,0.0]", paint6, stroke9, (java.awt.Paint) color17, stroke20, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 7, 0.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis1.getCategoryStart((int) (byte) 10, (int) (short) 100, rectangle2D9, rectangleEdge10);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis13.setAxisLineVisible(true);
        categoryAxis13.setCategoryMargin((double) 10.0f);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection19 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            lineRenderer3D0.drawItem(graphics2D8, categoryItemRendererState9, rectangle2D10, categoryPlot11, categoryAxis13, valueAxis18, (org.jfree.data.category.CategoryDataset) taskSeriesCollection19, 11, 11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color4 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 'a', (double) 7, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.setAxisLineVisible(true);
        java.awt.Paint paint6 = categoryAxis2.getTickLabelPaint();
        levelRenderer0.setBaseItemLabelPaint(paint6, true);
        java.awt.Font font10 = levelRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        java.awt.Paint paint12 = levelRenderer0.getSeriesOutlinePaint(3);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        double double3 = ringPlot1.getSectionDepth();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.setAxisLineVisible(true);
        java.awt.Paint paint7 = categoryAxis3.getAxisLinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        try {
            axisCollection0.add((org.jfree.chart.axis.Axis) categoryAxis3, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number6 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 100.0f, (java.lang.Comparable) "", 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        java.awt.Paint paint4 = null;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 'a', paint4);
        ringPlot0.setPieIndex((int) ' ');
        java.awt.Font font8 = ringPlot0.getLabelFont();
        ringPlot0.setLabelLinksVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke8 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint2, stroke3, (java.awt.Paint) color7, stroke8, 1.0f);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        boolean boolean15 = ringPlot13.equals((java.lang.Object) 'a');
        java.awt.Paint paint17 = null;
        ringPlot13.setSectionOutlinePaint((java.lang.Comparable) 'a', paint17);
        ringPlot13.setPieIndex((int) ' ');
        java.awt.Font font21 = ringPlot13.getLabelFont();
        java.awt.Color color23 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke26);
        int int28 = color23.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font21, (java.awt.Paint) color23);
        java.awt.Paint paint30 = labelBlock29.getPaint();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot(pieDataset31);
        java.awt.Stroke stroke33 = ringPlot32.getSeparatorStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(8.0d, paint2, stroke11, paint30, stroke33, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        ringPlot1.setDataset(pieDataset4);
        double double7 = ringPlot1.getExplodePercent((java.lang.Comparable) false);
        boolean boolean8 = ringPlot1.getSectionOutlinesVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        double double13 = ringPlot12.getInnerSeparatorExtension();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo15.getPlotInfo();
        try {
            org.jfree.chart.plot.PiePlotState piePlotState17 = ringPlot1.initialise(graphics2D9, rectangle2D10, (org.jfree.chart.plot.PiePlot) ringPlot12, (java.lang.Integer) 1, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 4, (java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-459), shape5, "", "RectangleAnchor.TOP");
        java.awt.Color color10 = java.awt.Color.gray;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        double double13 = ringPlot12.getInnerSeparatorExtension();
        java.awt.Paint paint14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot12.setLabelShadowPaint(paint14);
        ringPlot12.setShadowXOffset(0.2d);
        java.awt.Stroke stroke18 = ringPlot12.getSeparatorStroke();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot(pieDataset19);
        double double21 = ringPlot20.getInnerSeparatorExtension();
        java.awt.Paint paint22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot20.setLabelShadowPaint(paint22);
        ringPlot20.setShadowXOffset(0.2d);
        java.awt.Paint paint26 = ringPlot20.getBackgroundPaint();
        try {
            org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem(attributedString0, "RectangleAnchor.TOP", "TextAnchor.CENTER", "RectangleAnchor.TOP", shape5, (java.awt.Paint) color10, stroke18, paint26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        try {
            java.awt.GradientPaint gradientPaint5 = standardGradientPaintTransformer1.transform(gradientPaint2, shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getEndValue((java.lang.Comparable) (-1L), (java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            chartRenderingInfo0.setChartArea(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str5 = textAnchor4.toString();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str8 = textAnchor7.toString();
        try {
            java.awt.Shape shape9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("cyan", graphics2D1, (float) (-1), 0.0f, textAnchor4, 10.0d, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.CENTER" + "'", str5.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TextAnchor.CENTER" + "'", str8.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = null;
        try {
            ringPlot0.setSeparatorStroke(stroke1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Comparable comparable6 = taskSeriesCollection0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        try {
            java.util.List list10 = categoryAxis1.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getNoDataMessage();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedAreaRenderer1.getPositiveItemLabelPosition((int) (short) 10, 1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        stackedAreaRenderer1.notifyListeners(rendererChangeEvent5);
        java.awt.Font font7 = null;
        stackedAreaRenderer1.setBaseItemLabelFont(font7, true);
        org.jfree.chart.LegendItem legendItem12 = stackedAreaRenderer1.getLegendItem((int) (short) -1, (int) (byte) -1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(legendItem12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        java.awt.Paint paint4 = null;
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 'a', paint4);
        ringPlot0.setPieIndex((int) ' ');
        java.awt.Font font8 = ringPlot0.getLabelFont();
        java.lang.Object obj9 = ringPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 10;
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        chartRenderingInfo0.setEntityCollection(entityCollection1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = chartRenderingInfo0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = chartRenderingInfo0.getPlotInfo();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = plotRenderingInfo1.getSubplotInfo((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = chartRenderingInfo5.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        plotRenderingInfo6.setPlotArea(rectangle2D7);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = levelRenderer0.initialise(graphics2D1, rectangle2D2, categoryPlot3, (int) (short) 10, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "hi!", "hi!");
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreNullValues();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        double double5 = ringPlot0.getInteriorGap();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.25d + "'", double5 == 0.25d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        int int16 = color11.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font9, (java.awt.Paint) color11);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = null;
        try {
            org.jfree.chart.util.Size2D size2D20 = labelBlock17.arrange(graphics2D18, rectangleConstraint19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer0.getPadding();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            blockContainer0.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("hi!");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        java.awt.Paint paint6 = null;
        try {
            categoryAxis1.setTickLabelPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = statisticalBarRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot0.getLegendItems();
        java.awt.Image image2 = null;
        piePlot0.setBackgroundImage(image2);
        org.jfree.chart.util.Rotation rotation4 = null;
        try {
            piePlot0.setDirection(rotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number4 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 3, (java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit((int) (short) 10, 5, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer0.setMinimumBarLength((double) (short) 100);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer7 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        boolean boolean11 = ringPlot9.equals((java.lang.Object) 'a');
        java.awt.Paint paint13 = null;
        ringPlot9.setSectionOutlinePaint((java.lang.Comparable) 'a', paint13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke17 = categoryAxis16.getTickMarkStroke();
        categoryAxis16.setAxisLineVisible(true);
        java.awt.Paint paint20 = categoryAxis16.getAxisLinePaint();
        java.awt.Font font21 = categoryAxis16.getLabelFont();
        ringPlot9.setLabelFont(font21);
        levelRenderer7.setSeriesItemLabelFont(0, font21);
        try {
            statisticalBarRenderer0.setSeriesItemLabelFont((int) (byte) -1, font21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Comparable comparable5 = null;
        try {
            java.lang.Number number6 = taskSeriesCollection0.getEndValue((java.lang.Comparable) date4, comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setVerticalTickLabels(false);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double9 = numberAxis1.lengthToJava2D((double) 1900, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(10, 0, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        numberAxis1.centerRange(97.0d);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-5d + "'", double1 == 1.0E-5d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        int int10 = color6.getBlue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 205 + "'", int10 == 205);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer0.setMinimumBarLength((double) (short) 100);
        java.awt.Color color8 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke11 = categoryAxis10.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke11);
        statisticalBarRenderer0.setSeriesPaint((int) '4', (java.awt.Paint) color8);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D15 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color20 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets16, (java.awt.Paint) color20);
        lineRenderer3D15.setWallPaint((java.awt.Paint) color20);
        statisticalBarRenderer0.setSeriesPaint(0, (java.awt.Paint) color20, false);
        java.awt.color.ColorSpace colorSpace25 = null;
        float[] floatArray32 = new float[] { 1.0f, 100.0f, (short) 0, 10.0f, 11, (short) 10 };
        try {
            float[] floatArray33 = color20.getColorComponents(colorSpace25, floatArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setAxisLineVisible(true);
        categoryAxis1.setCategoryLabelPositionOffset(7);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double10 = categoryAxis1.getCategoryEnd(0, (int) (byte) 10, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer0.getPadding();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType5 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        try {
            java.lang.Object obj6 = blockContainer0.draw(graphics2D3, rectangle2D4, (java.lang.Object) gradientPaintTransformType5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        double double7 = ringPlot6.getInnerSeparatorExtension();
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot6.setLabelShadowPaint(paint8);
        stackedAreaRenderer1.setBaseOutlinePaint(paint8, false);
        stackedAreaRenderer1.setAutoPopulateSeriesShape(false);
        boolean boolean15 = stackedAreaRenderer1.isSeriesItemLabelsVisible(10);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        chartRenderingInfo0.setEntityCollection(entityCollection1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            chartRenderingInfo0.setChartArea(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setInnerSeparatorExtension((double) (byte) 100);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        ringPlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        float float7 = ringPlot1.getForegroundAlpha();
        java.awt.Paint paint8 = ringPlot1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = chartRenderingInfo11.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo13.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        plotRenderingInfo14.setPlotArea(rectangle2D15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo14);
        try {
            org.jfree.chart.axis.AxisState axisState18 = numberAxis1.draw(graphics2D6, (double) 10L, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(plotRenderingInfo12);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        boolean boolean11 = color6.equals((java.lang.Object) "RectangleAnchor.TOP");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) 255);
        int int5 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) 1559372400000L);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Stroke stroke2 = ringPlot1.getSeparatorStroke();
        java.awt.Paint paint3 = ringPlot1.getBaseSectionOutlinePaint();
        ringPlot1.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D1.getColumnKey(205);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 205, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.setVerticalTickLabels(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list10 = numberAxis1.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) 0);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = new org.jfree.chart.plot.PlotState();
        java.util.Map map7 = plotState6.getSharedAxisStates();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = chartRenderingInfo8.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = chartRenderingInfo10.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        plotRenderingInfo11.setPlotArea(rectangle2D12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo11);
        try {
            multiplePiePlot0.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(map7);
        org.junit.Assert.assertNotNull(plotRenderingInfo9);
        org.junit.Assert.assertNotNull(plotRenderingInfo11);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        ringPlot1.setLabelLinkStroke(stroke4);
        double double6 = ringPlot1.getShadowYOffset();
        ringPlot1.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = null;
        boolean boolean2 = standardCategorySeriesLabelGenerator0.equals(obj1);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection3 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.String str5 = standardCategorySeriesLabelGenerator0.generateLabel((org.jfree.data.category.CategoryDataset) taskSeriesCollection3, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryEnd((int) ' ', (-459), rectangle2D5, rectangleEdge6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        try {
            java.util.List list13 = categoryAxis1.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleAnchor.TOP", "TextAnchor.CENTER", "RectangleAnchor.TOP", "cyan");
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = new org.jfree.chart.plot.PlotState();
        java.util.Map map6 = plotState5.getSharedAxisStates();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            waferMapPlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(map6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSectionOutlinesVisible();
        double double3 = ringPlot1.getShadowXOffset();
        double double4 = ringPlot1.getInteriorGap();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.25d + "'", double4 == 0.25d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets0.createOutsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer0.getPadding();
        blockContainer0.setPadding((double) 3600000L, 8.0d, 97.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.Axis axis1 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            axisCollection0.add(axis1, rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("hi!");
        int int2 = color1.getGreen();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        java.awt.Font font7 = numberAxis1.getTickLabelFont();
        float float8 = numberAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Shape shape3 = ringPlot1.getLegendItemShape();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection6 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection6);
        int int9 = taskSeriesCollection6.indexOf((java.lang.Comparable) 255);
        boolean boolean10 = categoryAxis1.equals((java.lang.Object) 255);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double16 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor11, 1900, (int) (short) 0, rectangle2D14, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer5 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke8 = categoryAxis7.getTickMarkStroke();
        categoryAxis7.setAxisLineVisible(true);
        java.awt.Paint paint11 = categoryAxis7.getTickLabelPaint();
        levelRenderer5.setBaseItemLabelPaint(paint11, true);
        java.awt.Font font15 = levelRenderer5.getSeriesItemLabelFont((int) (byte) 100);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D19 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color24 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, (java.awt.Paint) color24);
        lineRenderer3D19.setWallPaint((java.awt.Paint) color24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = lineRenderer3D19.getSeriesPositiveItemLabelPosition((int) 'a');
        stackedAreaRenderer17.setSeriesNegativeItemLabelPosition(0, itemLabelPosition28, false);
        levelRenderer5.setBaseNegativeItemLabelPosition(itemLabelPosition28);
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(1, itemLabelPosition28);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(font15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        try {
            dateAxis1.setRange((double) (byte) 10, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockContainer0.getPadding();
        java.lang.Object obj3 = blockContainer0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { 3.0d, (byte) 10, "VerticalAlignment.BOTTOM" };
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { "VerticalAlignment.BOTTOM" };
        double[] doubleArray10 = new double[] { ' ', ' ', 3.0d, (byte) 1 };
        double[] doubleArray15 = new double[] { ' ', ' ', 3.0d, (byte) 1 };
        double[] doubleArray20 = new double[] { ' ', ' ', 3.0d, (byte) 1 };
        double[] doubleArray25 = new double[] { ' ', ' ', 3.0d, (byte) 1 };
        double[][] doubleArray26 = new double[][] { doubleArray10, doubleArray15, doubleArray20, doubleArray25 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray3, comparableArray5, doubleArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(12, (int) (byte) 10, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Object obj0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart2, chartChangeEventType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        int int12 = lineRenderer3D0.getPassCount();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        boolean boolean15 = ringPlot14.getSectionOutlinesVisible();
        double double16 = ringPlot14.getShadowXOffset();
        boolean boolean17 = lineRenderer3D0.equals((java.lang.Object) ringPlot14);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot19.setDomainAxisLocation(1900, axisLocation21);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            lineRenderer3D0.drawOutline(graphics2D18, categoryPlot19, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        jFreeChart1.removeLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color7 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, (java.awt.Paint) color7);
        double double9 = rectangleInsets3.getRight();
        jFreeChart1.setPadding(rectangleInsets3);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart1.getLegend(0);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(legendTitle12);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleAnchor.TOP", 12);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.plot.Plot plot4 = categoryAxis1.getPlot();
        categoryAxis1.setCategoryLabelPositionOffset((int) ' ');
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        double double8 = ringPlot7.getStartAngle();
        boolean boolean9 = categoryAxis1.hasListener((java.util.EventListener) ringPlot7);
        double double10 = ringPlot7.getShadowYOffset();
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot1.setLabelShadowPaint(paint3);
        ringPlot1.setShadowXOffset(0.2d);
        java.awt.Paint paint7 = ringPlot1.getBackgroundPaint();
        ringPlot1.setOuterSeparatorExtension((double) (-1.0f));
        ringPlot1.setPieIndex(255);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer0.setMinimumBarLength((double) (short) 100);
        boolean boolean8 = statisticalBarRenderer0.isItemLabelVisible(0, (int) (short) 10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "ChartChangeEventType.NEW_DATASET", "cyan");
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f), numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        int int16 = color11.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font9, (java.awt.Paint) color11);
        java.lang.Object obj18 = labelBlock17.clone();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            labelBlock17.draw(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (byte) 1, (java.lang.Number) 255);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image3, "hi!", "", "");
        java.lang.String str8 = projectInfo7.getCopyright();
        java.util.List list9 = projectInfo7.getContributors();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str3 = range2.toString();
        double double4 = range2.getCentralValue();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range2);
        java.util.Date date6 = dateRange5.getUpperDate();
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] { date6, 205, "RectangleEdge.BOTTOM", true };
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] { 10.0f, "TextAnchor.CENTER", 1560668399999L, 1560179855055L };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] {};
        java.lang.Number[] numberArray19 = new java.lang.Number[] {};
        java.lang.Number[] numberArray20 = new java.lang.Number[] {};
        java.lang.Number[] numberArray21 = new java.lang.Number[] {};
        java.lang.Number[] numberArray22 = new java.lang.Number[] {};
        java.lang.Number[] numberArray23 = new java.lang.Number[] {};
        java.lang.Number[] numberArray24 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray19, numberArray20, numberArray21, numberArray22, numberArray23, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray25);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray10, comparableArray15, numberArray16, numberArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean4 = ringPlot2.equals((java.lang.Object) 'a');
        java.awt.Paint paint6 = null;
        ringPlot2.setSectionOutlinePaint((java.lang.Comparable) 'a', paint6);
        ringPlot2.setPieIndex((int) ' ');
        java.awt.Font font10 = ringPlot2.getLabelFont();
        java.awt.Color color12 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke15 = categoryAxis14.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        int int17 = color12.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font10, (java.awt.Paint) color12);
        java.awt.Font font19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        labelBlock18.setFont(font19);
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke28 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint22, stroke23, (java.awt.Paint) color27, stroke28, 1.0f);
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font19, (java.awt.Paint) color27);
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean33 = textBlock31.equals((java.lang.Object) textAnchor32);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        org.jfree.chart.LegendItem legendItem6 = lineRenderer3D0.getLegendItem(11, (-1));
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.getDrawSharedDomainAxis();
        java.lang.String str2 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Category Plot" + "'", str2.equals("Category Plot"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo2.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        plotRenderingInfo3.setPlotArea(rectangle2D4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        plotRenderingInfo3.setDataArea(rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        double double9 = categoryItemRendererState8.getBarWidth();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        categoryAxis13.setAxisLineVisible(true);
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        piePlot17.removeChangeListener(plotChangeListener18);
        org.jfree.chart.plot.Plot plot20 = piePlot17.getRootPlot();
        categoryAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot17);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection23 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list24 = taskSeriesCollection23.getColumnKeys();
        int int26 = taskSeriesCollection23.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection23);
        try {
            stackedBarRenderer3D0.drawItem(graphics2D1, categoryItemRendererState8, rectangle2D10, categoryPlot11, categoryAxis13, valueAxis22, (org.jfree.data.category.CategoryDataset) taskSeriesCollection23, 2, (int) 'a', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) -1, (float) (byte) 100, (float) 205);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4503480) + "'", int3 == (-4503480));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint4 = lineBorder3.getPaint();
        java.awt.Stroke stroke5 = lineBorder3.getStroke();
        categoryPlot2.setDomainGridlineStroke(stroke5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            stackedBarRenderer3D0.drawDomainGridline(graphics2D1, categoryPlot2, rectangle2D9, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        java.awt.Color color3 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        valueMarker7.notifyListeners(markerChangeEvent8);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER;
        valueMarker7.setLabelTextAnchor(textAnchor10);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType13 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor10, (double) 1560668399999L, categoryLabelWidthType13, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextAnchor.CENTER");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = null;
        try {
            textLine1.draw(graphics2D2, (float) 1, (float) (byte) 10, textAnchor5, (float) (-1), (float) 1559372400000L, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot0.equals((java.lang.Object) 'a');
        ringPlot0.setForegroundAlpha((float) (short) -1);
        java.awt.Paint paint5 = ringPlot0.getSeparatorPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator6);
        ringPlot0.setIgnoreZeroValues(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setErrorIndicatorPaint(paint3);
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color4 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color4);
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color4.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext11);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        int int16 = color11.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font9, (java.awt.Paint) color11);
        java.awt.Paint paint18 = labelBlock17.getPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis20.setAxisLineVisible(true);
        categoryAxis20.setCategoryLabelPositionOffset(7);
        boolean boolean25 = labelBlock17.equals((java.lang.Object) categoryAxis20);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            labelBlock17.setBounds(rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("RectangleAnchor.TOP", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]");
        float float2 = textFragment1.getBaselineOffset();
        java.awt.Font font3 = textFragment1.getFont();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        try {
            defaultKeyedValues2D1.removeRow((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        try {
            java.util.Date date3 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        double double7 = ringPlot6.getInnerSeparatorExtension();
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot6.setLabelShadowPaint(paint8);
        stackedAreaRenderer1.setBaseOutlinePaint(paint8, false);
        stackedAreaRenderer1.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean15 = stackedAreaRenderer1.getSeriesVisible((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedAreaRenderer1.getBaseNegativeItemLabelPosition();
        boolean boolean17 = stackedAreaRenderer1.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = categoryLabelPosition1.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("TextAnchor.CENTER");
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = null;
        try {
            categoryPlot0.setRangeGridlineStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) 255);
        java.lang.Class<?> wildcardClass4 = taskSeriesCollection0.getClass();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Comparable comparable7 = null;
        try {
            java.lang.Number number8 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) 100.0f, comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis1.getTickUnit();
        java.awt.Font font8 = numberAxis1.getTickLabelFont();
        numberAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        try {
            java.util.Date date5 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedAreaRenderer6.getPositiveItemLabelPosition((int) (short) 10, 1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        stackedAreaRenderer6.notifyListeners(rendererChangeEvent10);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot(pieDataset12);
        double double14 = ringPlot13.getInnerSeparatorExtension();
        java.awt.Image image15 = ringPlot13.getBackgroundImage();
        java.awt.Paint paint16 = ringPlot13.getBaseSectionPaint();
        stackedAreaRenderer6.setBaseItemLabelPaint(paint16, false);
        numberAxis1.setAxisLinePaint(paint16);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setBaseSeriesVisible(true);
        double double3 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.clone(shape4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint8 = lineBorder7.getPaint();
        java.awt.Stroke stroke9 = lineBorder7.getStroke();
        categoryPlot6.setDomainGridlineStroke(stroke9);
        java.awt.Paint paint11 = null;
        try {
            org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem(attributedString0, "RectangleEdge.BOTTOM", "ChartChangeEventType.NEW_DATASET", "ChartChangeEventType.NEW_DATASET", shape4, stroke9, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        ringPlot1.setDataset(pieDataset4);
        ringPlot1.setNoDataMessage("255");
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = null;
        ringPlot1.setToolTipGenerator(pieToolTipGenerator8);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        float[] floatArray4 = new float[] { ' ' };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB((-1), 0, 255, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (-1L), (java.lang.Number) 4);
        org.jfree.data.RangeType rangeType3 = org.jfree.data.RangeType.POSITIVE;
        boolean boolean4 = meanAndStandardDeviation2.equals((java.lang.Object) rangeType3);
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryEnd((int) ' ', (-459), rectangle2D5, rectangleEdge6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot8);
        jFreeChart9.removeLegend();
        jFreeChart9.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart9.getLegend(3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str15 = chartChangeEventType14.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ' ', jFreeChart9, chartChangeEventType14);
        jFreeChart9.fireChartChanged();
        jFreeChart9.setBackgroundImageAlpha((float) (short) 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str15.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        blockContainer0.setPadding(rectangleInsets2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets2.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryEnd((int) ' ', (-459), rectangle2D5, rectangleEdge6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot8);
        jFreeChart9.removeLegend();
        jFreeChart9.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart9.getLegend(3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str15 = chartChangeEventType14.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ' ', jFreeChart9, chartChangeEventType14);
        org.jfree.chart.JFreeChart jFreeChart17 = chartChangeEvent16.getChart();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str15.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(jFreeChart17);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        boolean boolean7 = numberAxis1.isAutoRange();
        numberAxis1.setNegativeArrowVisible(false);
        try {
            numberAxis1.setRangeWithMargins((double) 5, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (5.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getInnerSeparatorExtension();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot1.setLabelShadowPaint(paint3);
        ringPlot1.setShadowXOffset(0.2d);
        java.awt.Paint paint7 = ringPlot1.getBackgroundPaint();
        ringPlot1.setOuterSeparatorExtension((double) (-1.0f));
        ringPlot1.setNoDataMessage("RectangleEdge.BOTTOM");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 1559372400000L, (java.lang.Comparable) 12.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) "cyan");
        java.util.Date date3 = month0.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("TextAnchor.CENTER", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        int int5 = stackedAreaRenderer1.getPassCount();
        java.awt.Stroke stroke6 = stackedAreaRenderer1.getBaseOutlineStroke();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = stackedAreaRenderer1.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(drawingSupplier7);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        blockContainer0.setPadding(rectangleInsets2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets2.createOutsetRectangle(rectangle2D4, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("VerticalAlignment.BOTTOM", font1, paint2, (float) 3600000L, (int) '4', textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryEnd((int) ' ', (-459), rectangle2D5, rectangleEdge6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot8);
        jFreeChart9.removeLegend();
        jFreeChart9.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart9.getLegend(3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str15 = chartChangeEventType14.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ' ', jFreeChart9, chartChangeEventType14);
        org.jfree.chart.title.Title title17 = null;
        jFreeChart9.removeSubtitle(title17);
        org.jfree.chart.title.Title title19 = null;
        jFreeChart9.removeSubtitle(title19);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str15.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleAnchor.TOP", graphics2D1, (float) 12, 1.0f, 0.0d, (float) 15, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        java.lang.Object obj9 = lineRenderer3D0.clone();
        java.awt.Font font10 = lineRenderer3D0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = lineRenderer3D0.getLegendItemToolTipGenerator();
        java.awt.Shape shape14 = lineRenderer3D0.getItemShape((-459), 100);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.lang.Object obj2 = dataPackageResources0.handleGetObject("hi!");
        java.util.Set<java.lang.String> strSet3 = dataPackageResources0.keySet();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        int int5 = stackedAreaRenderer1.getPassCount();
        java.awt.Stroke stroke6 = stackedAreaRenderer1.getBaseOutlineStroke();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator7 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        stackedAreaRenderer1.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator7);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection9 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        int int12 = taskSeriesCollection9.indexOf((java.lang.Comparable) 255);
        java.lang.Class<?> wildcardClass13 = taskSeriesCollection9.getClass();
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection9);
        try {
            java.lang.String str17 = standardCategoryURLGenerator7.generateURL((org.jfree.data.category.CategoryDataset) taskSeriesCollection9, (int) ' ', 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(number14);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis2.setMinimumDate(date3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str6 = serialDate5.toString();
//        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis8.setMinimumDate(date9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
//        org.jfree.data.time.SerialDate serialDate12 = serialDate5.getEndOfCurrentMonth(serialDate11);
//        try {
//            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-459), shape1, "", "RectangleAnchor.TOP");
        java.lang.String str6 = categoryLabelEntity5.getShapeType();
        java.lang.String str7 = categoryLabelEntity5.toString();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "poly" + "'", str6.equals("poly"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP" + "'", str7.equals("CategoryLabelEntity: category=-459, tooltip=, url=RectangleAnchor.TOP"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        java.awt.Font font7 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range5 = new org.jfree.data.Range(0.0d, 0.0d);
        org.jfree.data.Range range8 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str9 = range8.toString();
        org.jfree.data.Range range10 = org.jfree.data.Range.combine(range5, range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range2, range8);
        double double12 = rectangleConstraint11.getWidth();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Range[0.0,0.0]" + "'", str9.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = levelRenderer0.getBaseURLGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedAreaRenderer6.getPositiveItemLabelPosition((int) (short) 10, 1);
        levelRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = levelRenderer0.getSeriesPositiveItemLabelPosition(100);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB((int) (byte) 100, 0, 10, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-4503480), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Color color1 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        java.awt.Color color6 = color1.darker();
        java.awt.color.ColorSpace colorSpace7 = null;
        float[] floatArray12 = new float[] { '#', '4', ' ', 2 };
        try {
            float[] floatArray13 = color6.getComponents(colorSpace7, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSectionOutlinesVisible();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection3 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list4 = taskSeriesCollection3.getColumnKeys();
        int int6 = taskSeriesCollection3.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection3, comparable7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) boolean2, (org.jfree.data.general.Dataset) taskSeriesCollection3);
        try {
            java.lang.Number number13 = taskSeriesCollection3.getEndValue((java.lang.Comparable) "cyan", (java.lang.Comparable) 1900, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setErrorIndicatorPaint(paint3);
        java.lang.Boolean boolean6 = statisticalBarRenderer0.getSeriesCreateEntities((int) (short) 1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = chartRenderingInfo8.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        plotRenderingInfo9.setPlotArea(rectangle2D10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        plotRenderingInfo9.setDataArea(rectangle2D12);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState14 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo9);
        double double15 = categoryItemRendererState14.getBarWidth();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot17.setDomainAxisLocation(1900, axisLocation19);
        java.awt.Stroke stroke21 = categoryPlot17.getRangeCrosshairStroke();
        categoryPlot17.setAnchorValue((double) 1560179855055L);
        categoryPlot17.setWeight((int) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        boolean boolean29 = ringPlot27.equals((java.lang.Object) 'a');
        java.awt.Paint paint31 = null;
        ringPlot27.setSectionOutlinePaint((java.lang.Comparable) 'a', paint31);
        ringPlot27.setPieIndex((int) ' ');
        java.awt.Font font35 = ringPlot27.getLabelFont();
        java.awt.Color color37 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke40 = categoryAxis39.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color37, stroke40);
        int int42 = color37.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font35, (java.awt.Paint) color37);
        java.awt.Paint paint44 = labelBlock43.getPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis46.setAxisLineVisible(true);
        categoryAxis46.setCategoryLabelPositionOffset(7);
        boolean boolean51 = labelBlock43.equals((java.lang.Object) categoryAxis46);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis53.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand56 = null;
        numberAxis53.setMarkerBand(markerAxisBand56);
        org.jfree.data.Range range58 = numberAxis53.getDefaultAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit59 = numberAxis53.getTickUnit();
        java.awt.Paint paint60 = numberAxis53.getTickLabelPaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection61 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number62 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection61);
        org.jfree.data.gantt.TaskSeries taskSeries64 = taskSeriesCollection61.getSeries((java.lang.Comparable) true);
        try {
            statisticalBarRenderer0.drawItem(graphics2D7, categoryItemRendererState14, rectangle2D16, categoryPlot17, categoryAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis53, (org.jfree.data.category.CategoryDataset) taskSeriesCollection61, 6, (int) (short) 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires StatisticalCategoryDataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(plotRenderingInfo9);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 255 + "'", int42 == 255);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(numberTickUnit59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNull(number62);
        org.junit.Assert.assertNull(taskSeries64);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = ganttRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer5.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        java.awt.Paint paint11 = stackedAreaRenderer5.getItemOutlinePaint(4, (int) '#');
        ganttRenderer0.setBasePaint(paint11);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = statisticalBarRenderer0.getToolTipGenerator((int) (byte) 10, (int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNull(itemLabelPosition4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        ringPlot1.setDataset(pieDataset4);
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot1.setBackgroundPaint(paint6);
        java.awt.Paint paint8 = ringPlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0.25d, shape6, "", "");
        java.awt.Color color10 = java.awt.Color.GRAY;
        try {
            org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem(attributedString0, "10-June-2019", "poly", "10-June-2019", shape6, (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.plot.Plot plot4 = categoryAxis1.getPlot();
        categoryAxis1.setCategoryLabelPositionOffset((int) ' ');
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double11 = categoryAxis1.getCategoryEnd((int) '#', 10, rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        int int4 = taskSeriesCollection1.indexOf((java.lang.Comparable) 255);
        boolean boolean5 = rangeType0.equals((java.lang.Object) taskSeriesCollection1);
        org.jfree.data.gantt.TaskSeries taskSeries6 = null;
        try {
            taskSeriesCollection1.remove(taskSeries6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedAreaRenderer5.getPositiveItemLabelPosition((int) (short) 10, 1);
        double double9 = itemLabelPosition8.getAngle();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition8);
        statisticalBarRenderer0.setIncludeBaseInRange(true);
        boolean boolean15 = statisticalBarRenderer0.getItemCreateEntity(12, 0);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot19.setDomainAxisLocation(1900, axisLocation21);
        java.awt.Stroke stroke23 = categoryPlot19.getRangeCrosshairStroke();
        categoryPlot19.setAnchorValue((double) 1560179855055L);
        categoryPlot19.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot19.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        java.awt.Font font35 = categoryAxis30.getLabelFont();
        categoryAxis30.setLowerMargin(4.0d);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection39 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list40 = taskSeriesCollection39.getColumnKeys();
        int int42 = taskSeriesCollection39.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection39);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection39);
        java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection39);
        try {
            statisticalBarRenderer0.drawItem(graphics2D16, categoryItemRendererState17, rectangle2D18, categoryPlot19, categoryAxis30, valueAxis38, (org.jfree.data.category.CategoryDataset) taskSeriesCollection39, (int) '#', 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires StatisticalCategoryDataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNull(number45);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis2.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis2.setMarkerBand(markerAxisBand5);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        java.awt.Font font8 = numberAxis2.getTickLabelFont();
        boolean boolean9 = shapeList0.equals((java.lang.Object) numberAxis2);
        java.awt.Shape shape10 = numberAxis2.getUpArrow();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double14 = numberAxis2.java2DToValue((double) 1, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        boolean boolean4 = lineRenderer3D0.getUseOutlinePaint();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis12.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis12.setMarkerBand(markerAxisBand15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        boolean boolean18 = numberAxis12.isAutoRange();
        numberAxis12.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer21 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean25 = ringPlot23.equals((java.lang.Object) 'a');
        java.awt.Paint paint27 = null;
        ringPlot23.setSectionOutlinePaint((java.lang.Comparable) 'a', paint27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        java.awt.Font font35 = categoryAxis30.getLabelFont();
        ringPlot23.setLabelFont(font35);
        levelRenderer21.setSeriesItemLabelFont(0, font35);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer21);
        numberAxis12.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, (double) 100.0f);
        boolean boolean4 = stackedBarRenderer3D2.isSeriesVisibleInLegend(0);
        boolean boolean5 = stackedBarRenderer3D2.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.util.List list2 = taskSeriesCollection0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0d + "'", number1.equals(0.0d));
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelToolTip("");
        org.jfree.chart.plot.Plot plot4 = categoryAxis1.getPlot();
        categoryAxis1.setCategoryLabelPositionOffset((int) ' ');
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setFixedAutoRange((double) ' ');
        try {
            numberAxis1.setRangeWithMargins((double) 'a', 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedAreaRenderer1.getPositiveItemLabelPosition((int) (short) 10, 1);
        java.awt.Stroke stroke5 = stackedAreaRenderer1.getBaseStroke();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer6 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot8.equals((java.lang.Object) 'a');
        java.awt.Paint paint12 = null;
        ringPlot8.setSectionOutlinePaint((java.lang.Comparable) 'a', paint12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke16 = categoryAxis15.getTickMarkStroke();
        categoryAxis15.setAxisLineVisible(true);
        java.awt.Paint paint19 = categoryAxis15.getAxisLinePaint();
        java.awt.Font font20 = categoryAxis15.getLabelFont();
        ringPlot8.setLabelFont(font20);
        levelRenderer6.setSeriesItemLabelFont(0, font20);
        stackedAreaRenderer1.setBaseItemLabelFont(font20);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean2 = shapeList0.equals((java.lang.Object) stroke1);
        java.awt.Shape shape4 = shapeList0.getShape(5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer0.setMinimumBarLength((double) (short) 100);
        java.awt.Paint paint6 = statisticalBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator(4, categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint4 = statisticalBarRenderer1.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer1.setMinimumBarLength((double) (short) 100);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke12);
        statisticalBarRenderer1.setSeriesPaint((int) '4', (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D16 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, (java.awt.Paint) color21);
        lineRenderer3D16.setWallPaint((java.awt.Paint) color21);
        statisticalBarRenderer1.setSeriesPaint(0, (java.awt.Paint) color21, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = statisticalBarRenderer1.getPlot();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer1);
        boolean boolean28 = statisticalBarRenderer1.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(categoryPlot26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = ganttRenderer0.getURLGenerator((int) (byte) 1, 2);
        double double4 = ganttRenderer0.getBase();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = ganttRenderer0.getLegendItemURLGenerator();
        ganttRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.lang.Number number5 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) (short) -1, (java.lang.Number) 97.0d, (java.lang.Number) (short) -1, (java.lang.Number) (byte) 0, (java.lang.Number) 15, number5, (java.lang.Number) (short) 10, (java.lang.Number) 1559372400000L, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getQ1();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) -1 + "'", number10.equals((short) -1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, (double) 100.0f);
        boolean boolean4 = stackedBarRenderer3D2.isSeriesVisibleInLegend(0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo6.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        plotRenderingInfo7.setPlotArea(rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        plotRenderingInfo7.setDataArea(rectangle2D10);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo7);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot14.setDomainAxisLocation(1900, axisLocation16);
        java.awt.Stroke stroke18 = categoryPlot14.getRangeCrosshairStroke();
        categoryPlot14.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot14.getColumnRenderingOrder();
        java.awt.Stroke stroke22 = categoryPlot14.getOutlineStroke();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot14.getDomainMarkers((int) ' ', layer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke28 = categoryAxis27.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis27.getCategoryEnd((int) ' ', (-459), rectangle2D31, rectangleEdge32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryAxis27.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis36.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand39 = null;
        numberAxis36.setMarkerBand(markerAxisBand39);
        org.jfree.data.Range range41 = numberAxis36.getDefaultAutoRange();
        boolean boolean42 = numberAxis36.isAutoRange();
        numberAxis36.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range45 = numberAxis36.getDefaultAutoRange();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection46 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number47 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection46);
        int int49 = taskSeriesCollection46.indexOf((java.lang.Comparable) 255);
        java.lang.Class<?> wildcardClass50 = taskSeriesCollection46.getClass();
        java.lang.Number number51 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection46);
        try {
            stackedBarRenderer3D2.drawItem(graphics2D5, categoryItemRendererState12, rectangle2D13, categoryPlot14, categoryAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis36, (org.jfree.data.category.CategoryDataset) taskSeriesCollection46, (int) (byte) 10, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(number51);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Color color2 = java.awt.Color.getColor("Range[0.0,0.0]", 2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        ringPlot1.setDataset(pieDataset4);
        ringPlot1.setNoDataMessage("255");
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint9 = lineBorder8.getPaint();
        java.awt.Stroke stroke10 = lineBorder8.getStroke();
        java.awt.Paint paint11 = lineBorder8.getPaint();
        ringPlot1.setBaseSectionOutlinePaint(paint11);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = ringPlot1.getLegendLabelToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset14 = ringPlot1.getDataset();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertNull(pieDataset14);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        java.awt.Paint paint10 = categoryMarker9.getOutlinePaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = chartRenderingInfo11.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        plotRenderingInfo12.setPlotArea(rectangle2D13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        plotRenderingInfo12.setDataArea(rectangle2D15);
        boolean boolean17 = categoryMarker9.equals((java.lang.Object) rectangle2D15);
        categoryMarker9.setKey((java.lang.Comparable) (byte) 1);
        java.awt.Stroke stroke20 = null;
        categoryMarker9.setOutlineStroke(stroke20);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(plotRenderingInfo12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list3 = taskSeriesCollection2.getColumnKeys();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = null;
        taskSeriesCollection2.seriesChanged(seriesChangeEvent4);
        boolean boolean6 = taskSeriesCollection0.hasListener((java.util.EventListener) taskSeriesCollection2);
        org.jfree.data.general.DatasetGroup datasetGroup7 = null;
        try {
            taskSeriesCollection0.setGroup(datasetGroup7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot3.setDomainAxisLocation(1900, axisLocation5);
        java.awt.Stroke stroke7 = categoryPlot3.getRangeCrosshairStroke();
        categoryPlot3.setAnchorValue((double) 1560179855055L);
        categoryPlot3.setWeight((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot3.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation14);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int3 = taskSeriesCollection0.indexOf((java.lang.Comparable) 255);
        java.lang.Class<?> wildcardClass4 = taskSeriesCollection0.getClass();
        try {
            java.lang.Comparable comparable6 = taskSeriesCollection0.getColumnKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        java.awt.Stroke stroke2 = lineBorder0.getStroke();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            lineBorder0.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleAnchor.TOP", "hi!", "", image3, "hi!", "", "");
        projectInfo7.setName("Range[0.0,0.0]");
        java.lang.String str10 = projectInfo7.getName();
        org.jfree.chart.ui.Library library11 = null;
        try {
            projectInfo7.addLibrary(library11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Range[0.0,0.0]" + "'", str10.equals("Range[0.0,0.0]"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        java.lang.Object obj9 = lineRenderer3D0.clone();
        try {
            lineRenderer3D0.setSeriesItemLabelsVisible((int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.gantt.TaskSeries taskSeries4 = null;
        try {
            taskSeriesCollection0.remove(taskSeries4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint1, stroke2, (java.awt.Paint) color6, stroke7, 1.0f);
        java.awt.Paint paint10 = categoryMarker9.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker9);
        org.jfree.chart.plot.Marker marker12 = markerChangeEvent11.getMarker();
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        double double14 = blockContainer13.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockContainer13.getPadding();
        marker12.setLabelOffset(rectangleInsets15);
        java.awt.Paint paint17 = marker12.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(marker12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity7 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-459), shape3, "", "RectangleAnchor.TOP");
        shapeList0.setShape(255, shape3);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color1);
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray7 = new float[] { (byte) 100, 1L, 0.0f };
        try {
            float[] floatArray8 = color1.getComponents(colorSpace3, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo2.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        plotRenderingInfo3.setPlotArea(rectangle2D4);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        plotRenderingInfo3.setDataArea(rectangle2D6);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        double double9 = categoryItemRendererState8.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection10 = categoryItemRendererState8.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean13 = categoryPlot12.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke16 = categoryAxis15.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis15.getCategoryEnd((int) ' ', (-459), rectangle2D19, rectangleEdge20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis15.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection25 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list26 = taskSeriesCollection25.getColumnKeys();
        java.lang.Number number27 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection25);
        try {
            boxAndWhiskerRenderer0.drawItem(graphics2D1, categoryItemRendererState8, rectangle2D11, categoryPlot12, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.data.category.CategoryDataset) taskSeriesCollection25, 8, (-459), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: BoxAndWhiskerRenderer.drawItem() : the data should be of type BoxAndWhiskerCategoryDataset only.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNull(number27);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("10-June-2019");
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (-459));
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1559372400000L);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Color color1 = java.awt.Color.getColor("RangeType.FULL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.setAxisLineVisible(true);
        java.awt.Paint paint6 = categoryAxis2.getTickLabelPaint();
        levelRenderer0.setBaseItemLabelPaint(paint6, true);
        java.awt.Font font10 = levelRenderer0.getSeriesItemLabelFont((int) (byte) 100);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D14 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, (java.awt.Paint) color19);
        lineRenderer3D14.setWallPaint((java.awt.Paint) color19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineRenderer3D14.getSeriesPositiveItemLabelPosition((int) 'a');
        stackedAreaRenderer12.setSeriesNegativeItemLabelPosition(0, itemLabelPosition23, false);
        levelRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition23);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = chartRenderingInfo28.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        plotRenderingInfo29.setPlotArea(rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        plotRenderingInfo29.setDataArea(rectangle2D32);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState34 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean37 = categoryPlot36.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke40 = categoryAxis39.getTickMarkStroke();
        categoryAxis39.setAxisLineVisible(true);
        java.awt.Paint paint43 = categoryAxis39.getAxisLinePaint();
        java.awt.Font font44 = categoryAxis39.getLabelFont();
        java.awt.Paint paint46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color51 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke52 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint46, stroke47, (java.awt.Paint) color51, stroke52, 1.0f);
        categoryAxis39.setTickMarkStroke(stroke47);
        float float56 = categoryAxis39.getMaximumCategoryLabelWidthRatio();
        categoryAxis39.setTickMarkInsideLength((float) '4');
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection60 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list61 = taskSeriesCollection60.getColumnKeys();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection62 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list63 = taskSeriesCollection62.getColumnKeys();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent64 = null;
        taskSeriesCollection62.seriesChanged(seriesChangeEvent64);
        boolean boolean66 = taskSeriesCollection60.hasListener((java.util.EventListener) taskSeriesCollection62);
        try {
            levelRenderer0.drawItem(graphics2D27, categoryItemRendererState34, rectangle2D35, categoryPlot36, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis59, (org.jfree.data.category.CategoryDataset) taskSeriesCollection62, (int) (byte) 1, 15, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(plotRenderingInfo29);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 0.0f + "'", float56 == 0.0f);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getIgnoreNullValues();
        ringPlot0.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        ringPlot8.setInnerSeparatorExtension((double) (byte) 100);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        ringPlot8.setDataset(pieDataset11);
        double double14 = ringPlot8.getExplodePercent((java.lang.Comparable) false);
        boolean boolean15 = ringPlot8.getSectionOutlinesVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = chartRenderingInfo17.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = chartRenderingInfo19.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        plotRenderingInfo20.setPlotArea(rectangle2D21);
        plotRenderingInfo18.addSubplotInfo(plotRenderingInfo20);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState24 = ringPlot0.initialise(graphics2D5, rectangle2D6, (org.jfree.chart.plot.PiePlot) ringPlot8, (java.lang.Integer) 15, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo18);
        org.junit.Assert.assertNotNull(plotRenderingInfo20);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        java.util.List list2 = axisCollection0.getAxesAtLeft();
        java.util.List list3 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis12.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis12.setMarkerBand(markerAxisBand15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        boolean boolean18 = numberAxis12.isAutoRange();
        numberAxis12.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer21 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean25 = ringPlot23.equals((java.lang.Object) 'a');
        java.awt.Paint paint27 = null;
        ringPlot23.setSectionOutlinePaint((java.lang.Comparable) 'a', paint27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        java.awt.Font font35 = categoryAxis30.getLabelFont();
        ringPlot23.setLabelFont(font35);
        levelRenderer21.setSeriesItemLabelFont(0, font35);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer21);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot38.getRowRenderingOrder();
        java.awt.Stroke stroke40 = categoryPlot38.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        categoryPlot38.setFixedDomainAxisSpace(axisSpace41);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.setAxisLineVisible(true);
        java.awt.Paint paint6 = categoryAxis2.getTickLabelPaint();
        levelRenderer0.setBaseItemLabelPaint(paint6, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        levelRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        levelRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        try {
            java.util.Date date5 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setErrorIndicatorPaint(paint3);
        java.lang.Boolean boolean6 = statisticalBarRenderer0.getSeriesCreateEntities((int) (short) 1);
        java.awt.Paint paint8 = statisticalBarRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        statisticalBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        float float2 = ringPlot1.getForegroundAlpha();
        try {
            ringPlot1.setBackgroundImageAlpha((float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray5 = legendTitle3.getSources();
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(legendItemSourceArray5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        java.lang.Object obj9 = lineRenderer3D0.clone();
        lineRenderer3D0.setXOffset((double) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 100, (double) 10);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement5);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        blockContainer7.setPadding((double) 'a', (-1.0d), (double) '#', 1.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke15 = categoryAxis14.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis14.getCategoryEnd((int) ' ', (-459), rectangle2D18, rectangleEdge19);
        boolean boolean21 = blockContainer7.equals((java.lang.Object) rectangle2D18);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.Range range26 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str27 = range26.toString();
        double double28 = range26.getCentralValue();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange(range26);
        java.util.Date date30 = dateRange29.getUpperDate();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint35 = statisticalBarRenderer32.getItemFillPaint(0, (int) '#');
        boolean boolean36 = lengthConstraintType31.equals((java.lang.Object) 0);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis39.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis39.setMarkerBand(markerAxisBand42);
        org.jfree.data.Range range44 = numberAxis39.getDefaultAutoRange();
        boolean boolean45 = numberAxis39.isAutoRange();
        numberAxis39.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range48 = numberAxis39.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType49 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange29, lengthConstraintType31, 0.0d, range48, lengthConstraintType49);
        try {
            org.jfree.chart.util.Size2D size2D51 = columnArrangement5.arrange(blockContainer7, graphics2D22, rectangleConstraint50);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Range[0.0,0.0]" + "'", str27.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(lengthConstraintType49);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = piePlot0.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot2.setDomainAxisLocation(1900, axisLocation4);
        java.awt.Stroke stroke6 = categoryPlot2.getRangeCrosshairStroke();
        categoryPlot2.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getColumnRenderingOrder();
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot2.getDomainMarkers((int) ' ', layer12);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot2.getLegendItems();
        legendItemCollection1.addAll(legendItemCollection14);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(legendItemCollection14);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryEnd((int) ' ', (-459), rectangle2D5, rectangleEdge6);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot8);
        jFreeChart9.removeLegend();
        jFreeChart9.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart9.getLegend(3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str15 = chartChangeEventType14.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) ' ', jFreeChart9, chartChangeEventType14);
        org.jfree.chart.title.Title title17 = null;
        jFreeChart9.removeSubtitle(title17);
        java.awt.Image image19 = jFreeChart9.getBackgroundImage();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str15.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 3, 1.0d);
        size2D2.setWidth((double) (byte) 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str3 = range2.toString();
        double double4 = range2.getCentralValue();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range2);
        boolean boolean8 = dateRange5.intersects((double) 'a', (double) 6);
        java.util.Date date9 = dateRange5.getLowerDate();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,0.0]" + "'", str3.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) 0);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 0.25d, (double) (-459));
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart3.removeLegend();
        jFreeChart3.clearSubtitles();
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
        jFreeChart3.clearSubtitles();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        int int16 = color11.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font9, (java.awt.Paint) color11);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            labelBlock17.draw(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint3 = statisticalBarRenderer0.getItemFillPaint(0, (int) '#');
        java.awt.Color color4 = java.awt.Color.GREEN;
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color4, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration2 = dataPackageResources0.getKeys();
        java.lang.Object obj4 = dataPackageResources0.handleGetObject("ChartChangeEventType.NEW_DATASET");
        try {
            java.lang.Object obj6 = dataPackageResources0.getObject("RangeType.FULL");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key RangeType.FULL");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strEnumeration2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("poly");
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str10 = rectangleEdge9.toString();
        try {
            double double11 = categoryAxis1.getCategoryMiddle(11, 7, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleEdge.BOTTOM" + "'", str10.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color4 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color4);
        double double7 = rectangleInsets0.extendHeight((double) 'a');
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets0.getUnitType();
        double double10 = rectangleInsets0.calculateRightOutset((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = dateAxis1.getTickMarkPosition();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot3);
//        jFreeChart4.removeLegend();
//        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
//        java.awt.Color color10 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
//        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(rectangleInsets6, (java.awt.Paint) color10);
//        double double12 = rectangleInsets6.getRight();
//        jFreeChart4.setPadding(rectangleInsets6);
//        boolean boolean14 = jFreeChart4.getAntiAlias();
//        jFreeChart4.setNotify(true);
//        boolean boolean17 = dateAxis1.equals((java.lang.Object) true);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.util.Date date19 = month18.getEnd();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int21 = segmentedTimeline20.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot22);
//        jFreeChart23.removeLegend();
//        jFreeChart23.clearSubtitles();
//        boolean boolean26 = segmentedTimeline20.equals((java.lang.Object) jFreeChart23);
//        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long28 = segmentedTimeline20.getTime(date27);
//        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        java.util.Date date31 = month30.getEnd();
//        boolean boolean32 = segmentedTimeline20.containsDomainRange(date29, date31);
//        try {
//            dateAxis1.setRange(date19, date29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTickMarkPosition2);
//        org.junit.Assert.assertNotNull(rectangleInsets6);
//        org.junit.Assert.assertNotNull(color10);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(segmentedTimeline20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 7 + "'", int21 == 7);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560179855055L + "'", long28 == 1560179855055L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 5, (java.lang.Number) 1.0f, (java.lang.Number) 100, (java.lang.Number) 1.0E-8d, (java.lang.Number) 0.4d, (java.lang.Number) 2, (java.lang.Number) (-459), (java.lang.Number) (byte) 10, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMaxRegularValue();
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo();
        boolean boolean13 = boxAndWhiskerItem10.equals((java.lang.Object) projectInfo12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint16 = lineBorder15.getPaint();
        java.awt.Stroke stroke17 = lineBorder15.getStroke();
        categoryPlot14.setDomainGridlineStroke(stroke17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace19);
        boolean boolean21 = projectInfo12.equals((java.lang.Object) axisSpace19);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2 + "'", number11.equals(2));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.removeChangeListener(plotChangeListener6);
        org.jfree.chart.plot.Plot plot8 = piePlot5.getRootPlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot5);
        piePlot5.setNoDataMessage("cyan");
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = stackedAreaRenderer1.getPositiveItemLabelPosition((int) (short) 10, 1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        stackedAreaRenderer1.notifyListeners(rendererChangeEvent5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        double double9 = ringPlot8.getInnerSeparatorExtension();
        java.awt.Image image10 = ringPlot8.getBackgroundImage();
        java.awt.Paint paint11 = ringPlot8.getBaseSectionPaint();
        stackedAreaRenderer1.setBaseItemLabelPaint(paint11, false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo15.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        plotRenderingInfo16.setPlotArea(rectangle2D17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        plotRenderingInfo16.setDataArea(rectangle2D19);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState21 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo16);
        double double22 = categoryItemRendererState21.getBarWidth();
        org.jfree.chart.entity.EntityCollection entityCollection23 = categoryItemRendererState21.getEntityCollection();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint27 = lineBorder26.getPaint();
        java.awt.Stroke stroke28 = lineBorder26.getStroke();
        categoryPlot25.setDomainGridlineStroke(stroke28);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer30 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer30.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = levelRenderer30.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator34 = levelRenderer30.getBaseItemLabelGenerator();
        categoryPlot25.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer30, false);
        java.lang.Number[] numberArray39 = new java.lang.Number[] {};
        java.lang.Number[] numberArray40 = new java.lang.Number[] {};
        java.lang.Number[] numberArray41 = new java.lang.Number[] {};
        java.lang.Number[] numberArray42 = new java.lang.Number[] {};
        java.lang.Number[] numberArray43 = new java.lang.Number[] {};
        java.lang.Number[] numberArray44 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray39, numberArray40, numberArray41, numberArray42, numberArray43, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray45);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis49.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand52 = null;
        numberAxis49.setMarkerBand(markerAxisBand52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        boolean boolean55 = numberAxis49.isAutoRange();
        numberAxis49.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer58 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot60 = new org.jfree.chart.plot.RingPlot();
        boolean boolean62 = ringPlot60.equals((java.lang.Object) 'a');
        java.awt.Paint paint64 = null;
        ringPlot60.setSectionOutlinePaint((java.lang.Comparable) 'a', paint64);
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke68 = categoryAxis67.getTickMarkStroke();
        categoryAxis67.setAxisLineVisible(true);
        java.awt.Paint paint71 = categoryAxis67.getAxisLinePaint();
        java.awt.Font font72 = categoryAxis67.getLabelFont();
        ringPlot60.setLabelFont(font72);
        levelRenderer58.setSeriesItemLabelFont(0, font72);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D47, (org.jfree.chart.axis.ValueAxis) numberAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer58);
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis77.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand80 = null;
        numberAxis77.setMarkerBand(markerAxisBand80);
        org.jfree.data.Range range82 = numberAxis77.getDefaultAutoRange();
        boolean boolean83 = numberAxis77.isAutoRange();
        numberAxis77.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range86 = numberAxis77.getDefaultAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand87 = null;
        numberAxis77.setMarkerBand(markerAxisBand87);
        numberAxis77.setFixedDimension((double) 255);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection91 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list92 = taskSeriesCollection91.getColumnKeys();
        int int94 = taskSeriesCollection91.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range95 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection91);
        try {
            stackedAreaRenderer1.drawItem(graphics2D14, categoryItemRendererState21, rectangle2D24, categoryPlot25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D47, (org.jfree.chart.axis.ValueAxis) numberAxis77, (org.jfree.data.category.CategoryDataset) taskSeriesCollection91, 10, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(entityCollection23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(categoryURLGenerator33);
        org.junit.Assert.assertNull(categoryItemLabelGenerator34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertNotNull(range82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(range86);
        org.junit.Assert.assertNotNull(list92);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
        org.junit.Assert.assertNull(range95);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.setAxisLineVisible(true);
        java.awt.Paint paint7 = categoryAxis3.getAxisLinePaint();
        stackedAreaRenderer1.setBaseOutlinePaint(paint7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.lang.Number[] numberArray14 = new java.lang.Number[] {};
        java.lang.Number[] numberArray15 = new java.lang.Number[] {};
        java.lang.Number[] numberArray16 = new java.lang.Number[] {};
        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
        java.lang.Number[] numberArray18 = new java.lang.Number[] {};
        java.lang.Number[] numberArray19 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray14, numberArray15, numberArray16, numberArray17, numberArray18, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis24.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand27 = null;
        numberAxis24.setMarkerBand(markerAxisBand27);
        org.jfree.data.Range range29 = numberAxis24.getDefaultAutoRange();
        boolean boolean30 = numberAxis24.isAutoRange();
        numberAxis24.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer33 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        boolean boolean37 = ringPlot35.equals((java.lang.Object) 'a');
        java.awt.Paint paint39 = null;
        ringPlot35.setSectionOutlinePaint((java.lang.Comparable) 'a', paint39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke43 = categoryAxis42.getTickMarkStroke();
        categoryAxis42.setAxisLineVisible(true);
        java.awt.Paint paint46 = categoryAxis42.getAxisLinePaint();
        java.awt.Font font47 = categoryAxis42.getLabelFont();
        ringPlot35.setLabelFont(font47);
        levelRenderer33.setSeriesItemLabelFont(0, font47);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer33);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis52.setAxisLineVisible(true);
        categoryAxis52.setCategoryLabelPositionOffset(7);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        double double58 = numberAxis57.getUpperMargin();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection59 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list60 = taskSeriesCollection59.getColumnKeys();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = null;
        taskSeriesCollection59.seriesChanged(seriesChangeEvent61);
        try {
            stackedAreaRenderer1.drawItem(graphics2D9, categoryItemRendererState10, rectangle2D11, categoryPlot50, categoryAxis52, (org.jfree.chart.axis.ValueAxis) numberAxis57, (org.jfree.data.category.CategoryDataset) taskSeriesCollection59, (int) ' ', (int) (short) 10, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.05d + "'", double58 == 0.05d);
        org.junit.Assert.assertNotNull(list60);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType1);
        statisticalBarRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer2);
        java.awt.GradientPaint gradientPaint4 = null;
        java.awt.Shape shape5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        try {
            java.awt.GradientPaint gradientPaint6 = standardGradientPaintTransformer2.transform(gradientPaint4, shape5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.setAxisLineVisible(true);
        java.awt.Paint paint7 = categoryAxis3.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = textBlock8.calculateDimensions(graphics2D9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock8.calculateDimensions(graphics2D11);
        double double13 = size2D12.width;
        double double14 = size2D12.getHeight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(textBlock8);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown((double) (short) 10);
        axisState0.cursorUp((double) 10.0f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int1 = segmentedTimeline0.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
        jFreeChart3.removeLegend();
        jFreeChart3.clearSubtitles();
        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline0.getSegment(0L);
        int int9 = segmentedTimeline0.getSegmentsIncluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) itemLabelAnchor3);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        int int6 = segmentedTimeline5.getGroupSegmentCount();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot7);
        jFreeChart8.removeLegend();
        jFreeChart8.clearSubtitles();
        boolean boolean11 = segmentedTimeline5.equals((java.lang.Object) jFreeChart8);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline5.getSegment(0L);
        segment13.dec((long) (short) 10);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) segment13);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment19 = segment13.intersect(100L, 1560179855055L);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(segment13);
        org.junit.Assert.assertNull(segment19);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        java.lang.String str2 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str1.equals("GradientPaintTransformType.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str2.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        java.awt.Paint paint7 = stackedAreaRenderer1.getItemOutlinePaint(4, (int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint10 = lineBorder9.getPaint();
        java.awt.Stroke stroke11 = lineBorder9.getStroke();
        categoryPlot8.setDomainGridlineStroke(stroke11);
        stackedAreaRenderer1.setPlot(categoryPlot8);
        java.awt.Graphics2D graphics2D14 = null;
        java.lang.Number[] numberArray17 = new java.lang.Number[] {};
        java.lang.Number[] numberArray18 = new java.lang.Number[] {};
        java.lang.Number[] numberArray19 = new java.lang.Number[] {};
        java.lang.Number[] numberArray20 = new java.lang.Number[] {};
        java.lang.Number[] numberArray21 = new java.lang.Number[] {};
        java.lang.Number[] numberArray22 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] { numberArray17, numberArray18, numberArray19, numberArray20, numberArray21, numberArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray23);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis27.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis27.setMarkerBand(markerAxisBand30);
        org.jfree.data.Range range32 = numberAxis27.getDefaultAutoRange();
        boolean boolean33 = numberAxis27.isAutoRange();
        numberAxis27.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer36 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot38 = new org.jfree.chart.plot.RingPlot();
        boolean boolean40 = ringPlot38.equals((java.lang.Object) 'a');
        java.awt.Paint paint42 = null;
        ringPlot38.setSectionOutlinePaint((java.lang.Comparable) 'a', paint42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke46 = categoryAxis45.getTickMarkStroke();
        categoryAxis45.setAxisLineVisible(true);
        java.awt.Paint paint49 = categoryAxis45.getAxisLinePaint();
        java.awt.Font font50 = categoryAxis45.getLabelFont();
        ringPlot38.setLabelFont(font50);
        levelRenderer36.setSeriesItemLabelFont(0, font50);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer36);
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot53.getRowRenderingOrder();
        java.awt.Stroke stroke55 = categoryPlot53.getRangeCrosshairStroke();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        try {
            stackedAreaRenderer1.drawDomainGridline(graphics2D14, categoryPlot53, rectangle2D56, (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(sortOrder54);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (-459), (-1.0f));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            categoryPlot0.drawBackground(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Color color1 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        valueMarker5.notifyListeners(markerChangeEvent6);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        valueMarker5.setLabelTextAnchor(textAnchor8);
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        valueMarker5.setLabelPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 1560179855055L);
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = categoryPlot0.getDatasetRenderingOrder();
        try {
            categoryPlot0.mapDatasetToDomainAxis((-459), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.removeAll();
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = levelRenderer0.getBaseURLGenerator();
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke9 = categoryAxis8.getTickMarkStroke();
        categoryAxis8.setAxisLineVisible(true);
        java.awt.Paint paint12 = categoryAxis8.getAxisLinePaint();
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font6, paint12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint17 = statisticalBarRenderer14.getItemFillPaint(0, (int) '#');
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", font6, paint17);
        levelRenderer0.setBaseFillPaint(paint17, false);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.clone(shape22);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity26 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0.25d, shape23, "", "");
        java.awt.Shape shape27 = categoryLabelEntity26.getArea();
        levelRenderer0.setBaseShape(shape27, false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 8, (float) (byte) 100, textAnchor4, (double) 2, (float) 8, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        int int5 = stackedAreaRenderer1.getPassCount();
        java.awt.Stroke stroke6 = stackedAreaRenderer1.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D10 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, (java.awt.Paint) color15);
        lineRenderer3D10.setWallPaint((java.awt.Paint) color15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineRenderer3D10.getSeriesPositiveItemLabelPosition((int) 'a');
        stackedAreaRenderer8.setSeriesNegativeItemLabelPosition(0, itemLabelPosition19, false);
        stackedAreaRenderer1.setBasePositiveItemLabelPosition(itemLabelPosition19, true);
        int int24 = stackedAreaRenderer1.getPassCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        java.awt.Font font7 = numberAxis1.getTickLabelFont();
        numberAxis1.setFixedAutoRange((double) '#');
        org.jfree.chart.plot.Plot plot10 = numberAxis1.getPlot();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem11 = lineRenderer3D0.getLegendItem(10, 100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = lineRenderer3D0.getLegendItemURLGenerator();
        double double13 = lineRenderer3D0.getXOffset();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 12.0d + "'", double13 == 12.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        java.awt.Color color3 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke6);
        java.lang.String str8 = org.jfree.chart.util.PaintUtilities.colorToString(color3);
        multiplePiePlot0.setBackgroundPaint((java.awt.Paint) color3);
        java.awt.Color color10 = color3.brighter();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "cyan" + "'", str8.equals("cyan"));
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Color color1 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        java.awt.Paint paint6 = valueMarker5.getPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (byte) 0, (java.lang.Number) (-459));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        org.jfree.data.RangeType rangeType5 = numberAxis1.getRangeType();
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(rangeType5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 10.0d, (double) (-1), rectangleAnchor3);
        double double5 = size2D0.getHeight();
        size2D0.setHeight((double) 7);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        boolean boolean10 = textBlockAnchor0.equals((java.lang.Object) font9);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer5.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        double double11 = ringPlot10.getInnerSeparatorExtension();
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot10.setLabelShadowPaint(paint12);
        stackedAreaRenderer5.setBaseOutlinePaint(paint12, false);
        stackedAreaRenderer5.setAutoPopulateSeriesShape(false);
        java.lang.Boolean boolean19 = stackedAreaRenderer5.getSeriesVisible((int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = stackedAreaRenderer5.getBaseNegativeItemLabelPosition();
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition20, true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D27 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color32 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder(rectangleInsets28, (java.awt.Paint) color32);
        lineRenderer3D27.setWallPaint((java.awt.Paint) color32);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = lineRenderer3D27.getSeriesPositiveItemLabelPosition((int) 'a');
        stackedAreaRenderer25.setSeriesNegativeItemLabelPosition(0, itemLabelPosition36, false);
        try {
            lineRenderer3D0.setSeriesNegativeItemLabelPosition((int) (byte) -1, itemLabelPosition36, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        double double1 = categoryLabelPosition0.getAngle();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = categoryLabelPosition0.getCategoryAnchor();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean3 = ringPlot1.equals((java.lang.Object) 'a');
        java.awt.Paint paint5 = null;
        ringPlot1.setSectionOutlinePaint((java.lang.Comparable) 'a', paint5);
        ringPlot1.setPieIndex((int) ' ');
        java.awt.Font font9 = ringPlot1.getLabelFont();
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke14 = categoryAxis13.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        int int16 = color11.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font9, (java.awt.Paint) color11);
        java.lang.Object obj18 = labelBlock17.clone();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.Range range23 = new org.jfree.data.Range(0.0d, 0.0d);
        java.lang.String str24 = range23.toString();
        double double25 = range23.getCentralValue();
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange(range23);
        java.util.Date date27 = dateRange26.getUpperDate();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint32 = statisticalBarRenderer29.getItemFillPaint(0, (int) '#');
        boolean boolean33 = lengthConstraintType28.equals((java.lang.Object) 0);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis36.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand39 = null;
        numberAxis36.setMarkerBand(markerAxisBand39);
        org.jfree.data.Range range41 = numberAxis36.getDefaultAutoRange();
        boolean boolean42 = numberAxis36.isAutoRange();
        numberAxis36.resizeRange((double) 1559372400000L);
        org.jfree.data.Range range45 = numberAxis36.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType46 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange26, lengthConstraintType28, 0.0d, range45, lengthConstraintType46);
        try {
            org.jfree.chart.util.Size2D size2D48 = labelBlock17.arrange(graphics2D19, rectangleConstraint47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Range[0.0,0.0]" + "'", str24.equals("Range[0.0,0.0]"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(lengthConstraintType46);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) 'a', 0L);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        java.util.Date date5 = month4.getEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline0.getSegment(date5);
        segment6.inc();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(segment6);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis2.setMinimumDate(date3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str6 = serialDate5.toString();
//        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis8.setMinimumDate(date9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
//        org.jfree.data.time.SerialDate serialDate12 = serialDate5.getEndOfCurrentMonth(serialDate11);
//        java.lang.String str13 = serialDate12.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate12);
//        try {
//            org.jfree.data.time.SerialDate serialDate16 = serialDate14.getFollowingDayOfWeek(205);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "30-June-2019" + "'", str13.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
//        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
//        org.jfree.data.gantt.TaskSeries taskSeries3 = taskSeriesCollection0.getSeries((java.lang.Comparable) true);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int5 = segmentedTimeline4.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot6);
//        jFreeChart7.removeLegend();
//        jFreeChart7.clearSubtitles();
//        boolean boolean10 = segmentedTimeline4.equals((java.lang.Object) jFreeChart7);
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long12 = segmentedTimeline4.getTime(date11);
//        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.util.Date date15 = month14.getEnd();
//        boolean boolean16 = segmentedTimeline4.containsDomainRange(date13, date15);
//        try {
//            java.lang.Number number18 = taskSeriesCollection0.getValue((java.lang.Comparable) boolean16, (java.lang.Comparable) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(number1);
//        org.junit.Assert.assertNull(taskSeries3);
//        org.junit.Assert.assertNotNull(segmentedTimeline4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560179855055L + "'", long12 == 1560179855055L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TextAnchor.CENTER");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        categoryAxis2.setAxisLineVisible(true);
        java.awt.Paint paint6 = categoryAxis2.getTickLabelPaint();
        levelRenderer0.setBaseItemLabelPaint(paint6, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        levelRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator9);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis12.setMinimumDate(date13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection16 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list17 = taskSeriesCollection16.getColumnKeys();
        int int19 = taskSeriesCollection16.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable20 = null;
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection16, comparable20);
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection16, (java.lang.Comparable) 255);
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) serialDate15, (org.jfree.data.KeyedValues) pieDataset23);
        try {
            java.lang.String str26 = standardCategorySeriesLabelGenerator9.generateLabel(categoryDataset24, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(pieDataset21);
        org.junit.Assert.assertNotNull(pieDataset23);
        org.junit.Assert.assertNotNull(categoryDataset24);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,0.0]", "RectangleAnchor.TOP", numberArray8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis12.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis12.setMarkerBand(markerAxisBand15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        boolean boolean18 = numberAxis12.isAutoRange();
        numberAxis12.resizeRange((double) 1559372400000L);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer21 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean25 = ringPlot23.equals((java.lang.Object) 'a');
        java.awt.Paint paint27 = null;
        ringPlot23.setSectionOutlinePaint((java.lang.Comparable) 'a', paint27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        java.awt.Font font35 = categoryAxis30.getLabelFont();
        ringPlot23.setLabelFont(font35);
        levelRenderer21.setSeriesItemLabelFont(0, font35);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer21);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot38.getRowRenderingOrder();
        org.jfree.chart.text.TextFragment textFragment41 = new org.jfree.chart.text.TextFragment("Range[0.0,0.0]");
        boolean boolean42 = sortOrder39.equals((java.lang.Object) "Range[0.0,0.0]");
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation(1900, axisLocation2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxisForDataset((int) (byte) 1);
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint8, stroke9, (java.awt.Paint) color13, stroke14, 1.0f);
        java.awt.Paint paint17 = categoryMarker16.getOutlinePaint();
        categoryMarker16.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = categoryMarker16.getLabelOffsetType();
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker16, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation3);
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint7, stroke8, (java.awt.Paint) color12, stroke13, 1.0f);
        java.awt.Paint paint16 = categoryMarker15.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryMarker15.setOutlinePaint((java.awt.Paint) color18);
        org.jfree.chart.util.Layer layer20 = null;
        try {
            categoryPlot0.addDomainMarker((int) (byte) -1, categoryMarker15, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Object obj0 = null;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list2 = taskSeriesCollection1.getColumnKeys();
        int int4 = taskSeriesCollection1.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot6.equals((java.lang.Object) 'a');
        ringPlot6.setForegroundAlpha((float) (short) -1);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer12.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot(pieDataset16);
        double double18 = ringPlot17.getInnerSeparatorExtension();
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot17.setLabelShadowPaint(paint19);
        stackedAreaRenderer12.setBaseOutlinePaint(paint19, false);
        ringPlot6.setSeparatorPaint(paint19);
        taskSeriesCollection1.removeChangeListener((org.jfree.data.general.DatasetChangeListener) ringPlot6);
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent(obj0, (org.jfree.data.general.Dataset) taskSeriesCollection1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D3 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color8 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets4, (java.awt.Paint) color8);
        lineRenderer3D3.setWallPaint((java.awt.Paint) color8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = lineRenderer3D3.getSeriesPositiveItemLabelPosition((int) 'a');
        stackedAreaRenderer1.setSeriesNegativeItemLabelPosition(0, itemLabelPosition12, false);
        boolean boolean16 = stackedAreaRenderer1.isSeriesItemLabelsVisible((-1));
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Shape shape0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOutlineVisible(true);
        java.awt.Stroke stroke4 = ringPlot1.getBaseSectionOutlineStroke();
        org.jfree.chart.util.Rotation rotation5 = null;
        try {
            ringPlot1.setDirection(rotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setPadding((double) 'a', (-1.0d), (double) '#', 1.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke8 = categoryAxis7.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis7.getCategoryEnd((int) ' ', (-459), rectangle2D11, rectangleEdge12);
        boolean boolean14 = blockContainer0.equals((java.lang.Object) rectangle2D11);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.lang.Object obj17 = null;
        try {
            java.lang.Object obj18 = blockContainer0.draw(graphics2D15, rectangle2D16, obj17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
//        jFreeChart3.removeLegend();
//        jFreeChart3.clearSubtitles();
//        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long8 = segmentedTimeline0.getTime(date7);
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.util.Date date11 = month10.getEnd();
//        boolean boolean12 = segmentedTimeline0.containsDomainRange(date9, date11);
//        segmentedTimeline0.setStartTime((long) 15);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560179855055L + "'", long8 == 1560179855055L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint4 = statisticalBarRenderer1.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer1.setMinimumBarLength((double) (short) 100);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke12);
        statisticalBarRenderer1.setSeriesPaint((int) '4', (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D16 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, (java.awt.Paint) color21);
        lineRenderer3D16.setWallPaint((java.awt.Paint) color21);
        statisticalBarRenderer1.setSeriesPaint(0, (java.awt.Paint) color21, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = statisticalBarRenderer1.getPlot();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer1);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer29 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer29.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot(pieDataset33);
        double double35 = ringPlot34.getInnerSeparatorExtension();
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot34.setLabelShadowPaint(paint36);
        stackedAreaRenderer29.setBaseOutlinePaint(paint36, false);
        categoryPlot0.setBackgroundPaint(paint36);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(categoryPlot26);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.2d + "'", double35 == 0.2d);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        java.awt.Paint paint8 = lineRenderer3D0.getWallPaint();
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer10 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer10.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = levelRenderer10.getBaseURLGenerator();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer16.getPositiveItemLabelPosition((int) (short) 10, 1);
        levelRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition19);
        lineRenderer3D0.setSeriesPositiveItemLabelPosition(11, itemLabelPosition19, true);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = ganttRenderer0.getURLGenerator((int) (byte) 1, 2);
        double double4 = ganttRenderer0.getBase();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = ganttRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint7 = ganttRenderer0.lookupSeriesPaint((int) '4');
        ganttRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, comparable4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) 255);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieDataset7);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getEnd();
        int int5 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) date4);
        defaultKeyedValues2D1.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.clone(shape1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0.25d, shape2, "", "");
        java.awt.Shape shape6 = categoryLabelEntity5.getArea();
        java.lang.String str7 = categoryLabelEntity5.toString();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CategoryLabelEntity: category=0.25, tooltip=, url=" + "'", str7.equals("CategoryLabelEntity: category=0.25, tooltip=, url="));
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis3.setMinimumDate(date4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str7 = serialDate6.toString();
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis9.setMinimumDate(date10);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate6.getEndOfCurrentMonth(serialDate12);
//        java.lang.String str14 = serialDate13.toString();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate13);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) '4', serialDate15);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "30-June-2019" + "'", str14.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        int int4 = taskSeriesCollection1.indexOf((java.lang.Comparable) 255);
        boolean boolean5 = rangeType0.equals((java.lang.Object) taskSeriesCollection1);
        int int7 = taskSeriesCollection1.getColumnIndex((java.lang.Comparable) (byte) 0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint4 = statisticalBarRenderer1.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer1.setMinimumBarLength((double) (short) 100);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke12);
        statisticalBarRenderer1.setSeriesPaint((int) '4', (java.awt.Paint) color9);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D16 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, (java.awt.Paint) color21);
        lineRenderer3D16.setWallPaint((java.awt.Paint) color21);
        statisticalBarRenderer1.setSeriesPaint(0, (java.awt.Paint) color21, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = statisticalBarRenderer1.getPlot();
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer1);
        java.awt.Paint paint30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color35 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke36 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint30, stroke31, (java.awt.Paint) color35, stroke36, 1.0f);
        java.awt.Paint paint39 = categoryMarker38.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker38);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryMarker38.setLabelOffset(rectangleInsets41);
        org.jfree.chart.util.Layer layer43 = null;
        try {
            categoryPlot0.addDomainMarker(2, categoryMarker38, layer43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(categoryPlot26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getEnd();
        int int5 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) date4);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) 5);
        try {
            java.lang.Number number11 = defaultKeyedValues2D1.getValue(15, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis2.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis2.setMarkerBand(markerAxisBand5);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        java.awt.Font font8 = numberAxis2.getTickLabelFont();
        boolean boolean9 = shapeList0.equals((java.lang.Object) numberAxis2);
        java.awt.Shape shape10 = numberAxis2.getUpArrow();
        numberAxis2.configure();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.clone(shape13);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 0.25d, shape14, "", "");
        numberAxis2.setDownArrow(shape14);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint();
        java.lang.String str7 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 4.0d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        double double1 = lineRenderer3D0.getXOffset();
        boolean boolean2 = lineRenderer3D0.getBaseShapesFilled();
        boolean boolean3 = lineRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = lineRenderer3D0.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineRenderer3D0.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator6, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = ganttRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNull(itemLabelPosition1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle3.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color9 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color9);
        double double11 = rectangleInsets5.getRight();
        double double13 = rectangleInsets5.calculateBottomInset((double) 2);
        legendTitle3.setLegendItemGraphicPadding(rectangleInsets5);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.Paint paint18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color23 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke24 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint18, stroke19, (java.awt.Paint) color23, stroke24, 1.0f);
        java.awt.Paint paint27 = categoryMarker26.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker26);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryMarker26.setLabelOffset(rectangleInsets29);
        double double32 = rectangleInsets29.calculateLeftInset((double) 1.0f);
        try {
            java.lang.Object obj33 = legendTitle3.draw(graphics2D15, rectangle2D16, (java.lang.Object) double32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date2);
        dateAxis1.setRange(0.0d, (double) (short) 10);
        float float7 = dateAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setAxisLineVisible(true);
        java.awt.Paint paint5 = categoryAxis1.getAxisLinePaint();
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint8, stroke9, (java.awt.Paint) color13, stroke14, 1.0f);
        categoryAxis1.setTickMarkStroke(stroke9);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        boolean boolean20 = ringPlot19.getIgnoreNullValues();
        ringPlot19.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        boolean boolean24 = categoryLabelPositions18.equals((java.lang.Object) (short) -1);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions18);
        categoryAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, (double) 100.0f);
        boolean boolean4 = stackedBarRenderer3D2.isSeriesVisibleInLegend(0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint10 = statisticalBarRenderer7.getItemFillPaint(0, (int) '#');
        statisticalBarRenderer7.setMinimumBarLength((double) (short) 100);
        java.awt.Color color15 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke18 = categoryAxis17.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke18);
        statisticalBarRenderer7.setSeriesPaint((int) '4', (java.awt.Paint) color15);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D22 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder(rectangleInsets23, (java.awt.Paint) color27);
        lineRenderer3D22.setWallPaint((java.awt.Paint) color27);
        statisticalBarRenderer7.setSeriesPaint(0, (java.awt.Paint) color27, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = statisticalBarRenderer7.getPlot();
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = chartRenderingInfo36.getPlotInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = chartRenderingInfo38.getPlotInfo();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        plotRenderingInfo39.setPlotArea(rectangle2D40);
        plotRenderingInfo37.addSubplotInfo(plotRenderingInfo39);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        numberAxis44.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis44.setMarkerBand(markerAxisBand47);
        boolean boolean49 = plotRenderingInfo37.equals((java.lang.Object) markerAxisBand47);
        java.awt.geom.Rectangle2D rectangle2D50 = plotRenderingInfo37.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = null;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D51, rectangleAnchor52);
        categoryPlot6.zoomDomainAxes((double) '4', 10.0d, plotRenderingInfo37, point2D53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        try {
            stackedBarRenderer3D2.drawDomainGridline(graphics2D5, categoryPlot6, rectangle2D55, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(categoryPlot32);
        org.junit.Assert.assertNotNull(plotRenderingInfo37);
        org.junit.Assert.assertNotNull(plotRenderingInfo39);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(rectangle2D50);
        org.junit.Assert.assertNotNull(point2D53);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity2 = new org.jfree.chart.entity.LegendItemEntity(shape1);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color5);
        lineRenderer3D0.setWallPaint((java.awt.Paint) color5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = lineRenderer3D0.getBaseToolTipGenerator();
        java.lang.Object obj9 = lineRenderer3D0.clone();
        java.awt.Font font10 = lineRenderer3D0.getBaseItemLabelFont();
        lineRenderer3D0.setDrawOutlines(true);
        lineRenderer3D0.setItemLabelAnchorOffset(1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection8 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list9 = taskSeriesCollection8.getColumnKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem10 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 5, (java.lang.Number) 1.0f, (java.lang.Number) 100, (java.lang.Number) 1.0E-8d, (java.lang.Number) 0.4d, (java.lang.Number) 2, (java.lang.Number) (-459), (java.lang.Number) (byte) 10, list9);
        java.lang.Number number11 = boxAndWhiskerItem10.getMaxRegularValue();
        java.lang.Number number12 = boxAndWhiskerItem10.getMinRegularValue();
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2 + "'", number11.equals(2));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.4d + "'", number12.equals(0.4d));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        try {
            layeredBarRenderer0.setSeriesBarWidth((-4503480), (double) 1561964399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        int int3 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable4 = null;
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, comparable4);
        try {
            java.lang.Number number9 = taskSeriesCollection0.getPercentComplete(4, 11, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(pieDataset5);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        ringPlot1.setLabelLinkStroke(stroke4);
        double double6 = ringPlot1.getShadowYOffset();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        boolean boolean10 = ringPlot8.equals((java.lang.Object) 'a');
        java.awt.Paint paint12 = null;
        ringPlot8.setSectionOutlinePaint((java.lang.Comparable) 'a', paint12);
        ringPlot8.setPieIndex((int) ' ');
        java.awt.Font font16 = ringPlot8.getLabelFont();
        java.awt.Color color18 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke21 = categoryAxis20.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color18, stroke21);
        int int23 = color18.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font16, (java.awt.Paint) color18);
        ringPlot1.setNoDataMessageFont(font16);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = ganttRenderer0.getURLGenerator((int) (byte) 1, 2);
        double double4 = ganttRenderer0.getBase();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = ganttRenderer0.getLegendItemURLGenerator();
        ganttRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = ganttRenderer0.getToolTipGenerator((int) (short) -1, 0);
        java.awt.Paint paint15 = ganttRenderer0.getItemPaint(11, (int) 'a');
        double double16 = ganttRenderer0.getUpperClip();
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean7 = lineRenderer3D0.isItemLabelVisible((-459), (-1));
        java.awt.Shape shape8 = lineRenderer3D0.getBaseShape();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseSeriesVisibleInLegend(false);
        double double3 = ganttRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int1 = segmentedTimeline0.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot2);
//        jFreeChart3.removeLegend();
//        jFreeChart3.clearSubtitles();
//        boolean boolean6 = segmentedTimeline0.equals((java.lang.Object) jFreeChart3);
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long8 = segmentedTimeline0.getTime(date7);
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.util.Date date11 = month10.getEnd();
//        boolean boolean12 = segmentedTimeline0.containsDomainRange(date9, date11);
//        org.jfree.data.general.PieDataset pieDataset13 = null;
//        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
//        double double15 = ringPlot14.getInnerSeparatorExtension();
//        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
//        ringPlot14.setLabelShadowPaint(paint16);
//        ringPlot14.setShadowXOffset(0.2d);
//        java.awt.Stroke stroke20 = ringPlot14.getSeparatorStroke();
//        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
//        stackedAreaRenderer22.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
//        org.jfree.data.general.PieDataset pieDataset26 = null;
//        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot(pieDataset26);
//        double double28 = ringPlot27.getInnerSeparatorExtension();
//        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
//        ringPlot27.setLabelShadowPaint(paint29);
//        stackedAreaRenderer22.setBaseOutlinePaint(paint29, false);
//        ringPlot14.setNoDataMessagePaint(paint29);
//        java.lang.Class<?> wildcardClass34 = paint29.getClass();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline35 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int36 = segmentedTimeline35.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot37 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot37);
//        jFreeChart38.removeLegend();
//        jFreeChart38.clearSubtitles();
//        boolean boolean41 = segmentedTimeline35.equals((java.lang.Object) jFreeChart38);
//        java.util.Date date42 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long43 = segmentedTimeline35.getTime(date42);
//        java.util.TimeZone timeZone44 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date42, timeZone44);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(date11, date42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560179855055L + "'", long8 == 1560179855055L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
//        org.junit.Assert.assertNotNull(paint16);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
//        org.junit.Assert.assertNotNull(paint29);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(segmentedTimeline35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 7 + "'", int36 == 7);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560179855055L + "'", long43 == 1560179855055L);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (-459), shape1, "", "RectangleAnchor.TOP");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape1);
        java.lang.Comparable comparable7 = legendItemEntity6.getSeriesKey();
        java.lang.Comparable comparable8 = legendItemEntity6.getSeriesKey();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(comparable7);
        org.junit.Assert.assertNull(comparable8);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection1);
        int int4 = taskSeriesCollection1.indexOf((java.lang.Comparable) 255);
        boolean boolean5 = rangeType0.equals((java.lang.Object) taskSeriesCollection1);
        int int7 = taskSeriesCollection1.getColumnIndex((java.lang.Comparable) (byte) 0);
        try {
            java.lang.Number number11 = taskSeriesCollection1.getEndValue((java.lang.Comparable) (short) 100, (java.lang.Comparable) "CategoryLabelEntity: category=0.25, tooltip=, url=", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 3, (float) 0L);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        boolean boolean4 = ringPlot2.equals((java.lang.Object) 'a');
        java.awt.Paint paint6 = null;
        ringPlot2.setSectionOutlinePaint((java.lang.Comparable) 'a', paint6);
        ringPlot2.setPieIndex((int) ' ');
        java.awt.Font font10 = ringPlot2.getLabelFont();
        java.awt.Color color12 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke15 = categoryAxis14.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        int int17 = color12.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("Range[0.0,0.0]", font10, (java.awt.Paint) color12);
        java.awt.Font font19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        labelBlock18.setFont(font19);
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke28 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint22, stroke23, (java.awt.Paint) color27, stroke28, 1.0f);
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font19, (java.awt.Paint) color27);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = statisticalBarRenderer32.getToolTipGenerator((int) (byte) 10, (int) (short) -1);
        boolean boolean36 = textBlock31.equals((java.lang.Object) statisticalBarRenderer32);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNull(categoryToolTipGenerator35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent2);
        java.lang.String str4 = waferMapPlot1.getPlotType();
        java.lang.String str5 = waferMapPlot1.getPlotType();
        java.lang.String str6 = waferMapPlot1.getPlotType();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer7 = null;
        waferMapPlot1.setRenderer(waferMapRenderer7);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer9 = null;
        waferMapPlot1.setRenderer(waferMapRenderer9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "WMAP_Plot" + "'", str5.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "WMAP_Plot" + "'", str6.equals("WMAP_Plot"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesLinesVisible(100);
        int int3 = lineRenderer3D0.getPassCount();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint2 = lineBorder1.getPaint();
        java.awt.Stroke stroke3 = lineBorder1.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke3);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke8 = categoryAxis7.getTickMarkStroke();
        categoryAxis7.setAxisLineVisible(true);
        java.awt.Paint paint11 = categoryAxis7.getAxisLinePaint();
        java.awt.Font font12 = categoryAxis7.getLabelFont();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke20 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint14, stroke15, (java.awt.Paint) color19, stroke20, 1.0f);
        categoryAxis7.setTickMarkStroke(stroke15);
        categoryPlot0.setDomainAxis((int) '#', categoryAxis7, true);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        categoryAxis30.setAxisLineVisible(true);
        java.awt.Paint paint34 = categoryAxis30.getAxisLinePaint();
        java.awt.Font font35 = categoryAxis30.getLabelFont();
        java.awt.Paint paint37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color42 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke43 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint37, stroke38, (java.awt.Paint) color42, stroke43, 1.0f);
        categoryAxis30.setTickMarkStroke(stroke38);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions47 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        boolean boolean49 = ringPlot48.getIgnoreNullValues();
        ringPlot48.setExplodePercent((java.lang.Comparable) (short) -1, (double) (short) 100);
        boolean boolean53 = categoryLabelPositions47.equals((java.lang.Object) (short) -1);
        categoryAxis30.setCategoryLabelPositions(categoryLabelPositions47);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge55);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition57 = categoryLabelPositions47.getLabelPosition(rectangleEdge55);
        try {
            double double58 = categoryAxis7.getCategoryEnd(0, (int) (byte) 100, rectangle2D28, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(categoryLabelPosition57);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement2 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, (org.jfree.chart.block.Arrangement) columnArrangement1, (org.jfree.chart.block.Arrangement) centerArrangement2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle3.getItemLabelPadding();
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (byte) 1, (float) '4', (float) (short) -1);
        java.awt.Stroke stroke12 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0.2d, paint6, stroke7, (java.awt.Paint) color11, stroke12, 1.0f);
        java.awt.Paint paint15 = categoryMarker14.getOutlinePaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker14);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = categoryMarker14.getLabelOffsetType();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot18);
        java.awt.Color color21 = java.awt.Color.CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Stroke stroke24 = categoryAxis23.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color21, stroke24);
        java.lang.String str26 = org.jfree.chart.util.PaintUtilities.colorToString(color21);
        multiplePiePlot18.setBackgroundPaint((java.awt.Paint) color21);
        categoryMarker14.setOutlinePaint((java.awt.Paint) color21);
        legendTitle3.setItemPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "cyan" + "'", str26.equals("cyan"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        double double4 = ringPlot3.getInnerSeparatorExtension();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot3.setLabelShadowPaint(paint5);
        ringPlot3.setShadowXOffset(0.2d);
        java.awt.Stroke stroke9 = ringPlot3.getSeparatorStroke();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
        stackedAreaRenderer11.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot(pieDataset15);
        double double17 = ringPlot16.getInnerSeparatorExtension();
        java.awt.Paint paint18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot16.setLabelShadowPaint(paint18);
        stackedAreaRenderer11.setBaseOutlinePaint(paint18, false);
        ringPlot3.setNoDataMessagePaint(paint18);
        java.lang.Class<?> wildcardClass23 = paint18.getClass();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection25 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection25);
        int int28 = taskSeriesCollection25.indexOf((java.lang.Comparable) 255);
        java.lang.Class<?> wildcardClass29 = taskSeriesCollection25.getClass();
        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("cyan", (java.lang.Class) wildcardClass29);
        boolean boolean31 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass29);
        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Range[0.0,0.0]", (java.lang.Class) wildcardClass23, (java.lang.Class) wildcardClass29);
        java.lang.Object obj33 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TextAnchor.CENTER", (java.lang.Class) wildcardClass23);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNull(obj33);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        java.util.Date date0 = null;
//        org.jfree.data.general.PieDataset pieDataset1 = null;
//        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
//        double double3 = ringPlot2.getInnerSeparatorExtension();
//        java.awt.Paint paint4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
//        ringPlot2.setLabelShadowPaint(paint4);
//        ringPlot2.setShadowXOffset(0.2d);
//        java.awt.Stroke stroke8 = ringPlot2.getSeparatorStroke();
//        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
//        stackedAreaRenderer10.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) false);
//        org.jfree.data.general.PieDataset pieDataset14 = null;
//        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot(pieDataset14);
//        double double16 = ringPlot15.getInnerSeparatorExtension();
//        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
//        ringPlot15.setLabelShadowPaint(paint17);
//        stackedAreaRenderer10.setBaseOutlinePaint(paint17, false);
//        ringPlot2.setNoDataMessagePaint(paint17);
//        java.lang.Class<?> wildcardClass22 = paint17.getClass();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline23 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        int int24 = segmentedTimeline23.getGroupSegmentCount();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot();
//        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot25);
//        jFreeChart26.removeLegend();
//        jFreeChart26.clearSubtitles();
//        boolean boolean29 = segmentedTimeline23.equals((java.lang.Object) jFreeChart26);
//        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        long long31 = segmentedTimeline23.getTime(date30);
//        java.util.TimeZone timeZone32 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date30, timeZone32);
//        try {
//            org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date0, timeZone32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
//        org.junit.Assert.assertNotNull(paint4);
//        org.junit.Assert.assertNotNull(stroke8);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
//        org.junit.Assert.assertNotNull(paint17);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(segmentedTimeline23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 7 + "'", int24 == 7);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560179855055L + "'", long31 == 1560179855055L);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//    }
//}

