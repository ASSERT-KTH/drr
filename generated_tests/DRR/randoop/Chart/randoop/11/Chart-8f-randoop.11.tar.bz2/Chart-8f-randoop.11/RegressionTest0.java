import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            week0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date2, timeZone7, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test021");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.lang.String str4 = week0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getFirstMillisecond();
//        int int4 = week0.compareTo((java.lang.Object) week2);
//        java.util.Date date5 = week2.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test030");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        java.util.Date date8 = week5.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date2, timeZone14);
//        java.util.Calendar calendar17 = null;
//        try {
//            week16.peg(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        boolean boolean4 = week0.equals((java.lang.Object) "Week 24, 2019");
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.util.TimeZone timeZone5 = null;
//        try {
//            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        java.util.Date date5 = week3.getStart();
//        java.util.Date date6 = week3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date6, timeZone7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        java.util.Date date12 = week10.getStart();
//        java.lang.Class<?> wildcardClass13 = week10.getClass();
//        java.lang.Class<?> wildcardClass14 = week10.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getEnd();
//        long long19 = week17.getSerialIndex();
//        java.util.Date date20 = week17.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass23 = timePeriodFormatException22.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getEnd();
//        java.util.Date date26 = week24.getStart();
//        java.util.Date date27 = week24.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date20, timeZone28);
//        java.util.Locale locale31 = null;
//        try {
//            org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date6, timeZone28, locale31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 107031L + "'", long19 == 107031L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.util.Date date5 = week4.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        long long10 = week8.getSerialIndex();
//        java.util.Date date11 = week8.getEnd();
//        java.lang.Class<?> wildcardClass12 = date11.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getEnd();
//        long long15 = week13.getSerialIndex();
//        java.util.Date date16 = week13.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date5, timeZone17);
//        java.util.Locale locale20 = null;
//        try {
//            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date2, timeZone17, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107031L + "'", long15 == 107031L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getFirstMillisecond();
//        int int4 = week0.compareTo((java.lang.Object) week2);
//        java.util.Date date5 = week2.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        java.util.Date date8 = week6.getStart();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        java.lang.Class<?> wildcardClass10 = week6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getEnd();
//        java.util.Date date14 = week12.getStart();
//        java.lang.Class<?> wildcardClass15 = week12.getClass();
//        java.lang.Class<?> wildcardClass16 = week12.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getEnd();
//        java.util.Date date19 = week17.getStart();
//        java.lang.Class<?> wildcardClass20 = week17.getClass();
//        java.lang.Class<?> wildcardClass21 = week17.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        boolean boolean24 = week12.equals((java.lang.Object) class23);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        java.util.Date date27 = week26.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date27, timeZone28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getEnd();
//        long long32 = week30.getSerialIndex();
//        java.util.Date date33 = week30.getEnd();
//        java.lang.Class<?> wildcardClass34 = date33.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getEnd();
//        long long37 = week35.getSerialIndex();
//        java.util.Date date38 = week35.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date27, timeZone39);
//        boolean boolean42 = week12.equals((java.lang.Object) date27);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        java.util.Date date45 = week44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date45, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date27, timeZone46);
//        java.util.Locale locale49 = null;
//        try {
//            org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date5, timeZone46, locale49);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 107031L + "'", long32 == 107031L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 107031L + "'", long37 == 107031L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        java.util.Date date8 = week6.getStart();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        java.lang.Class<?> wildcardClass10 = week6.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        java.util.Date date13 = week11.getStart();
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.lang.Class<?> wildcardClass15 = week11.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        boolean boolean18 = week6.equals((java.lang.Object) class17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getEnd();
//        long long26 = week24.getSerialIndex();
//        java.util.Date date27 = week24.getEnd();
//        java.lang.Class<?> wildcardClass28 = date27.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getEnd();
//        long long31 = week29.getSerialIndex();
//        java.util.Date date32 = week29.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date21, timeZone33);
//        boolean boolean36 = week6.equals((java.lang.Object) date21);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        java.util.Date date39 = week38.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date39, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date21, timeZone40);
//        long long43 = regularTimePeriod42.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 107031L + "'", long26 == 107031L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 107031L + "'", long31 == 107031L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560668399999L + "'", long43 == 1560668399999L);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.util.Date date4 = week0.getEnd();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        int int5 = week0.getYearValue();
//        long long6 = week0.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        java.util.Date date9 = week7.getStart();
//        java.util.Date date10 = week7.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
//        java.util.Locale locale13 = null;
//        try {
//            org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date3, timeZone11, locale13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getFirstMillisecond();
//        int int4 = week0.compareTo((java.lang.Object) week2);
//        java.util.Date date5 = week2.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week2.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        java.util.Date date6 = week0.getStart();
        org.jfree.data.time.Year year7 = week0.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (short) 1);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        boolean boolean5 = week0.equals((java.lang.Object) 2019);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getFirstMillisecond();
//        int int4 = week0.compareTo((java.lang.Object) week2);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        int int5 = week0.getYearValue();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        java.lang.String str5 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        java.lang.String str6 = week0.toString();
//        java.util.Date date7 = week0.getEnd();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        java.util.Date date12 = week10.getStart();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date6, timeZone14);
//        java.util.Calendar calendar17 = null;
//        try {
//            week16.peg(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        int int6 = week0.getYearValue();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week0.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        java.util.TimeZone timeZone4 = null;
//        try {
//            org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3, timeZone4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        long long2 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        java.util.Date date5 = week3.getStart();
//        java.util.Date date6 = week3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date6, timeZone7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        int int11 = week9.getWeek();
//        int int13 = week9.compareTo((java.lang.Object) 0);
//        long long14 = week9.getFirstMillisecond();
//        java.util.Date date15 = week9.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getEnd();
//        java.util.Date date21 = week19.getStart();
//        java.util.Date date22 = week19.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date15, timeZone23);
//        java.util.Locale locale26 = null;
//        try {
//            org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date6, timeZone23, locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        int int5 = week0.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        java.util.Date date7 = week5.getStart();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getEnd();
//        long long14 = week12.getSerialIndex();
//        java.util.Date date15 = week12.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getEnd();
//        java.util.Date date21 = week19.getStart();
//        java.util.Date date22 = week19.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone23);
//        java.util.Locale locale26 = null;
//        try {
//            org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date3, timeZone23, locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        java.lang.String str6 = week0.toString();
//        java.util.Date date7 = week0.getEnd();
//        long long8 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date2, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        int int6 = week0.getYearValue();
//        java.util.Date date7 = week0.getStart();
//        long long8 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        java.util.Date date8 = week6.getStart();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        java.lang.Class<?> wildcardClass10 = week6.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        java.util.Date date13 = week11.getStart();
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.lang.Class<?> wildcardClass15 = week11.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        boolean boolean18 = week6.equals((java.lang.Object) class17);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getEnd();
//        long long26 = week24.getSerialIndex();
//        java.util.Date date27 = week24.getEnd();
//        java.lang.Class<?> wildcardClass28 = date27.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getEnd();
//        long long31 = week29.getSerialIndex();
//        java.util.Date date32 = week29.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date21, timeZone33);
//        boolean boolean36 = week6.equals((java.lang.Object) date21);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        java.util.Date date39 = week38.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date39, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date21, timeZone40);
//        java.util.Calendar calendar43 = null;
//        try {
//            long long44 = regularTimePeriod42.getMiddleMillisecond(calendar43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 107031L + "'", long26 == 107031L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 107031L + "'", long31 == 107031L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year5 = week0.getYear();
//        java.lang.String str6 = week0.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getFirstMillisecond();
//        int int4 = week0.compareTo((java.lang.Object) week2);
//        int int5 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Class<?> wildcardClass4 = week0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        java.util.Date date7 = week0.getEnd();
//        java.util.Calendar calendar8 = null;
//        try {
//            week0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.Year year5 = week0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            week0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException1.getSuppressed();
        java.lang.String str12 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str18 = timePeriodFormatException14.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        java.util.Date date8 = week5.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date2, timeZone14);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getEnd();
//        java.util.Date date19 = week17.getStart();
//        java.lang.Class<?> wildcardClass20 = week17.getClass();
//        java.lang.Class<?> wildcardClass21 = week17.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        java.util.Date date25 = week23.getStart();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        java.lang.Class<?> wildcardClass27 = week23.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.util.Date date29 = week28.getEnd();
//        java.util.Date date30 = week28.getStart();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        java.lang.Class<?> wildcardClass32 = week28.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        boolean boolean35 = week23.equals((java.lang.Object) class34);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        java.util.Date date38 = week37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.util.Date date42 = week41.getEnd();
//        long long43 = week41.getSerialIndex();
//        java.util.Date date44 = week41.getEnd();
//        java.lang.Class<?> wildcardClass45 = date44.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        java.util.Date date47 = week46.getEnd();
//        long long48 = week46.getSerialIndex();
//        java.util.Date date49 = week46.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date49, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date38, timeZone50);
//        boolean boolean53 = week23.equals((java.lang.Object) date38);
//        java.lang.Class class54 = null;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        java.util.Date date56 = week55.getEnd();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date56, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date38, timeZone57);
//        java.util.Locale locale60 = null;
//        try {
//            org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date2, timeZone57, locale60);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 107031L + "'", long43 == 107031L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 107031L + "'", long48 == 107031L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        org.jfree.data.time.Year year13 = week0.getYear();
//        boolean boolean15 = week0.equals((java.lang.Object) 10.0f);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str26 = timePeriodFormatException24.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException34.getSuppressed();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.Throwable[] throwableArray46 = timePeriodFormatException29.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        java.lang.String str52 = timePeriodFormatException48.toString();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException48.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str52.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray55);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Class<?> wildcardClass4 = week0.getClass();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        java.util.Date date6 = week5.getEnd();
        java.util.Date date7 = week5.getStart();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        java.lang.Class<?> wildcardClass9 = week5.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean12 = week0.equals((java.lang.Object) class11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = week0.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        long long4 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (byte) -1, year3);
//        java.lang.Object obj5 = null;
//        int int6 = week4.compareTo(obj5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        java.util.Date date8 = regularTimePeriod7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        long long11 = week9.getSerialIndex();
//        java.util.Date date12 = week9.getEnd();
//        java.lang.Class<?> wildcardClass13 = date12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        long long16 = week14.getSerialIndex();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date8, timeZone18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        int int23 = week21.getWeek();
//        int int25 = week21.compareTo((java.lang.Object) 0);
//        long long26 = week21.getFirstMillisecond();
//        java.lang.String str27 = week21.toString();
//        java.util.Date date28 = week21.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getEnd();
//        java.util.Date date31 = week29.getStart();
//        java.lang.Class<?> wildcardClass32 = week29.getClass();
//        java.lang.Class<?> wildcardClass33 = week29.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        java.util.Date date37 = week36.getEnd();
//        long long38 = week36.getSerialIndex();
//        java.util.Date date39 = week36.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass42 = timePeriodFormatException41.getClass();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        java.util.Date date44 = week43.getEnd();
//        java.util.Date date45 = week43.getStart();
//        java.util.Date date46 = week43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date46, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date28, timeZone47);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        java.util.Date date52 = week51.getEnd();
//        java.util.Date date53 = week51.getStart();
//        java.lang.Class<?> wildcardClass54 = week51.getClass();
//        java.lang.Class<?> wildcardClass55 = week51.getClass();
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        java.util.Date date59 = week58.getEnd();
//        long long60 = week58.getSerialIndex();
//        java.util.Date date61 = week58.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException63 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass64 = timePeriodFormatException63.getClass();
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week();
//        java.util.Date date66 = week65.getEnd();
//        java.util.Date date67 = week65.getStart();
//        java.util.Date date68 = week65.getEnd();
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date68, timeZone69);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date61, timeZone69);
//        java.lang.Class class72 = null;
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week();
//        java.util.Date date74 = week73.getEnd();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date74, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date61, timeZone75);
//        java.lang.Class class78 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560063600000L + "'", long26 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 107031L + "'", long38 == 107031L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 107031L + "'", long60 == 107031L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(class78);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getFirstMillisecond();
//        int int4 = week0.compareTo((java.lang.Object) week2);
//        java.util.Date date5 = week2.getEnd();
//        java.util.Date date6 = week2.getEnd();
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getSerialIndex();
//        int int7 = week0.getYearValue();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        java.util.Date date8 = week5.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date4, timeZone14);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
        java.lang.String str8 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str10 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        long long9 = week7.getSerialIndex();
//        java.util.Date date10 = week7.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        java.util.Date date16 = week14.getStart();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone18);
//        java.util.TimeZone timeZone21 = null;
//        try {
//            org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date10, timeZone21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        java.util.Date date8 = week5.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date2, timeZone14);
//        long long17 = week16.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week16.previous();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) -1);
        long long3 = week2.getSerialIndex();
        long long4 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-53L) + "'", long3 == (-53L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-53L) + "'", long4 == (-53L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (byte) -1, year3);
//        long long5 = week4.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107006L + "'", long5 == 107006L);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getWeek();
//        int int6 = week2.compareTo((java.lang.Object) 0);
//        int int7 = week2.getYearValue();
//        long long8 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week2.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(5, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 100, year9);
//        java.util.Date date12 = year9.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getEnd();
//        java.util.Date date15 = week13.getStart();
//        java.lang.Class<?> wildcardClass16 = week13.getClass();
//        java.lang.Class<?> wildcardClass17 = week13.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getEnd();
//        long long22 = week20.getSerialIndex();
//        java.util.Date date23 = week20.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass26 = timePeriodFormatException25.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.util.Date date28 = week27.getEnd();
//        java.util.Date date29 = week27.getStart();
//        java.util.Date date30 = week27.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone31);
//        java.util.Locale locale34 = null;
//        try {
//            org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date12, timeZone31, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 107031L + "'", long22 == 107031L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.Date date3 = week1.getStart();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        java.lang.Class<?> wildcardClass5 = week1.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        java.util.Date date9 = week7.getStart();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        java.lang.Class<?> wildcardClass11 = week7.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getEnd();
//        java.util.Date date14 = week12.getStart();
//        java.lang.Class<?> wildcardClass15 = week12.getClass();
//        java.lang.Class<?> wildcardClass16 = week12.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        boolean boolean19 = week7.equals((java.lang.Object) class18);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        java.util.Date date26 = week25.getEnd();
//        long long27 = week25.getSerialIndex();
//        java.util.Date date28 = week25.getEnd();
//        java.lang.Class<?> wildcardClass29 = date28.getClass();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getEnd();
//        long long32 = week30.getSerialIndex();
//        java.util.Date date33 = week30.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date33, timeZone34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date22, timeZone34);
//        boolean boolean37 = week7.equals((java.lang.Object) date22);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        java.util.Date date40 = week39.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date40, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date22, timeZone41);
//        java.util.Locale locale44 = null;
//        try {
//            org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date0, timeZone41, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 107031L + "'", long27 == 107031L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 107031L + "'", long32 == 107031L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.lang.String str4 = week0.toString();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) (short) 10);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 530L + "'", long3 == 530L);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        java.util.Date date7 = week5.getStart();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean12 = week0.equals((java.lang.Object) class11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) -1, 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
//        boolean boolean17 = week0.equals((java.lang.Object) regularTimePeriod16);
//        java.lang.String str18 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        java.util.Date date6 = week0.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        java.util.Date date8 = week7.getEnd();
        java.util.Date date9 = week7.getStart();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        java.lang.Object obj11 = null;
        boolean boolean12 = week7.equals(obj11);
        int int13 = week7.getYearValue();
        java.util.Date date14 = week7.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        java.util.Date date19 = week18.getEnd();
        java.util.Date date20 = week18.getStart();
        java.util.Date date21 = week18.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date14, timeZone22);
        java.util.Locale locale25 = null;
        try {
            org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date6, timeZone22, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.Date date3 = week1.getStart();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = week1.equals(obj5);
//        int int7 = week1.getYearValue();
//        java.util.Date date8 = week1.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getEnd();
//        int int15 = week13.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.next();
//        java.util.Date date17 = regularTimePeriod16.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        long long20 = week18.getSerialIndex();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class<?> wildcardClass22 = date21.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        long long25 = week23.getSerialIndex();
//        java.util.Date date26 = week23.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date26, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date17, timeZone27);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getEnd();
//        int int32 = week30.getWeek();
//        int int34 = week30.compareTo((java.lang.Object) 0);
//        long long35 = week30.getFirstMillisecond();
//        java.lang.String str36 = week30.toString();
//        java.util.Date date37 = week30.getEnd();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        java.util.Date date39 = week38.getEnd();
//        java.util.Date date40 = week38.getStart();
//        java.lang.Class<?> wildcardClass41 = week38.getClass();
//        java.lang.Class<?> wildcardClass42 = week38.getClass();
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        java.util.Date date46 = week45.getEnd();
//        long long47 = week45.getSerialIndex();
//        java.util.Date date48 = week45.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass51 = timePeriodFormatException50.getClass();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        java.util.Date date53 = week52.getEnd();
//        java.util.Date date54 = week52.getStart();
//        java.util.Date date55 = week52.getEnd();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date55, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date37, timeZone56);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        java.util.Date date61 = week60.getEnd();
//        java.util.Date date62 = week60.getStart();
//        java.lang.Class<?> wildcardClass63 = week60.getClass();
//        java.lang.Class<?> wildcardClass64 = week60.getClass();
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        java.util.Date date68 = week67.getEnd();
//        long long69 = week67.getSerialIndex();
//        java.util.Date date70 = week67.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException72 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass73 = timePeriodFormatException72.getClass();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week();
//        java.util.Date date75 = week74.getEnd();
//        java.util.Date date76 = week74.getStart();
//        java.util.Date date77 = week74.getEnd();
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date77, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date70, timeZone78);
//        java.lang.Class class81 = null;
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        java.util.Date date83 = week82.getEnd();
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date83, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date70, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone84);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException89 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass90 = timePeriodFormatException89.getClass();
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week();
//        java.util.Date date92 = week91.getEnd();
//        java.util.Date date93 = week91.getStart();
//        java.util.Date date94 = week91.getEnd();
//        java.util.TimeZone timeZone95 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass90, date94, timeZone95);
//        org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date8, timeZone95);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 24 + "'", int32 == 24);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560063600000L + "'", long35 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 107031L + "'", long47 == 107031L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 107031L + "'", long69 == 107031L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(wildcardClass90);
//        org.junit.Assert.assertNotNull(date92);
//        org.junit.Assert.assertNotNull(date93);
//        org.junit.Assert.assertNotNull(date94);
//        org.junit.Assert.assertNotNull(timeZone95);
//        org.junit.Assert.assertNull(regularTimePeriod96);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
        java.lang.Object obj6 = null;
        int int7 = week0.compareTo(obj6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        java.util.Date date3 = week1.getStart();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        java.util.Date date6 = year4.getEnd();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable6 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str14 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        java.util.Date date8 = week5.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date2, timeZone14);
//        long long17 = week16.getFirstMillisecond();
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = week16.getMiddleMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) (short) 10);
        long long3 = week2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61852608000000L) + "'", long3 == (-61852608000000L));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        java.util.Date date7 = week5.getStart();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean12 = week0.equals((java.lang.Object) class11);
//        java.lang.String str13 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        int int6 = week0.getYearValue();
        java.util.Date date7 = week0.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        java.util.Date date12 = week11.getEnd();
        java.util.Date date13 = week11.getStart();
        java.util.Date date14 = week11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date7, timeZone15);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week17.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.String str6 = timePeriodFormatException3.toString();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        int int6 = week0.getYearValue();
        java.util.Date date7 = week0.getStart();
        java.lang.Class<?> wildcardClass8 = date7.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        java.util.Date date7 = week0.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        java.util.Date date10 = week8.getStart();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        java.lang.Object obj12 = null;
//        boolean boolean13 = week8.equals(obj12);
//        int int14 = week8.getYearValue();
//        java.util.Date date15 = week8.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getEnd();
//        java.util.Date date21 = week19.getStart();
//        java.util.Date date22 = week19.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date15, timeZone23);
//        java.lang.Class<?> wildcardClass26 = timeZone23.getClass();
//        java.util.Locale locale27 = null;
//        try {
//            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date7, timeZone23, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        int int5 = week0.getYearValue();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        long long8 = regularTimePeriod7.getMiddleMillisecond();
//        java.util.Date date9 = regularTimePeriod7.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560970799999L + "'", long8 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        org.jfree.data.time.Year year3 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        java.util.Date date8 = regularTimePeriod7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        long long11 = week9.getSerialIndex();
//        java.util.Date date12 = week9.getEnd();
//        java.lang.Class<?> wildcardClass13 = date12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        long long16 = week14.getSerialIndex();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date8, timeZone18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        java.util.Date date23 = week21.getStart();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date23, timeZone24);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        int int6 = week0.getYearValue();
//        long long7 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getWeek();
//        int int6 = week2.compareTo((java.lang.Object) 0);
//        int int7 = week2.getYearValue();
//        long long8 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week2.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(5, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 0, year9);
//        java.util.Date date12 = week11.getStart();
//        long long13 = week11.getFirstMillisecond();
//        java.util.Calendar calendar14 = null;
//        try {
//            week11.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1545552000000L + "'", long13 == 1545552000000L);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 9);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        long long7 = week0.getMiddleMillisecond();
//        long long8 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        int int3 = week1.getWeek();
//        int int5 = week1.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, year6);
//        long long8 = year6.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        int int5 = week0.getYearValue();
//        long long6 = week0.getFirstMillisecond();
//        int int7 = week0.getYearValue();
//        long long8 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getMiddleMillisecond();
//        java.util.Date date7 = week0.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        java.util.Date date8 = week6.getStart();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date8, timeZone9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        long long2 = week0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        int int5 = week0.getYearValue();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        java.util.Date date8 = week6.getStart();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        java.lang.Class<?> wildcardClass10 = week6.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        java.util.Date date13 = week11.getStart();
//        java.lang.Class<?> wildcardClass14 = week11.getClass();
//        java.lang.Class<?> wildcardClass15 = week11.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        boolean boolean18 = week6.equals((java.lang.Object) class17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (byte) -1, 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
//        boolean boolean23 = week6.equals((java.lang.Object) regularTimePeriod22);
//        int int24 = week0.compareTo((java.lang.Object) boolean23);
//        long long25 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        long long3 = week1.getSerialIndex();
//        java.util.Date date4 = week1.getEnd();
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        boolean boolean6 = week4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: hi!");
//        java.util.Date date7 = week4.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) (byte) 10);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        java.util.Date date3 = week1.getStart();
        java.lang.Class<?> wildcardClass4 = week1.getClass();
        java.lang.Object obj5 = null;
        boolean boolean6 = week1.equals(obj5);
        int int7 = week1.getYearValue();
        java.util.Date date8 = week1.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        java.util.Date date14 = week12.getStart();
        java.util.Date date15 = week12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date8, timeZone16);
        java.lang.Class<?> wildcardClass19 = timeZone16.getClass();
        java.util.Locale locale20 = null;
        try {
            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date0, timeZone16, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.lang.String str5 = week4.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week4.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        int int13 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass14 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        int int7 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.previous();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = week0.equals(obj5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        long long9 = week7.getSerialIndex();
//        java.util.Date date10 = week7.getStart();
//        int int11 = week7.getWeek();
//        int int12 = week0.compareTo((java.lang.Object) week7);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week7.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        java.util.Date date8 = regularTimePeriod7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        long long11 = week9.getSerialIndex();
//        java.util.Date date12 = week9.getEnd();
//        java.lang.Class<?> wildcardClass13 = date12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        long long16 = week14.getSerialIndex();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date8, timeZone18);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(class21);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        java.util.Date date8 = week6.getStart();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.lang.Class<?> wildcardClass14 = date13.getClass();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.util.Date date16 = week15.getEnd();
//        long long17 = week15.getSerialIndex();
//        java.util.Date date18 = week15.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        java.util.Date date23 = week21.getStart();
//        java.lang.Class<?> wildcardClass24 = week21.getClass();
//        java.lang.Class<?> wildcardClass25 = week21.getClass();
//        java.util.Date date26 = week21.getStart();
//        java.lang.Class class27 = null;
//        java.util.Date date28 = null;
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date26, timeZone29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone29);
//        int int33 = week0.compareTo((java.lang.Object) regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 107031L + "'", long17 == 107031L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getWeek();
//        int int7 = week3.compareTo((java.lang.Object) 0);
//        long long8 = week3.getFirstMillisecond();
//        java.util.Date date9 = week3.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getEnd();
//        java.util.Date date15 = week13.getStart();
//        java.util.Date date16 = week13.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone17);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date2, timeZone17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date2);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray17);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        java.util.Date date8 = regularTimePeriod7.getEnd();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Class<?> wildcardClass4 = week0.getClass();
        java.util.Calendar calendar5 = null;
        try {
            week0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 5, 2019");
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        java.util.Date date8 = week5.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date2, timeZone14);
//        long long17 = week16.getFirstMillisecond();
//        java.util.Date date18 = week16.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = date2.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getMiddleMillisecond();
//        long long7 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        java.util.Date date7 = week5.getStart();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean12 = week0.equals((java.lang.Object) class11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        long long20 = week18.getSerialIndex();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class<?> wildcardClass22 = date21.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        long long25 = week23.getSerialIndex();
//        java.util.Date date26 = week23.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date26, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date15, timeZone27);
//        boolean boolean30 = week0.equals((java.lang.Object) date15);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date15);
//        int int33 = week31.compareTo((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week31.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 2019" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) (short) 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        java.util.Date date6 = week0.getStart();
//        long long7 = week0.getSerialIndex();
//        org.jfree.data.time.Year year8 = week0.getYear();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = year8.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        java.lang.String str24 = timePeriodFormatException20.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException1.getSuppressed();
        java.lang.String str27 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        java.util.Date date6 = week0.getStart();
//        long long7 = week0.getSerialIndex();
//        org.jfree.data.time.Year year8 = week0.getYear();
//        java.util.Calendar calendar9 = null;
//        try {
//            week0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        java.util.Date date3 = week1.getStart();
        java.lang.Class<?> wildcardClass4 = week1.getClass();
        java.lang.Object obj5 = null;
        boolean boolean6 = week1.equals(obj5);
        int int7 = week1.getYearValue();
        java.util.Date date8 = week1.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        java.util.Date date14 = week12.getStart();
        java.util.Date date15 = week12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone16);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNull(regularTimePeriod18);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 12, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getLastMillisecond();
//        java.lang.String str5 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        int int6 = week0.getYearValue();
//        java.util.Date date7 = week0.getStart();
//        int int8 = week0.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        java.lang.String str6 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = week0.equals(obj5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        long long9 = week7.getSerialIndex();
//        java.util.Date date10 = week7.getStart();
//        int int11 = week7.getWeek();
//        int int12 = week0.compareTo((java.lang.Object) week7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        java.util.Date date7 = week5.getStart();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean12 = week0.equals((java.lang.Object) class11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        long long20 = week18.getSerialIndex();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class<?> wildcardClass22 = date21.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        long long25 = week23.getSerialIndex();
//        java.util.Date date26 = week23.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date26, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date15, timeZone27);
//        boolean boolean30 = week0.equals((java.lang.Object) date15);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date15);
//        int int33 = week31.compareTo((java.lang.Object) 10L);
//        org.jfree.data.time.Year year34 = week31.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(year34);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        long long3 = week0.getFirstMillisecond();
//        boolean boolean5 = week0.equals((java.lang.Object) (byte) -1);
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        long long8 = week0.getLastMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            week0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        org.jfree.data.time.Year year13 = week0.getYear();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week0.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(year13);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 11);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        java.lang.String str6 = week0.toString();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.Year year8 = week0.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        java.util.Date date11 = week9.getStart();
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        long long13 = week9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week9.next();
//        boolean boolean15 = week0.equals((java.lang.Object) regularTimePeriod14);
//        org.jfree.data.time.Year year16 = week0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(year16);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getWeek();
//        int int6 = week2.compareTo((java.lang.Object) 0);
//        int int7 = week2.getYearValue();
//        long long8 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week2.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(5, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 0, year9);
//        java.util.Date date12 = week11.getStart();
//        long long13 = week11.getSerialIndex();
//        int int14 = week11.getYearValue();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week11.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107007L + "'", long13 == 107007L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) 'a');
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59106513600001L) + "'", long3 == (-59106513600001L));
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        int int6 = week0.getYearValue();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        java.util.Date date12 = week10.getStart();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.next();
//        int int18 = week0.compareTo((java.lang.Object) regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        int int8 = week6.getWeek();
//        int int10 = week6.compareTo((java.lang.Object) 0);
//        int int11 = week6.getYearValue();
//        long long12 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year13 = week6.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(5, year13);
//        boolean boolean15 = week0.equals((java.lang.Object) year13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        long long7 = week0.getMiddleMillisecond();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = week0.equals(obj8);
//        int int10 = week0.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        int int6 = week0.getYearValue();
//        java.util.Date date7 = week0.getEnd();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        int int6 = week4.getWeek();
//        int int8 = week4.compareTo((java.lang.Object) 0);
//        int int9 = week4.getYearValue();
//        long long10 = week4.getFirstMillisecond();
//        org.jfree.data.time.Year year11 = week4.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(5, year11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (byte) 0, year11);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(5, year11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, year11);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year11);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 12, 2019");
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        java.util.Date date0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        java.util.Date date4 = week2.getStart();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week2.equals(obj6);
//        int int8 = week2.getYearValue();
//        java.util.Date date9 = week2.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week14.next();
//        java.util.Date date18 = regularTimePeriod17.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getEnd();
//        long long21 = week19.getSerialIndex();
//        java.util.Date date22 = week19.getEnd();
//        java.lang.Class<?> wildcardClass23 = date22.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.util.Date date25 = week24.getEnd();
//        long long26 = week24.getSerialIndex();
//        java.util.Date date27 = week24.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone28);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getEnd();
//        int int33 = week31.getWeek();
//        int int35 = week31.compareTo((java.lang.Object) 0);
//        long long36 = week31.getFirstMillisecond();
//        java.lang.String str37 = week31.toString();
//        java.util.Date date38 = week31.getEnd();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        java.util.Date date40 = week39.getEnd();
//        java.util.Date date41 = week39.getStart();
//        java.lang.Class<?> wildcardClass42 = week39.getClass();
//        java.lang.Class<?> wildcardClass43 = week39.getClass();
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        java.util.Date date47 = week46.getEnd();
//        long long48 = week46.getSerialIndex();
//        java.util.Date date49 = week46.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass52 = timePeriodFormatException51.getClass();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        java.util.Date date54 = week53.getEnd();
//        java.util.Date date55 = week53.getStart();
//        java.util.Date date56 = week53.getEnd();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date56, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date49, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date38, timeZone57);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        java.util.Date date62 = week61.getEnd();
//        java.util.Date date63 = week61.getStart();
//        java.lang.Class<?> wildcardClass64 = week61.getClass();
//        java.lang.Class<?> wildcardClass65 = week61.getClass();
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass65);
//        java.lang.Class class67 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass65);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
//        java.util.Date date69 = week68.getEnd();
//        long long70 = week68.getSerialIndex();
//        java.util.Date date71 = week68.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException73 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass74 = timePeriodFormatException73.getClass();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        java.util.Date date76 = week75.getEnd();
//        java.util.Date date77 = week75.getStart();
//        java.util.Date date78 = week75.getEnd();
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date78, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date71, timeZone79);
//        java.lang.Class class82 = null;
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week();
//        java.util.Date date84 = week83.getEnd();
//        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class82, date84, timeZone85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date71, timeZone85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date9, timeZone85);
//        java.lang.Class class89 = null;
//        java.util.Date date90 = null;
//        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class89, date90, timeZone91);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date9, timeZone91);
//        java.util.Locale locale94 = null;
//        try {
//            org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date0, timeZone91, locale94);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 107031L + "'", long26 == 107031L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560063600000L + "'", long36 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Week 24, 2019" + "'", str37.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 107031L + "'", long48 == 107031L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertNotNull(class67);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 107031L + "'", long70 == 107031L);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(wildcardClass74);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(timeZone85);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(timeZone91);
//        org.junit.Assert.assertNull(regularTimePeriod92);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        int int6 = week0.getYearValue();
        java.util.Date date7 = week0.getStart();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        int int13 = week0.getYearValue();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week0.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException8.getClass();
        java.lang.String str13 = timePeriodFormatException8.toString();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        int int2 = week0.getYearValue();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
//        java.util.Date date12 = regularTimePeriod11.getStart();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod11.getClass();
//        int int14 = week0.compareTo((java.lang.Object) regularTimePeriod11);
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week0.getLastMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = week0.equals(obj5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
//        java.util.Date date12 = regularTimePeriod11.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getEnd();
//        long long15 = week13.getSerialIndex();
//        java.util.Date date16 = week13.getEnd();
//        java.lang.Class<?> wildcardClass17 = date16.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        long long20 = week18.getSerialIndex();
//        java.util.Date date21 = week18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date12, timeZone22);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        java.util.Date date26 = week25.getEnd();
//        int int27 = week25.getWeek();
//        int int29 = week25.compareTo((java.lang.Object) 0);
//        long long30 = week25.getFirstMillisecond();
//        java.lang.String str31 = week25.toString();
//        java.util.Date date32 = week25.getEnd();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        java.util.Date date34 = week33.getEnd();
//        java.util.Date date35 = week33.getStart();
//        java.lang.Class<?> wildcardClass36 = week33.getClass();
//        java.lang.Class<?> wildcardClass37 = week33.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        java.util.Date date41 = week40.getEnd();
//        long long42 = week40.getSerialIndex();
//        java.util.Date date43 = week40.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass46 = timePeriodFormatException45.getClass();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        java.util.Date date48 = week47.getEnd();
//        java.util.Date date49 = week47.getStart();
//        java.util.Date date50 = week47.getEnd();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date50, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date32, timeZone51);
//        java.util.Locale locale55 = null;
//        try {
//            org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date3, timeZone51, locale55);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107031L + "'", long15 == 107031L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560063600000L + "'", long30 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 107031L + "'", long42 == 107031L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        int int6 = week4.getWeek();
//        int int8 = week4.compareTo((java.lang.Object) 0);
//        int int9 = week4.getYearValue();
//        long long10 = week4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week4.next();
//        int int12 = week0.compareTo((java.lang.Object) regularTimePeriod11);
//        long long13 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        java.lang.String str24 = timePeriodFormatException20.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException34.getSuppressed();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        java.lang.String str52 = timePeriodFormatException50.toString();
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        java.lang.Throwable[] throwableArray54 = timePeriodFormatException34.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str52.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray54);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        long long13 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 100);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Class<?> wildcardClass4 = week0.getClass();
        java.util.Date date5 = week0.getStart();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
        java.lang.Class<?> wildcardClass11 = date5.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str26 = timePeriodFormatException24.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException34.getSuppressed();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.String str47 = timePeriodFormatException8.toString();
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str47.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str17 = timePeriodFormatException5.toString();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.Date date3 = week1.getStart();
//        java.util.Date date4 = week1.getEnd();
//        long long5 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(53, year6);
//        java.util.Date date8 = week7.getStart();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getWeek();
//        int int7 = week3.compareTo((java.lang.Object) 0);
//        long long8 = week3.getFirstMillisecond();
//        java.util.Date date9 = week3.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getEnd();
//        java.util.Date date15 = week13.getStart();
//        java.util.Date date16 = week13.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date9, timeZone17);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date2, timeZone17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        java.util.Date date23 = week21.getStart();
//        java.lang.Class<?> wildcardClass24 = week21.getClass();
//        java.lang.Class<?> wildcardClass25 = week21.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.util.Date date29 = week28.getEnd();
//        long long30 = week28.getSerialIndex();
//        java.util.Date date31 = week28.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass34 = timePeriodFormatException33.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getEnd();
//        java.util.Date date37 = week35.getStart();
//        java.util.Date date38 = week35.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone39);
//        java.util.Locale locale42 = null;
//        try {
//            org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date2, timeZone39, locale42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 107031L + "'", long30 == 107031L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        java.lang.Class<?> wildcardClass5 = regularTimePeriod3.getClass();
//        java.util.Date date6 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        java.util.Date date9 = week7.getStart();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = week7.equals(obj11);
//        int int13 = week7.getYearValue();
//        java.util.Date date14 = week7.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        java.util.Date date20 = week18.getStart();
//        java.util.Date date21 = week18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date14, timeZone22);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date6, timeZone22);
//        long long26 = week25.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561273199999L + "'", long26 == 1561273199999L);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Class<?> wildcardClass4 = week0.getClass();
        java.util.Date date5 = week0.getStart();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date5);
        int int13 = week11.compareTo((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        java.util.Date date6 = regularTimePeriod5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        int int6 = week0.getYearValue();
        java.util.Date date7 = week0.getStart();
        int int8 = week0.getYearValue();
        java.util.Date date9 = week0.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) (short) 10);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61852305600001L) + "'", long3 == (-61852305600001L));
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getWeek();
//        int int6 = week2.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year7 = week2.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 0, year7);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        int int6 = week0.getYearValue();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        java.util.Date date10 = week8.getStart();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        java.lang.Object obj12 = null;
//        boolean boolean13 = week8.equals(obj12);
//        int int14 = week8.getYearValue();
//        java.util.Date date15 = week8.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getEnd();
//        java.util.Date date21 = week19.getStart();
//        java.util.Date date22 = week19.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date15, timeZone23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date7, timeZone23);
//        java.lang.String str27 = week26.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 9);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61869240000001L) + "'", long3 == (-61869240000001L));
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        java.lang.Class<?> wildcardClass5 = regularTimePeriod3.getClass();
//        java.util.Date date6 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        java.util.Date date9 = week7.getStart();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = week7.equals(obj11);
//        int int13 = week7.getYearValue();
//        java.util.Date date14 = week7.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        java.util.Date date20 = week18.getStart();
//        java.util.Date date21 = week18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date14, timeZone22);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date6, timeZone22);
//        long long26 = week25.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 107032L + "'", long26 == 107032L);
//    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = year2.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year2);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = regularTimePeriod5.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        int int3 = week1.getWeek();
//        int int5 = week1.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, year6);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week7.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(year6);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        java.util.Date date6 = week0.getStart();
//        long long7 = week0.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        long long3 = week0.getFirstMillisecond();
//        boolean boolean5 = week0.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        int int5 = week0.getYearValue();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        long long8 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        int int4 = week0.getWeek();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        java.lang.String str6 = week0.toString();
//        java.util.Date date7 = week0.getStart();
//        long long8 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        java.util.Date date7 = week0.getEnd();
//        int int8 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) (short) 10);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61852608000000L) + "'", long3 == (-61852608000000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61852608000000L) + "'", long4 == (-61852608000000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61852003200001L) + "'", long5 == (-61852003200001L));
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        java.util.Date date8 = week5.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date2, timeZone14);
//        long long17 = week16.getFirstMillisecond();
//        java.util.Date date18 = week16.getStart();
//        org.jfree.data.time.Year year19 = week16.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week16.previous();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.lang.String str4 = week0.toString();
//        long long5 = week0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        long long8 = week5.getSerialIndex();
//        int int9 = week5.getWeek();
//        long long10 = week5.getFirstMillisecond();
//        int int11 = week0.compareTo((java.lang.Object) week5);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week5.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getFirstMillisecond();
//        long long3 = week1.getSerialIndex();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        int int5 = week0.getYearValue();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        java.util.Date date8 = week5.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date2, timeZone14);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date2);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        java.util.Date date0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getEnd();
//        java.lang.Class<?> wildcardClass10 = date9.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        long long13 = week11.getSerialIndex();
//        java.util.Date date14 = week11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date3, timeZone15);
//        long long18 = week17.getFirstMillisecond();
//        java.util.Date date19 = week17.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        try {
//            org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date0, timeZone20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063600000L + "'", long18 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        long long9 = week7.getSerialIndex();
//        java.util.Date date10 = week7.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        java.util.Date date16 = week14.getStart();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone18);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        java.util.Date date27 = week26.getEnd();
//        long long28 = week26.getSerialIndex();
//        java.util.Date date29 = week26.getEnd();
//        java.lang.Class<?> wildcardClass30 = date29.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getEnd();
//        long long33 = week31.getSerialIndex();
//        java.util.Date date34 = week31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date34, timeZone35);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date23, timeZone35);
//        java.util.Locale locale38 = null;
//        try {
//            org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date10, timeZone35, locale38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 107031L + "'", long28 == 107031L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 107031L + "'", long33 == 107031L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        int int5 = week0.getYearValue();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year7 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException10.getClass();
        java.lang.String str15 = timePeriodFormatException10.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable throwable30 = null;
        try {
            timePeriodFormatException10.addSuppressed(throwable30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        long long6 = week4.getSerialIndex();
//        java.util.Date date7 = week4.getEnd();
//        java.lang.Class<?> wildcardClass8 = date7.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        long long11 = week9.getSerialIndex();
//        java.util.Date date12 = week9.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.util.Date date16 = week15.getEnd();
//        java.util.Date date17 = week15.getStart();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        java.lang.Class<?> wildcardClass19 = week15.getClass();
//        java.util.Date date20 = week15.getStart();
//        java.lang.Class class21 = null;
//        java.util.Date date22 = null;
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date20, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date12, timeZone23);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(class27);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 8);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 10, 8" + "'", str3.equals("Week 10, 8"));
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.Date date3 = week1.getStart();
//        java.util.Date date4 = week1.getEnd();
//        long long5 = week1.getFirstMillisecond();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(53, year6);
//        java.util.Date date8 = week7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        int int11 = week9.getWeek();
//        int int13 = week9.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year14 = week9.getYear();
//        java.lang.String str15 = week9.toString();
//        int int16 = week7.compareTo((java.lang.Object) week9);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 29 + "'", int16 == 29);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        java.util.Calendar calendar13 = null;
//        try {
//            week0.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        long long9 = week7.getSerialIndex();
//        java.util.Date date10 = week7.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        java.util.Date date16 = week14.getStart();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone18);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = regularTimePeriod20.getMiddleMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        int int6 = week0.getYearValue();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 6);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        int int6 = week0.getYearValue();
//        int int7 = week0.getWeek();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        java.util.Date date0 = null;
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass3 = timePeriodFormatException2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        int int7 = week5.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        java.util.Date date9 = regularTimePeriod8.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.lang.Class<?> wildcardClass14 = date13.getClass();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.util.Date date16 = week15.getEnd();
//        long long17 = week15.getSerialIndex();
//        java.util.Date date18 = week15.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date9, timeZone19);
//        try {
//            org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date0, timeZone19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 107031L + "'", long17 == 107031L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        java.util.Date date8 = regularTimePeriod7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        long long11 = week9.getSerialIndex();
//        java.util.Date date12 = week9.getEnd();
//        java.lang.Class<?> wildcardClass13 = date12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        long long16 = week14.getSerialIndex();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date8, timeZone18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        int int23 = week21.getWeek();
//        int int25 = week21.compareTo((java.lang.Object) 0);
//        long long26 = week21.getFirstMillisecond();
//        java.lang.String str27 = week21.toString();
//        java.util.Date date28 = week21.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getEnd();
//        java.util.Date date31 = week29.getStart();
//        java.lang.Class<?> wildcardClass32 = week29.getClass();
//        java.lang.Class<?> wildcardClass33 = week29.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        java.util.Date date37 = week36.getEnd();
//        long long38 = week36.getSerialIndex();
//        java.util.Date date39 = week36.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass42 = timePeriodFormatException41.getClass();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        java.util.Date date44 = week43.getEnd();
//        java.util.Date date45 = week43.getStart();
//        java.util.Date date46 = week43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date46, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date28, timeZone47);
//        java.util.Date date51 = null;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        java.util.Date date53 = week52.getEnd();
//        java.util.Date date54 = week52.getStart();
//        java.lang.Class<?> wildcardClass55 = week52.getClass();
//        java.lang.Class<?> wildcardClass56 = week52.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        java.util.Date date59 = week58.getEnd();
//        java.util.Date date60 = week58.getStart();
//        java.lang.Class<?> wildcardClass61 = week58.getClass();
//        java.lang.Class<?> wildcardClass62 = week58.getClass();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        java.util.Date date64 = week63.getEnd();
//        java.util.Date date65 = week63.getStart();
//        java.lang.Class<?> wildcardClass66 = week63.getClass();
//        java.lang.Class<?> wildcardClass67 = week63.getClass();
//        java.lang.Class class68 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass67);
//        java.lang.Class class69 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass67);
//        boolean boolean70 = week58.equals((java.lang.Object) class69);
//        java.lang.Class class71 = null;
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
//        java.util.Date date73 = week72.getEnd();
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date73, timeZone74);
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week();
//        java.util.Date date77 = week76.getEnd();
//        long long78 = week76.getSerialIndex();
//        java.util.Date date79 = week76.getEnd();
//        java.lang.Class<?> wildcardClass80 = date79.getClass();
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week();
//        java.util.Date date82 = week81.getEnd();
//        long long83 = week81.getSerialIndex();
//        java.util.Date date84 = week81.getEnd();
//        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date84, timeZone85);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date73, timeZone85);
//        boolean boolean88 = week58.equals((java.lang.Object) date73);
//        java.lang.Class class89 = null;
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week();
//        java.util.Date date91 = week90.getEnd();
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class89, date91, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date73, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date51, timeZone92);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560063600000L + "'", long26 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 107031L + "'", long38 == 107031L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(class68);
//        org.junit.Assert.assertNotNull(class69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 107031L + "'", long78 == 107031L);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(wildcardClass80);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 107031L + "'", long83 == 107031L);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(timeZone85);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//        org.junit.Assert.assertNull(regularTimePeriod95);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        java.util.Date date7 = week6.getEnd();
        java.util.Date date8 = week6.getStart();
        java.lang.Class<?> wildcardClass9 = week6.getClass();
        java.util.Date date10 = week6.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.previous();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        boolean boolean13 = week0.equals((java.lang.Object) regularTimePeriod11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str21 = timePeriodFormatException8.toString();
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.String str13 = timePeriodFormatException10.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        java.util.Date date3 = week2.getEnd();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Year year5 = week2.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(5, year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.util.Date date3 = week0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, (int) (byte) 0);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        java.util.Date date6 = week4.getStart();
//        java.lang.Class<?> wildcardClass7 = week4.getClass();
//        java.lang.Class<?> wildcardClass8 = week4.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        long long13 = week11.getSerialIndex();
//        java.util.Date date14 = week11.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        java.util.Date date20 = week18.getStart();
//        java.util.Date date21 = week18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone22);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date3, timeZone22);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date3);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        java.util.Date date7 = week5.getStart();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean12 = week0.equals((java.lang.Object) class11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        long long20 = week18.getSerialIndex();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class<?> wildcardClass22 = date21.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        long long25 = week23.getSerialIndex();
//        java.util.Date date26 = week23.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date26, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date15, timeZone27);
//        boolean boolean30 = week0.equals((java.lang.Object) date15);
//        java.lang.String str31 = week0.toString();
//        long long32 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560063600000L + "'", long32 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
//        java.util.Date date12 = regularTimePeriod11.getStart();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod11.getClass();
//        int int14 = week0.compareTo((java.lang.Object) regularTimePeriod11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week0.next();
//        long long16 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.Date date3 = week1.getStart();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = week1.equals(obj5);
//        java.util.Date date7 = week1.getStart();
//        long long8 = week1.getSerialIndex();
//        org.jfree.data.time.Year year9 = week1.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(29, year9);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(year9);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
        java.lang.String str8 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str10 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable throwable20 = null;
        try {
            timePeriodFormatException14.addSuppressed(throwable20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        int int6 = week0.getYearValue();
//        java.lang.String str7 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        int int6 = week4.getWeek();
//        int int8 = week4.compareTo((java.lang.Object) 0);
//        int int9 = week4.getYearValue();
//        long long10 = week4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week4.next();
//        int int12 = week0.compareTo((java.lang.Object) regularTimePeriod11);
//        java.util.Calendar calendar13 = null;
//        try {
//            week0.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException6.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        java.util.Date date6 = week4.getStart();
//        java.lang.Class<?> wildcardClass7 = week4.getClass();
//        java.lang.Class<?> wildcardClass8 = week4.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        long long13 = week11.getSerialIndex();
//        java.util.Date date14 = week11.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        java.util.Date date20 = week18.getStart();
//        java.util.Date date21 = week18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone22);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date3, timeZone22);
//        java.lang.Class<?> wildcardClass26 = timeZone22.getClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        org.jfree.data.time.Year year3 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
        java.lang.Class<?> wildcardClass6 = regularTimePeriod5.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
//        java.util.Date date12 = regularTimePeriod11.getStart();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod11.getClass();
//        int int14 = week0.compareTo((java.lang.Object) regularTimePeriod11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week0.next();
//        java.lang.Class class16 = null;
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
//        boolean boolean20 = week0.equals((java.lang.Object) regularTimePeriod19);
//        int int21 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
        java.lang.String str8 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str22 = timePeriodFormatException11.toString();
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 8);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61908854400001L) + "'", long3 == (-61908854400001L));
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        int int6 = week0.getYearValue();
//        java.util.Date date7 = week0.getStart();
//        int int8 = week0.getYearValue();
//        java.util.Date date9 = week0.getEnd();
//        java.lang.String str10 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        int int8 = week6.getWeek();
//        int int10 = week6.compareTo((java.lang.Object) 0);
//        int int11 = week6.getYearValue();
//        long long12 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year13 = week6.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(5, year13);
//        boolean boolean15 = week0.equals((java.lang.Object) year13);
//        long long16 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getStart();
//        long long7 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        long long10 = week8.getSerialIndex();
//        long long11 = week8.getSerialIndex();
//        int int12 = week8.getWeek();
//        long long13 = week8.getFirstMillisecond();
//        boolean boolean14 = week0.equals((java.lang.Object) long13);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) -1);
        int int4 = week2.compareTo((java.lang.Object) (-59106513600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str18 = timePeriodFormatException6.toString();
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) -1);
        long long3 = week2.getSerialIndex();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        java.util.Date date5 = week4.getEnd();
        java.util.Date date6 = week4.getStart();
        java.lang.Class<?> wildcardClass7 = week4.getClass();
        java.lang.Class<?> wildcardClass8 = week4.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        java.util.Date date10 = week9.getEnd();
        java.util.Date date11 = week9.getStart();
        java.lang.Class<?> wildcardClass12 = week9.getClass();
        java.lang.Class<?> wildcardClass13 = week9.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        boolean boolean16 = week4.equals((java.lang.Object) class15);
        int int17 = week2.compareTo((java.lang.Object) week4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-53L) + "'", long3 == (-53L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2020) + "'", int17 == (-2020));
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        java.lang.String str6 = week0.toString();
//        java.util.Date date7 = week0.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        int int13 = week11.getWeek();
//        int int15 = week11.compareTo((java.lang.Object) 0);
//        int int16 = week11.getYearValue();
//        long long17 = week11.getFirstMillisecond();
//        org.jfree.data.time.Year year18 = week11.getYear();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(5, year18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (byte) 0, year18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(5, year18);
//        int int22 = week0.compareTo((java.lang.Object) year18);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, 0);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62167104000000L) + "'", long3 == (-62167104000000L));
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        int int6 = week0.getYearValue();
//        long long7 = week0.getSerialIndex();
//        long long8 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        int int3 = week1.getWeek();
//        int int5 = week1.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, year6);
//        java.util.Calendar calendar8 = null;
//        try {
//            week7.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, 2019);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.lang.String str4 = week0.toString();
//        int int5 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        java.util.Date date13 = week0.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.String str6 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        int int6 = week0.getYearValue();
//        java.util.Date date7 = week0.getStart();
//        int int8 = week0.getYearValue();
//        java.util.Date date9 = week0.getEnd();
//        int int10 = week0.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        java.util.Date date7 = week0.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str26 = timePeriodFormatException24.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.Throwable[] throwableArray44 = timePeriodFormatException34.getSuppressed();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.String str47 = timePeriodFormatException34.toString();
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str47.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week6.next();
//        long long14 = regularTimePeriod13.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560970799999L + "'", long14 == 1560970799999L);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = week0.equals(obj5);
//        java.lang.String str7 = week0.toString();
//        long long8 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        int int4 = week0.getYearValue();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = week0.equals(obj5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        long long9 = week7.getSerialIndex();
//        java.util.Date date10 = week7.getStart();
//        int int11 = week7.getWeek();
//        int int12 = week0.compareTo((java.lang.Object) week7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week7.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week7.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        java.util.Date date5 = week3.getStart();
//        java.util.Date date6 = week3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date6, timeZone7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        long long11 = week9.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException4.getClass();
        java.lang.String str9 = timePeriodFormatException4.toString();
        java.lang.String str10 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException4.getSuppressed();
        java.lang.String str12 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (short) 1);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62132932800001L) + "'", long3 == (-62132932800001L));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        org.jfree.data.time.Year year6 = week0.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        java.util.Date date8 = week7.getEnd();
        java.util.Date date9 = week7.getStart();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        java.util.Date date11 = week7.getEnd();
        int int12 = week0.compareTo((java.lang.Object) date11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        java.util.Date date7 = week5.getStart();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        java.util.Date date12 = week10.getStart();
//        java.lang.Class<?> wildcardClass13 = week10.getClass();
//        java.lang.Class<?> wildcardClass14 = week10.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        boolean boolean17 = week5.equals((java.lang.Object) class16);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        long long25 = week23.getSerialIndex();
//        java.util.Date date26 = week23.getEnd();
//        java.lang.Class<?> wildcardClass27 = date26.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.util.Date date29 = week28.getEnd();
//        long long30 = week28.getSerialIndex();
//        java.util.Date date31 = week28.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date31, timeZone32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date20, timeZone32);
//        boolean boolean35 = week5.equals((java.lang.Object) date20);
//        java.lang.String str36 = week5.toString();
//        long long37 = week5.getFirstMillisecond();
//        java.util.Date date38 = week5.getStart();
//        java.lang.Class class39 = null;
//        java.util.Date date40 = null;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date38, timeZone41);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 107031L + "'", long30 == 107031L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560063600000L + "'", long37 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        long long8 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getFirstMillisecond();
//        int int11 = week9.getYearValue();
//        int int12 = week0.compareTo((java.lang.Object) int11);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        int int13 = week0.getYearValue();
//        long long14 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week0.equals(obj6);
//        long long8 = week0.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            week0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        long long7 = week0.getSerialIndex();
//        long long8 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        java.util.Date date5 = week3.getStart();
        java.util.Date date6 = week3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date6, timeZone7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
        java.util.Date date13 = week12.getEnd();
        java.util.Date date14 = week12.getStart();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date14, timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getWeek();
//        int int6 = week2.compareTo((java.lang.Object) 0);
//        int int7 = week2.getYearValue();
//        long long8 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week2.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(5, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(9, year9);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year9);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 1);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        java.util.Date date6 = week4.getStart();
//        java.lang.Class<?> wildcardClass7 = week4.getClass();
//        java.lang.Class<?> wildcardClass8 = week4.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        long long13 = week11.getSerialIndex();
//        java.util.Date date14 = week11.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        java.util.Date date20 = week18.getStart();
//        java.util.Date date21 = week18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone22);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date3, timeZone22);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        java.util.Date date27 = week26.getEnd();
//        int int28 = week26.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week26.next();
//        java.util.Date date30 = regularTimePeriod29.getStart();
//        java.lang.Class class31 = null;
//        java.util.Date date32 = null;
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
//        java.lang.Class<?> wildcardClass35 = timeZone33.getClass();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date30, timeZone33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date3, timeZone33);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        java.util.Date date8 = week5.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        long long12 = week10.getSerialIndex();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date2, timeZone14);
//        long long17 = week16.getFirstMillisecond();
//        java.util.Date date18 = week16.getStart();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
//        java.util.Calendar calendar21 = null;
//        try {
//            week20.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        int int5 = week0.getWeek();
//        java.lang.String str6 = week0.toString();
//        java.lang.Class<?> wildcardClass7 = week0.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        long long8 = week5.getSerialIndex();
//        int int9 = week5.getWeek();
//        long long10 = week5.getFirstMillisecond();
//        int int11 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week0.next();
//        java.util.Date date14 = week0.getEnd();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getWeek();
//        int int6 = week2.compareTo((java.lang.Object) 0);
//        int int7 = week2.getYearValue();
//        long long8 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week2.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(5, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 0, year9);
//        org.jfree.data.time.Year year12 = week11.getYear();
//        boolean boolean14 = week11.equals((java.lang.Object) 100.0d);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        java.util.Date date5 = week3.getStart();
        java.util.Date date6 = week3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        java.util.Date date11 = week9.getStart();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getWeek();
//        int int6 = week2.compareTo((java.lang.Object) 0);
//        int int7 = week2.getYearValue();
//        long long8 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week2.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(5, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 0, year9);
//        java.util.Date date12 = week11.getStart();
//        long long13 = week11.getSerialIndex();
//        int int14 = week11.getWeek();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107007L + "'", long13 == 107007L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        long long5 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getFirstMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getFirstMillisecond();
//        int int10 = week6.compareTo((java.lang.Object) week8);
//        java.util.Date date11 = week8.getEnd();
//        java.util.Date date12 = week8.getEnd();
//        int int13 = week0.compareTo((java.lang.Object) date12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.String str13 = timePeriodFormatException10.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.String str23 = timePeriodFormatException19.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.String str25 = timePeriodFormatException19.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        int int7 = week0.getWeek();
//        int int8 = week0.getYearValue();
//        java.util.Calendar calendar9 = null;
//        try {
//            week0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        java.lang.Class<?> wildcardClass8 = week4.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        long long11 = week9.getSerialIndex();
//        java.util.Date date12 = week9.getEnd();
//        java.lang.Class<?> wildcardClass13 = date12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        long long16 = week14.getSerialIndex();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        java.lang.Class class20 = null;
//        java.util.Date date21 = null;
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
//        java.lang.Class<?> wildcardClass24 = timeZone22.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date17, timeZone22);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass28 = timePeriodFormatException27.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.util.Date date30 = week29.getEnd();
//        java.util.Date date31 = week29.getStart();
//        java.util.Date date32 = week29.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date32);
//        java.lang.Class<?> wildcardClass36 = date32.getClass();
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        java.util.Date date39 = week38.getEnd();
//        int int40 = week38.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week38.next();
//        long long42 = week38.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week38.next();
//        java.util.Date date44 = regularTimePeriod43.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        java.util.Date date46 = week45.getEnd();
//        java.util.Date date47 = week45.getStart();
//        java.lang.Class<?> wildcardClass48 = week45.getClass();
//        java.lang.Object obj49 = null;
//        boolean boolean50 = week45.equals(obj49);
//        java.lang.String str51 = week45.toString();
//        java.util.Date date52 = week45.getStart();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        java.util.Date date54 = week53.getEnd();
//        long long55 = week53.getSerialIndex();
//        java.util.Date date56 = week53.getEnd();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        java.util.Date date58 = week57.getEnd();
//        java.util.Date date59 = week57.getStart();
//        java.lang.Class<?> wildcardClass60 = week57.getClass();
//        java.lang.Class<?> wildcardClass61 = week57.getClass();
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        java.util.Date date65 = week64.getEnd();
//        long long66 = week64.getSerialIndex();
//        java.util.Date date67 = week64.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException69 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass70 = timePeriodFormatException69.getClass();
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        java.util.Date date72 = week71.getEnd();
//        java.util.Date date73 = week71.getStart();
//        java.util.Date date74 = week71.getEnd();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date74, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date67, timeZone75);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date56, timeZone75);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date52, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date44, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date17, timeZone75);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        java.util.Date date83 = week82.getEnd();
//        int int84 = week82.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = week82.next();
//        java.util.Date date86 = regularTimePeriod85.getStart();
//        java.lang.Class class87 = null;
//        java.util.Date date88 = null;
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class87, date88, timeZone89);
//        java.lang.Class<?> wildcardClass91 = timeZone89.getClass();
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date86, timeZone89);
//        java.util.Locale locale93 = null;
//        try {
//            org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date17, timeZone89, locale93);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 24 + "'", int40 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560063600000L + "'", long42 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Week 24, 2019" + "'", str51.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 107031L + "'", long55 == 107031L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNotNull(class63);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 107031L + "'", long66 == 107031L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 24 + "'", int84 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(wildcardClass91);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException1.getClass();
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.String str7 = timePeriodFormatException1.toString();
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException10.getClass();
        java.lang.String str15 = timePeriodFormatException10.toString();
        java.lang.String str16 = timePeriodFormatException10.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException21.getSuppressed();
        java.lang.String str24 = timePeriodFormatException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Class<?> wildcardClass32 = timePeriodFormatException28.getClass();
        java.lang.String str33 = timePeriodFormatException28.toString();
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException41.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.util.Date date5 = week0.getStart();
//        java.lang.Class class6 = null;
//        java.util.Date date7 = null;
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date5);
//        long long12 = week11.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        int int13 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass14 = week0.getClass();
//        int int15 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        long long8 = week5.getSerialIndex();
//        int int9 = week5.getWeek();
//        long long10 = week5.getFirstMillisecond();
//        int int11 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.next();
//        long long13 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) 'a');
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 97" + "'", str3.equals("Week 0, 97"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        java.util.Date date5 = week3.getStart();
        java.util.Date date6 = week3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6);
        java.lang.Class<?> wildcardClass10 = date6.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getFirstMillisecond();
//        int int4 = week0.compareTo((java.lang.Object) week2);
//        java.util.Date date5 = week2.getEnd();
//        long long6 = week2.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        int int6 = week0.getYearValue();
        int int7 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        long long8 = week5.getSerialIndex();
//        int int9 = week5.getWeek();
//        long long10 = week5.getFirstMillisecond();
//        int int11 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.previous();
//        java.lang.String str13 = week0.toString();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week0.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        int int6 = week0.getYearValue();
//        long long7 = week0.getSerialIndex();
//        long long8 = week0.getFirstMillisecond();
//        long long9 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        org.jfree.data.time.Year year13 = week0.getYear();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week0.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(year13);
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
//        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
//        java.lang.String str6 = timePeriodFormatException3.toString();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        long long10 = week8.getSerialIndex();
//        java.util.Date date11 = week8.getEnd();
//        java.lang.Class<?> wildcardClass12 = date11.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        java.util.Date date17 = week16.getEnd();
//        int int18 = week16.getWeek();
//        int int20 = week16.compareTo((java.lang.Object) 0);
//        int int21 = week16.getYearValue();
//        long long22 = week16.getFirstMillisecond();
//        org.jfree.data.time.Year year23 = week16.getYear();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(5, year23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (byte) 100, year23);
//        java.util.Date date26 = year23.getStart();
//        java.util.Date date27 = year23.getStart();
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date27, timeZone28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.util.Date date31 = week30.getEnd();
//        java.util.Date date32 = week30.getStart();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        java.util.Date date34 = week33.getEnd();
//        int int35 = week33.getWeek();
//        int int37 = week33.compareTo((java.lang.Object) 0);
//        long long38 = week33.getFirstMillisecond();
//        java.util.Date date39 = week33.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass42 = timePeriodFormatException41.getClass();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        java.util.Date date44 = week43.getEnd();
//        java.util.Date date45 = week43.getStart();
//        java.util.Date date46 = week43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date46, timeZone47);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date39, timeZone47);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date32, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date27, timeZone47);
//        org.junit.Assert.assertNotNull(throwableArray5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 24 + "'", int35 == 24);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560063600000L + "'", long38 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getEnd();
//        java.lang.Class<?> wildcardClass10 = date9.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        long long13 = week11.getSerialIndex();
//        java.util.Date date14 = week11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date3, timeZone15);
//        long long18 = week17.getFirstMillisecond();
//        java.util.Date date19 = week17.getStart();
//        org.jfree.data.time.Year year20 = week17.getYear();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (byte) 1, year20);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063600000L + "'", long18 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(year20);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 9);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getLastMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        int int6 = week4.getWeek();
//        int int8 = week4.compareTo((java.lang.Object) 0);
//        long long9 = week4.getFirstMillisecond();
//        java.lang.String str10 = week4.toString();
//        java.util.Date date11 = week4.getEnd();
//        boolean boolean12 = week0.equals((java.lang.Object) date11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass15 = timePeriodFormatException14.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        java.util.Date date17 = week16.getEnd();
//        java.util.Date date18 = week16.getStart();
//        java.util.Date date19 = week16.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date11, timeZone20);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str26 = timePeriodFormatException24.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str28 = timePeriodFormatException8.toString();
        java.lang.String str29 = timePeriodFormatException8.toString();
        java.lang.Class<?> wildcardClass30 = timePeriodFormatException8.getClass();
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        java.util.Date date3 = week1.getStart();
        org.jfree.data.time.Year year4 = week1.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Year year6 = week5.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year6);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        java.lang.Class<?> wildcardClass9 = timeZone7.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date4, timeZone7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        java.util.Date date16 = week14.getStart();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date17);
//        java.lang.Class<?> wildcardClass21 = date17.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        int int25 = week23.getWeek();
//        int int27 = week23.compareTo((java.lang.Object) 0);
//        long long28 = week23.getFirstMillisecond();
//        java.lang.String str29 = week23.toString();
//        java.util.Date date30 = week23.getEnd();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.util.Date date32 = week31.getEnd();
//        java.util.Date date33 = week31.getStart();
//        java.lang.Class<?> wildcardClass34 = week31.getClass();
//        java.lang.Object obj35 = null;
//        boolean boolean36 = week31.equals(obj35);
//        java.lang.String str37 = week31.toString();
//        java.util.Date date38 = week31.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        java.util.Date date40 = week39.getEnd();
//        long long41 = week39.getSerialIndex();
//        java.util.Date date42 = week39.getEnd();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        java.util.Date date44 = week43.getEnd();
//        java.util.Date date45 = week43.getStart();
//        java.lang.Class<?> wildcardClass46 = week43.getClass();
//        java.lang.Class<?> wildcardClass47 = week43.getClass();
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        java.util.Date date51 = week50.getEnd();
//        long long52 = week50.getSerialIndex();
//        java.util.Date date53 = week50.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass56 = timePeriodFormatException55.getClass();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        java.util.Date date58 = week57.getEnd();
//        java.util.Date date59 = week57.getStart();
//        java.util.Date date60 = week57.getEnd();
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date53, timeZone61);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date42, timeZone61);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date38, timeZone61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date30, timeZone61);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date4, timeZone61);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560063600000L + "'", long28 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 24, 2019" + "'", str29.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Week 24, 2019" + "'", str37.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 107031L + "'", long41 == 107031L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 107031L + "'", long52 == 107031L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 3);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        java.util.Date date7 = week0.getEnd();
//        java.lang.Class class8 = null;
//        java.util.Date date9 = null;
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date7, timeZone10);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        int int5 = week0.getYearValue();
//        long long6 = week0.getFirstMillisecond();
//        java.lang.String str7 = week0.toString();
//        long long8 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
//        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
//        java.lang.String str6 = timePeriodFormatException3.toString();
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        long long11 = week9.getSerialIndex();
//        java.util.Date date12 = week9.getEnd();
//        java.lang.Class<?> wildcardClass13 = date12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        long long16 = week14.getSerialIndex();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getEnd();
//        java.util.Date date22 = week20.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        int int25 = week23.getWeek();
//        int int27 = week23.compareTo((java.lang.Object) 0);
//        long long28 = week23.getFirstMillisecond();
//        java.util.Date date29 = week23.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass32 = timePeriodFormatException31.getClass();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        java.util.Date date34 = week33.getEnd();
//        java.util.Date date35 = week33.getStart();
//        java.util.Date date36 = week33.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date36, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date29, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date22, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date17, timeZone37);
//        org.junit.Assert.assertNotNull(throwableArray5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560063600000L + "'", long28 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        int int6 = week0.getYearValue();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        java.util.Date date13 = week11.getStart();
//        java.util.Date date14 = week11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date7, timeZone15);
//        java.lang.String str18 = week17.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        java.util.Date date8 = week6.getStart();
//        java.util.Date date9 = week6.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        boolean boolean13 = week0.equals((java.lang.Object) week12);
//        int int14 = week12.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getEnd();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getSerialIndex();
//        java.util.Date date9 = week6.getStart();
//        long long10 = week6.getFirstMillisecond();
//        long long11 = week6.getFirstMillisecond();
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week6.next();
//        long long14 = week6.getFirstMillisecond();
//        org.jfree.data.time.Year year15 = week6.getYear();
//        long long16 = week6.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560365999999L + "'", long16 == 1560365999999L);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        java.lang.String str5 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
        java.lang.String str8 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str10 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str20 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 24, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = week0.equals(obj5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.util.Date date8 = week7.getEnd();
//        long long9 = week7.getSerialIndex();
//        java.util.Date date10 = week7.getStart();
//        int int11 = week7.getWeek();
//        int int12 = week0.compareTo((java.lang.Object) week7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week7.next();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week7.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.util.Date date6 = week0.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        java.lang.String str24 = timePeriodFormatException20.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.String str32 = timePeriodFormatException28.toString();
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException28.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray33);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        long long7 = week5.getSerialIndex();
//        long long8 = week5.getSerialIndex();
//        int int9 = week5.getWeek();
//        long long10 = week5.getFirstMillisecond();
//        int int11 = week0.compareTo((java.lang.Object) week5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.previous();
//        java.lang.String str13 = week0.toString();
//        boolean boolean15 = week0.equals((java.lang.Object) (byte) 0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getWeek();
//        int int6 = week2.compareTo((java.lang.Object) 0);
//        int int7 = week2.getYearValue();
//        long long8 = week2.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week2.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(5, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 100, year9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 0);
        int int3 = week2.getYearValue();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        int int6 = week4.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        java.util.Date date8 = regularTimePeriod7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.util.Date date10 = week9.getEnd();
//        long long11 = week9.getSerialIndex();
//        java.util.Date date12 = week9.getEnd();
//        java.lang.Class<?> wildcardClass13 = date12.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        long long16 = week14.getSerialIndex();
//        java.util.Date date17 = week14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date8, timeZone18);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        long long23 = week21.getSerialIndex();
//        java.util.Date date24 = week21.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        java.util.Date date26 = week25.getEnd();
//        java.util.Date date27 = week25.getStart();
//        java.lang.Class<?> wildcardClass28 = week25.getClass();
//        java.lang.Class<?> wildcardClass29 = week25.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        java.util.Date date33 = week32.getEnd();
//        long long34 = week32.getSerialIndex();
//        java.util.Date date35 = week32.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass38 = timePeriodFormatException37.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        java.util.Date date40 = week39.getEnd();
//        java.util.Date date41 = week39.getStart();
//        java.util.Date date42 = week39.getEnd();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date42, timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone43);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date24, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        java.util.Date date48 = week47.getEnd();
//        java.util.Date date49 = week47.getStart();
//        java.lang.Class<?> wildcardClass50 = week47.getClass();
//        java.lang.Object obj51 = null;
//        boolean boolean52 = week47.equals(obj51);
//        int int53 = week47.getYearValue();
//        java.util.Date date54 = week47.getStart();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        java.util.Date date56 = week55.getEnd();
//        java.util.Date date57 = week55.getStart();
//        java.lang.Class<?> wildcardClass58 = week55.getClass();
//        java.lang.Object obj59 = null;
//        boolean boolean60 = week55.equals(obj59);
//        int int61 = week55.getYearValue();
//        java.util.Date date62 = week55.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException64 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass65 = timePeriodFormatException64.getClass();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        java.util.Date date67 = week66.getEnd();
//        java.util.Date date68 = week66.getStart();
//        java.util.Date date69 = week66.getEnd();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date69, timeZone70);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date62, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date54, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date24, timeZone70);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 107031L + "'", long23 == 107031L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 107031L + "'", long34 == 107031L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 0);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 0, 0" + "'", str4.equals("Week 0, 0"));
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        java.util.Date date6 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        long long5 = week0.getSerialIndex();
//        java.util.Date date6 = week0.getEnd();
//        java.lang.Class<?> wildcardClass7 = date6.getClass();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
//        java.util.Date date6 = week5.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        java.util.Date date7 = week5.getStart();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = week5.equals(obj9);
//        int int11 = week5.getYearValue();
//        java.util.Date date12 = week5.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass15 = timePeriodFormatException14.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getEnd();
//        int int19 = week17.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week17.next();
//        java.util.Date date21 = regularTimePeriod20.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.util.Date date23 = week22.getEnd();
//        long long24 = week22.getSerialIndex();
//        java.util.Date date25 = week22.getEnd();
//        java.lang.Class<?> wildcardClass26 = date25.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.util.Date date28 = week27.getEnd();
//        long long29 = week27.getSerialIndex();
//        java.util.Date date30 = week27.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date21, timeZone31);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.util.Date date35 = week34.getEnd();
//        int int36 = week34.getWeek();
//        int int38 = week34.compareTo((java.lang.Object) 0);
//        long long39 = week34.getFirstMillisecond();
//        java.lang.String str40 = week34.toString();
//        java.util.Date date41 = week34.getEnd();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        java.util.Date date43 = week42.getEnd();
//        java.util.Date date44 = week42.getStart();
//        java.lang.Class<?> wildcardClass45 = week42.getClass();
//        java.lang.Class<?> wildcardClass46 = week42.getClass();
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        java.util.Date date50 = week49.getEnd();
//        long long51 = week49.getSerialIndex();
//        java.util.Date date52 = week49.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass55 = timePeriodFormatException54.getClass();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        java.util.Date date57 = week56.getEnd();
//        java.util.Date date58 = week56.getStart();
//        java.util.Date date59 = week56.getEnd();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date52, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date41, timeZone60);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        java.util.Date date65 = week64.getEnd();
//        java.util.Date date66 = week64.getStart();
//        java.lang.Class<?> wildcardClass67 = week64.getClass();
//        java.lang.Class<?> wildcardClass68 = week64.getClass();
//        java.lang.Class class69 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass68);
//        java.lang.Class class70 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass68);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        java.util.Date date72 = week71.getEnd();
//        long long73 = week71.getSerialIndex();
//        java.util.Date date74 = week71.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException76 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass77 = timePeriodFormatException76.getClass();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week();
//        java.util.Date date79 = week78.getEnd();
//        java.util.Date date80 = week78.getStart();
//        java.util.Date date81 = week78.getEnd();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date81, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date74, timeZone82);
//        java.lang.Class class85 = null;
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week();
//        java.util.Date date87 = week86.getEnd();
//        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance(class85, date87, timeZone88);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date74, timeZone88);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date12, timeZone88);
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date12, timeZone92);
//        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 107031L + "'", long24 == 107031L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560063600000L + "'", long39 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Week 24, 2019" + "'", str40.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 107031L + "'", long51 == 107031L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(class69);
//        org.junit.Assert.assertNotNull(class70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 107031L + "'", long73 == 107031L);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertNotNull(timeZone88);
//        org.junit.Assert.assertNull(regularTimePeriod89);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
//        java.util.Date date12 = regularTimePeriod11.getStart();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod11.getClass();
//        int int14 = week0.compareTo((java.lang.Object) regularTimePeriod11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week0.next();
//        java.lang.Class class16 = null;
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
//        boolean boolean20 = week0.equals((java.lang.Object) regularTimePeriod19);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.util.Date date22 = week21.getEnd();
//        java.util.Date date23 = week21.getStart();
//        java.lang.Class<?> wildcardClass24 = week21.getClass();
//        java.lang.Object obj25 = null;
//        boolean boolean26 = week21.equals(obj25);
//        int int27 = week21.getYearValue();
//        java.util.Date date28 = week21.getStart();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass31 = timePeriodFormatException30.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        java.util.Date date33 = week32.getEnd();
//        java.util.Date date34 = week32.getStart();
//        java.util.Date date35 = week32.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone36);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date28, timeZone36);
//        boolean boolean39 = week0.equals((java.lang.Object) date28);
//        int int40 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
        java.lang.String str8 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str10 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException23.getSuppressed();
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException23.getSuppressed();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray26);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        long long5 = week0.getFirstMillisecond();
//        java.lang.String str6 = week0.toString();
//        int int7 = week0.getWeek();
//        long long8 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        java.util.Date date6 = week4.getStart();
//        java.lang.Class<?> wildcardClass7 = week4.getClass();
//        java.lang.Class<?> wildcardClass8 = week4.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        long long13 = week11.getSerialIndex();
//        java.util.Date date14 = week11.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        java.util.Date date20 = week18.getStart();
//        java.util.Date date21 = week18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone22);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date3, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
//        long long27 = regularTimePeriod26.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559761199999L + "'", long27 == 1559761199999L);
//    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Date date5 = week0.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        java.util.Date date2 = week1.getEnd();
        java.util.Date date3 = week1.getStart();
        java.lang.Class<?> wildcardClass4 = week1.getClass();
        java.lang.Object obj5 = null;
        boolean boolean6 = week1.equals(obj5);
        int int7 = week1.getYearValue();
        java.util.Date date8 = week1.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        java.util.Date date10 = week9.getEnd();
        java.util.Date date11 = week9.getStart();
        java.lang.Class<?> wildcardClass12 = week9.getClass();
        java.lang.Object obj13 = null;
        boolean boolean14 = week9.equals(obj13);
        int int15 = week9.getYearValue();
        java.util.Date date16 = week9.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
        java.util.Date date21 = week20.getEnd();
        java.util.Date date22 = week20.getStart();
        java.util.Date date23 = week20.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date16, timeZone24);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date8, timeZone24);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.Year year29 = week28.getYear();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) (short) -1, year29);
        java.lang.Class<?> wildcardClass31 = week30.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 53);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getMiddleMillisecond();
//        long long7 = week0.getLastMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        int int3 = week1.getWeek();
//        int int5 = week1.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, year6);
//        java.util.Date date8 = week7.getEnd();
//        java.lang.String str9 = week7.toString();
//        long long10 = week7.getSerialIndex();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 12, 2019" + "'", str9.equals("Week 12, 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107019L + "'", long10 == 107019L);
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.util.Date date9 = week8.getEnd();
//        java.util.Date date10 = week8.getStart();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        int int12 = week0.compareTo((java.lang.Object) week8);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException6.getClass();
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Class<?> wildcardClass4 = week0.getClass();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        java.util.Date date6 = week5.getEnd();
        java.util.Date date7 = week5.getStart();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        java.lang.Class<?> wildcardClass9 = week5.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean12 = week0.equals((java.lang.Object) class11);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) -1, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
        boolean boolean17 = week0.equals((java.lang.Object) regularTimePeriod16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week0.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        int int4 = week0.getWeek();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        java.util.Date date7 = week5.getStart();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean12 = week0.equals((java.lang.Object) class11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        long long20 = week18.getSerialIndex();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class<?> wildcardClass22 = date21.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        long long25 = week23.getSerialIndex();
//        java.util.Date date26 = week23.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date26, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date15, timeZone27);
//        boolean boolean30 = week0.equals((java.lang.Object) date15);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date15);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass34 = timePeriodFormatException33.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.util.Date date36 = week35.getEnd();
//        java.util.Date date37 = week35.getStart();
//        java.util.Date date38 = week35.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date15, timeZone39);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass44 = timePeriodFormatException43.getClass();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        java.util.Date date46 = week45.getEnd();
//        java.util.Date date47 = week45.getStart();
//        java.util.Date date48 = week45.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date48, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date48);
//        java.lang.Class<?> wildcardClass52 = date48.getClass();
//        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        java.util.Date date55 = week54.getEnd();
//        int int56 = week54.getWeek();
//        int int58 = week54.compareTo((java.lang.Object) 0);
//        long long59 = week54.getFirstMillisecond();
//        java.lang.String str60 = week54.toString();
//        java.util.Date date61 = week54.getEnd();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        java.util.Date date63 = week62.getEnd();
//        java.util.Date date64 = week62.getStart();
//        java.lang.Class<?> wildcardClass65 = week62.getClass();
//        java.lang.Object obj66 = null;
//        boolean boolean67 = week62.equals(obj66);
//        java.lang.String str68 = week62.toString();
//        java.util.Date date69 = week62.getStart();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
//        java.util.Date date71 = week70.getEnd();
//        long long72 = week70.getSerialIndex();
//        java.util.Date date73 = week70.getEnd();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week();
//        java.util.Date date75 = week74.getEnd();
//        java.util.Date date76 = week74.getStart();
//        java.lang.Class<?> wildcardClass77 = week74.getClass();
//        java.lang.Class<?> wildcardClass78 = week74.getClass();
//        java.lang.Class class79 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass78);
//        java.lang.Class class80 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass78);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week();
//        java.util.Date date82 = week81.getEnd();
//        long long83 = week81.getSerialIndex();
//        java.util.Date date84 = week81.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException86 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass87 = timePeriodFormatException86.getClass();
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week();
//        java.util.Date date89 = week88.getEnd();
//        java.util.Date date90 = week88.getStart();
//        java.util.Date date91 = week88.getEnd();
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass87, date91, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass78, date84, timeZone92);
//        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date73, timeZone92);
//        org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date69, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date61, timeZone92);
//        org.jfree.data.time.Week week98 = new org.jfree.data.time.Week(date15, timeZone92);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(class53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 24 + "'", int56 == 24);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560063600000L + "'", long59 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Week 24, 2019" + "'", str60.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Week 24, 2019" + "'", str68.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 107031L + "'", long72 == 107031L);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNotNull(wildcardClass78);
//        org.junit.Assert.assertNotNull(class79);
//        org.junit.Assert.assertNotNull(class80);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 107031L + "'", long83 == 107031L);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(wildcardClass87);
//        org.junit.Assert.assertNotNull(date89);
//        org.junit.Assert.assertNotNull(date90);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//        org.junit.Assert.assertNull(regularTimePeriod97);
//    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 10);
//        int int4 = week2.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        int int7 = week5.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        long long9 = week5.getSerialIndex();
//        boolean boolean10 = week2.equals((java.lang.Object) week5);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = week0.equals(obj4);
//        java.lang.String str6 = week0.toString();
//        java.util.Date date7 = week0.getEnd();
//        java.lang.String str8 = week0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 7);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int4 = week0.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        java.util.Date date8 = week6.getStart();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        java.lang.Class<?> wildcardClass10 = week6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.util.Date date14 = week13.getEnd();
//        long long15 = week13.getSerialIndex();
//        java.util.Date date16 = week13.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getEnd();
//        java.util.Date date22 = week20.getStart();
//        java.util.Date date23 = week20.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone24);
//        java.lang.Class<?> wildcardClass27 = date16.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        int int29 = week0.compareTo((java.lang.Object) class28);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107031L + "'", long15 == 107031L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getWeek();
//        int int7 = week3.compareTo((java.lang.Object) 0);
//        int int8 = week3.getYearValue();
//        long long9 = week3.getFirstMillisecond();
//        org.jfree.data.time.Year year10 = week3.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(5, year10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (byte) 0, year10);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(5, year10);
//        java.lang.String str14 = week13.toString();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        java.lang.Class<?> wildcardClass16 = year15.getClass();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 5, 2019" + "'", str14.equals("Week 5, 2019"));
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.util.Date date3 = week0.getEnd();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getEnd();
        java.util.Date date2 = week0.getStart();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.lang.Class<?> wildcardClass4 = week0.getClass();
        java.util.Date date5 = week0.getStart();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week11.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException19.getSuppressed();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException19.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray33);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
        java.lang.String str8 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable throwable10 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException1.getClass();
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.String str7 = timePeriodFormatException1.toString();
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException10.getClass();
        java.lang.String str15 = timePeriodFormatException10.toString();
        java.lang.String str16 = timePeriodFormatException10.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str18 = timePeriodFormatException10.toString();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        int int3 = week1.getWeek();
//        int int5 = week1.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) 'a', year6);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(year6);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getStart();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.util.Date date6 = week5.getEnd();
//        java.util.Date date7 = week5.getStart();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean12 = week0.equals((java.lang.Object) class11);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.util.Date date15 = week14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        long long20 = week18.getSerialIndex();
//        java.util.Date date21 = week18.getEnd();
//        java.lang.Class<?> wildcardClass22 = date21.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        long long25 = week23.getSerialIndex();
//        java.util.Date date26 = week23.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date26, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date15, timeZone27);
//        boolean boolean30 = week0.equals((java.lang.Object) date15);
//        java.lang.String str31 = week0.toString();
//        int int32 = week0.getWeek();
//        long long33 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 24 + "'", int32 == 24);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560365999999L + "'", long33 == 1560365999999L);
//    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        java.util.Date date5 = week3.getStart();
//        java.util.Date date6 = week3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date6, timeZone7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6);
//        java.lang.Class<?> wildcardClass10 = date6.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.util.Date date13 = week12.getEnd();
//        int int14 = week12.getWeek();
//        int int16 = week12.compareTo((java.lang.Object) 0);
//        long long17 = week12.getFirstMillisecond();
//        java.lang.String str18 = week12.toString();
//        java.util.Date date19 = week12.getEnd();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        java.util.Date date21 = week20.getEnd();
//        java.util.Date date22 = week20.getStart();
//        java.lang.Class<?> wildcardClass23 = week20.getClass();
//        java.lang.Object obj24 = null;
//        boolean boolean25 = week20.equals(obj24);
//        java.lang.String str26 = week20.toString();
//        java.util.Date date27 = week20.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.util.Date date29 = week28.getEnd();
//        long long30 = week28.getSerialIndex();
//        java.util.Date date31 = week28.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        java.util.Date date33 = week32.getEnd();
//        java.util.Date date34 = week32.getStart();
//        java.lang.Class<?> wildcardClass35 = week32.getClass();
//        java.lang.Class<?> wildcardClass36 = week32.getClass();
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        java.util.Date date40 = week39.getEnd();
//        long long41 = week39.getSerialIndex();
//        java.util.Date date42 = week39.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass45 = timePeriodFormatException44.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        java.util.Date date47 = week46.getEnd();
//        java.util.Date date48 = week46.getStart();
//        java.util.Date date49 = week46.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date49, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date42, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date31, timeZone50);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date27, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date19, timeZone50);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date19);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 24, 2019" + "'", str26.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 107031L + "'", long30 == 107031L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 107031L + "'", long41 == 107031L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.util.Date date2 = week1.getEnd();
//        int int3 = week1.getWeek();
//        int int5 = week1.compareTo((java.lang.Object) 0);
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, year6);
//        java.util.Date date8 = week7.getEnd();
//        java.lang.Class class9 = null;
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = timeZone11.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date8, timeZone11);
//        org.jfree.data.time.Year year15 = week14.getYear();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.util.Date date20 = week19.getEnd();
//        java.util.Date date21 = week19.getStart();
//        java.util.Date date22 = week19.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone23);
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
//        int int27 = week14.compareTo((java.lang.Object) class26);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        long long2 = week0.getSerialIndex();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        java.util.Date date6 = week4.getStart();
//        java.lang.Class<?> wildcardClass7 = week4.getClass();
//        java.lang.Class<?> wildcardClass8 = week4.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.util.Date date12 = week11.getEnd();
//        long long13 = week11.getSerialIndex();
//        java.util.Date date14 = week11.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.util.Date date19 = week18.getEnd();
//        java.util.Date date20 = week18.getStart();
//        java.util.Date date21 = week18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone22);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date3, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
//        java.util.Date date27 = regularTimePeriod26.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.util.Date date29 = week28.getEnd();
//        java.util.Date date30 = week28.getStart();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        java.lang.Class<?> wildcardClass32 = week28.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.util.Date date35 = week34.getEnd();
//        java.util.Date date36 = week34.getStart();
//        java.lang.Class<?> wildcardClass37 = week34.getClass();
//        java.lang.Class<?> wildcardClass38 = week34.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        java.util.Date date40 = week39.getEnd();
//        java.util.Date date41 = week39.getStart();
//        java.lang.Class<?> wildcardClass42 = week39.getClass();
//        java.lang.Class<?> wildcardClass43 = week39.getClass();
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        boolean boolean46 = week34.equals((java.lang.Object) class45);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.util.Date date49 = week48.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date49, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        java.util.Date date53 = week52.getEnd();
//        long long54 = week52.getSerialIndex();
//        java.util.Date date55 = week52.getEnd();
//        java.lang.Class<?> wildcardClass56 = date55.getClass();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        java.util.Date date58 = week57.getEnd();
//        long long59 = week57.getSerialIndex();
//        java.util.Date date60 = week57.getEnd();
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone61);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date49, timeZone61);
//        boolean boolean64 = week34.equals((java.lang.Object) date49);
//        java.lang.Class class65 = null;
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        java.util.Date date67 = week66.getEnd();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date67, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date49, timeZone68);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date27, timeZone68);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 107031L + "'", long54 == 107031L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 107031L + "'", long59 == 107031L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//    }
//}

