import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(11, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Nearest");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, 11, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getNearestDayOfWeek(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) 'a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(31, 5, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = null;
//        try {
//            timeSeries11.add(timeSeriesDataItem13, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190972334L + "'", long9 == 1560190972334L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date12, timeZone13);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190972425L + "'", long9 == 1560190972425L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "May" + "'", str1.equals("May"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setRangeDescription("June 2019");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
//        try {
//            timeSeries11.add(regularTimePeriod15, (double) 1560190972625L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190972783L + "'", long9 == 1560190972783L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("May");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 100);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries11.getTimePeriod(5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190972882L + "'", long9 == 1560190972882L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10, (int) (byte) 1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((-1), serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '4', serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 100);
//        try {
//            timeSeries11.delete(1, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190973852L + "'", long9 == 1560190973852L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
//        timeSeries11.delete(regularTimePeriod30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long34 = fixedMillisecond33.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.previous();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond33.getLastMillisecond(calendar36);
//        try {
//            timeSeries11.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 1560190972625L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190973929L + "'", long9 == 1560190973929L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190973932L + "'", long23 == 1560190973932L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.Object obj2 = null;
        int int3 = month0.compareTo(obj2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        try {
//            timeSeries11.update(4, (java.lang.Number) 100.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190974682L + "'", long9 == 1560190974682L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 1559372400000L);
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = null;
//        try {
//            timeSeries27.update(regularTimePeriod28, (java.lang.Number) 1560190972206L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190976067L + "'", long9 == 1560190976067L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190976069L + "'", long23 == 1560190976069L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond13.previous();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond13.getFirstMillisecond(calendar15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond13.getFirstMillisecond(calendar17);
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1560190974253L, false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = null;
//        try {
//            timeSeries11.add(timeSeriesDataItem22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190976655L + "'", long9 == 1560190976655L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        long long31 = month30.getSerialIndex();
//        java.lang.Object obj32 = null;
//        int int33 = month30.compareTo(obj32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.previous();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond35.getFirstMillisecond(calendar37);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getFirstMillisecond(calendar39);
//        int int41 = month30.compareTo((java.lang.Object) fixedMillisecond35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month30.next();
//        int int43 = month30.getMonth();
//        java.lang.Number number44 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) month30);
//        try {
//            timeSeries25.delete(1, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190977245L + "'", long9 == 1560190977245L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190977247L + "'", long23 == 1560190977247L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 24234L + "'", long31 == 24234L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(number44);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        timeSeries11.fireSeriesChanged();
//        java.lang.String str18 = timeSeries11.getDescription();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries11.getDataItem(31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190977342L + "'", long9 == 1560190977342L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str18);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((-1), serialDate2);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        try {
            org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getYearValue();
//        int int6 = month3.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str7 = month3.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str7, "", "hi!", (java.lang.Class) wildcardClass13);
//        java.lang.Class<?> wildcardClass15 = timeSeries14.getClass();
//        boolean boolean16 = day0.equals((java.lang.Object) timeSeries14);
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day0.getLastMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190978103L + "'", long12 == 1560190978103L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        serialDate3.setDescription("");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-447) + "'", int1 == (-447));
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        java.lang.String str19 = day17.toString();
//        try {
//            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day17, (double) 1560190975907L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190978252L + "'", long9 == 1560190978252L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getYearValue();
//        int int31 = month28.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str32 = month28.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
//        java.lang.Class<?> wildcardClass38 = fixedMillisecond35.getClass();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str32, "", "hi!", (java.lang.Class) wildcardClass38);
//        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
//        java.lang.String str41 = timeSeries39.getDomainDescription();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        int int43 = month42.getYearValue();
//        int int45 = month42.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str46 = month42.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond49.getLastMillisecond(calendar50);
//        java.lang.Class<?> wildcardClass52 = fixedMillisecond49.getClass();
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str46, "", "hi!", (java.lang.Class) wildcardClass52);
//        java.lang.String str54 = timeSeries53.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries39.addAndOrUpdate(timeSeries53);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
//        timeSeries53.removeChangeListener(seriesChangeListener56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        boolean boolean60 = year58.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
//        long long62 = day61.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) year58, (org.jfree.data.time.RegularTimePeriod) day61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries65 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) day61, regularTimePeriod64);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190978404L + "'", long9 == 1560190978404L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190978408L + "'", long23 == 1560190978408L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560190978410L + "'", long37 == 1560190978410L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560190978422L + "'", long51 == 1560190978422L);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560236399999L + "'", long62 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries63);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getDayOfMonth();
        long long8 = day6.getLastMillisecond();
        int int10 = day6.compareTo((java.lang.Object) 1560190972122L);
        java.util.Calendar calendar11 = null;
        try {
            day6.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2114092800001L) + "'", long8 == (-2114092800001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Last");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("May");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond10.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, "org.jfree.data.general.SeriesChangeEvent[source=11]", "Nearest", (java.lang.Class) wildcardClass13);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        try {
//            timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 1900);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190978761L + "'", long12 == 1560190978761L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        java.lang.Number number20 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        try {
//            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) number20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190978831L + "'", long9 == 1560190978831L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(number20);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        long long29 = month28.getSerialIndex();
//        java.lang.Object obj30 = null;
//        int int31 = month28.compareTo(obj30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.previous();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond33.getFirstMillisecond(calendar35);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond33.getFirstMillisecond(calendar37);
//        int int39 = month28.compareTo((java.lang.Object) fixedMillisecond33);
//        try {
//            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 100.0f, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190978881L + "'", long9 == 1560190978881L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190978883L + "'", long23 == 1560190978883L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setMaximumItemAge(1560190970939L);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getSerialIndex();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 1560190978666L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
//        try {
//            timeSeries11.delete(regularTimePeriod20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190979182L + "'", long9 == 1560190979182L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ', (-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1900, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener14);
//        java.lang.Object obj16 = timeSeries11.clone();
//        java.lang.String str17 = timeSeries11.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190979628L + "'", long9 == 1560190979628L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.Object obj2 = null;
        int int3 = month0.compareTo(obj2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        int int13 = month0.getMonth();
        java.util.Calendar calendar14 = null;
        try {
            month0.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 10, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oct" + "'", str2.equals("Oct"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 11);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=11]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=11]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=11]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=11]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=11]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=11]"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Preceding");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day33);
//        java.util.Calendar calendar36 = null;
//        try {
//            year30.peg(calendar36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190979904L + "'", long9 == 1560190979904L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190979907L + "'", long23 == 1560190979907L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(8, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener14);
//        java.lang.Object obj16 = timeSeries11.clone();
//        java.util.List list17 = timeSeries11.getItems();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = null;
//        try {
//            timeSeries11.update(regularTimePeriod18, (java.lang.Number) 1560190976560L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190980228L + "'", long9 == 1560190980228L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertNotNull(list17);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 100);
//        timeSeries11.fireSeriesChanged();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate26);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate26);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.next();
//        try {
//            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day29, (double) 1560190970597L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190980273L + "'", long9 == 1560190980273L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1900, serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener14);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.getDataItem((-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -460");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190980555L + "'", long9 == 1560190980555L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        int int5 = day0.compareTo((java.lang.Object) fixedMillisecond2);
//        int int7 = day0.compareTo((java.lang.Object) 1);
//        java.util.Calendar calendar8 = null;
//        try {
//            day0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190980808L + "'", long4 == 1560190980808L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getFirstMillisecond();
        long long4 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable3 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener14);
//        java.lang.String str16 = timeSeries11.getRangeDescription();
//        timeSeries11.setRangeDescription("Preceding");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190981460L + "'", long9 == 1560190981460L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month31 = org.jfree.data.time.Month.parseMonth("June 2019");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) 1560190974098L);
//        java.lang.Object obj34 = timeSeriesDataItem33.clone();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        java.util.Date date36 = year35.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
//        boolean boolean39 = timeSeriesDataItem33.equals((java.lang.Object) day38);
//        try {
//            timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day38, (double) '4');
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190981641L + "'", long9 == 1560190981641L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190981643L + "'", long23 == 1560190981643L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(month31);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("3-January-1903");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getYearValue();
//        int int5 = month2.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str6 = month2.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        java.lang.Class<?> wildcardClass12 = fixedMillisecond9.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str6, "", "hi!", (java.lang.Class) wildcardClass12);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        java.lang.String str15 = timeSeries13.getDomainDescription();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getYearValue();
//        int int19 = month16.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str20 = month16.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
//        java.lang.Class<?> wildcardClass26 = fixedMillisecond23.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str20, "", "hi!", (java.lang.Class) wildcardClass26);
//        java.lang.String str28 = timeSeries27.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries13.addAndOrUpdate(timeSeries27);
//        java.util.Collection collection30 = timeSeries27.getTimePeriods();
//        try {
//            int int31 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries27);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560190981874L + "'", long11 == 1560190981874L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560190981876L + "'", long25 == 1560190981876L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(collection30);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getFirstMillisecond();
        java.lang.String str4 = month0.toString();
        long long5 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        try {
//            java.lang.Number number14 = timeSeries11.getValue(10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190982231L + "'", long9 == 1560190982231L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=11]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        timeSeries11.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=11]");
//        try {
//            timeSeries11.update(31, (java.lang.Number) 1560190974253L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190982373L + "'", long9 == 1560190982373L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-447));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -447");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        timeSeries11.setNotify(false);
//        timeSeries11.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries11.addPropertyChangeListener(propertyChangeListener17);
//        try {
//            timeSeries11.setMaximumItemCount((-447));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190982435L + "'", long9 == 1560190982435L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        timeSeries11.setMaximumItemAge(0L);
//        timeSeries11.clear();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeries11.getTimePeriod((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190982453L + "'", long9 == 1560190982453L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190982454L + "'", long23 == 1560190982454L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        long long31 = month30.getSerialIndex();
//        java.lang.Object obj32 = null;
//        int int33 = month30.compareTo(obj32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.previous();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond35.getFirstMillisecond(calendar37);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getFirstMillisecond(calendar39);
//        int int41 = month30.compareTo((java.lang.Object) fixedMillisecond35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month30.next();
//        int int43 = month30.getMonth();
//        java.lang.Number number44 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) month30);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries25.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = null;
//        try {
//            java.lang.Number number48 = timeSeries25.getValue(regularTimePeriod47);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190982474L + "'", long9 == 1560190982474L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190982476L + "'", long23 == 1560190982476L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 24234L + "'", long31 == 24234L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(number44);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate3 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(6);
        int int6 = spreadsheetDate5.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((-1), serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((-1), serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = serialDate14.getEndOfCurrentMonth(serialDate17);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate23);
        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate25);
        boolean boolean27 = spreadsheetDate5.isInRange(serialDate10, serialDate17);
        try {
            boolean boolean29 = spreadsheetDate1.isInRange(serialDate3, (org.jfree.data.time.SerialDate) spreadsheetDate5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = timeSeries1.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener14);
//        java.lang.Object obj16 = timeSeries11.clone();
//        java.util.List list17 = timeSeries11.getItems();
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener18);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries11.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190982634L + "'", long9 == 1560190982634L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertNotNull(list17);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        timeSeries1.removeAgedItems(false);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener14);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries11.addPropertyChangeListener(propertyChangeListener16);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190982694L + "'", long9 == 1560190982694L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int14 = month13.getYearValue();
//        int int16 = month13.compareTo((java.lang.Object) 1560190970939L);
//        try {
//            timeSeries11.update((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 1560190977026L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190982724L + "'", long9 == 1560190982724L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((-1), serialDate2);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = serialDate6.getEndOfCurrentMonth(serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate17 = serialDate15.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        java.lang.Object obj31 = null;
//        int int32 = month30.compareTo(obj31);
//        java.lang.String str33 = month30.toString();
//        java.lang.Number number34 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month30);
//        try {
//            timeSeries11.delete((-452), (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -452");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190982768L + "'", long9 == 1560190982768L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190982770L + "'", long23 == 1560190982770L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
//        org.junit.Assert.assertNull(number34);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        int int5 = day0.compareTo((java.lang.Object) fixedMillisecond2);
//        int int6 = day0.getMonth();
//        int int7 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190983400L + "'", long4 == 1560190983400L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.Month month14 = org.jfree.data.time.Month.parseMonth("June 2019");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1560190974098L);
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month14);
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = month14.getLastMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190983414L + "'", long9 == 1560190983414L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(month14);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setRangeDescription("June 2019");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = null;
//        try {
//            timeSeries11.add(timeSeriesDataItem15, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190983430L + "'", long9 == 1560190983430L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        long long2 = month0.getSerialIndex();
//        long long3 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        int int9 = day4.compareTo((java.lang.Object) fixedMillisecond6);
//        int int10 = month0.compareTo((java.lang.Object) fixedMillisecond6);
//        int int12 = month0.compareTo((java.lang.Object) 9999);
//        int int13 = month0.getYearValue();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = month0.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190983816L + "'", long8 == 1560190983816L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getFirstMillisecond(calendar5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1900);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
//        java.lang.Object obj10 = timeSeriesDataItem8.clone();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190983859L + "'", long2 == 1560190983859L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190983859L + "'", long6 == 1560190983859L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(obj10);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month31 = org.jfree.data.time.Month.parseMonth("June 2019");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) 1560190974098L);
//        java.lang.Object obj34 = timeSeriesDataItem33.clone();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        java.util.Date date36 = year35.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
//        boolean boolean39 = timeSeriesDataItem33.equals((java.lang.Object) day38);
//        try {
//            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day38, (double) 1099L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190984114L + "'", long9 == 1560190984114L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190984116L + "'", long23 == 1560190984116L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(month31);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1560190976483L);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        int int7 = month6.getYearValue();
//        int int9 = month6.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str10 = month6.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        java.lang.Class<?> wildcardClass16 = fixedMillisecond13.getClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str10, "", "hi!", (java.lang.Class) wildcardClass16);
//        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
//        java.lang.String str19 = timeSeries17.getDomainDescription();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        int int21 = month20.getYearValue();
//        int int23 = month20.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str24 = month20.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        java.lang.Class<?> wildcardClass30 = fixedMillisecond27.getClass();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str24, "", "hi!", (java.lang.Class) wildcardClass30);
//        java.lang.String str32 = timeSeries31.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries17.addAndOrUpdate(timeSeries31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.previous();
//        timeSeries17.delete(regularTimePeriod36);
//        boolean boolean38 = timeSeriesDataItem5.equals((java.lang.Object) regularTimePeriod36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem5.getPeriod();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190984207L + "'", long15 == 1560190984207L);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190984211L + "'", long29 == 1560190984211L);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((-1), serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = serialDate7.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate7);
        serialDate17.setDescription("June 2019");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560190973023L);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries11.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190984655L + "'", long9 == 1560190984655L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1560190976483L);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        int int7 = month6.getYearValue();
//        int int9 = month6.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str10 = month6.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        java.lang.Class<?> wildcardClass16 = fixedMillisecond13.getClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str10, "", "hi!", (java.lang.Class) wildcardClass16);
//        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
//        java.lang.String str19 = timeSeries17.getDomainDescription();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        int int21 = month20.getYearValue();
//        int int23 = month20.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str24 = month20.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        java.lang.Class<?> wildcardClass30 = fixedMillisecond27.getClass();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str24, "", "hi!", (java.lang.Class) wildcardClass30);
//        java.lang.String str32 = timeSeries31.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries17.addAndOrUpdate(timeSeries31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.previous();
//        timeSeries17.delete(regularTimePeriod36);
//        boolean boolean38 = timeSeriesDataItem5.equals((java.lang.Object) regularTimePeriod36);
//        java.lang.Object obj39 = null;
//        int int40 = timeSeriesDataItem5.compareTo(obj39);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190985177L + "'", long15 == 1560190985177L);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190985178L + "'", long29 == 1560190985178L);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        boolean boolean14 = timeSeries11.getNotify();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190985338L + "'", long9 == 1560190985338L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1, 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        java.lang.Object obj31 = null;
//        int int32 = month30.compareTo(obj31);
//        java.lang.String str33 = month30.toString();
//        java.lang.Number number34 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) month30);
//        timeSeries11.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//        try {
//            org.jfree.data.time.TimeSeries timeSeries39 = timeSeries11.createCopy((-1), 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190985519L + "'", long9 == 1560190985519L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190985521L + "'", long23 == 1560190985521L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
//        org.junit.Assert.assertNull(number34);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        int int5 = day0.compareTo((java.lang.Object) fixedMillisecond2);
//        java.lang.String str6 = fixedMillisecond2.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190985804L + "'", long4 == 1560190985804L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Mon Jun 10 11:23:05 PDT 2019" + "'", str6.equals("Mon Jun 10 11:23:05 PDT 2019"));
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 11:23:05 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setMaximumItemAge(1560190970939L);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getSerialIndex();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 1560190978666L);
//        java.lang.Class class20 = timeSeries11.getTimePeriodClass();
//        try {
//            timeSeries11.removeAgedItems(1099L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190986702L + "'", long9 == 1560190986702L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(class20);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((-1), serialDate2);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = serialDate6.getEndOfCurrentMonth(serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate17 = serialDate14.getPreviousDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, 12, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, (int) (short) 1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((-1), serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = serialDate7.getEndOfCurrentMonth(serialDate15);
        try {
            org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) -1, serialDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("1-February-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        timeSeries11.setNotify(false);
//        timeSeries11.fireSeriesChanged();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
//        java.lang.Number number18 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate(regularTimePeriod17, number18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190987626L + "'", long9 == 1560190987626L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.util.Date date2 = day0.getEnd();
//        int int3 = day0.getYear();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((-1), serialDate6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((-1), serialDate10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = serialDate11.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate20);
        org.jfree.data.time.SerialDate serialDate23 = serialDate14.getEndOfCurrentMonth(serialDate22);
        boolean boolean24 = spreadsheetDate2.isInRange(serialDate7, serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((-1), serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        java.util.Date date3 = month0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        java.util.Calendar calendar8 = null;
        try {
            year5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        timeSeries11.setNotify(false);
//        timeSeries11.setRangeDescription("3-January-1903");
//        try {
//            timeSeries11.removeAgedItems(1560190985804L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190989138L + "'", long9 == 1560190989138L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("May");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate3 = null;
        try {
            boolean boolean4 = spreadsheetDate1.isAfter(serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        int int7 = month6.getYearValue();
//        int int9 = month6.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str10 = month6.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        java.lang.Class<?> wildcardClass16 = fixedMillisecond13.getClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str10, "", "hi!", (java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.util.Date date20 = year19.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date20, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date3, timeZone22);
//        long long25 = year24.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190989737L + "'", long15 == 1560190989737L);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        int int5 = day0.compareTo((java.lang.Object) fixedMillisecond2);
//        java.lang.Object obj6 = null;
//        boolean boolean7 = day0.equals(obj6);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190990073L + "'", long4 == 1560190990073L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        java.lang.Object obj2 = null;
//        int int3 = month0.compareTo(obj2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
//        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
//        int int12 = month0.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        int int19 = fixedMillisecond13.compareTo((java.lang.Object) long18);
//        int int20 = month0.compareTo((java.lang.Object) long18);
//        int int21 = month0.getYearValue();
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = month0.getFirstMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190990177L + "'", long15 == 1560190990177L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190990178L + "'", long18 == 1560190990178L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("May");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4, 3, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getYearValue();
//        int int6 = month3.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str7 = month3.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str7, "", "hi!", (java.lang.Class) wildcardClass13);
//        java.lang.Class<?> wildcardClass15 = timeSeries14.getClass();
//        boolean boolean16 = day0.equals((java.lang.Object) timeSeries14);
//        long long17 = day0.getFirstMillisecond();
//        int int18 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190990525L + "'", long12 == 1560190990525L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        java.lang.Object obj2 = timeSeries1.clone();
        try {
            timeSeries1.delete(2, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
        int int5 = month0.compareTo((java.lang.Object) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        timeSeries11.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=11]");
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        int int16 = month15.getYearValue();
//        int int18 = month15.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str19 = month15.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        java.lang.Class<?> wildcardClass25 = fixedMillisecond22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str19, "", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getDomainDescription();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        int int30 = month29.getYearValue();
//        int int32 = month29.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str33 = month29.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getLastMillisecond(calendar37);
//        java.lang.Class<?> wildcardClass39 = fixedMillisecond36.getClass();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str33, "", "hi!", (java.lang.Class) wildcardClass39);
//        java.lang.String str41 = timeSeries40.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries26.addAndOrUpdate(timeSeries40);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timeSeries40.removeChangeListener(seriesChangeListener43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        boolean boolean47 = year45.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        long long49 = day48.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) year45, (org.jfree.data.time.RegularTimePeriod) day48);
//        try {
//            timeSeries11.update((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 1560190981114L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190990651L + "'", long9 == 1560190990651L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560190990653L + "'", long24 == 1560190990653L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560190990655L + "'", long38 == 1560190990655L);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560236399999L + "'", long49 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries50);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        timeSeries11.setNotify(false);
//        timeSeries11.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries11.addPropertyChangeListener(propertyChangeListener17);
//        boolean boolean19 = timeSeries11.getNotify();
//        boolean boolean20 = timeSeries11.getNotify();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190990674L + "'", long9 == 1560190990674L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        long long2 = month0.getSerialIndex();
//        long long3 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        int int9 = day4.compareTo((java.lang.Object) fixedMillisecond6);
//        int int10 = month0.compareTo((java.lang.Object) fixedMillisecond6);
//        int int12 = month0.compareTo((java.lang.Object) 9999);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = month0.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190990906L + "'", long8 == 1560190990906L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        java.lang.Object obj2 = null;
//        int int3 = month0.compareTo(obj2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
//        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
//        int int12 = month0.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        int int19 = fixedMillisecond13.compareTo((java.lang.Object) long18);
//        int int20 = month0.compareTo((java.lang.Object) long18);
//        org.jfree.data.time.Year year21 = month0.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, 0.0d);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        boolean boolean26 = year24.equals((java.lang.Object) (byte) -1);
//        long long27 = year24.getSerialIndex();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getLastMillisecond();
//        java.util.Date date30 = day28.getEnd();
//        java.util.Date date31 = day28.getStart();
//        boolean boolean32 = year24.equals((java.lang.Object) day28);
//        boolean boolean33 = timeSeriesDataItem23.equals((java.lang.Object) boolean32);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190990935L + "'", long15 == 1560190990935L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190990935L + "'", long18 == 1560190990935L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        int int6 = fixedMillisecond0.compareTo((java.lang.Object) 1560190975820L);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getLastMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190991017L + "'", long2 == 1560190991017L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190991017L + "'", long4 == 1560190991017L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190991017L + "'", long8 == 1560190991017L);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Mon Jun 10 11:23:05 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((-1), serialDate4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate8.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate8);
        serialDate8.setDescription("Oct");
        try {
            org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-29), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9999);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1964 + "'", int1 == 1964);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        boolean boolean10 = spreadsheetDate1.isAfter(serialDate8);
        try {
            org.jfree.data.time.SerialDate serialDate12 = serialDate8.getFollowingDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) -1, (-447));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 1559372400000L);
        boolean boolean4 = year0.equals((java.lang.Object) 1560190976138L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        long long6 = year0.getFirstMillisecond();
        java.lang.Object obj7 = null;
        boolean boolean8 = year0.equals(obj7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190992209L + "'", long2 == 1560190992209L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560190992209L + "'", long3 == 1560190992209L);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) 1559372400000L);
        boolean boolean5 = year1.equals((java.lang.Object) 1560190976138L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.next();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((-29), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, 31);
        java.lang.String str3 = month2.toString();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "November 31" + "'", str3.equals("November 31"));
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        timeSeries11.fireSeriesChanged();
//        java.lang.String str18 = timeSeries11.getDescription();
//        timeSeries11.setDescription("");
//        timeSeries11.clear();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        int int23 = month22.getYearValue();
//        long long24 = month22.getSerialIndex();
//        try {
//            timeSeries11.update((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1560190986722L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190992671L + "'", long9 == 1560190992671L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 24234L + "'", long24 == 24234L);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(3, serialDate8);
        java.lang.String str12 = serialDate8.getDescription();
        int int13 = spreadsheetDate2.compare(serialDate8);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays((-1), serialDate16);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = serialDate17.getEndOfCurrentMonth(serialDate20);
        java.lang.String str23 = serialDate20.getDescription();
        boolean boolean24 = spreadsheetDate2.isOnOrBefore(serialDate20);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-29) + "'", int13 == (-29));
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        int int7 = day6.getDayOfMonth();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        int int10 = month9.getYearValue();
//        int int12 = month9.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str13 = month9.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        java.lang.Class<?> wildcardClass19 = fixedMillisecond16.getClass();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str13, "", "hi!", (java.lang.Class) wildcardClass19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, (java.lang.Class) wildcardClass19);
//        long long22 = day6.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3-January-1903" + "'", str8.equals("3-January-1903"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190992829L + "'", long18 == 1560190992829L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2114092800001L) + "'", long22 == (-2114092800001L));
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        java.lang.Object obj2 = null;
//        int int3 = month0.compareTo(obj2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
//        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
//        int int12 = month0.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        int int19 = fixedMillisecond13.compareTo((java.lang.Object) long18);
//        int int20 = month0.compareTo((java.lang.Object) long18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month0.previous();
//        int int22 = month0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190993357L + "'", long15 == 1560190993357L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190993357L + "'", long18 == 1560190993357L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((-1), serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek((int) (byte) 1);
        java.lang.String str7 = serialDate6.getDescription();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(1, serialDate6);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 100);
//        timeSeries11.fireSeriesChanged();
//        boolean boolean23 = timeSeries11.getNotify();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        int int25 = month24.getYearValue();
//        long long26 = month24.getSerialIndex();
//        long long27 = month24.getFirstMillisecond();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getFirstMillisecond(calendar31);
//        int int33 = day28.compareTo((java.lang.Object) fixedMillisecond30);
//        int int34 = month24.compareTo((java.lang.Object) fixedMillisecond30);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond30.getMiddleMillisecond(calendar35);
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        timeSeries11.clear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190993469L + "'", long9 == 1560190993469L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 24234L + "'", long26 == 24234L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190993473L + "'", long32 == 1560190993473L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560190993473L + "'", long36 == 1560190993473L);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond10.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, "org.jfree.data.general.SeriesChangeEvent[source=11]", "Nearest", (java.lang.Class) wildcardClass13);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        boolean boolean20 = year18.equals((java.lang.Object) (byte) -1);
//        long long21 = year18.getSerialIndex();
//        try {
//            timeSeries15.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 1560190973274L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190993604L + "'", long12 == 1560190993604L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getYearValue();
//        int int6 = month3.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str7 = month3.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str7, "", "hi!", (java.lang.Class) wildcardClass13);
//        java.lang.Class<?> wildcardClass15 = timeSeries14.getClass();
//        boolean boolean16 = day0.equals((java.lang.Object) timeSeries14);
//        timeSeries14.setDescription("10-June-2019");
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate22);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
//        int int26 = day25.getDayOfMonth();
//        java.lang.String str27 = day25.toString();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getYearValue();
//        int int31 = month28.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str32 = month28.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
//        java.lang.Class<?> wildcardClass38 = fixedMillisecond35.getClass();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str32, "", "hi!", (java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, (java.lang.Class) wildcardClass38);
//        try {
//            timeSeries14.add((org.jfree.data.time.RegularTimePeriod) day25, (double) 1560190982799L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190993775L + "'", long12 == 1560190993775L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "3-January-1903" + "'", str27.equals("3-January-1903"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560190993779L + "'", long37 == 1560190993779L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("3-January-1903");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        timeSeries11.setMaximumItemAge(0L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries11.addChangeListener(seriesChangeListener32);
//        try {
//            java.lang.Number number35 = timeSeries11.getValue(2958465);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190994231L + "'", long9 == 1560190994231L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190994233L + "'", long23 == 1560190994233L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2114179200000L) + "'", long7 == (-2114179200000L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 1559372400000L);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.Object obj2 = null;
        int int3 = month0.compareTo(obj2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
        int int12 = month0.getYearValue();
        long long13 = month0.getLastMillisecond();
        int int14 = month0.getYearValue();
        long long15 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
        long long5 = fixedMillisecond2.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond2.getLastMillisecond(calendar6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((-1), serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getNearestDayOfWeek((int) (byte) 1);
        java.lang.String str7 = serialDate6.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 10, serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.Object obj2 = null;
        int int3 = month0.compareTo(obj2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        long long13 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        int int3 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(8, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate8);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        java.lang.Class<?> wildcardClass18 = fixedMillisecond15.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod12, "org.jfree.data.general.SeriesChangeEvent[source=11]", "Nearest", (java.lang.Class) wildcardClass18);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
//        try {
//            int int23 = spreadsheetDate2.compareTo((java.lang.Object) propertyChangeListener21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560190996579L + "'", long17 == 1560190996579L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        boolean boolean2 = year0.equals((java.lang.Object) (byte) -1);
//        long long3 = year0.getSerialIndex();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        java.util.Date date6 = day4.getEnd();
//        java.util.Date date7 = day4.getStart();
//        boolean boolean8 = year0.equals((java.lang.Object) day4);
//        long long9 = day4.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        timeSeries11.setMaximumItemAge(0L);
//        timeSeries11.clear();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        int int34 = month33.getYearValue();
//        long long35 = month33.getSerialIndex();
//        long long36 = month33.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        long long39 = month38.getSerialIndex();
//        java.lang.Object obj40 = null;
//        int int41 = month38.compareTo(obj40);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond43.previous();
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond43.getFirstMillisecond(calendar45);
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond43.getFirstMillisecond(calendar47);
//        int int49 = month38.compareTo((java.lang.Object) fixedMillisecond43);
//        int int50 = month38.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar52 = null;
//        long long53 = fixedMillisecond51.getLastMillisecond(calendar52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getLastMillisecond(calendar55);
//        int int57 = fixedMillisecond51.compareTo((java.lang.Object) long56);
//        int int58 = month38.compareTo((java.lang.Object) long56);
//        org.jfree.data.time.Year year59 = month38.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month38, 0.0d);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 1560190993558L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190996632L + "'", long9 == 1560190996632L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190996634L + "'", long23 == 1560190996634L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24234L + "'", long35 == 24234L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1559372400000L + "'", long36 == 1559372400000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 24234L + "'", long39 == 24234L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1L + "'", long46 == 1L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1L + "'", long48 == 1L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560190996638L + "'", long53 == 1560190996638L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560190996638L + "'", long56 == 1560190996638L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(year59);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries11.getTimePeriod(1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190996818L + "'", long9 == 1560190996818L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("3-January-1903");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException7);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod7, (double) 1560190977026L);
        timeSeriesDataItem9.setValue((java.lang.Number) 1560190981903L);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate31);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        try {
//            timeSeries27.add(regularTimePeriod35, (java.lang.Number) (-2114179200000L), false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190996896L + "'", long9 == 1560190996896L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190996898L + "'", long23 == 1560190996898L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((-1), serialDate4);
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((-1), serialDate12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = serialDate13.getEndOfCurrentMonth(serialDate16);
        java.lang.String str19 = serialDate16.getDescription();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate23);
        boolean boolean27 = spreadsheetDate9.isInRange(serialDate16, serialDate23, 9999);
        boolean boolean28 = spreadsheetDate1.isInRange(serialDate7, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(6);
        int int31 = spreadsheetDate30.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays((-1), serialDate34);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((-1), serialDate38);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = serialDate39.getEndOfCurrentMonth(serialDate42);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate48);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate48);
        org.jfree.data.time.SerialDate serialDate51 = serialDate42.getEndOfCurrentMonth(serialDate50);
        boolean boolean52 = spreadsheetDate30.isInRange(serialDate35, serialDate42);
        java.lang.Object obj53 = null;
        boolean boolean54 = spreadsheetDate30.equals(obj53);
        java.util.Date date55 = spreadsheetDate30.toDate();
        boolean boolean56 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addDays((-1), serialDate61);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate65);
        org.jfree.data.time.SerialDate serialDate67 = serialDate62.getEndOfCurrentMonth(serialDate65);
        java.lang.String str68 = serialDate65.getDescription();
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate72);
        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate72);
        boolean boolean76 = spreadsheetDate58.isInRange(serialDate65, serialDate72, 9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addDays((-1), serialDate81);
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate85);
        org.jfree.data.time.SerialDate serialDate87 = serialDate82.getEndOfCurrentMonth(serialDate85);
        java.lang.String str88 = serialDate85.getDescription();
        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate93 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate92);
        org.jfree.data.time.SerialDate serialDate94 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate92);
        boolean boolean96 = spreadsheetDate78.isInRange(serialDate85, serialDate92, 9999);
        boolean boolean97 = spreadsheetDate58.isOnOrBefore(serialDate92);
        int int98 = spreadsheetDate58.getYYYY();
        boolean boolean99 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 5 + "'", int31 == 5);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 1900 + "'", int98 == 1900);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + true + "'", boolean99 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond10.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, "org.jfree.data.general.SeriesChangeEvent[source=11]", "Nearest", (java.lang.Class) wildcardClass13);
//        java.lang.String str16 = timeSeries15.getRangeDescription();
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190998742L + "'", long12 == 1560190998742L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Nearest" + "'", str16.equals("Nearest"));
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        boolean boolean17 = timeSeries11.getNotify();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190998825L + "'", long9 == 1560190998825L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        timeSeries11.fireSeriesChanged();
//        timeSeries11.setMaximumItemCount(10);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        int int21 = month20.getYearValue();
//        int int23 = month20.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str24 = month20.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        java.lang.Class<?> wildcardClass30 = fixedMillisecond27.getClass();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str24, "", "hi!", (java.lang.Class) wildcardClass30);
//        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
//        java.lang.String str33 = timeSeries31.getDomainDescription();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        int int35 = month34.getYearValue();
//        int int37 = month34.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str38 = month34.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getLastMillisecond(calendar42);
//        java.lang.Class<?> wildcardClass44 = fixedMillisecond41.getClass();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str38, "", "hi!", (java.lang.Class) wildcardClass44);
//        java.lang.String str46 = timeSeries45.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries31.addAndOrUpdate(timeSeries45);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries45.removeChangeListener(seriesChangeListener48);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        boolean boolean52 = year50.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        long long54 = day53.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) year50, (org.jfree.data.time.RegularTimePeriod) day53);
//        int int56 = day53.getYear();
//        java.lang.Number number57 = null;
//        try {
//            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day53, number57, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190998852L + "'", long9 == 1560190998852L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190998854L + "'", long29 == 1560190998854L);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190998855L + "'", long43 == 1560190998855L);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560236399999L + "'", long54 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ', 9, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getFirstMillisecond(calendar5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1900);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate12);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        int int16 = day15.getDayOfMonth();
//        boolean boolean17 = timeSeriesDataItem8.equals((java.lang.Object) int16);
//        java.lang.Number number18 = null;
//        timeSeriesDataItem8.setValue(number18);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190999672L + "'", long2 == 1560190999672L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190999672L + "'", long6 == 1560190999672L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        int int2 = month1.getYearValue();
//        int int4 = month1.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str5 = month1.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str5, "", "hi!", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.util.Date date15 = year14.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        java.util.TimeZone timeZone19 = null;
//        try {
//            org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date15, timeZone19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560190999720L + "'", long10 == 1560190999720L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 1559372400000L);
        boolean boolean4 = year0.equals((java.lang.Object) 1560190976138L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        long long6 = year0.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries25.addChangeListener(seriesChangeListener36);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries25.addChangeListener(seriesChangeListener38);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191000128L + "'", long9 == 1560191000128L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191000129L + "'", long23 == 1560191000129L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        timeSeries11.setMaximumItemAge(0L);
//        java.lang.Class<?> wildcardClass32 = timeSeries11.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191000300L + "'", long9 == 1560191000300L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191000302L + "'", long23 == 1560191000302L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        timeSeries11.setDomainDescription("Nearest");
//        java.lang.String str30 = timeSeries11.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191000355L + "'", long9 == 1560191000355L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191000372L + "'", long23 == 1560191000372L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Last");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(3, serialDate5);
        java.lang.String str9 = serialDate5.getDescription();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(6, serialDate5);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(6);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        long long3 = month2.getSerialIndex();
//        java.lang.Object obj4 = null;
//        int int5 = month2.compareTo(obj4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond7.getFirstMillisecond(calendar11);
//        int int13 = month2.compareTo((java.lang.Object) fixedMillisecond7);
//        int int14 = month2.getYearValue();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        int int16 = month15.getYearValue();
//        int int18 = month15.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str19 = month15.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        java.lang.Class<?> wildcardClass25 = fixedMillisecond22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str19, "", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        int int28 = month2.compareTo((java.lang.Object) timeSeries26);
//        boolean boolean29 = month0.equals((java.lang.Object) month2);
//        java.util.Calendar calendar30 = null;
//        try {
//            long long31 = month2.getLastMillisecond(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191001556L + "'", long24 == 1560191001556L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560190981851L);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190981851L + "'", long2 == 1560190981851L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1560190982405L);
        java.util.Calendar calendar9 = null;
        fixedMillisecond1.peg(calendar9);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getYearValue();
//        int int6 = month3.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str7 = month3.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str7, "", "hi!", (java.lang.Class) wildcardClass13);
//        java.lang.Class<?> wildcardClass15 = timeSeries14.getClass();
//        boolean boolean16 = day0.equals((java.lang.Object) timeSeries14);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries14.createCopy((-1), 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560191001686L + "'", long12 == 1560191001686L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        long long2 = month0.getSerialIndex();
//        java.util.Date date3 = month0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        int int8 = month7.getYearValue();
//        int int10 = month7.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str11 = month7.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
//        java.lang.Class<?> wildcardClass17 = fixedMillisecond14.getClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str11, "", "hi!", (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.util.Date date21 = year20.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date3, timeZone23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getLastMillisecond(calendar29);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize(class32);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "Oct", "", class33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
//        java.lang.Class<?> wildcardClass38 = fixedMillisecond35.getClass();
//        long long39 = fixedMillisecond35.getLastMillisecond();
//        try {
//            timeSeries34.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) 1560190985726L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Millisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560191001722L + "'", long16 == 1560191001722L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560191001724L + "'", long30 == 1560191001724L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560191001725L + "'", long37 == 1560191001725L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560191001725L + "'", long39 == 1560191001725L);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7, (-1), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        long long2 = month0.getSerialIndex();
//        long long3 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        int int9 = day4.compareTo((java.lang.Object) fixedMillisecond6);
//        int int10 = month0.compareTo((java.lang.Object) fixedMillisecond6);
//        long long11 = fixedMillisecond6.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191001769L + "'", long8 == 1560191001769L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560191001769L + "'", long11 == 1560191001769L);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        int int2 = month1.getYearValue();
//        int int4 = month1.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str5 = month1.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str5, "", "hi!", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
//        java.lang.String str27 = timeSeries25.getDomainDescription();
//        timeSeries25.setNotify(false);
//        timeSeries25.fireSeriesChanged();
//        timeSeries25.fireSeriesChanged();
//        java.util.Collection collection32 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries25.getDataItem((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191002613L + "'", long10 == 1560191002613L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191002614L + "'", long23 == 1560191002614L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
//        org.junit.Assert.assertNotNull(collection32);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((-1), serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((-1), serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate10.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate13.getEndOfCurrentMonth(serialDate21);
        boolean boolean23 = spreadsheetDate1.isInRange(serialDate6, serialDate13);
        org.jfree.data.time.SerialDate serialDate25 = serialDate13.getNearestDayOfWeek(5);
        try {
            org.jfree.data.time.SerialDate serialDate27 = serialDate13.getFollowingDayOfWeek((-1093));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((-1), serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((-1), serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate10.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate13.getEndOfCurrentMonth(serialDate21);
        boolean boolean23 = spreadsheetDate1.isInRange(serialDate6, serialDate13);
        java.lang.Object obj24 = null;
        boolean boolean25 = spreadsheetDate1.equals(obj24);
        java.util.Date date26 = spreadsheetDate1.toDate();
        boolean boolean28 = spreadsheetDate1.equals((java.lang.Object) 1560190980310L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((-1), serialDate33);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = serialDate34.getEndOfCurrentMonth(serialDate37);
        java.lang.String str40 = serialDate37.getDescription();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate44);
        boolean boolean48 = spreadsheetDate30.isInRange(serialDate37, serialDate44, 9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addDays((-1), serialDate53);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate57);
        org.jfree.data.time.SerialDate serialDate59 = serialDate54.getEndOfCurrentMonth(serialDate57);
        java.lang.String str60 = serialDate57.getDescription();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate64);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate64);
        boolean boolean68 = spreadsheetDate50.isInRange(serialDate57, serialDate64, 9999);
        boolean boolean69 = spreadsheetDate30.isOnOrBefore(serialDate64);
        int int70 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        java.lang.String str71 = spreadsheetDate30.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNull(str71);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        java.lang.Number number20 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = null;
//        try {
//            timeSeries11.add(timeSeriesDataItem21, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191003015L + "'", long9 == 1560191003015L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(number20);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1964, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1964");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1964, (int) (short) -1, (-29));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        long long31 = month30.getSerialIndex();
//        java.lang.Object obj32 = null;
//        int int33 = month30.compareTo(obj32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.previous();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond35.getFirstMillisecond(calendar37);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getFirstMillisecond(calendar39);
//        int int41 = month30.compareTo((java.lang.Object) fixedMillisecond35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month30.next();
//        int int43 = month30.getMonth();
//        java.lang.Number number44 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) month30);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries25.addPropertyChangeListener(propertyChangeListener45);
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timeSeries25.addPropertyChangeListener(propertyChangeListener47);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191003043L + "'", long9 == 1560191003043L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191003045L + "'", long23 == 1560191003045L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 24234L + "'", long31 == 24234L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(number44);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((-1), serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((-1), serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate10.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate13.getEndOfCurrentMonth(serialDate21);
        boolean boolean23 = spreadsheetDate1.isInRange(serialDate6, serialDate13);
        java.lang.Object obj24 = null;
        boolean boolean25 = spreadsheetDate1.equals(obj24);
        int int26 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.Object obj2 = null;
        int int3 = month0.compareTo(obj2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
        java.util.Calendar calendar12 = null;
        fixedMillisecond5.peg(calendar12);
        long long14 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar15 = null;
        fixedMillisecond5.peg(calendar15);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        java.lang.Object obj2 = null;
//        int int3 = month0.compareTo(obj2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
//        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
//        int int12 = month0.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        int int19 = fixedMillisecond13.compareTo((java.lang.Object) long18);
//        int int20 = month0.compareTo((java.lang.Object) long18);
//        org.jfree.data.time.Year year21 = month0.getYear();
//        java.util.Calendar calendar22 = null;
//        try {
//            month0.peg(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191003281L + "'", long15 == 1560191003281L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191003281L + "'", long18 == 1560191003281L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(year21);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        java.util.Collection collection28 = timeSeries25.getTimePeriods();
//        java.lang.Class class29 = timeSeries25.getTimePeriodClass();
//        timeSeries25.setMaximumItemCount((int) (byte) 1);
//        timeSeries25.setNotify(false);
//        timeSeries25.setNotify(true);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191003295L + "'", long9 == 1560191003295L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191003311L + "'", long23 == 1560191003311L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertNotNull(class29);
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        boolean boolean2 = year0.equals((java.lang.Object) (byte) -1);
//        long long3 = year0.getSerialIndex();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = month4.getYearValue();
//        int int7 = month4.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str8 = month4.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
//        java.lang.Class<?> wildcardClass14 = fixedMillisecond11.getClass();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str8, "", "hi!", (java.lang.Class) wildcardClass14);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.lang.String str17 = timeSeries15.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long20 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.previous();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond19.getMiddleMillisecond(calendar22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) (short) 100);
//        timeSeries15.fireSeriesChanged();
//        boolean boolean27 = timeSeries15.getNotify();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getYearValue();
//        long long30 = month28.getSerialIndex();
//        long long31 = month28.getFirstMillisecond();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        int int33 = day32.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getFirstMillisecond(calendar35);
//        int int37 = day32.compareTo((java.lang.Object) fixedMillisecond34);
//        int int38 = month28.compareTo((java.lang.Object) fixedMillisecond34);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond34.getMiddleMillisecond(calendar39);
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        java.util.List list42 = timeSeries15.getItems();
//        boolean boolean43 = year0.equals((java.lang.Object) timeSeries15);
//        boolean boolean45 = year0.equals((java.lang.Object) 1560190993469L);
//        java.util.Calendar calendar46 = null;
//        try {
//            long long47 = year0.getFirstMillisecond(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560191003450L + "'", long13 == 1560191003450L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24234L + "'", long30 == 24234L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1559372400000L + "'", long31 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560191003454L + "'", long36 == 1560191003454L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560191003454L + "'", long40 == 1560191003454L);
//        org.junit.Assert.assertNotNull(list42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        int int4 = year0.compareTo((java.lang.Object) "June 2019");
        long long5 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.Object obj2 = null;
        int int3 = month0.compareTo(obj2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
        long long12 = month0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        try {
//            timeSeries11.delete(9, 1964);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191004153L + "'", long9 == 1560191004153L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, 1.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        int int4 = year0.compareTo((java.lang.Object) "June 2019");
        int int5 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        int int28 = timeSeries11.getItemCount();
//        timeSeries11.setMaximumItemAge(0L);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries11.getDataItem(1964);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1964, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191004746L + "'", long9 == 1560191004746L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191004748L + "'", long23 == 1560191004748L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        int int4 = year0.compareTo((java.lang.Object) "June 2019");
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        timeSeries11.fireSeriesChanged();
//        timeSeries11.setMaximumItemCount(10);
//        timeSeries11.fireSeriesChanged();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries11.getTimePeriod((-1093));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191004772L + "'", long9 == 1560191004772L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getYearValue();
//        int int5 = month2.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str6 = month2.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        java.lang.Class<?> wildcardClass12 = fixedMillisecond9.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str6, "", "hi!", (java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.util.Date date16 = year15.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date16, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, (java.lang.Class) wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560191004786L + "'", long11 == 1560191004786L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("November 31");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        long long3 = month2.getSerialIndex();
//        java.lang.Object obj4 = null;
//        int int5 = month2.compareTo(obj4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond7.getFirstMillisecond(calendar11);
//        int int13 = month2.compareTo((java.lang.Object) fixedMillisecond7);
//        int int14 = month2.getYearValue();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        int int16 = month15.getYearValue();
//        int int18 = month15.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str19 = month15.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        java.lang.Class<?> wildcardClass25 = fixedMillisecond22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str19, "", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        int int28 = month2.compareTo((java.lang.Object) timeSeries26);
//        boolean boolean29 = month0.equals((java.lang.Object) month2);
//        int int31 = month2.compareTo((java.lang.Object) "3-January-1903");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191004870L + "'", long24 == 1560191004870L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day33);
//        timeSeries35.setMaximumItemCount(0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191006240L + "'", long9 == 1560191006240L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191006242L + "'", long23 == 1560191006242L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        timeSeries11.setMaximumItemAge(0L);
//        timeSeries11.clear();
//        timeSeries11.setKey((java.lang.Comparable) 1560190990598L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191006325L + "'", long9 == 1560191006325L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191006327L + "'", long23 == 1560191006327L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        java.util.Collection collection28 = timeSeries25.getTimePeriods();
//        timeSeries25.setDescription("");
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        int int32 = month31.getYearValue();
//        int int34 = month31.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str35 = month31.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        java.lang.Class<?> wildcardClass41 = fixedMillisecond38.getClass();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str35, "", "hi!", (java.lang.Class) wildcardClass41);
//        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
//        java.lang.String str44 = timeSeries42.getDomainDescription();
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        int int46 = month45.getYearValue();
//        int int48 = month45.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str49 = month45.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond52.getLastMillisecond(calendar53);
//        java.lang.Class<?> wildcardClass55 = fixedMillisecond52.getClass();
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str49, "", "hi!", (java.lang.Class) wildcardClass55);
//        java.lang.String str57 = timeSeries56.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries42.addAndOrUpdate(timeSeries56);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
//        timeSeries56.removeChangeListener(seriesChangeListener59);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        boolean boolean63 = year61.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        long long65 = day64.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) year61, (org.jfree.data.time.RegularTimePeriod) day64);
//        int int67 = day64.getYear();
//        int int68 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) day64);
//        int int69 = day64.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191006600L + "'", long9 == 1560191006600L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191006601L + "'", long23 == 1560191006601L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "June 2019" + "'", str35.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560191006604L + "'", long40 == 1560191006604L);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "June 2019" + "'", str49.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560191006605L + "'", long54 == 1560191006605L);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560236399999L + "'", long65 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2019 + "'", int67 == 2019);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getFirstMillisecond(calendar5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1900);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond0.getMiddleMillisecond(calendar9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191006787L + "'", long2 == 1560191006787L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560191006787L + "'", long6 == 1560191006787L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191006787L + "'", long10 == 1560191006787L);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        long long8 = day6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.previous();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1099L + "'", long8 == 1099L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 100);
//        timeSeries11.fireSeriesChanged();
//        boolean boolean23 = timeSeries11.getNotify();
//        try {
//            java.lang.Number number25 = timeSeries11.getValue((int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191006867L + "'", long9 == 1560191006867L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setMaximumItemAge(1560190970939L);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener15);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191006900L + "'", long9 == 1560191006900L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        java.lang.Object obj2 = null;
//        int int3 = month0.compareTo(obj2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
//        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
//        int int12 = month0.getYearValue();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int14 = month13.getYearValue();
//        int int16 = month13.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str17 = month13.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
//        java.lang.Class<?> wildcardClass23 = fixedMillisecond20.getClass();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str17, "", "hi!", (java.lang.Class) wildcardClass23);
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        int int26 = month0.compareTo((java.lang.Object) timeSeries24);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        int int28 = month27.getYearValue();
//        long long29 = month27.getSerialIndex();
//        java.util.Date date30 = month27.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
//        try {
//            timeSeries24.add((org.jfree.data.time.RegularTimePeriod) year32, (double) 1560190999072L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560191006988L + "'", long22 == 1560191006988L);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setMaximumItemAge(1560190970939L);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getSerialIndex();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 1560190978666L);
//        java.lang.Class class20 = timeSeries11.getTimePeriodClass();
//        java.lang.Class class21 = timeSeries11.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond22.peg(calendar25);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond22.getFirstMillisecond(calendar27);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1900);
//        try {
//            timeSeries11.add(timeSeriesDataItem30, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period Mon Jun 10 11:23:27 PDT 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191007181L + "'", long9 == 1560191007181L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191007183L + "'", long24 == 1560191007183L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560191007183L + "'", long28 == 1560191007183L);
//    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        timeSeries11.fireSeriesChanged();
//        java.lang.String str18 = timeSeries11.getDescription();
//        timeSeries11.setDescription("");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        int int22 = month21.getYearValue();
//        int int24 = month21.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str25 = month21.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getLastMillisecond(calendar29);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str25, "", "hi!", (java.lang.Class) wildcardClass31);
//        java.lang.String str33 = timeSeries32.getDomainDescription();
//        java.lang.Object obj34 = timeSeries32.clone();
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries32.removePropertyChangeListener(propertyChangeListener35);
//        java.lang.Object obj37 = timeSeries32.clone();
//        boolean boolean38 = timeSeries32.isEmpty();
//        timeSeries32.setKey((java.lang.Comparable) 1560190971349L);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries11.addAndOrUpdate(timeSeries32);
//        try {
//            timeSeries11.update((-459), (java.lang.Number) 1560190975199L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191007202L + "'", long9 == 1560191007202L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560191007210L + "'", long30 == 1560191007210L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(timeSeries41);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(3, serialDate8);
        java.lang.String str12 = serialDate8.getDescription();
        int int13 = spreadsheetDate2.compare(serialDate8);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays((-1), serialDate16);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = serialDate17.getEndOfCurrentMonth(serialDate20);
        java.lang.String str23 = serialDate20.getDescription();
        boolean boolean24 = spreadsheetDate2.isOnOrBefore(serialDate20);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-29) + "'", int13 == (-29));
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
//        timeSeries11.delete(regularTimePeriod30);
//        timeSeries11.fireSeriesChanged();
//        java.lang.Class class33 = timeSeries11.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191007256L + "'", long9 == 1560191007256L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191007258L + "'", long23 == 1560191007258L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(class33);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560190981851L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560190981851L + "'", long3 == 1560190981851L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code." + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((-1), serialDate4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate8.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate8);
        java.lang.String str19 = serialDate18.toString();
        try {
            org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1-February-1900" + "'", str19.equals("1-February-1900"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        long long8 = day6.getSerialIndex();
        java.util.Date date9 = day6.getEnd();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1099L + "'", long8 == 1099L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        java.util.Date date10 = fixedMillisecond1.getStart();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        long long2 = month0.getSerialIndex();
//        long long3 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        int int9 = day4.compareTo((java.lang.Object) fixedMillisecond6);
//        int int10 = month0.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond6.getMiddleMillisecond(calendar11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond6.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
//        java.lang.Class<?> wildcardClass20 = fixedMillisecond17.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "1-February-1900", "", class21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond6, class21);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191007548L + "'", long8 == 1560191007548L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560191007548L + "'", long12 == 1560191007548L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560191007549L + "'", long19 == 1560191007549L);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560190989001L, "November 31", "3-January-1903", class3);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        int int28 = timeSeries11.getItemCount();
//        try {
//            timeSeries11.removeAgedItems(1560191000128L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191007791L + "'", long9 == 1560191007791L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191007808L + "'", long23 == 1560191007808L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Oct");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener14);
//        java.lang.Object obj16 = timeSeries11.clone();
//        java.util.List list17 = timeSeries11.getItems();
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener18);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries11.addChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getYear();
//        long long24 = day22.getLastMillisecond();
//        try {
//            timeSeries11.update((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 1560190975091L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191008153L + "'", long9 == 1560191008153L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertNotNull(list17);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month1, (java.lang.Number) 1560190974098L);
        java.lang.Object obj4 = timeSeriesDataItem3.clone();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        boolean boolean9 = timeSeriesDataItem3.equals((java.lang.Object) day8);
        java.lang.Number number10 = timeSeriesDataItem3.getValue();
        java.lang.Object obj11 = timeSeriesDataItem3.clone();
        boolean boolean13 = timeSeriesDataItem3.equals((java.lang.Object) "Nearest");
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1560190974098L + "'", number10.equals(1560190974098L));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setMaximumItemAge(1560190970939L);
//        java.util.Collection collection15 = timeSeries11.getTimePeriods();
//        try {
//            timeSeries11.update((int) '4', (java.lang.Number) 1560190981851L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191008227L + "'", long9 == 1560191008227L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(collection15);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2019, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("1-February-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setMaximumItemAge(1560190970939L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.TimeSeries timeSeries17 = null;
//        try {
//            java.util.Collection collection18 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191008284L + "'", long9 == 1560191008284L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        long long2 = month0.getSerialIndex();
//        long long3 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        int int9 = day4.compareTo((java.lang.Object) fixedMillisecond6);
//        int int10 = month0.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = month0.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191009139L + "'", long8 == 1560191009139L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((-1), serialDate4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate8.getEndOfCurrentMonth(serialDate16);
        boolean boolean18 = spreadsheetDate1.isOnOrBefore(serialDate17);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        java.util.Date date15 = day13.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
//        java.util.Calendar calendar18 = null;
//        try {
//            day13.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191009449L + "'", long9 == 1560191009449L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        long long10 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day33);
//        java.lang.String str36 = year30.toString();
//        long long37 = year30.getSerialIndex();
//        long long38 = year30.getMiddleMillisecond();
//        long long39 = year30.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191009495L + "'", long9 == 1560191009495L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191009497L + "'", long23 == 1560191009497L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1562097599999L + "'", long38 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        timeSeries11.fireSeriesChanged();
//        timeSeries11.setMaximumItemCount(10);
//        timeSeries11.fireSeriesChanged();
//        java.lang.Object obj21 = null;
//        boolean boolean22 = timeSeries11.equals(obj21);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191009601L + "'", long9 == 1560191009601L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        long long2 = month0.getSerialIndex();
//        java.util.Date date3 = month0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        int int8 = month7.getYearValue();
//        int int10 = month7.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str11 = month7.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
//        java.lang.Class<?> wildcardClass17 = fixedMillisecond14.getClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str11, "", "hi!", (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.util.Date date21 = year20.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date3, timeZone23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getLastMillisecond(calendar29);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize(class32);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "Oct", "", class33);
//        java.lang.String str35 = day25.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560191010330L + "'", long16 == 1560191010330L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560191010332L + "'", long30 == 1560191010332L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "30-June-2019" + "'", str35.equals("30-June-2019"));
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        timeSeries11.setNotify(false);
//        java.lang.String str16 = timeSeries11.getRangeDescription();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        int int18 = month17.getYearValue();
//        int int20 = month17.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str21 = month17.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        java.lang.Class<?> wildcardClass27 = fixedMillisecond24.getClass();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str21, "", "hi!", (java.lang.Class) wildcardClass27);
//        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
//        timeSeries28.setRangeDescription("June 2019");
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries11.addAndOrUpdate(timeSeries28);
//        timeSeries11.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191010469L + "'", long9 == 1560191010469L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560191010472L + "'", long26 == 1560191010472L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(timeSeries32);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        int int2 = month1.getYearValue();
//        int int4 = month1.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str5 = month1.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str5, "", "hi!", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.util.Date date15 = year14.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        int int20 = month19.getYearValue();
//        int int22 = month19.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str23 = month19.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
//        java.lang.Class<?> wildcardClass29 = fixedMillisecond26.getClass();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str23, "", "hi!", (java.lang.Class) wildcardClass29);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        java.lang.String str32 = timeSeries30.getDomainDescription();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        int int34 = month33.getYearValue();
//        int int36 = month33.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str37 = month33.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getLastMillisecond(calendar41);
//        java.lang.Class<?> wildcardClass43 = fixedMillisecond40.getClass();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str37, "", "hi!", (java.lang.Class) wildcardClass43);
//        java.lang.String str45 = timeSeries44.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries30.addAndOrUpdate(timeSeries44);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
//        timeSeries44.removeChangeListener(seriesChangeListener47);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
//        boolean boolean51 = year49.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        long long53 = day52.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) year49, (org.jfree.data.time.RegularTimePeriod) day52);
//        java.lang.String str55 = day52.toString();
//        java.util.Date date56 = day52.getStart();
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
//        int int59 = month58.getYearValue();
//        int int61 = month58.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str62 = month58.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar66 = null;
//        long long67 = fixedMillisecond65.getLastMillisecond(calendar66);
//        java.lang.Class<?> wildcardClass68 = fixedMillisecond65.getClass();
//        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str62, "", "hi!", (java.lang.Class) wildcardClass68);
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass68);
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
//        java.util.Date date72 = year71.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond(date72);
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date72, timeZone74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date56, timeZone74);
//        java.lang.Class class77 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191012133L + "'", long10 == 1560191012133L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560191012135L + "'", long28 == 1560191012135L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560191012152L + "'", long42 == 1560191012152L);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560236399999L + "'", long53 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10-June-2019" + "'", str55.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "June 2019" + "'", str62.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560191012156L + "'", long67 == 1560191012156L);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(class77);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.util.Date date2 = day0.getEnd();
//        int int3 = day0.getYear();
//        boolean boolean5 = day0.equals((java.lang.Object) 1560190989941L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-1093), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((-1), serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = serialDate7.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate7);
        java.lang.String str18 = serialDate7.getDescription();
        java.lang.String str19 = serialDate7.getDescription();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(str19);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        java.lang.Number number20 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        long long21 = fixedMillisecond18.getMiddleMillisecond();
//        long long22 = fixedMillisecond18.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191012845L + "'", long9 == 1560191012845L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setMaximumItemAge(1560190970939L);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getSerialIndex();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 1560190978666L);
//        boolean boolean20 = timeSeries11.isEmpty();
//        java.lang.Object obj21 = timeSeries11.clone();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191012874L + "'", long9 == 1560191012874L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(obj21);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 100);
//        timeSeries11.fireSeriesChanged();
//        boolean boolean23 = timeSeries11.getNotify();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        int int25 = month24.getYearValue();
//        long long26 = month24.getSerialIndex();
//        long long27 = month24.getFirstMillisecond();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getFirstMillisecond(calendar31);
//        int int33 = day28.compareTo((java.lang.Object) fixedMillisecond30);
//        int int34 = month24.compareTo((java.lang.Object) fixedMillisecond30);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond30.getMiddleMillisecond(calendar35);
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        int int39 = month38.getYearValue();
//        long long40 = month38.getSerialIndex();
//        java.util.Date date41 = month38.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date41, timeZone42);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        int int45 = month44.getYearValue();
//        int int47 = month44.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str48 = month44.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar52 = null;
//        long long53 = fixedMillisecond51.getLastMillisecond(calendar52);
//        java.lang.Class<?> wildcardClass54 = fixedMillisecond51.getClass();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str48, "", "hi!", (java.lang.Class) wildcardClass54);
//        java.lang.Class class56 = timeSeries55.getTimePeriodClass();
//        java.lang.String str57 = timeSeries55.getDomainDescription();
//        java.util.Collection collection58 = timeSeries55.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
//        timeSeries55.addChangeListener(seriesChangeListener59);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        java.util.Date date62 = year61.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(date62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond63.previous();
//        int int65 = timeSeries55.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
//        boolean boolean66 = year43.equals((java.lang.Object) timeSeries55);
//        long long67 = year43.getMiddleMillisecond();
//        try {
//            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 1560190990674L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191012968L + "'", long9 == 1560191012968L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 24234L + "'", long26 == 24234L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560191012972L + "'", long32 == 1560191012972L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560191012972L + "'", long36 == 1560191012972L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 24234L + "'", long40 == 24234L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "June 2019" + "'", str48.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560191012974L + "'", long53 == 1560191012974L);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
//        org.junit.Assert.assertNotNull(collection58);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1562097599999L + "'", long67 == 1562097599999L);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
        int int5 = spreadsheetDate4.getDayOfMonth();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean8 = spreadsheetDate4.equals((java.lang.Object) (short) 10);
        int int9 = spreadsheetDate4.getYYYY();
        try {
            int int11 = spreadsheetDate4.compareTo((java.lang.Object) 1560191001048L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1560190976483L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((-1), serialDate4);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate8);
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
//        java.lang.String str11 = serialDate8.getDescription();
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate15);
//        boolean boolean19 = spreadsheetDate1.isInRange(serialDate8, serialDate15, 9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
//        java.lang.Class<?> wildcardClass26 = fixedMillisecond23.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "1-February-1900", "", class27);
//        boolean boolean29 = spreadsheetDate1.equals((java.lang.Object) timeSeries28);
//        try {
//            org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate1.getFollowingDayOfWeek((-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560191013133L + "'", long25 == 1560191013133L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560190979577L);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setRangeDescription("June 2019");
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries11.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191013154L + "'", long9 == 1560191013154L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=11]");
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
        int int5 = spreadsheetDate4.getDayOfMonth();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((-1), serialDate10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = serialDate11.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate20);
        org.jfree.data.time.SerialDate serialDate23 = serialDate14.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate14);
        java.lang.String str25 = serialDate24.toString();
        boolean boolean26 = spreadsheetDate4.isOnOrAfter(serialDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(6);
        int int32 = spreadsheetDate31.getDayOfMonth();
        boolean boolean33 = spreadsheetDate28.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays((-1), serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = serialDate38.getEndOfCurrentMonth(serialDate41);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate47);
        org.jfree.data.time.SerialDate serialDate50 = serialDate41.getEndOfCurrentMonth(serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate41);
        java.lang.String str52 = serialDate51.toString();
        boolean boolean53 = spreadsheetDate31.isOnOrAfter(serialDate51);
        boolean boolean54 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        try {
            int int56 = spreadsheetDate31.compareTo((java.lang.Object) 1560190989737L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1-February-1900" + "'", str25.equals("1-February-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1-February-1900" + "'", str52.equals("1-February-1900"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day33);
//        java.lang.String str36 = day33.toString();
//        java.util.Calendar calendar37 = null;
//        try {
//            long long38 = day33.getFirstMillisecond(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191013410L + "'", long9 == 1560191013410L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191013412L + "'", long23 == 1560191013412L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((-1), serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1964, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Oct");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(3, serialDate7);
        java.lang.String str11 = serialDate7.getDescription();
        int int12 = spreadsheetDate1.compare(serialDate7);
        int int13 = spreadsheetDate1.getDayOfWeek();
        int int14 = spreadsheetDate1.getMonth();
        spreadsheetDate1.setDescription("org.jfree.data.time.TimePeriodFormatException: June 2019");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-29) + "'", int12 == (-29));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getYearValue();
//        int int6 = month3.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str7 = month3.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str7, "", "hi!", (java.lang.Class) wildcardClass13);
//        java.lang.Class<?> wildcardClass15 = timeSeries14.getClass();
//        boolean boolean16 = day0.equals((java.lang.Object) timeSeries14);
//        long long17 = day0.getFirstMillisecond();
//        int int18 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560191013525L + "'", long12 == 1560191013525L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long19 = fixedMillisecond18.getMiddleMillisecond();
//        java.lang.Number number20 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        try {
//            timeSeries11.delete(4, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191013548L + "'", long9 == 1560191013548L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(number20);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        java.lang.Object obj2 = null;
//        int int3 = month0.compareTo(obj2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
//        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
//        int int12 = month0.getYearValue();
//        long long13 = month0.getLastMillisecond();
//        int int14 = month0.getYearValue();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        int int16 = month15.getYearValue();
//        int int18 = month15.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str19 = month15.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        java.lang.Class<?> wildcardClass25 = fixedMillisecond22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str19, "", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.String str27 = timeSeries26.getDomainDescription();
//        java.lang.Object obj28 = timeSeries26.clone();
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries26.removePropertyChangeListener(propertyChangeListener29);
//        java.lang.Object obj31 = timeSeries26.clone();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        int int33 = month32.getYearValue();
//        int int35 = month32.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str36 = month32.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getLastMillisecond(calendar40);
//        java.lang.Class<?> wildcardClass42 = fixedMillisecond39.getClass();
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str36, "", "hi!", (java.lang.Class) wildcardClass42);
//        java.lang.Class class44 = timeSeries43.getTimePeriodClass();
//        java.lang.String str45 = timeSeries43.getDomainDescription();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        int int47 = month46.getYearValue();
//        int int49 = month46.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str50 = month46.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond53.getLastMillisecond(calendar54);
//        java.lang.Class<?> wildcardClass56 = fixedMillisecond53.getClass();
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str50, "", "hi!", (java.lang.Class) wildcardClass56);
//        java.lang.String str58 = timeSeries57.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries43.addAndOrUpdate(timeSeries57);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener60 = null;
//        timeSeries43.removeChangeListener(seriesChangeListener60);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month();
//        java.lang.Object obj63 = null;
//        int int64 = month62.compareTo(obj63);
//        java.lang.String str65 = month62.toString();
//        java.lang.Number number66 = timeSeries43.getValue((org.jfree.data.time.RegularTimePeriod) month62);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) month62);
//        boolean boolean68 = month0.equals((java.lang.Object) timeSeries26);
//        java.util.Calendar calendar69 = null;
//        try {
//            long long70 = month0.getFirstMillisecond(calendar69);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191013579L + "'", long24 == 1560191013579L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560191013582L + "'", long41 == 1560191013582L);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560191013583L + "'", long55 == 1560191013583L);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "" + "'", str58.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "June 2019" + "'", str65.equals("June 2019"));
//        org.junit.Assert.assertNull(number66);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        java.lang.String str8 = regularTimePeriod7.toString();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4-January-1903" + "'", str8.equals("4-January-1903"));
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate7);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(3, serialDate7);
//        java.lang.String str11 = serialDate7.getDescription();
//        int int12 = spreadsheetDate1.compare(serialDate7);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays((-1), serialDate15);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate19);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate16.getEndOfCurrentMonth(serialDate19);
//        java.lang.String str22 = serialDate19.getDescription();
//        boolean boolean23 = spreadsheetDate1.isOnOrBefore(serialDate19);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate27);
//        boolean boolean30 = spreadsheetDate1.isOnOrAfter(serialDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays((-1), serialDate35);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate36.getNearestDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays((-1), serialDate43);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate47);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate44.getEndOfCurrentMonth(serialDate47);
//        java.lang.String str50 = serialDate47.getDescription();
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate54);
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate54);
//        boolean boolean58 = spreadsheetDate40.isInRange(serialDate47, serialDate54, 9999);
//        boolean boolean59 = spreadsheetDate32.isInRange(serialDate38, serialDate47);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        int int61 = month60.getYearValue();
//        long long62 = month60.getSerialIndex();
//        java.util.Date date63 = month60.getEnd();
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date63, timeZone64);
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
//        int int68 = month67.getYearValue();
//        int int70 = month67.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str71 = month67.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar75 = null;
//        long long76 = fixedMillisecond74.getLastMillisecond(calendar75);
//        java.lang.Class<?> wildcardClass77 = fixedMillisecond74.getClass();
//        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str71, "", "hi!", (java.lang.Class) wildcardClass77);
//        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass77);
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year();
//        java.util.Date date81 = year80.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond(date81);
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date81, timeZone83);
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date63, timeZone83);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond88 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar89 = null;
//        long long90 = fixedMillisecond88.getLastMillisecond(calendar89);
//        java.lang.Class<?> wildcardClass91 = fixedMillisecond88.getClass();
//        java.lang.Class class92 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass91);
//        java.lang.Class class93 = org.jfree.data.time.RegularTimePeriod.downsize(class92);
//        org.jfree.data.time.TimeSeries timeSeries94 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day85, "Oct", "", class93);
//        boolean boolean95 = spreadsheetDate32.equals((java.lang.Object) "");
//        boolean boolean96 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
//        org.jfree.data.time.SerialDate serialDate97 = null;
//        try {
//            boolean boolean98 = spreadsheetDate32.isOn(serialDate97);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-29) + "'", int12 == (-29));
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNull(str50);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 24234L + "'", long62 == 24234L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "June 2019" + "'", str71.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560191013640L + "'", long76 == 1560191013640L);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560191013641L + "'", long90 == 1560191013641L);
//        org.junit.Assert.assertNotNull(wildcardClass91);
//        org.junit.Assert.assertNotNull(class92);
//        org.junit.Assert.assertNotNull(class93);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.util.Date date18 = year17.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
//        int int21 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        int int22 = timeSeries11.getItemCount();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191013674L + "'", long9 == 1560191013674L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        java.lang.Object obj2 = null;
//        int int3 = month0.compareTo(obj2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
//        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
//        int int12 = month0.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        int int19 = fixedMillisecond13.compareTo((java.lang.Object) long18);
//        int int20 = month0.compareTo((java.lang.Object) long18);
//        org.jfree.data.time.Year year21 = month0.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, 0.0d);
//        int int24 = month0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191013723L + "'", long15 == 1560191013723L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191013723L + "'", long18 == 1560191013723L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener14);
//        java.lang.Object obj16 = timeSeries11.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond17.peg(calendar20);
//        java.lang.Number number22 = null;
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, number22);
//        boolean boolean24 = timeSeries11.isEmpty();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191013753L + "'", long9 == 1560191013753L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560191013755L + "'", long19 == 1560191013755L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        java.util.Collection collection28 = timeSeries25.getTimePeriods();
//        java.lang.Class class29 = timeSeries25.getTimePeriodClass();
//        timeSeries25.setMaximumItemCount((int) (byte) 1);
//        boolean boolean33 = timeSeries25.equals((java.lang.Object) 1560190983400L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener34);
//        boolean boolean36 = timeSeries25.getNotify();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191013961L + "'", long9 == 1560191013961L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191013963L + "'", long23 == 1560191013963L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        int int28 = timeSeries11.getItemCount();
//        timeSeries11.setMaximumItemAge(0L);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        int int32 = month31.getYearValue();
//        int int34 = month31.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str35 = month31.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        java.lang.Class<?> wildcardClass41 = fixedMillisecond38.getClass();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str35, "", "hi!", (java.lang.Class) wildcardClass41);
//        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
//        java.lang.String str44 = timeSeries42.getDomainDescription();
//        java.util.Collection collection45 = timeSeries42.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
//        timeSeries42.addChangeListener(seriesChangeListener46);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long50 = fixedMillisecond49.getMiddleMillisecond();
//        java.lang.Number number51 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        long long52 = fixedMillisecond49.getMiddleMillisecond();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191014016L + "'", long9 == 1560191014016L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191014017L + "'", long23 == 1560191014017L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "June 2019" + "'", str35.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560191014019L + "'", long40 == 1560191014019L);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1L + "'", long50 == 1L);
//        org.junit.Assert.assertNull(number51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getYearValue();
//        int int6 = month3.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str7 = month3.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str7, "", "hi!", (java.lang.Class) wildcardClass13);
//        java.lang.Class<?> wildcardClass15 = timeSeries14.getClass();
//        boolean boolean16 = day0.equals((java.lang.Object) timeSeries14);
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = day0.getFirstMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560191014137L + "'", long12 == 1560191014137L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        int int7 = month6.getYearValue();
//        int int9 = month6.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str10 = month6.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        java.lang.Class<?> wildcardClass16 = fixedMillisecond13.getClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str10, "", "hi!", (java.lang.Class) wildcardClass16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.util.Date date20 = year19.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date20, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date3, timeZone22);
//        java.util.Calendar calendar25 = null;
//        try {
//            long long26 = year24.getLastMillisecond(calendar25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191014152L + "'", long15 == 1560191014152L);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        long long2 = month0.getSerialIndex();
//        long long3 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = day4.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        int int9 = day4.compareTo((java.lang.Object) fixedMillisecond6);
//        int int10 = month0.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = month0.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191014166L + "'", long8 == 1560191014166L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getLastMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getDayOfMonth();
        int int8 = day6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2114092800001L) + "'", long10 == (-2114092800001L));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((-1), serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((-1), serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate10.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate13.getEndOfCurrentMonth(serialDate21);
        boolean boolean23 = spreadsheetDate1.isInRange(serialDate6, serialDate13);
        java.lang.Object obj24 = null;
        boolean boolean25 = spreadsheetDate1.equals(obj24);
        java.util.Date date26 = spreadsheetDate1.toDate();
        int int27 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate28 = null;
        try {
            boolean boolean29 = spreadsheetDate1.isAfter(serialDate28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        java.util.Collection collection28 = timeSeries25.getTimePeriods();
//        java.lang.Class class29 = timeSeries25.getTimePeriodClass();
//        boolean boolean31 = timeSeries25.equals((java.lang.Object) 1560191003045L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191014396L + "'", long9 == 1560191014396L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191014398L + "'", long23 == 1560191014398L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        int int28 = timeSeries11.getItemCount();
//        try {
//            timeSeries11.update((int) (byte) 10, (java.lang.Number) 1560190992246L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191014444L + "'", long9 == 1560191014444L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191014461L + "'", long23 == 1560191014461L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-29));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-467) + "'", int1 == (-467));
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class<?> wildcardClass12 = timeSeries11.getClass();
//        long long13 = timeSeries11.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191014481L + "'", long9 == 1560191014481L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 43626L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        boolean boolean3 = timeSeries1.equals((java.lang.Object) 1560190994398L);
        org.jfree.data.time.TimeSeries timeSeries4 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.addAndOrUpdate(timeSeries4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setMaximumItemAge(1560190970939L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        boolean boolean17 = timeSeries11.isEmpty();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191014617L + "'", long9 == 1560191014617L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (-29));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries25.addChangeListener(seriesChangeListener36);
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries25.removePropertyChangeListener(propertyChangeListener38);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191014833L + "'", long9 == 1560191014833L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191014835L + "'", long23 == 1560191014835L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Object obj1 = null;
        int int2 = month0.compareTo(obj1);
        java.lang.String str3 = month0.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        java.lang.Object obj2 = null;
//        int int3 = month0.compareTo(obj2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
//        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
//        int int12 = month0.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        int int19 = fixedMillisecond13.compareTo((java.lang.Object) long18);
//        int int20 = month0.compareTo((java.lang.Object) long18);
//        org.jfree.data.time.Year year21 = month0.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, 0.0d);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        java.util.Date date25 = year24.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        int int31 = month30.getYearValue();
//        int int33 = month30.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str34 = month30.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getLastMillisecond(calendar38);
//        java.lang.Class<?> wildcardClass40 = fixedMillisecond37.getClass();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str34, "", "hi!", (java.lang.Class) wildcardClass40);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass40);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        java.util.Date date44 = year43.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date44, timeZone46);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
//        java.util.Date date49 = year48.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        int int54 = month53.getYearValue();
//        int int56 = month53.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str57 = month53.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond60.getLastMillisecond(calendar61);
//        java.lang.Class<?> wildcardClass63 = fixedMillisecond60.getClass();
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str57, "", "hi!", (java.lang.Class) wildcardClass63);
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass63);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
//        java.util.Date date67 = year66.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond(date67);
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date67, timeZone69);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date49, timeZone69);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date25, timeZone69);
//        int int73 = timeSeriesDataItem23.compareTo((java.lang.Object) day72);
//        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
//        int int77 = month76.getYearValue();
//        int int79 = month76.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str80 = month76.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar84 = null;
//        long long85 = fixedMillisecond83.getLastMillisecond(calendar84);
//        java.lang.Class<?> wildcardClass86 = fixedMillisecond83.getClass();
//        org.jfree.data.time.TimeSeries timeSeries87 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str80, "", "hi!", (java.lang.Class) wildcardClass86);
//        java.lang.Class class88 = timeSeries87.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries89 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day72, "Preceding", "org.jfree.data.general.SeriesChangeEvent[source=11]", class88);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191014904L + "'", long15 == 1560191014904L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191014905L + "'", long18 == 1560191014905L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "June 2019" + "'", str34.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560191014908L + "'", long39 == 1560191014908L);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "June 2019" + "'", str57.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560191014926L + "'", long62 == 1560191014926L);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 2019 + "'", int77 == 2019);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "June 2019" + "'", str80.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560191014929L + "'", long85 == 1560191014929L);
//        org.junit.Assert.assertNotNull(wildcardClass86);
//        org.junit.Assert.assertNotNull(class88);
//    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        int int2 = month1.getYearValue();
//        int int4 = month1.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str5 = month1.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str5, "", "hi!", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        long long16 = month14.getSerialIndex();
//        long long17 = month14.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month14.previous();
//        try {
//            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1560190976754L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191016011L + "'", long10 == 1560191016011L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        java.lang.Object obj2 = null;
//        int int3 = month0.compareTo(obj2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
//        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
//        int int12 = month0.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        int int19 = fixedMillisecond13.compareTo((java.lang.Object) long18);
//        int int20 = month0.compareTo((java.lang.Object) long18);
//        org.jfree.data.time.Year year21 = month0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191016042L + "'", long15 == 1560191016042L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191016042L + "'", long18 == 1560191016042L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: June 2019" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: June 2019"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560190985898L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-29));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-29) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8, 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
//        long long6 = fixedMillisecond1.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond1.getFirstMillisecond(calendar7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        int int10 = month9.getYearValue();
//        int int12 = month9.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str13 = month9.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        java.lang.Class<?> wildcardClass19 = fixedMillisecond16.getClass();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str13, "", "hi!", (java.lang.Class) wildcardClass19);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        java.lang.Object obj22 = timeSeries20.clone();
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries20.removePropertyChangeListener(propertyChangeListener23);
//        java.lang.Object obj25 = timeSeries20.clone();
//        java.util.List list26 = timeSeries20.getItems();
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries20.removePropertyChangeListener(propertyChangeListener27);
//        boolean boolean29 = fixedMillisecond1.equals((java.lang.Object) propertyChangeListener27);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191016791L + "'", long18 == 1560191016791L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertNotNull(list26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((-1), serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((-1), serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = serialDate14.getEndOfCurrentMonth(serialDate17);
        java.lang.String str20 = serialDate17.getDescription();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate24);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate24);
        boolean boolean28 = spreadsheetDate10.isInRange(serialDate17, serialDate24, 9999);
        boolean boolean29 = spreadsheetDate2.isInRange(serialDate8, serialDate17);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays((-1), serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate2.getEndOfCurrentMonth(serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addMonths(7, serialDate33);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        timeSeries11.fireSeriesChanged();
//        java.lang.String str18 = timeSeries11.getDescription();
//        timeSeries11.setDescription("");
//        timeSeries11.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        int int25 = month24.getYearValue();
//        int int27 = month24.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str28 = month24.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
//        java.lang.Class<?> wildcardClass34 = fixedMillisecond31.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str28, "", "hi!", (java.lang.Class) wildcardClass34);
//        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
//        java.lang.String str37 = timeSeries35.getDomainDescription();
//        java.util.Collection collection38 = timeSeries35.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries35.addChangeListener(seriesChangeListener39);
//        timeSeries35.fireSeriesChanged();
//        java.lang.String str42 = timeSeries35.getDescription();
//        timeSeries35.setDescription("");
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        int int46 = month45.getYearValue();
//        int int48 = month45.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str49 = month45.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond52.getLastMillisecond(calendar53);
//        java.lang.Class<?> wildcardClass55 = fixedMillisecond52.getClass();
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str49, "", "hi!", (java.lang.Class) wildcardClass55);
//        java.lang.String str57 = timeSeries56.getDomainDescription();
//        java.lang.Object obj58 = timeSeries56.clone();
//        java.beans.PropertyChangeListener propertyChangeListener59 = null;
//        timeSeries56.removePropertyChangeListener(propertyChangeListener59);
//        java.lang.Object obj61 = timeSeries56.clone();
//        boolean boolean62 = timeSeries56.isEmpty();
//        timeSeries56.setKey((java.lang.Comparable) 1560190971349L);
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries35.addAndOrUpdate(timeSeries56);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries11.addAndOrUpdate(timeSeries35);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191017011L + "'", long9 == 1560191017011L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560191017029L + "'", long33 == 1560191017029L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertNull(str42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "June 2019" + "'", str49.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560191017032L + "'", long54 == 1560191017032L);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNotNull(timeSeries66);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day33);
//        timeSeries25.setRangeDescription("May");
//        timeSeries25.clear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191017278L + "'", long9 == 1560191017278L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191017280L + "'", long23 == 1560191017280L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.lang.Class<?> wildcardClass3 = fixedMillisecond0.getClass();
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191017337L + "'", long2 == 1560191017337L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191017337L + "'", long4 == 1560191017337L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        boolean boolean10 = spreadsheetDate1.isAfter(serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = null;
        try {
            int int12 = spreadsheetDate1.compare(serialDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9, 9999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(31);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: June 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((-1), serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((-1), serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate10.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate13.getEndOfCurrentMonth(serialDate21);
        boolean boolean23 = spreadsheetDate1.isInRange(serialDate6, serialDate13);
        java.lang.Object obj24 = null;
        boolean boolean25 = spreadsheetDate1.equals(obj24);
        java.util.Date date26 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getYearValue();
        long long29 = month27.getSerialIndex();
        java.util.Date date30 = month27.getEnd();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date26, timeZone31);
        java.util.Calendar calendar34 = null;
        try {
            long long35 = month33.getLastMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        timeSeries11.fireSeriesChanged();
//        java.lang.String str18 = timeSeries11.getDescription();
//        timeSeries11.setDescription("");
//        timeSeries11.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        int int25 = month24.getYearValue();
//        int int27 = month24.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str28 = month24.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
//        java.lang.Class<?> wildcardClass34 = fixedMillisecond31.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str28, "", "hi!", (java.lang.Class) wildcardClass34);
//        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
//        java.lang.String str37 = timeSeries35.getDomainDescription();
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        int int39 = month38.getYearValue();
//        int int41 = month38.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str42 = month38.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond45.getLastMillisecond(calendar46);
//        java.lang.Class<?> wildcardClass48 = fixedMillisecond45.getClass();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str42, "", "hi!", (java.lang.Class) wildcardClass48);
//        java.lang.String str50 = timeSeries49.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries35.addAndOrUpdate(timeSeries49);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        long long53 = month52.getSerialIndex();
//        java.lang.Object obj54 = null;
//        int int55 = month52.compareTo(obj54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond57.previous();
//        java.util.Calendar calendar59 = null;
//        long long60 = fixedMillisecond57.getFirstMillisecond(calendar59);
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond57.getFirstMillisecond(calendar61);
//        int int63 = month52.compareTo((java.lang.Object) fixedMillisecond57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month52.next();
//        long long65 = month52.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month52, (double) 1560190992790L);
//        try {
//            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month52, (double) 1560190995597L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191017453L + "'", long9 == 1560191017453L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560191017913L + "'", long33 == 1560191017913L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "June 2019" + "'", str42.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560191017915L + "'", long47 == 1560191017915L);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 24234L + "'", long53 == 24234L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1L + "'", long60 == 1L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1L + "'", long62 == 1L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1561964399999L + "'", long65 == 1561964399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setMaximumItemAge(1560190970939L);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        long long16 = month15.getSerialIndex();
//        long long17 = month15.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 1560190978666L);
//        java.lang.Class class20 = timeSeries11.getTimePeriodClass();
//        java.lang.Class class21 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setMaximumItemAge(1560191010510L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191017944L + "'", long9 == 1560191017944L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(class21);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getDayOfMonth();
        int int8 = day6.getMonth();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day6.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        timeSeries11.setNotify(false);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries11.addPropertyChangeListener(propertyChangeListener16);
//        timeSeries11.fireSeriesChanged();
//        timeSeries11.fireSeriesChanged();
//        java.lang.String str20 = timeSeries11.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191018031L + "'", long9 == 1560191018031L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(3, serialDate7);
        java.lang.String str11 = serialDate7.getDescription();
        int int12 = spreadsheetDate1.compare(serialDate7);
        int int13 = spreadsheetDate1.getDayOfWeek();
        int int14 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate15 = null;
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((-1), serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getNearestDayOfWeek((int) (byte) 1);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        try {
            boolean boolean24 = spreadsheetDate1.isInRange(serialDate15, serialDate21, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-29) + "'", int12 == (-29));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        boolean boolean14 = timeSeries11.getNotify();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        int int16 = month15.getYearValue();
//        int int18 = month15.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str19 = month15.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        java.lang.Class<?> wildcardClass25 = fixedMillisecond22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str19, "", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long31 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond30.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) (short) 100);
//        java.util.Collection collection37 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries26);
//        timeSeries26.setNotify(false);
//        timeSeries26.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191018490L + "'", long9 == 1560191018490L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191018491L + "'", long24 == 1560191018491L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNotNull(collection37);
//    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        int int2 = month1.getYearValue();
//        int int4 = month1.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str5 = month1.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str5, "", "hi!", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass11);
//        int int14 = timeSeries13.getMaximumItemCount();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
//        try {
//            timeSeries13.add(regularTimePeriod15, (java.lang.Number) 1560191013674L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191018545L + "'", long10 == 1560191018545L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        java.util.Collection collection28 = timeSeries25.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries25.createCopy((int) (byte) 1, 9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getFirstMillisecond(calendar33);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond32.getMiddleMillisecond(calendar35);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond32.getFirstMillisecond(calendar37);
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191018582L + "'", long9 == 1560191018582L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191018583L + "'", long23 == 1560191018583L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560191018584L + "'", long34 == 1560191018584L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560191018584L + "'", long36 == 1560191018584L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560191018584L + "'", long38 == 1560191018584L);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        boolean boolean7 = month0.equals((java.lang.Object) 1560190973648L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.Object obj2 = null;
        int int3 = month0.compareTo(obj2);
        long long4 = month0.getMiddleMillisecond();
        int int5 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        timeSeries11.setMaximumItemAge(0L);
//        timeSeries11.clear();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        int int34 = month33.getYearValue();
//        long long35 = month33.getSerialIndex();
//        long long36 = month33.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
//        try {
//            timeSeries11.update((int) (short) 10, (java.lang.Number) 1560191013437L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191018684L + "'", long9 == 1560191018684L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191018686L + "'", long23 == 1560191018686L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24234L + "'", long35 == 24234L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1559372400000L + "'", long36 == 1559372400000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 6, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, (int) (byte) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6);
        int int4 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((-1), serialDate7);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays((-1), serialDate11);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = serialDate12.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = serialDate15.getEndOfCurrentMonth(serialDate23);
        boolean boolean25 = spreadsheetDate3.isInRange(serialDate8, serialDate15);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate29);
        org.jfree.data.time.SerialDate serialDate32 = serialDate15.getEndOfCurrentMonth(serialDate31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays((int) 'a', serialDate15);
        try {
            org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1560190976483L);
        org.jfree.data.time.Year year6 = month0.getYear();
        org.jfree.data.time.Year year7 = month0.getYear();
        java.lang.String str8 = month0.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener28);
//        timeSeries11.setMaximumItemAge(0L);
//        timeSeries11.clear();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        int int34 = month33.getYearValue();
//        long long35 = month33.getSerialIndex();
//        long long36 = month33.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
//        java.lang.String str38 = month33.toString();
//        java.util.Calendar calendar39 = null;
//        try {
//            long long40 = month33.getFirstMillisecond(calendar39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191019096L + "'", long9 == 1560191019096L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191019098L + "'", long23 == 1560191019098L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24234L + "'", long35 == 24234L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1559372400000L + "'", long36 == 1559372400000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
//    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries11.addChangeListener(seriesChangeListener15);
//        timeSeries11.fireSeriesChanged();
//        java.lang.String str18 = timeSeries11.getDescription();
//        timeSeries11.setDescription("");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        int int22 = month21.getYearValue();
//        int int24 = month21.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str25 = month21.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getLastMillisecond(calendar29);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str25, "", "hi!", (java.lang.Class) wildcardClass31);
//        java.lang.String str33 = timeSeries32.getDomainDescription();
//        java.lang.Object obj34 = timeSeries32.clone();
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries32.removePropertyChangeListener(propertyChangeListener35);
//        java.lang.Object obj37 = timeSeries32.clone();
//        boolean boolean38 = timeSeries32.isEmpty();
//        timeSeries32.setKey((java.lang.Comparable) 1560190971349L);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries11.addAndOrUpdate(timeSeries32);
//        java.lang.Class class42 = timeSeries32.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191019125L + "'", long9 == 1560191019125L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560191019128L + "'", long30 == 1560191019128L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(class42);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(9999, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        boolean boolean10 = spreadsheetDate1.isAfter(serialDate8);
        java.lang.String str11 = serialDate8.getDescription();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int7 = day6.getDayOfMonth();
        long long8 = day6.getSerialIndex();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1099L + "'", long8 == 1099L);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        int int2 = month1.getYearValue();
//        int int4 = month1.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str5 = month1.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str5, "", "hi!", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.util.Date date15 = year14.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        try {
//            java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191019265L + "'", long10 == 1560191019265L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("5-January-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1560190976483L);
        org.jfree.data.time.Year year6 = month0.getYear();
        org.jfree.data.time.Year year7 = month0.getYear();
        java.util.Calendar calendar8 = null;
        try {
            year7.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(year7);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getYearValue();
//        int int6 = month3.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str7 = month3.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getLastMillisecond(calendar11);
//        java.lang.Class<?> wildcardClass13 = fixedMillisecond10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str7, "", "hi!", (java.lang.Class) wildcardClass13);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        java.lang.String str16 = timeSeries14.getDomainDescription();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        int int18 = month17.getYearValue();
//        int int20 = month17.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str21 = month17.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        java.lang.Class<?> wildcardClass27 = fixedMillisecond24.getClass();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str21, "", "hi!", (java.lang.Class) wildcardClass27);
//        java.lang.String str29 = timeSeries28.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries14.addAndOrUpdate(timeSeries28);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        boolean boolean35 = year33.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        long long37 = day36.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) day36);
//        java.lang.String str39 = day36.toString();
//        java.util.Date date40 = day36.getStart();
//        boolean boolean41 = day0.equals((java.lang.Object) day36);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560191019895L + "'", long12 == 1560191019895L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560191019897L + "'", long26 == 1560191019897L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560190974398L);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190974398L + "'", long2 == 1560190974398L);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        long long2 = month0.getSerialIndex();
//        java.util.Date date3 = month0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        int int8 = month7.getYearValue();
//        int int10 = month7.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str11 = month7.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
//        java.lang.Class<?> wildcardClass17 = fixedMillisecond14.getClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str11, "", "hi!", (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.util.Date date21 = year20.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date3, timeZone23);
//        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560191020011L + "'", long16 == 1560191020011L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(serialDate26);
//    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        long long3 = month2.getSerialIndex();
//        java.lang.Object obj4 = null;
//        int int5 = month2.compareTo(obj4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond7.getFirstMillisecond(calendar11);
//        int int13 = month2.compareTo((java.lang.Object) fixedMillisecond7);
//        int int14 = month2.getYearValue();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        int int16 = month15.getYearValue();
//        int int18 = month15.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str19 = month15.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        java.lang.Class<?> wildcardClass25 = fixedMillisecond22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str19, "", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        int int28 = month2.compareTo((java.lang.Object) timeSeries26);
//        boolean boolean29 = month0.equals((java.lang.Object) month2);
//        java.util.Calendar calendar30 = null;
//        try {
//            month0.peg(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191020437L + "'", long24 == 1560191020437L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        long long16 = month14.getSerialIndex();
//        long long17 = month14.getFirstMillisecond();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        int int23 = day18.compareTo((java.lang.Object) fixedMillisecond20);
//        int int24 = month14.compareTo((java.lang.Object) fixedMillisecond20);
//        int int26 = month14.compareTo((java.lang.Object) 9999);
//        int int27 = month14.getYearValue();
//        try {
//            timeSeries11.update((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 31);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191020451L + "'", long9 == 1560191020451L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560191020453L + "'", long22 == 1560191020453L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        int int4 = year0.compareTo((java.lang.Object) "June 2019");
        long long5 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        java.util.Collection collection28 = timeSeries25.getTimePeriods();
//        timeSeries25.setDescription("");
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        int int32 = month31.getYearValue();
//        int int34 = month31.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str35 = month31.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        java.lang.Class<?> wildcardClass41 = fixedMillisecond38.getClass();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str35, "", "hi!", (java.lang.Class) wildcardClass41);
//        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
//        java.lang.String str44 = timeSeries42.getDomainDescription();
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        int int46 = month45.getYearValue();
//        int int48 = month45.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str49 = month45.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond52.getLastMillisecond(calendar53);
//        java.lang.Class<?> wildcardClass55 = fixedMillisecond52.getClass();
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str49, "", "hi!", (java.lang.Class) wildcardClass55);
//        java.lang.String str57 = timeSeries56.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries42.addAndOrUpdate(timeSeries56);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
//        timeSeries56.removeChangeListener(seriesChangeListener59);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        boolean boolean63 = year61.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        long long65 = day64.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries56.createCopy((org.jfree.data.time.RegularTimePeriod) year61, (org.jfree.data.time.RegularTimePeriod) day64);
//        int int67 = day64.getYear();
//        int int68 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) day64);
//        timeSeries25.setDomainDescription("ERROR : Relative To String");
//        timeSeries25.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191020533L + "'", long9 == 1560191020533L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191020535L + "'", long23 == 1560191020535L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "June 2019" + "'", str35.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560191020537L + "'", long40 == 1560191020537L);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "June 2019" + "'", str49.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560191020543L + "'", long54 == 1560191020543L);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560236399999L + "'", long65 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2019 + "'", int67 == 2019);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, 2958465, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        timeSeries11.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=11]");
//        java.lang.Comparable comparable15 = timeSeries11.getKey();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191020721L + "'", long9 == 1560191020721L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "June 2019" + "'", comparable15.equals("June 2019"));
//    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        int int7 = day6.getDayOfMonth();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        int int10 = month9.getYearValue();
//        int int12 = month9.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str13 = month9.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        java.lang.Class<?> wildcardClass19 = fixedMillisecond16.getClass();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str13, "", "hi!", (java.lang.Class) wildcardClass19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, (java.lang.Class) wildcardClass19);
//        java.lang.Object obj22 = timeSeries21.clone();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getYear();
//        long long25 = day23.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        try {
//            timeSeries21.update((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 1560190972646L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3-January-1903" + "'", str8.equals("3-January-1903"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191020745L + "'", long18 == 1560191020745L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate26);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        java.util.Date date3 = month0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: June 2019" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: June 2019"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-467));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
        int int5 = spreadsheetDate4.getDayOfMonth();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((-1), serialDate10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = serialDate11.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate20);
        org.jfree.data.time.SerialDate serialDate23 = serialDate14.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate14);
        java.lang.String str25 = serialDate24.toString();
        boolean boolean26 = spreadsheetDate4.isOnOrAfter(serialDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(6);
        int int32 = spreadsheetDate31.getDayOfMonth();
        boolean boolean33 = spreadsheetDate28.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays((-1), serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = serialDate38.getEndOfCurrentMonth(serialDate41);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate47);
        org.jfree.data.time.SerialDate serialDate50 = serialDate41.getEndOfCurrentMonth(serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate41);
        java.lang.String str52 = serialDate51.toString();
        boolean boolean53 = spreadsheetDate31.isOnOrAfter(serialDate51);
        boolean boolean54 = spreadsheetDate4.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(6);
        java.util.Date date57 = spreadsheetDate56.toDate();
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate61);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate61);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(serialDate63);
        boolean boolean65 = spreadsheetDate56.isAfter(serialDate63);
        int int66 = spreadsheetDate31.compare(serialDate63);
        org.jfree.data.time.SerialDate serialDate67 = null;
        try {
            boolean boolean68 = spreadsheetDate31.isAfter(serialDate67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1-February-1900" + "'", str25.equals("1-February-1900"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1-February-1900" + "'", str52.equals("1-February-1900"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1093) + "'", int66 == (-1093));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-467));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        int int2 = month1.getYearValue();
//        int int4 = month1.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str5 = month1.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getLastMillisecond(calendar9);
//        java.lang.Class<?> wildcardClass11 = fixedMillisecond8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str5, "", "hi!", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
//        java.lang.String str27 = timeSeries25.getDomainDescription();
//        timeSeries25.setNotify(false);
//        timeSeries25.fireSeriesChanged();
//        timeSeries25.fireSeriesChanged();
//        java.util.Collection collection32 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries13.getDataItem((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191021087L + "'", long10 == 1560191021087L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191021088L + "'", long23 == 1560191021088L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
//        org.junit.Assert.assertNotNull(collection32);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(3, serialDate8);
        java.lang.String str12 = serialDate8.getDescription();
        int int13 = spreadsheetDate2.compare(serialDate8);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays((-1), serialDate16);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = serialDate17.getEndOfCurrentMonth(serialDate20);
        java.lang.String str23 = serialDate20.getDescription();
        boolean boolean24 = spreadsheetDate2.isOnOrBefore(serialDate20);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate28);
        boolean boolean31 = spreadsheetDate2.isOnOrAfter(serialDate30);
        try {
            org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-29) + "'", int13 == (-29));
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.String str12 = timeSeries11.getDomainDescription();
//        java.lang.Object obj13 = timeSeries11.clone();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        boolean boolean20 = year18.equals((java.lang.Object) 1559372400000L);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        int int22 = month21.getYearValue();
//        int int24 = month21.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str25 = month21.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getLastMillisecond(calendar29);
//        java.lang.Class<?> wildcardClass31 = fixedMillisecond28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str25, "", "hi!", (java.lang.Class) wildcardClass31);
//        java.lang.Class<?> wildcardClass33 = timeSeries32.getClass();
//        boolean boolean34 = year18.equals((java.lang.Object) timeSeries32);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries11.addAndOrUpdate(timeSeries32);
//        timeSeries35.setKey((java.lang.Comparable) (-1L));
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191021135L + "'", long9 == 1560191021135L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560191021137L + "'", long30 == 1560191021137L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day33);
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timeSeries35.addPropertyChangeListener(propertyChangeListener36);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191021254L + "'", long9 == 1560191021254L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191021256L + "'", long23 == 1560191021256L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getYearValue();
//        int int17 = month14.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str18 = month14.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
//        java.lang.Class<?> wildcardClass24 = fixedMillisecond21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str18, "", "hi!", (java.lang.Class) wildcardClass24);
//        java.lang.String str26 = timeSeries25.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.addAndOrUpdate(timeSeries25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
//        boolean boolean32 = year30.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day33);
//        timeSeries25.setRangeDescription("May");
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries25.addPropertyChangeListener(propertyChangeListener38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        java.util.Date date41 = year40.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date41);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date41);
//        try {
//            timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day45, (double) 1560190994257L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191021314L + "'", long9 == 1560191021314L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191021316L + "'", long23 == 1560191021316L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNotNull(date41);
//    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        boolean boolean14 = timeSeries11.getNotify();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        int int16 = month15.getYearValue();
//        int int18 = month15.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str19 = month15.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        java.lang.Class<?> wildcardClass25 = fixedMillisecond22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str19, "", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long31 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond30.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) (short) 100);
//        java.util.Collection collection37 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries26);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = null;
//        try {
//            timeSeries26.add(timeSeriesDataItem38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191021339L + "'", long9 == 1560191021339L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191021341L + "'", long24 == 1560191021341L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNotNull(collection37);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 11);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 11 + "'", obj2.equals(11));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=11]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=11]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=11]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=11]"));
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        long long2 = month0.getSerialIndex();
//        java.util.Date date3 = month0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        int int8 = month7.getYearValue();
//        int int10 = month7.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str11 = month7.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
//        java.lang.Class<?> wildcardClass17 = fixedMillisecond14.getClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str11, "", "hi!", (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6, (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.util.Date date21 = year20.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date3, timeZone23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date3);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560191022317L + "'", long16 == 1560191022317L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.Object obj2 = null;
        int int3 = month0.compareTo(obj2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        java.util.Date date13 = regularTimePeriod12.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((-1), serialDate5);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate9);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
//        java.lang.String str12 = serialDate9.getDescription();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate16);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate16);
//        boolean boolean20 = spreadsheetDate2.isInRange(serialDate9, serialDate16, 9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        java.lang.Class<?> wildcardClass27 = fixedMillisecond24.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "1-February-1900", "", class28);
//        boolean boolean30 = spreadsheetDate2.equals((java.lang.Object) timeSeries29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays((-1), serialDate35);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate39);
//        org.jfree.data.time.SerialDate serialDate41 = serialDate36.getEndOfCurrentMonth(serialDate39);
//        java.lang.String str42 = serialDate39.getDescription();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate46);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate46);
//        boolean boolean50 = spreadsheetDate32.isInRange(serialDate39, serialDate46, 9999);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(6);
//        int int53 = spreadsheetDate52.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate58);
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate58);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears(3, serialDate58);
//        java.lang.String str62 = serialDate58.getDescription();
//        int int63 = spreadsheetDate52.compare(serialDate58);
//        int int64 = spreadsheetDate52.getMonth();
//        boolean boolean65 = spreadsheetDate2.isInRange(serialDate39, (org.jfree.data.time.SerialDate) spreadsheetDate52);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths((int) (short) 1, serialDate39);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560191022461L + "'", long26 == 1560191022461L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNull(str42);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 5 + "'", int53 == 5);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNull(str62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-29) + "'", int63 == (-29));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertNotNull(serialDate66);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-459), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        long long16 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond15.previous();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 100);
//        timeSeries11.fireSeriesChanged();
//        boolean boolean23 = timeSeries11.getNotify();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        int int25 = month24.getYearValue();
//        long long26 = month24.getSerialIndex();
//        long long27 = month24.getFirstMillisecond();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getFirstMillisecond(calendar31);
//        int int33 = day28.compareTo((java.lang.Object) fixedMillisecond30);
//        int int34 = month24.compareTo((java.lang.Object) fixedMillisecond30);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond30.getMiddleMillisecond(calendar35);
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        java.util.List list38 = timeSeries11.getItems();
//        long long39 = timeSeries11.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191022863L + "'", long9 == 1560191022863L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 24234L + "'", long26 == 24234L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560191022870L + "'", long32 == 1560191022870L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560191022870L + "'", long36 == 1560191022870L);
//        org.junit.Assert.assertNotNull(list38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((-1), serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((-1), serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate10.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate13.getEndOfCurrentMonth(serialDate21);
        boolean boolean23 = spreadsheetDate1.isInRange(serialDate6, serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(6);
        int int26 = spreadsheetDate25.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays((-1), serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((-1), serialDate33);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = serialDate34.getEndOfCurrentMonth(serialDate37);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate43);
        org.jfree.data.time.SerialDate serialDate46 = serialDate37.getEndOfCurrentMonth(serialDate45);
        boolean boolean47 = spreadsheetDate25.isInRange(serialDate30, serialDate37);
        org.jfree.data.time.SerialDate serialDate49 = serialDate37.getNearestDayOfWeek(5);
        java.lang.String str50 = serialDate49.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(6);
        int int56 = spreadsheetDate55.getDayOfMonth();
        boolean boolean57 = spreadsheetDate52.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate60);
        boolean boolean62 = spreadsheetDate55.isOnOrBefore(serialDate60);
        boolean boolean63 = spreadsheetDate1.isInRange(serialDate49, serialDate60);
        int int64 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate65 = null;
        try {
            boolean boolean66 = spreadsheetDate1.isAfter(serialDate65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1-February-1900" + "'", str50.equals("1-February-1900"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 5 + "'", int56 == 5);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate2 = null;
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(6);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((-1), serialDate7);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate8.getEndOfCurrentMonth(serialDate11);
//        java.lang.String str14 = serialDate11.getDescription();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) '#');
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate18);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate18);
//        boolean boolean22 = spreadsheetDate4.isInRange(serialDate11, serialDate18, 9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
//        java.lang.Class<?> wildcardClass29 = fixedMillisecond26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "1-February-1900", "", class30);
//        boolean boolean32 = spreadsheetDate4.equals((java.lang.Object) timeSeries31);
//        try {
//            boolean boolean34 = spreadsheetDate1.isInRange(serialDate2, (org.jfree.data.time.SerialDate) spreadsheetDate4, 1964);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560191023427L + "'", long28 == 1560191023427L);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        try {
            org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getFollowingDayOfWeek((-1093));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.Object obj13 = timeSeries11.clone();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191023447L + "'", long9 == 1560191023447L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(obj13);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560190984450L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 1560190973420L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        java.util.Date date3 = month0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        java.util.Date date8 = year5.getEnd();
        int int9 = year5.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getSerialIndex();
//        java.lang.Object obj2 = null;
//        int int3 = month0.compareTo(obj2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getFirstMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
//        int int11 = month0.compareTo((java.lang.Object) fixedMillisecond5);
//        int int12 = month0.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
//        int int19 = fixedMillisecond13.compareTo((java.lang.Object) long18);
//        int int20 = month0.compareTo((java.lang.Object) long18);
//        org.jfree.data.time.Year year21 = month0.getYear();
//        int int23 = year21.compareTo((java.lang.Object) 1560190990426L);
//        int int24 = year21.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191023765L + "'", long15 == 1560191023765L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191023766L + "'", long18 == 1560191023766L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getYearValue();
//        int int3 = month0.compareTo((java.lang.Object) 1560190970939L);
//        java.lang.String str4 = month0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str4, "", "hi!", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setNotify(true);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191023787L + "'", long9 == 1560191023787L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
        long long5 = fixedMillisecond2.getLastMillisecond();
        long long6 = fixedMillisecond2.getSerialIndex();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond2.getFirstMillisecond(calendar7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: June 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: June 2019"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(6);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isBefore(serialDate6);
        boolean boolean9 = spreadsheetDate1.equals((java.lang.Object) 1560190987610L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Date date5 = year4.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
    }
}

