import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(date1, date3);
        java.util.Date date5 = simpleTimePeriod4.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) (byte) 10);
//        java.lang.String str6 = day3.toString();
//        java.lang.String str7 = day3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int11 = timePeriodValues10.getMaxMiddleIndex();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) (byte) 10);
//        int int15 = day3.compareTo((java.lang.Object) day12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day3.next();
//        java.util.Date date17 = regularTimePeriod16.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.util.Date date19 = year18.getEnd();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.util.Date date21 = year20.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date19, date21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date21, "", "hi!");
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.util.Date date28 = year27.getEnd();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.util.Date date30 = year29.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date28, date30);
//        long long32 = simpleTimePeriod31.getStartMillis();
//        long long33 = simpleTimePeriod31.getEndMillis();
//        java.util.Date date34 = simpleTimePeriod31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date21, timeZone35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date17, date21);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test05");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) (byte) 10);
//        java.lang.String str6 = day3.toString();
//        java.lang.String str7 = day3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int11 = timePeriodValues10.getMaxMiddleIndex();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) (byte) 10);
//        int int15 = day3.compareTo((java.lang.Object) day12);
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day12);
//        int int18 = day12.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = year0.toString();
        int int3 = year0.getYear();
        long long4 = year0.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test07");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) (byte) 10);
//        java.lang.String str6 = day3.toString();
//        java.lang.String str7 = day3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int11 = timePeriodValues10.getMaxMiddleIndex();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) (byte) 10);
//        int int15 = day3.compareTo((java.lang.Object) day12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int18 = timePeriodValues17.getMaxMiddleIndex();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (byte) 10);
//        java.lang.String str22 = day19.toString();
//        java.lang.String str23 = day19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day19.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.previous();
//        int int26 = day12.compareTo((java.lang.Object) day19);
//        long long27 = day19.getFirstMillisecond();
//        int int28 = day19.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day19.next();
//        java.lang.String str30 = day19.toString();
//        long long31 = day19.getFirstMillisecond();
//        long long32 = day19.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560409200000L + "'", long27 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560409200000L + "'", long31 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560409200000L + "'", long32 == 1560409200000L);
//    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(date1, date3);
        long long5 = simpleTimePeriod4.getStartMillis();
        long long6 = simpleTimePeriod4.getEndMillis();
        java.util.Date date7 = simpleTimePeriod4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
        java.util.Date date11 = year10.getEnd();
        java.util.Date date12 = year10.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "", "org.jfree.data.general.SeriesException: hi!");
        long long8 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        timePeriodValues1.setRangeDescription("13-June-2019");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int5 = year4.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(date7, date9);
        long long11 = simpleTimePeriod10.getStartMillis();
        boolean boolean13 = simpleTimePeriod10.equals((java.lang.Object) "org.jfree.data.general.SeriesException: hi!");
        java.util.Date date14 = simpleTimePeriod10.getEnd();
        long long15 = simpleTimePeriod10.getEndMillis();
        int int16 = year4.compareTo((java.lang.Object) simpleTimePeriod10);
        timePeriodValues1.setKey((java.lang.Comparable) int16);
        try {
            timePeriodValues1.delete((int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(date1, date3);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod4);
        timePeriodValues5.setNotify(true);
        int int8 = timePeriodValues5.getMinMiddleIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        long long11 = year9.getLastMillisecond();
        boolean boolean12 = timePeriodValues5.equals((java.lang.Object) long11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test12");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        int int2 = timePeriodValues1.getMaxMiddleIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) (byte) 10);
//        java.lang.String str6 = day3.toString();
//        java.lang.String str7 = day3.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day3.previous();
//        java.util.Date date10 = day3.getStart();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.util.Date date12 = year11.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date10, date12);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.util.Date date15 = year14.getEnd();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        java.util.Date date17 = year16.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date15, date17);
//        boolean boolean19 = simpleTimePeriod13.equals((java.lang.Object) date17);
//        long long20 = simpleTimePeriod13.getEndMillis();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        java.util.Date date22 = year21.getEnd();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        java.util.Date date24 = year23.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date22, date24);
//        java.util.Date date26 = simpleTimePeriod25.getStart();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26, timeZone27);
//        java.lang.Class<?> wildcardClass29 = day28.getClass();
//        boolean boolean30 = simpleTimePeriod13.equals((java.lang.Object) day28);
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day28, 0.0d);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }
//}

