import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str1.equals("java.awt.Color[r=255,g=128,b=128]"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        try {
            categoryPlot4.setRangeAxisLocation(axisLocation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes(100.0d, (double) (-1.0f), plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes(100.0d, (double) (-1.0f), plotRenderingInfo9, point2D10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            categoryPlot4.setRangeAxisLocation(axisLocation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        try {
            boolean boolean7 = categoryPlot4.removeAnnotation(categoryAnnotation5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace13 = dateAxis1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) categoryPlot7, rectangle2D10, rectangleEdge11, axisSpace12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double6 = rectangleInsets5.getTop();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets5.createOutsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot11.getIndexOf(categoryItemRenderer12);
        int int14 = categoryPlot11.getDomainAxisCount();
        categoryPlot11.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace23 = dateAxis1.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) categoryPlot11, rectangle2D20, rectangleEdge21, axisSpace22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        try {
            dateAxis1.setRange(2.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean11 = categoryPlot4.removeAnnotation(categoryAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.util.Date date4 = null;
        java.util.Date date5 = null;
        try {
            dateAxis1.setRange(date4, date5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        boolean boolean3 = categoryPlot0.removeDomainMarker(marker1, layer2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            categoryPlot0.drawBackground(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        categoryPlot0.setInsets(rectangleInsets6);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets6.createAdjustedRectangle(rectangle2D8, lengthAdjustmentType9, lengthAdjustmentType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color4 = java.awt.Color.getColor("", color3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextPaint();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) ' ', (java.awt.Paint) color4, stroke5, paint20, stroke21, (float) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation11);
        try {
            double double13 = dateAxis1.java2DToValue(0.0d, rectangle2D9, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabel("");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        boolean boolean12 = dateAxis1.isTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
        try {
            double double18 = dateAxis1.lengthToJava2D((double) (short) 0, rectangle2D14, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets9.createInsetRectangle(rectangle2D12, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis12.valueToJava2D(10.0d, rectangle2D14, rectangleEdge15);
        dateAxis12.setAutoTickUnitSelection(true);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = null;
        try {
            dateAxis12.setTickMarkPosition(dateTickMarkPosition20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        int int15 = categoryPlot13.getIndexOf(categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot13.setRenderer((int) (short) 10, categoryItemRenderer17, true);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        categoryPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation30, plotOrientation31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace34 = dateAxis1.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) categoryPlot13, rectangle2D29, rectangleEdge32, axisSpace33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabel("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        try {
            java.util.Date date5 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            categoryPlot4.addRangeMarker(1, marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Color color1 = java.awt.Color.BLACK;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 6, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke4, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            categoryPlot4.drawOutline(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot4.addRangeMarker(3, marker14, layer15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes(100.0d, (double) (-1.0f), plotRenderingInfo9, point2D10);
        try {
            categoryPlot4.zoom((double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        try {
            categoryPlot4.setDomainAxis((int) (short) -1, categoryAxis14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation8, plotOrientation9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = dateAxis1.draw(graphics2D4, (double) (byte) 100, rectangle2D6, rectangle2D7, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            categoryPlot4.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        try {
            dateAxis1.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets9.createOutsetRectangle(rectangle2D12, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int3 = java.awt.Color.HSBtoRGB((float) 0L, 0.0f, 2.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2) + "'", int3 == (-2));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.plot.Plot plot6 = dateAxis1.getPlot();
        dateAxis1.setUpperMargin((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation8, plotOrientation9);
        try {
            double double11 = dateAxis1.valueToJava2D(0.05d, rectangle2D7, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        java.lang.String str13 = categoryPlot4.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot4.drawOutline(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis4.setMinimumDate(date13);
        java.lang.Class class15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis19.valueToJava2D(10.0d, rectangle2D21, rectangleEdge22);
        dateAxis19.setAutoTickUnitSelection(true);
        java.util.Date date26 = dateAxis19.getMaximumDate();
        dateAxis17.setMinimumDate(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date26, timeZone28);
        try {
            dateAxis1.setRange(date13, date26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        categoryPlot4.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation4, plotOrientation5);
        try {
            double double7 = dateAxis1.java2DToValue((double) '4', rectangle2D3, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot10.getIndexOf(categoryItemRenderer11);
        int int13 = categoryPlot10.getDomainAxisCount();
        categoryPlot10.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot10.setRenderers(categoryItemRendererArray17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation20);
        categoryPlot10.setDomainAxisLocation(axisLocation19, false);
        java.awt.Paint paint24 = categoryPlot10.getOutlinePaint();
        categoryAxis4.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint24);
        java.awt.Stroke stroke26 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 128, paint1, stroke2, paint24, stroke26, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot4.getDomainMarkers(layer13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis12.valueToJava2D(10.0d, rectangle2D14, rectangleEdge15);
        dateAxis12.setAutoTickUnitSelection(true);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        dateAxis12.setLabel("DatasetRenderingOrder.REVERSE");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        categoryPlot4.setDomainGridlinesVisible(false);
        categoryPlot4.mapDatasetToRangeAxis((int) '#', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot9.getIndexOf(categoryItemRenderer10);
        int int12 = categoryPlot9.getDomainAxisCount();
        categoryPlot9.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot9.setBackgroundImageAlignment(12);
        int int18 = categoryPlot9.getDatasetCount();
        categoryPlot9.clearRangeMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot9.getDomainAxisEdge();
        try {
            double double21 = dateAxis1.valueToJava2D(100.0d, rectangle2D4, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight(2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        java.awt.Stroke stroke8 = dateAxis1.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis10.java2DToValue(0.0d, rectangle2D12, rectangleEdge13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        dateAxis1.setRightArrow(shape15);
        java.awt.Stroke stroke17 = null;
        try {
            dateAxis1.setTickMarkStroke(stroke17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        categoryPlot0.setInsets(rectangleInsets6);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            categoryPlot4.handleClick(8, 1, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = regularTimePeriod2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.Object obj0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent(obj0, dataset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int3 = java.awt.Color.HSBtoRGB(10.0f, (float) 3, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = null;
        try {
            categoryPlot4.setDomainGridlinePosition(categoryAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone9);
        dateAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        java.lang.Object obj7 = categoryPlot4.clone();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean11 = categoryPlot4.removeAnnotation(categoryAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(axisSpace8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) (short) 0, (double) (short) 1, (double) 10.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset((int) '4', categoryDataset16);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            boolean boolean19 = categoryPlot4.removeAnnotation(categoryAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis6.getStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource11);
        dateAxis1.resizeRange((double) 1.0f, (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        dateAxis1.setAutoTickUnitSelection(false, false);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        int int15 = categoryPlot13.getIndexOf(categoryItemRenderer14);
        int int16 = categoryPlot13.getDomainAxisCount();
        categoryPlot13.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot13.setBackgroundImageAlignment(12);
        int int22 = categoryPlot13.getDatasetCount();
        categoryPlot13.clearRangeMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot13.getDomainAxisEdge();
        try {
            double double25 = dateAxis1.valueToJava2D(10.0d, rectangle2D8, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        try {
            categoryPlot4.zoom(0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        java.lang.String str3 = color1.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=0,g=0,b=255]" + "'", str3.equals("java.awt.Color[r=0,g=0,b=255]"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        try {
            java.util.Date date9 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 10.0d, dataset1);
        org.jfree.data.general.Dataset dataset3 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertNull(dataset3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        boolean boolean12 = dateAxis1.isTickMarksVisible();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot18.getIndexOf(categoryItemRenderer19);
        int int21 = categoryPlot18.getDomainAxisCount();
        categoryPlot18.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot18.setBackgroundImageAlignment(12);
        int int27 = categoryPlot18.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot18.setFixedRangeAxisSpace(axisSpace28);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation31, plotOrientation32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace35 = dateAxis1.reserveSpace(graphics2D13, (org.jfree.chart.plot.Plot) categoryPlot18, rectangle2D30, rectangleEdge33, axisSpace34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, false);
        try {
            categoryPlot4.zoom((double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        plotChangeEvent9.setChart(jFreeChart10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = plotChangeEvent9.getType();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "DatasetRenderingOrder.REVERSE", paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            boolean boolean19 = categoryPlot4.removeAnnotation(categoryAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        categoryPlot0.drawBackgroundImage(graphics2D1, rectangle2D2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot4.drawOutline(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Color color2 = java.awt.Color.RED;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color4 = java.awt.Color.red;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) 15, (java.awt.Paint) color2, stroke3, (java.awt.Paint) color4, stroke5, (float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot4.getDomainAxisLocation((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.05d, (double) 0, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        int int7 = categoryPlot5.getIndexOf(categoryItemRenderer6);
        int int8 = categoryPlot5.getDomainAxisCount();
        categoryPlot5.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot5.setBackgroundImageAlignment(12);
        int int14 = categoryPlot5.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot5.setDomainAxis(9, categoryAxis18, true);
        java.awt.Paint paint21 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot5.getDomainAxisLocation();
        java.awt.Paint paint23 = categoryPlot5.getNoDataMessagePaint();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color25 = java.awt.Color.ORANGE;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = dateAxis27.java2DToValue(0.0d, rectangle2D29, rectangleEdge30);
        java.awt.Shape shape32 = dateAxis27.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = dateAxis27.getLabelInsets();
        java.awt.Stroke stroke34 = dateAxis27.getTickMarkStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker(0.2d, paint23, stroke24, (java.awt.Paint) color25, stroke34, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double6 = rectangleInsets5.getTop();
        double double8 = rectangleInsets5.trimHeight((double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets5.createOutsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) 100L);
        java.lang.Object obj3 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.plot.Plot plot6 = dateAxis1.getPlot();
        dateAxis1.setLabel("");
        double double9 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        dateAxis1.resizeRange(100.0d);
        dateAxis1.setVisible(true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getComponents(floatArray6);
        float[] floatArray8 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray7);
        float[] floatArray9 = color1.getRGBColorComponents(floatArray8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot14.getAxisOffset();
        java.awt.Stroke stroke16 = categoryPlot14.getDomainGridlineStroke();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3, (java.awt.Paint) color1, stroke16, (java.awt.Paint) color17, stroke18, (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Color color1 = java.awt.Color.getColor("EXPAND");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        java.lang.Object obj7 = categoryPlot4.clone();
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) dateAxis1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getRangeAxisLocation(0);
        categoryPlot4.setWeight(0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        double double11 = categoryPlot4.getRangeCrosshairValue();
        boolean boolean12 = categoryPlot4.isOutlineVisible();
        java.awt.Stroke stroke13 = categoryPlot4.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.valueToJava2D(10.0d, rectangle2D5, rectangleEdge6);
        dateAxis3.setAutoTickUnitSelection(true);
        java.util.Date date10 = dateAxis3.getMaximumDate();
        dateAxis1.setMinimumDate(date10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        try {
            java.util.Date date13 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, true);
        org.jfree.data.category.CategoryDataset categoryDataset19 = categoryPlot4.getDataset((-16777216));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(categoryDataset19);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Color color1 = java.awt.Color.BLUE;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot6.addChangeListener(plotChangeListener7);
        java.awt.Image image9 = null;
        categoryPlot6.setBackgroundImage(image9);
        java.awt.Stroke stroke11 = categoryPlot6.getRangeCrosshairStroke();
        java.awt.Color color12 = java.awt.Color.darkGray;
        int int13 = color12.getTransparency();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.VERTICAL", (java.awt.Paint) color1, stroke11, (java.awt.Paint) color12, stroke14, (float) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(tickUnitSource7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color0 = java.awt.Color.CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray3 = null;
        float[] floatArray4 = color2.getComponents(floatArray3);
        try {
            float[] floatArray5 = color0.getComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getRangeAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        try {
            categoryPlot4.setRangeAxisLocation((int) (short) -1, axisLocation8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        boolean boolean9 = categoryPlot4.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, false);
        java.awt.Paint paint18 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.configure();
        categoryAxis6.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        categoryAxis1.setMaximumCategoryLabelLines(128);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        try {
            double double20 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 2.0d, (java.lang.Comparable) '#', categoryDataset16, (double) 32.0f, rectangle2D18, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D2, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        java.lang.String str10 = plotChangeEvent9.toString();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        plotChangeEvent9.setChart(jFreeChart11);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        double double8 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(categoryItemRenderer11, true);
        categoryPlot4.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = regularTimePeriod1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Color color0 = java.awt.Color.orange;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        numberAxis26.setUpperMargin((double) 10.0f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis4.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
        dateAxis4.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot15.getIndexOf(categoryItemRenderer16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot15.setRenderer((int) (short) 10, categoryItemRenderer19, true);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = dateAxis23.valueToJava2D(10.0d, rectangle2D25, rectangleEdge26);
        dateAxis23.setAutoTickUnitSelection(true);
        categoryPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        java.awt.Font font31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot15.setNoDataMessageFont(font31);
        dateAxis4.setTickLabelFont(font31);
        boolean boolean34 = objectList0.equals((java.lang.Object) font31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        categoryPlot4.clearDomainAxes();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        boolean boolean11 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker8, layer9, true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot4.addChangeListener(plotChangeListener12);
        categoryPlot4.clearDomainAxes();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getComponents(floatArray2);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray8 = null;
        float[] floatArray9 = color7.getComponents(floatArray8);
        float[] floatArray10 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray9);
        float[] floatArray11 = color1.getRGBComponents(floatArray10);
        float[] floatArray12 = color0.getRGBColorComponents(floatArray11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit31 = null;
        try {
            numberAxis26.setTickUnit(numberTickUnit31, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setTickMarkOutsideLength((float) 13);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        java.lang.Object obj10 = plotChangeEvent9.getSource();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        double double14 = categoryPlot7.getRangeCrosshairValue();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace20 = categoryAxis1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) categoryPlot7, rectangle2D15, rectangleEdge18, axisSpace19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        boolean boolean3 = categoryPlot0.removeDomainMarker(marker1, layer2);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(15, axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo2, point2D3, true);
        java.awt.Paint paint6 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        categoryPlot0.setInsets(rectangleInsets6);
        boolean boolean8 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        int int19 = categoryPlot17.getIndexOf(categoryItemRenderer18);
        int int20 = categoryPlot17.getDomainAxisCount();
        categoryPlot17.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot17.setRenderers(categoryItemRendererArray24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation26, plotOrientation27);
        categoryPlot17.setDomainAxisLocation(axisLocation26, false);
        java.awt.Paint paint31 = categoryPlot17.getOutlinePaint();
        categoryAxis11.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint31);
        try {
            categoryPlot0.setDomainAxis((int) (short) -1, categoryAxis11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 2, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color0 = java.awt.Color.darkGray;
        int int1 = color0.getTransparency();
        int int2 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            categoryPlot4.drawBackground(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets7.createInsetRectangle(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        double double13 = categoryPlot4.getAnchorValue();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray20 = null;
        float[] floatArray21 = color19.getComponents(floatArray20);
        float[] floatArray22 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray21);
        float[] floatArray23 = color15.getRGBColorComponents(floatArray22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color15, stroke24);
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = null;
        org.jfree.chart.util.Layer layer28 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker27, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        java.awt.Stroke stroke8 = dateAxis1.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis10.java2DToValue(0.0d, rectangle2D12, rectangleEdge13);
        java.awt.Shape shape15 = dateAxis10.getUpArrow();
        dateAxis1.setRightArrow(shape15);
        java.text.DateFormat dateFormat17 = null;
        dateAxis1.setDateFormatOverride(dateFormat17);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        java.awt.Stroke stroke12 = null;
        try {
            dateAxis1.setAxisLineStroke(stroke12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str22 = lengthAdjustmentType21.toString();
        boolean boolean23 = axisLocation16.equals((java.lang.Object) lengthAdjustmentType21);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType21);
        org.jfree.chart.text.TextAnchor textAnchor25 = valueMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "NO_CHANGE" + "'", str22.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        categoryPlot4.mapDatasetToDomainAxis(128, 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.valueToJava2D(10.0d, rectangle2D5, rectangleEdge6);
        dateAxis3.setAutoTickUnitSelection(true);
        java.util.Date date10 = dateAxis3.getMaximumDate();
        dateAxis1.setMinimumDate(date10);
        double double12 = dateAxis1.getUpperBound();
        boolean boolean13 = dateAxis1.isVisible();
        java.lang.String str14 = dateAxis1.getLabel();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        boolean boolean3 = categoryPlot0.removeDomainMarker(marker1, layer2);
        boolean boolean4 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        java.awt.Stroke stroke6 = categoryPlot4.getDomainGridlineStroke();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot4.removeDomainMarker(marker7);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        categoryPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot4.getRangeAxisEdge();
        float float14 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot4.setRenderer(10, categoryItemRenderer16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo2, point2D3, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo7, point2D8, true);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis15.valueToJava2D(10.0d, rectangle2D17, rectangleEdge18);
        dateAxis15.setAutoTickUnitSelection(true);
        java.util.Date date22 = dateAxis15.getMaximumDate();
        dateAxis13.setMinimumDate(date22);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = null;
        categoryPlot0.axisChanged(axisChangeEvent26);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.plot.Plot plot6 = dateAxis1.getPlot();
        dateAxis1.setLabel("");
        java.lang.String str9 = dateAxis1.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis12.valueToJava2D(10.0d, rectangle2D14, rectangleEdge15);
        dateAxis12.setAutoTickUnitSelection(true);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Color color20 = java.awt.Color.BLACK;
        dateAxis12.setTickMarkPaint((java.awt.Paint) color20);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 1, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color1 = color0.darker();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color0.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        double double11 = categoryPlot4.getRangeCrosshairValue();
        boolean boolean12 = categoryPlot4.isOutlineVisible();
        double double13 = categoryPlot4.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker1.setLabel("hi!");
        double double4 = valueMarker1.getValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, false);
        float float18 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot4.setRenderer(0, categoryItemRenderer22, false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        try {
            categoryPlot4.setRenderer((-16777216), categoryItemRenderer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        dateAxis1.setFixedAutoRange(1.0E-8d);
        boolean boolean9 = dateAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        boolean boolean7 = categoryPlot4.isSubplot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot4.getRenderer();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        boolean boolean7 = categoryPlot4.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot4.setDataset(5, categoryDataset9);
        try {
            categoryPlot4.zoom((double) 1560538799999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        double double13 = categoryPlot4.getAnchorValue();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        java.lang.Object obj16 = plotChangeEvent15.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = plotChangeEvent15.getType();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        java.awt.Image image9 = null;
        plot8.setBackgroundImage(image9);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        boolean boolean14 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker17.setLabel("hi!");
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean22 = categoryPlot4.removeRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) valueMarker17, layer20, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = null;
        try {
            valueMarker17.setLabelAnchor(rectangleAnchor23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color9, paint10, paint11 };
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str14 = color13.toString();
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { color13, paint15 };
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] {};
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray21 = new java.awt.Shape[] { shape19, shape20 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray16, strokeArray17, strokeArray18, shapeArray21);
        boolean boolean24 = defaultDrawingSupplier22.equals((java.lang.Object) 1L);
        boolean boolean26 = defaultDrawingSupplier22.equals((java.lang.Object) (byte) 100);
        java.awt.Paint paint27 = defaultDrawingSupplier22.getNextOutlinePaint();
        dateAxis1.setTickMarkPaint(paint27);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str14.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot5.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot9 = categoryPlot5.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot5.getRowRenderingOrder();
        boolean boolean12 = dateAxis0.hasListener((java.util.EventListener) categoryPlot5);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = dateAxis16.valueToJava2D(10.0d, rectangle2D18, rectangleEdge19);
        dateAxis16.setAutoTickUnitSelection(true);
        java.util.Date date23 = dateAxis16.getMaximumDate();
        dateAxis14.setMinimumDate(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        dateAxis0.setTimeZone(timeZone25);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone25);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Color color0 = java.awt.Color.BLUE;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        boolean boolean12 = dateAxis1.isTickMarksVisible();
        dateAxis1.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot19.getDomainAxis();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] { color21, paint22, paint23 };
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str26 = color25.toString();
        java.awt.Paint paint27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color25, paint27 };
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] {};
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray33 = new java.awt.Shape[] { shape31, shape32 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray24, paintArray28, strokeArray29, strokeArray30, shapeArray33);
        categoryPlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier34);
        java.awt.Shape shape36 = defaultDrawingSupplier34.getNextShape();
        dateAxis1.setRightArrow(shape36);
        dateAxis1.setUpperBound((double) 'a');
        dateAxis1.centerRange((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str26.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shapeArray33);
        org.junit.Assert.assertNotNull(shape36);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            day0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis26.setMarkerBand(markerAxisBand31);
        numberAxis26.setLowerBound((double) ' ');
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        categoryPlot0.setInsets(rectangleInsets6);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            rectangleInsets6.trim(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis4.setMinimumDate(date13);
        double double15 = dateAxis4.getUpperBound();
        int int16 = objectList0.indexOf((java.lang.Object) double15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot4.markerChanged(markerChangeEvent21);
        java.awt.Stroke stroke23 = categoryPlot4.getRangeGridlineStroke();
        java.lang.String str24 = categoryPlot4.getNoDataMessage();
        categoryPlot4.setForegroundAlpha((float) 1560538799999L);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        dateAxis1.setUpperMargin((double) 500);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getMonth();
//        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
//        int int10 = categoryPlot8.getIndexOf(categoryItemRenderer9);
//        java.lang.Object obj11 = categoryPlot8.clone();
//        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot8.getFixedDomainAxisSpace();
//        java.awt.Paint paint13 = categoryPlot8.getRangeCrosshairPaint();
//        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        java.awt.Paint paint15 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
//        int int22 = categoryPlot20.getIndexOf(categoryItemRenderer21);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
//        categoryPlot20.setRenderer((int) (short) 10, categoryItemRenderer24, true);
//        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.geom.Rectangle2D rectangle2D30 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
//        double double32 = dateAxis28.valueToJava2D(10.0d, rectangle2D30, rectangleEdge31);
//        dateAxis28.setAutoTickUnitSelection(true);
//        categoryPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis28);
//        java.awt.Stroke stroke36 = categoryPlot20.getDomainGridlineStroke();
//        try {
//            org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) int3, paint13, stroke14, paint15, stroke36, (float) 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNull(axisSpace12);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertNotNull(stroke14);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertNotNull(stroke36);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.java2DToValue(0.0d, rectangle2D5, rectangleEdge6);
        java.awt.Shape shape8 = dateAxis3.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        int int18 = categoryPlot16.getIndexOf(categoryItemRenderer17);
        int int19 = categoryPlot16.getDomainAxisCount();
        categoryPlot16.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot16.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot16.getLegendItems();
        categoryPlot11.setFixedLegendItems(legendItemCollection25);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection25);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.plot.Plot plot6 = dateAxis1.getPlot();
        dateAxis1.setTickMarkOutsideLength((float) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        dateAxis1.setLabelInsets(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot27.getAxisOffset();
        categoryPlot22.setInsets(rectangleInsets28);
        boolean boolean30 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str33 = axisLocation32.toString();
        categoryPlot22.setRangeAxisLocation(9, axisLocation32);
        categoryPlot4.setDomainAxisLocation(0, axisLocation32, false);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        int int43 = categoryPlot41.getIndexOf(categoryItemRenderer42);
        int int44 = categoryPlot41.getDomainAxisCount();
        categoryPlot41.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray48 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot41.setRenderers(categoryItemRendererArray48);
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation50, plotOrientation51);
        categoryPlot41.setDomainAxisLocation(axisLocation50, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType55 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str56 = lengthAdjustmentType55.toString();
        boolean boolean57 = axisLocation50.equals((java.lang.Object) lengthAdjustmentType55);
        categoryPlot4.setRangeAxisLocation(axisLocation50, true);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str33.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray48);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(plotOrientation51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(lengthAdjustmentType55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "NO_CHANGE" + "'", str56.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        double double8 = rectangleInsets6.calculateRightOutset(0.0d);
        dateAxis0.setTickLabelInsets(rectangleInsets6);
        double double11 = rectangleInsets6.calculateTopInset((double) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis12.valueToJava2D(10.0d, rectangle2D14, rectangleEdge15);
        dateAxis12.setAutoTickUnitSelection(true);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.lang.Object obj20 = categoryPlot4.clone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(obj20);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.resizeRange((double) (short) 10, 0.0d);
        double double9 = dateAxis1.getFixedDimension();
        dateAxis1.setRange((double) (-16777216), (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        valueMarker1.setValue((double) (-2));
        java.awt.Paint paint5 = valueMarker1.getOutlinePaint();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        categoryPlot4.setAnchorValue((double) (-1L));
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(sortOrder10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo2, point2D3, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis7.configure();
        categoryAxis7.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis12.configure();
        categoryAxis12.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis12.getCategoryLabelPositions();
        categoryAxis7.setCategoryLabelPositions(categoryLabelPositions16);
        categoryAxis7.setLabelToolTip("java.awt.Color[r=0,g=0,b=255]");
        java.util.List list20 = categoryPlot0.getCategoriesForAxis(categoryAxis7);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.Point2D point2D23 = null;
        org.jfree.chart.plot.PlotState plotState24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            categoryPlot0.draw(graphics2D21, rectangle2D22, point2D23, plotState24, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot4.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot4.addDomainMarker(categoryMarker15);
        org.jfree.chart.text.TextAnchor textAnchor17 = categoryMarker15.getLabelTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor18 = categoryMarker15.getLabelTextAnchor();
        java.lang.Comparable comparable19 = null;
        try {
            categoryMarker15.setKey(comparable19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (short) 0, marker12, layer13);
        org.jfree.chart.plot.Plot plot15 = categoryPlot4.getParent();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color17 = color16.darker();
        try {
            plot15.setOutlinePaint((java.awt.Paint) color17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = plotChangeEvent9.getType();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        java.lang.Object obj7 = categoryPlot4.clone();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        try {
            categoryPlot4.zoom(9.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(axisSpace8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis6.getStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = dateAxis14.valueToJava2D(10.0d, rectangle2D16, rectangleEdge17);
        dateAxis14.setAutoTickUnitSelection(true);
        java.util.Date date21 = dateAxis14.getMaximumDate();
        dateAxis14.setFixedDimension(0.0d);
        org.jfree.chart.axis.Timeline timeline24 = dateAxis14.getTimeline();
        dateAxis1.setTimeline(timeline24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeline24);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        java.text.DateFormat dateFormat12 = null;
        dateAxis1.setDateFormatOverride(dateFormat12);
        java.text.DateFormat dateFormat14 = dateAxis1.getDateFormatOverride();
        double double15 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(dateFormat14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot4.markerChanged(markerChangeEvent21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str25 = datasetRenderingOrder24.toString();
        java.lang.Object obj26 = null;
        boolean boolean27 = datasetRenderingOrder24.equals(obj26);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder24);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str25.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRenderer();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        java.lang.String str11 = sortOrder10.toString();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "SortOrder.ASCENDING" + "'", str11.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            xYPlot31.drawBackground(graphics2D32, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        boolean boolean3 = categoryAxis1.isVisible();
        java.lang.Object obj4 = categoryAxis1.clone();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ChartChangeEventType.GENERAL");
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.java2DToValue(0.0d, rectangle2D5, rectangleEdge6);
        java.awt.Shape shape8 = dateAxis3.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        dateAxis3.setFixedAutoRange(8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        java.lang.Object obj7 = categoryPlot4.clone();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray15 = null;
        float[] floatArray16 = color14.getComponents(floatArray15);
        float[] floatArray17 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray16);
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke19);
        float float21 = valueMarker20.getAlpha();
        boolean boolean22 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        categoryPlot4.mapDatasetToRangeAxis((int) '#', (int) '4');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        boolean boolean29 = numberAxis26.getAutoRangeIncludesZero();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot36.getIndexOf(categoryItemRenderer37);
        int int39 = categoryPlot36.getDomainAxisCount();
        categoryPlot36.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot36.setBackgroundImageAlignment(12);
        int int45 = categoryPlot36.getDatasetCount();
        categoryPlot36.clearRangeMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        categoryPlot36.setDataset((int) '4', categoryDataset48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot36.getDomainAxisEdge();
        try {
            double double51 = numberAxis26.valueToJava2D((double) 2019, rectangle2D31, rectangleEdge50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot5.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot9 = categoryPlot5.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot5.getRowRenderingOrder();
        boolean boolean12 = dateAxis0.hasListener((java.util.EventListener) categoryPlot5);
        categoryPlot5.setBackgroundImageAlignment((-2));
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker4.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot10.getIndexOf(categoryItemRenderer11);
        int int13 = categoryPlot10.getDomainAxisCount();
        categoryPlot10.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot10.setRenderers(categoryItemRendererArray17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation20);
        categoryPlot10.setDomainAxisLocation(axisLocation19, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str25 = lengthAdjustmentType24.toString();
        boolean boolean26 = axisLocation19.equals((java.lang.Object) lengthAdjustmentType24);
        valueMarker4.setLabelOffsetType(lengthAdjustmentType24);
        try {
            java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "NO_CHANGE" + "'", str25.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, true);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot22.getIndexOf(categoryItemRenderer23);
        int int25 = categoryPlot22.getDomainAxisCount();
        categoryPlot22.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot22.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot22.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot22.addDomainMarker(categoryMarker33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        int int41 = categoryPlot39.getIndexOf(categoryItemRenderer40);
        int int42 = categoryPlot39.getDomainAxisCount();
        categoryPlot39.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Font font46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot39.setNoDataMessageFont(font46);
        categoryMarker33.setLabelFont(font46);
        org.jfree.chart.util.Layer layer49 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker33, layer49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection31);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(font46);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        dateAxis1.setLabelInsets(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes(100.0d, (double) (-1.0f), plotRenderingInfo9, point2D10);
        categoryPlot4.setRangeCrosshairValue((double) (-1));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot4.setRenderer(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        categoryPlot4.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot4.zoomDomainAxes((double) 15, plotRenderingInfo8, point2D9, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        try {
            categoryPlot4.setRenderer((int) (byte) -1, categoryItemRenderer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot4.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot4.addDomainMarker(categoryMarker15);
        org.jfree.chart.text.TextAnchor textAnchor17 = categoryMarker15.getLabelTextAnchor();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray24 = null;
        float[] floatArray25 = color23.getComponents(floatArray24);
        float[] floatArray26 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray25);
        float[] floatArray27 = color19.getRGBColorComponents(floatArray26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color19, stroke28);
        categoryMarker15.setOutlineStroke(stroke28);
        categoryMarker15.setDrawAsLine(false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        categoryAxis1.setTickMarkOutsideLength((float) 0);
        double double7 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot27.getAxisOffset();
        categoryPlot22.setInsets(rectangleInsets28);
        boolean boolean30 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str33 = axisLocation32.toString();
        categoryPlot22.setRangeAxisLocation(9, axisLocation32);
        categoryPlot4.setDomainAxisLocation(0, axisLocation32, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot4.getIndexOf(categoryItemRenderer37);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str33.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        double double3 = intervalMarker2.getStartValue();
        java.lang.Object obj4 = intervalMarker2.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis1.setMaximumCategoryLabelLines(6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color8, paint9, paint10 };
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str13 = color12.toString();
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color12, paint14 };
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] {};
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape18, shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray15, strokeArray16, strokeArray17, shapeArray20);
        java.lang.Class<?> wildcardClass22 = strokeArray17.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.lang.Class class24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = dateAxis28.valueToJava2D(10.0d, rectangle2D30, rectangleEdge31);
        dateAxis28.setAutoTickUnitSelection(true);
        java.util.Date date35 = dateAxis28.getMaximumDate();
        dateAxis26.setMinimumDate(date35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date35, timeZone37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date35, timeZone39);
        java.awt.Font font41 = categoryAxis1.getTickLabelFont((java.lang.Comparable) date35);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str13.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(font41);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (short) 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot4.notifyListeners(plotChangeEvent7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot4.setDataset(0, categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categoryAxis13);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        dateAxis1.setAutoRangeMinimumSize((double) 3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace9);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        categoryPlot4.setDomainGridlinesVisible(false);
        boolean boolean13 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Category Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Category Plot\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        numberAxis26.setAutoRangeStickyZero(false);
        java.awt.Paint paint33 = numberAxis26.getTickLabelPaint();
        numberAxis26.setAutoRangeStickyZero(false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        categoryPlot4.drawBackgroundImage(graphics2D11, rectangle2D12);
        try {
            categoryPlot4.zoom((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.clearRangeAxes();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE", timeZone15);
        java.lang.String str17 = dateAxis16.getLabelToolTip();
        int int18 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        int int19 = categoryPlot4.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = valueMarker2.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        int int10 = categoryPlot8.getIndexOf(categoryItemRenderer9);
        int int11 = categoryPlot8.getDomainAxisCount();
        categoryPlot8.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray15 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation17, plotOrientation18);
        categoryPlot8.setDomainAxisLocation(axisLocation17, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str23 = lengthAdjustmentType22.toString();
        boolean boolean24 = axisLocation17.equals((java.lang.Object) lengthAdjustmentType22);
        valueMarker2.setLabelOffsetType(lengthAdjustmentType22);
        valueMarker2.setValue(10.0d);
        java.awt.Color color28 = java.awt.Color.magenta;
        boolean boolean29 = valueMarker2.equals((java.lang.Object) color28);
        boolean boolean30 = unitType0.equals((java.lang.Object) color28);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "NO_CHANGE" + "'", str23.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot5.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot9 = categoryPlot5.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot5.getRowRenderingOrder();
        boolean boolean12 = dateAxis0.hasListener((java.util.EventListener) categoryPlot5);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis20.java2DToValue(0.0d, rectangle2D22, rectangleEdge23);
        java.awt.Shape shape25 = dateAxis20.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = dateAxis20.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot28.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            org.jfree.chart.axis.AxisState axisState31 = dateAxis0.draw(graphics2D13, (double) (byte) -1, rectangle2D15, rectangle2D16, rectangleEdge29, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo2, point2D3, true);
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat9 = null;
        dateAxis8.setDateFormatOverride(dateFormat9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryPlot15.getAxisOffset();
        double double17 = rectangleInsets16.getTop();
        dateAxis8.setLabelInsets(rectangleInsets16);
        categoryPlot0.setAxisOffset(rectangleInsets16);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str23 = lengthAdjustmentType22.toString();
        java.awt.Paint[] paintArray24 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        boolean boolean25 = lengthAdjustmentType22.equals((java.lang.Object) paintArray24);
        java.lang.String str26 = lengthAdjustmentType22.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets16.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType21, lengthAdjustmentType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "NO_CHANGE" + "'", str23.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "NO_CHANGE" + "'", str26.equals("NO_CHANGE"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        boolean boolean11 = categoryPlot4.isOutlineVisible();
        categoryPlot4.setBackgroundAlpha((float) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot22.getIndexOf(categoryItemRenderer23);
        int int25 = categoryPlot22.getDomainAxisCount();
        categoryPlot22.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray29 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot22.setRenderers(categoryItemRendererArray29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation31, plotOrientation32);
        categoryPlot22.setDomainAxisLocation(axisLocation31, false);
        java.awt.Paint paint36 = categoryPlot22.getOutlinePaint();
        categoryAxis16.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint36);
        int int38 = categoryAxis16.getCategoryLabelPositionOffset();
        try {
            categoryPlot4.setDomainAxis((int) (byte) -1, categoryAxis16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        boolean boolean6 = dateAxis1.isNegativeArrowVisible();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot11.getAxisOffset();
        java.awt.Stroke stroke13 = categoryPlot11.getDomainGridlineStroke();
        java.awt.Image image14 = categoryPlot11.getBackgroundImage();
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        boolean boolean16 = categoryPlot11.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        boolean boolean3 = categoryPlot0.removeDomainMarker(marker1, layer2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset(6);
        categoryPlot0.configureRangeAxes();
        java.awt.Paint paint7 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        categoryAxis1.configure();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        int int26 = day24.getYear();
        java.lang.String str27 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day24);
        java.awt.Paint paint28 = categoryAxis1.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot4.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot4.addDomainMarker(categoryMarker15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        int int23 = categoryPlot21.getIndexOf(categoryItemRenderer22);
        int int24 = categoryPlot21.getDomainAxisCount();
        categoryPlot21.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot21.setNoDataMessageFont(font28);
        categoryMarker15.setLabelFont(font28);
        categoryMarker15.setKey((java.lang.Comparable) 'a');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace40 = xYPlot31.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(axisSpace40);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 10.0d, dataset1);
        java.lang.String str3 = datasetChangeEvent2.toString();
        java.lang.String str4 = datasetChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=10.0]" + "'", str3.equals("org.jfree.data.general.DatasetChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=10.0]" + "'", str4.equals("org.jfree.data.general.DatasetChangeEvent[source=10.0]"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        java.awt.Paint paint89 = xYPlot31.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace90 = null;
        xYPlot31.setFixedRangeAxisSpace(axisSpace90);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertNotNull(paint89);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot4.markerChanged(markerChangeEvent21);
        java.awt.Stroke stroke23 = categoryPlot4.getRangeGridlineStroke();
        java.lang.String str24 = categoryPlot4.getNoDataMessage();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot4.getRangeAxisLocation();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.awt.Paint paint29 = numberAxis26.getTickLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        int int36 = categoryPlot34.getIndexOf(categoryItemRenderer35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot34.zoomDomainAxes(100.0d, (double) (-1.0f), plotRenderingInfo39, point2D40);
        numberAxis26.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        numberAxis26.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        float float25 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        dateAxis1.setAutoTickUnitSelection(false);
        java.lang.Object obj5 = dateAxis1.clone();
        try {
            dateAxis1.setRange(0.0d, (double) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) -1, (double) 12, 1.0E-8d, (double) (byte) 0);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        java.lang.Object obj7 = categoryPlot4.clone();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray15 = null;
        float[] floatArray16 = color14.getComponents(floatArray15);
        float[] floatArray17 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray16);
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke19);
        float float21 = valueMarker20.getAlpha();
        boolean boolean22 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        java.awt.Stroke stroke23 = categoryPlot4.getOutlineStroke();
        org.jfree.data.general.Dataset dataset25 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 10.0d, dataset25);
        java.lang.String str27 = datasetChangeEvent26.toString();
        categoryPlot4.datasetChanged(datasetChangeEvent26);
        boolean boolean29 = categoryPlot4.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=10.0]" + "'", str27.equals("org.jfree.data.general.DatasetChangeEvent[source=10.0]"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        boolean boolean33 = xYPlot31.isDomainZoomable();
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 10.0d, dataset35);
        java.lang.String str37 = datasetChangeEvent36.toString();
        xYPlot31.datasetChanged(datasetChangeEvent36);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=10.0]" + "'", str37.equals("org.jfree.data.general.DatasetChangeEvent[source=10.0]"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        categoryPlot0.setInsets(rectangleInsets6);
        double double8 = rectangleInsets6.getBottom();
        double double10 = rectangleInsets6.calculateBottomOutset((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        boolean boolean29 = numberAxis26.getAutoRangeIncludesZero();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot36.getIndexOf(categoryItemRenderer37);
        int int39 = categoryPlot36.getDomainAxisCount();
        categoryPlot36.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot36.setBackgroundImageAlignment(12);
        int int45 = categoryPlot36.getDatasetCount();
        categoryPlot36.clearRangeMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        categoryPlot36.setDataset((int) '4', categoryDataset48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot36.getDomainAxisEdge();
        try {
            double double51 = numberAxis26.valueToJava2D((double) (short) -1, rectangle2D31, rectangleEdge50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) -1, (double) 12, 1.0E-8d, (double) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot10.getIndexOf(categoryItemRenderer11);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot10.setRangeAxes(valueAxisArray13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot10.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent17);
        java.lang.String str19 = categoryPlot10.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot10.setDataset((int) (short) 100, categoryDataset21);
        boolean boolean23 = unitType0.equals((java.lang.Object) categoryPlot10);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Category Plot" + "'", str19.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis1.setLabelURL("SortOrder.ASCENDING");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
//        long long7 = regularTimePeriod6.getMiddleMillisecond();
//        long long8 = regularTimePeriod6.getMiddleMillisecond();
//        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
//        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
//        int int18 = categoryPlot16.getIndexOf(categoryItemRenderer17);
//        int int19 = categoryPlot16.getDomainAxisCount();
//        categoryPlot16.setRangeCrosshairValue((double) (short) 100, false);
//        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
//        categoryPlot16.setRenderers(categoryItemRendererArray23);
//        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        org.jfree.chart.plot.PlotOrientation plotOrientation26 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
//        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation25, plotOrientation26);
//        categoryPlot16.setDomainAxisLocation(axisLocation25, false);
//        java.awt.Paint paint30 = categoryPlot16.getOutlinePaint();
//        categoryAxis10.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint30);
//        double double32 = categoryAxis10.getCategoryMargin();
//        categoryAxis10.configure();
//        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
//        boolean boolean36 = numberAxis35.isInverted();
//        boolean boolean37 = categoryAxis10.equals((java.lang.Object) numberAxis35);
//        java.text.NumberFormat numberFormat38 = null;
//        numberAxis35.setNumberFormatOverride(numberFormat38);
//        numberAxis35.setAutoRangeStickyZero(false);
//        java.text.NumberFormat numberFormat42 = numberAxis35.getNumberFormatOverride();
//        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
//        boolean boolean44 = numberAxis35.equals((java.lang.Object) paint43);
//        categoryAxis1.setTickLabelPaint((java.lang.Comparable) long8, paint43);
//        categoryAxis1.setTickMarkInsideLength(0.5f);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560538799999L + "'", long7 == 1560538799999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560538799999L + "'", long8 == 1560538799999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
//        org.junit.Assert.assertNotNull(axisLocation25);
//        org.junit.Assert.assertNotNull(plotOrientation26);
//        org.junit.Assert.assertNotNull(rectangleEdge27);
//        org.junit.Assert.assertNotNull(paint30);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.2d + "'", double32 == 0.2d);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNull(numberFormat42);
//        org.junit.Assert.assertNotNull(paint43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, false);
        float float18 = categoryPlot4.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        objectList1.clear();
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickMarksVisible();
        boolean boolean3 = dateAxis1.isInverted();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        java.util.Date date8 = regularTimePeriod6.getStart();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis13.java2DToValue(0.0d, rectangle2D15, rectangleEdge16);
        java.awt.Shape shape18 = dateAxis13.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis13.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot21.getDomainAxisEdge();
        try {
            double double23 = dateAxis1.dateToJava2D(date8, rectangle2D9, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getOutlinePaint();
        boolean boolean6 = categoryPlot4.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot4.getDomainAxis((int) (byte) 10);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryAxis9);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        int int2 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.trimWidth((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        int int2 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        long long4 = regularTimePeriod3.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        boolean boolean29 = numberAxis26.getAutoRangeIncludesZero();
        double double30 = numberAxis26.getLowerMargin();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset((int) '4', categoryDataset16);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot4.getDomainMarkers(6, layer19);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(collection20);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis17.setLabel("");
        categoryPlot4.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis17, false);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        int int28 = categoryPlot26.getIndexOf(categoryItemRenderer27);
        int int29 = categoryPlot26.getDomainAxisCount();
        categoryPlot26.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot26.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot26.getLegendItems();
        categoryPlot4.setFixedLegendItems(legendItemCollection35);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = null;
        categoryPlot4.axisChanged(axisChangeEvent37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot4.getDomainAxisLocation(8);
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot4.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(axisLocation41);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis90 = xYPlot31.getRangeAxisForDataset(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 13 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot4.getLegendItems();
        categoryPlot4.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection14);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.axis.ValueAxis valueAxis54 = xYPlot31.getDomainAxisForDataset(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation55 = null;
        try {
            xYPlot31.addAnnotation(xYAnnotation55, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(valueAxis54);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        numberAxis26.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat33 = numberAxis26.getNumberFormatOverride();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean35 = numberAxis26.equals((java.lang.Object) paint34);
        double double36 = numberAxis26.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = dateAxis38.valueToJava2D(10.0d, rectangle2D40, rectangleEdge41);
        dateAxis38.resizeRange((double) (short) 10, 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean48 = dateAxis47.isTickMarksVisible();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = dateAxis50.java2DToValue(0.0d, rectangle2D52, rectangleEdge53);
        dateAxis50.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, valueAxis59, categoryItemRenderer60);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        int int63 = categoryPlot61.getIndexOf(categoryItemRenderer62);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        categoryPlot61.setRenderer((int) (short) 10, categoryItemRenderer65, true);
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        double double73 = dateAxis69.valueToJava2D(10.0d, rectangle2D71, rectangleEdge72);
        dateAxis69.setAutoTickUnitSelection(true);
        categoryPlot61.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis69);
        java.awt.Font font77 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot61.setNoDataMessageFont(font77);
        dateAxis50.setTickLabelFont(font77);
        org.jfree.data.Range range80 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis50.setRange(range80);
        dateAxis47.setRange(range80, true, false);
        dateAxis38.setRange(range80, false, false);
        numberAxis26.setRange(range80);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(numberFormat33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(range80);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE", timeZone1);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone1);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        java.lang.Comparable comparable24 = null;
        try {
            categoryAxis1.addCategoryLabelToolTip(comparable24, "java.awt.Color[r=0,g=0,b=128]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        categoryPlot4.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot4.zoomDomainAxes((double) 15, plotRenderingInfo8, point2D9, false);
        boolean boolean12 = categoryPlot4.isSubplot();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot4.getRenderer();
        categoryPlot4.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(categoryItemRenderer11, true);
        int int14 = categoryPlot4.getWeight();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis17.setLabel("");
        categoryPlot4.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis17, false);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        int int28 = categoryPlot26.getIndexOf(categoryItemRenderer27);
        int int29 = categoryPlot26.getDomainAxisCount();
        categoryPlot26.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot26.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot26.getLegendItems();
        categoryPlot4.setFixedLegendItems(legendItemCollection35);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = null;
        categoryPlot4.axisChanged(axisChangeEvent37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot4.getDomainAxisLocation(8);
        java.lang.String str41 = categoryPlot4.getPlotType();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Category Plot" + "'", str41.equals("Category Plot"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot18.getIndexOf(categoryItemRenderer19);
        int int21 = categoryPlot18.getDomainAxisCount();
        categoryPlot18.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot18.getDomainMarkers(layer25);
        categoryPlot18.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        int int37 = categoryPlot35.getIndexOf(categoryItemRenderer36);
        int int38 = categoryPlot35.getDomainAxisCount();
        categoryPlot35.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot35.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot35.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot35.addDomainMarker(categoryMarker46);
        org.jfree.chart.util.Layer layer48 = null;
        categoryPlot18.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker46, layer48, false);
        boolean boolean51 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker46);
        java.lang.Comparable comparable52 = null;
        try {
            categoryMarker46.setKey(comparable52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        java.awt.Paint[] paintArray4 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color5, paint6, paint7 };
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str10 = color9.toString();
        java.awt.Paint paint11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color9, paint11 };
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray17 = new java.awt.Shape[] { shape15, shape16 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray12, strokeArray13, strokeArray14, shapeArray17);
        java.awt.Stroke[] strokeArray19 = null;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot25.getIndexOf(categoryItemRenderer26);
        int int28 = categoryPlot25.getDomainAxisCount();
        categoryPlot25.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot25.setBackgroundImageAlignment(12);
        int int34 = categoryPlot25.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot25.setFixedRangeAxisSpace(axisSpace35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        categoryPlot25.setDomainAxis(9, categoryAxis38, true);
        java.awt.Paint paint41 = categoryPlot25.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot25.getDomainAxisLocation();
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot25.setDomainGridlineStroke(stroke43);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray46 = new java.awt.Stroke[] { stroke20, stroke43, stroke45 };
        java.awt.Shape[] shapeArray47 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray12, strokeArray19, strokeArray46, shapeArray47);
        boolean boolean49 = dateAxis1.equals((java.lang.Object) paintArray12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str10.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shapeArray17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(shapeArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = dateAxis33.java2DToValue(0.0d, rectangle2D35, rectangleEdge36);
        dateAxis33.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        int int46 = categoryPlot44.getIndexOf(categoryItemRenderer45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        categoryPlot44.setRenderer((int) (short) 10, categoryItemRenderer48, true);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = dateAxis52.valueToJava2D(10.0d, rectangle2D54, rectangleEdge55);
        dateAxis52.setAutoTickUnitSelection(true);
        categoryPlot44.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis52);
        java.awt.Font font60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot44.setNoDataMessageFont(font60);
        dateAxis33.setTickLabelFont(font60);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis33.setRange(range63);
        java.lang.Object obj65 = dateAxis33.clone();
        boolean boolean66 = dateAxis33.isNegativeArrowVisible();
        int int67 = xYPlot31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        xYPlot31.setRenderer(255, xYItemRenderer69, true);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis73 = xYPlot31.getRangeAxisForDataset((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(obj65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        xYPlot31.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis91 = null;
        xYPlot31.setRangeAxis(9, valueAxis91);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.java2DToValue(0.0d, rectangle2D19, rectangleEdge20);
        java.awt.Shape shape22 = dateAxis17.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = dateAxis17.getLabelInsets();
        java.awt.Stroke stroke24 = dateAxis17.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = dateAxis26.valueToJava2D(10.0d, rectangle2D28, rectangleEdge29);
        dateAxis26.setAutoTickUnitSelection(true);
        java.util.Date date33 = dateAxis26.getMaximumDate();
        dateAxis26.setFixedDimension(0.0d);
        org.jfree.chart.axis.Timeline timeline36 = dateAxis26.getTimeline();
        dateAxis17.setTimeline(timeline36);
        java.awt.Font font38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis17.setLabelFont(font38);
        categoryPlot4.setNoDataMessageFont(font38);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeline36);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot4.markerChanged(markerChangeEvent21);
        categoryPlot4.clearAnnotations();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis6.getStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource11);
        dateAxis1.setAutoRangeMinimumSize((double) 100);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape15);
        dateAxis1.zoomRange((double) 0, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color0, paint1, paint2 };
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str5 = color4.toString();
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color4, paint6 };
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] {};
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray12 = new java.awt.Shape[] { shape10, shape11 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray7, strokeArray8, strokeArray9, shapeArray12);
        java.lang.Class<?> wildcardClass14 = strokeArray9.getClass();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = dateAxis16.valueToJava2D(10.0d, rectangle2D18, rectangleEdge19);
        dateAxis16.setAutoTickUnitSelection(true);
        java.util.Date date23 = dateAxis16.getMaximumDate();
        dateAxis16.resizeRange(100.0d);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
        java.util.Date date28 = regularTimePeriod27.getEnd();
        dateAxis16.setMinimumDate(date28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date28, timeZone30);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str5.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        dateAxis1.setAutoTickUnitSelection(false, false);
        java.awt.Stroke stroke7 = null;
        try {
            dateAxis1.setAxisLineStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        categoryPlot4.clearDomainAxes();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        boolean boolean11 = categoryPlot4.render(graphics2D7, rectangle2D8, 15, plotRenderingInfo10);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        xYPlot31.clearDomainMarkers();
        java.awt.Color color90 = java.awt.Color.darkGray;
        int int91 = color90.getTransparency();
        boolean boolean92 = xYPlot31.equals((java.lang.Object) int91);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertNotNull(color90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        boolean boolean14 = categoryPlot4.isRangeCrosshairVisible();
        double double15 = categoryPlot4.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot4.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = xYPlot31.getRangeAxisEdge();
        java.awt.Stroke stroke90 = null;
        try {
            xYPlot31.setRangeGridlineStroke(stroke90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertNotNull(rectangleEdge89);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot4.getRangeMarkers(layer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis17.configure();
        categoryAxis17.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis22.configure();
        categoryAxis22.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = categoryAxis22.getCategoryLabelPositions();
        categoryAxis17.setCategoryLabelPositions(categoryLabelPositions26);
        categoryAxis17.setLabelToolTip("NO_CHANGE");
        categoryPlot4.setDomainAxis((int) (short) 0, categoryAxis17);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D2, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        org.jfree.chart.util.ObjectList objectList43 = new org.jfree.chart.util.ObjectList();
        boolean boolean45 = objectList43.equals((java.lang.Object) 100L);
        int int46 = objectList43.size();
        boolean boolean47 = intervalMarker42.equals((java.lang.Object) objectList43);
        intervalMarker42.setStartValue((double) (short) -1);
        org.jfree.chart.util.Layer layer50 = null;
        try {
            xYPlot31.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42, layer50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        java.awt.Paint paint21 = defaultDrawingSupplier19.getNextPaint();
        try {
            java.awt.Stroke stroke22 = defaultDrawingSupplier19.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        categoryPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot4.getRangeAxisEdge();
        java.awt.Paint paint14 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        int int22 = categoryPlot20.getIndexOf(categoryItemRenderer21);
        int int23 = categoryPlot20.getDomainAxisCount();
        categoryPlot20.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot20.setBackgroundImageAlignment(12);
        int int29 = categoryPlot20.getDatasetCount();
        java.util.List list30 = categoryPlot20.getAnnotations();
        categoryPlot20.setForegroundAlpha((float) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot20.setDomainAxis(0, categoryAxis35, true);
        categoryPlot4.setDomainAxis((int) '4', categoryAxis35, false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.Font font2 = numberAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str22 = lengthAdjustmentType21.toString();
        boolean boolean23 = axisLocation16.equals((java.lang.Object) lengthAdjustmentType21);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType21);
        valueMarker1.setValue(10.0d);
        java.awt.Color color27 = java.awt.Color.magenta;
        boolean boolean28 = valueMarker1.equals((java.lang.Object) color27);
        java.awt.Paint paint29 = null;
        valueMarker1.setOutlinePaint(paint29);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "NO_CHANGE" + "'", str22.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double7 = rectangleInsets5.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-8.0d) + "'", double7 == (-8.0d));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot4.setDataset((int) (short) 100, categoryDataset15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot21.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot25 = categoryPlot21.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot21);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        plotChangeEvent26.setChart(jFreeChart27);
        categoryPlot4.notifyListeners(plotChangeEvent26);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(plot25);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("NO_CHANGE");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double2 = rectangleInsets0.getRight();
        double double4 = rectangleInsets0.calculateRightInset((double) 4);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        java.awt.Stroke stroke6 = categoryPlot4.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis8.java2DToValue(0.0d, rectangle2D10, rectangleEdge11);
        java.awt.Shape shape13 = dateAxis8.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis8.getLabelInsets();
        categoryPlot4.setInsets(rectangleInsets14, false);
        categoryPlot4.clearDomainMarkers((int) '#');
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot4.removeChangeListener(plotChangeListener19);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double6 = rectangleInsets5.getTop();
        double double8 = rectangleInsets5.trimHeight((double) (byte) 10);
        double double9 = rectangleInsets5.getRight();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets5.createInsetRectangle(rectangle2D10, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double6 = rectangleInsets5.getTop();
        double double8 = rectangleInsets5.extendHeight((double) 1);
        double double10 = rectangleInsets5.trimHeight((double) 15);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            rectangleInsets5.trim(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.0d + "'", double8 == 9.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 7.0d + "'", double10 == 7.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabel("");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getRangeAxisLocation();
        java.lang.String str10 = axisLocation9.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str10.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        int int2 = day0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        dateAxis1.setRangeWithMargins(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        categoryPlot4.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot4.getRangeAxisEdge();
        java.awt.Paint paint14 = categoryPlot4.getRangeGridlinePaint();
        categoryPlot4.clearAnnotations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint14);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList();
        boolean boolean5 = objectList3.equals((java.lang.Object) 100L);
        int int6 = objectList3.size();
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) objectList3);
        java.awt.Color color9 = java.awt.Color.BLUE;
        java.awt.Color color10 = java.awt.Color.getColor("hi!", color9);
        intervalMarker2.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(9.0d);
        boolean boolean14 = intervalMarker2.equals((java.lang.Object) valueMarker13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        java.awt.Stroke stroke59 = xYPlot31.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = null;
        double double68 = dateAxis64.valueToJava2D(10.0d, rectangle2D66, rectangleEdge67);
        dateAxis64.setAutoTickUnitSelection(true);
        java.util.Date date71 = dateAxis64.getMaximumDate();
        dateAxis64.setTickMarkInsideLength((float) ' ');
        double double74 = dateAxis64.getAutoRangeMinimumSize();
        float float75 = dateAxis64.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis79 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = null;
        double double83 = dateAxis79.valueToJava2D(10.0d, rectangle2D81, rectangleEdge82);
        dateAxis79.setAutoTickUnitSelection(true);
        java.util.Date date86 = dateAxis79.getMaximumDate();
        dateAxis77.setMinimumDate(date86);
        double double88 = dateAxis77.getUpperBound();
        java.awt.Font font89 = dateAxis77.getLabelFont();
        dateAxis77.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer92 = null;
        org.jfree.chart.plot.XYPlot xYPlot93 = new org.jfree.chart.plot.XYPlot(xYDataset62, (org.jfree.chart.axis.ValueAxis) dateAxis64, (org.jfree.chart.axis.ValueAxis) dateAxis77, xYItemRenderer92);
        java.awt.geom.Point2D point2D94 = xYPlot93.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 'a', plotRenderingInfo61, point2D94);
        xYPlot31.setWeight((-16777216));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 2.0d + "'", double74 == 2.0d);
        org.junit.Assert.assertTrue("'" + float75 + "' != '" + 32.0f + "'", float75 == 32.0f);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 2.0d + "'", double88 == 2.0d);
        org.junit.Assert.assertNotNull(font89);
        org.junit.Assert.assertNotNull(point2D94);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat4 = null;
        dateAxis3.setDateFormatOverride(dateFormat4);
        dateAxis3.setAutoTickUnitSelection(false, false);
        java.lang.Object obj9 = dateAxis3.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot11.setFixedDomainAxisSpace(axisSpace13, true);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(valueAxis12);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        categoryPlot4.clearDomainMarkers((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot15.getIndexOf(categoryItemRenderer16);
        int int18 = categoryPlot15.getDomainAxisCount();
        categoryPlot15.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot15.setBackgroundImageAlignment(12);
        int int24 = categoryPlot15.getDatasetCount();
        java.util.List list25 = categoryPlot15.getAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot15.getRangeAxisForDataset(1);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot15.getRangeAxisEdge();
        try {
            java.util.List list29 = dateAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo2, point2D3, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis7.configure();
        categoryAxis7.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis12.configure();
        categoryAxis12.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis12.getCategoryLabelPositions();
        categoryAxis7.setCategoryLabelPositions(categoryLabelPositions16);
        categoryAxis7.setLabelToolTip("java.awt.Color[r=0,g=0,b=255]");
        java.util.List list20 = categoryPlot0.getCategoriesForAxis(categoryAxis7);
        categoryAxis7.setCategoryLabelPositionOffset(15);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList();
        boolean boolean20 = objectList18.equals((java.lang.Object) 100L);
        int int21 = objectList18.size();
        boolean boolean22 = intervalMarker17.equals((java.lang.Object) objectList18);
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = null;
        intervalMarker17.setGradientPaintTransformer(gradientPaintTransformer24);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        xYPlot31.setDomainCrosshairValue((double) (-2), false);
        java.awt.geom.Point2D point2D36 = null;
        try {
            xYPlot31.setQuadrantOrigin(point2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        int int23 = categoryPlot21.getIndexOf(categoryItemRenderer22);
        int int24 = categoryPlot21.getDomainAxisCount();
        categoryPlot21.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot21.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = categoryPlot21.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot21.addDomainMarker(categoryMarker32);
        org.jfree.chart.util.Layer layer34 = null;
        categoryPlot4.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker32, layer34, false);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        int int43 = categoryPlot41.getIndexOf(categoryItemRenderer42);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray44 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot41.setRangeAxes(valueAxisArray44);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        categoryPlot41.setFixedDomainAxisSpace(axisSpace46);
        categoryMarker32.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot41);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray44);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot5.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot9 = categoryPlot5.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot5.getRowRenderingOrder();
        boolean boolean12 = dateAxis0.hasListener((java.util.EventListener) categoryPlot5);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        int int16 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot22.getIndexOf(categoryItemRenderer23);
        int int25 = categoryPlot22.getDomainAxisCount();
        categoryPlot22.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray29 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot22.setRenderers(categoryItemRendererArray29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation31, plotOrientation32);
        categoryPlot22.setDomainAxisLocation(axisLocation31, false);
        categoryPlot15.setRangeAxisLocation((int) (byte) 10, axisLocation31);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot15.getRangeAxisEdge(255);
        try {
            double double39 = dateAxis0.lengthToJava2D((double) 9, rectangle2D14, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getMiddleMillisecond();
//        org.jfree.chart.JFreeChart jFreeChart3 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) long2, jFreeChart3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        int int23 = categoryPlot21.getIndexOf(categoryItemRenderer22);
        int int24 = categoryPlot21.getDomainAxisCount();
        categoryPlot21.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot21.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = categoryPlot21.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot21.addDomainMarker(categoryMarker32);
        org.jfree.chart.util.Layer layer34 = null;
        categoryPlot4.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker32, layer34, false);
        boolean boolean37 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot4.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(sortOrder38);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot18.getIndexOf(categoryItemRenderer19);
        int int21 = categoryPlot18.getDomainAxisCount();
        categoryPlot18.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot18.getDomainMarkers(layer25);
        categoryPlot18.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        int int37 = categoryPlot35.getIndexOf(categoryItemRenderer36);
        int int38 = categoryPlot35.getDomainAxisCount();
        categoryPlot35.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot35.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot35.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot35.addDomainMarker(categoryMarker46);
        org.jfree.chart.util.Layer layer48 = null;
        categoryPlot18.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker46, layer48, false);
        boolean boolean51 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker46);
        org.jfree.data.category.CategoryDataset categoryDataset52 = categoryPlot4.getDataset();
        java.awt.Paint paint53 = categoryPlot4.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(categoryDataset52);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot10.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot10.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot14 = categoryPlot10.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot10);
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        plotChangeEvent15.setChart(jFreeChart16);
        categoryPlot4.notifyListeners(plotChangeEvent15);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        boolean boolean14 = categoryPlot4.isRangeCrosshairVisible();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot4.setDomainGridlineStroke(stroke15);
        java.util.List list17 = categoryPlot4.getAnnotations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.awt.Paint paint2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot7.setRangeAxes(valueAxisArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot7.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        categoryPlot7.rendererChanged(rendererChangeEvent14);
        java.lang.String str16 = categoryPlot7.getPlotType();
        boolean boolean17 = categoryPlot7.isRangeCrosshairVisible();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot7.setDomainGridlineStroke(stroke18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.lang.String str21 = color20.toString();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis24.valueToJava2D(10.0d, rectangle2D26, rectangleEdge27);
        dateAxis24.setAutoTickUnitSelection(true);
        java.util.Date date31 = dateAxis24.getMaximumDate();
        dateAxis24.setTickMarkInsideLength((float) ' ');
        double double34 = dateAxis24.getAutoRangeMinimumSize();
        float float35 = dateAxis24.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = dateAxis39.valueToJava2D(10.0d, rectangle2D41, rectangleEdge42);
        dateAxis39.setAutoTickUnitSelection(true);
        java.util.Date date46 = dateAxis39.getMaximumDate();
        dateAxis37.setMinimumDate(date46);
        double double48 = dateAxis37.getUpperBound();
        java.awt.Font font49 = dateAxis37.getLabelFont();
        dateAxis37.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer52);
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker55.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean59 = valueMarker55.equals((java.lang.Object) rectangleInsets58);
        boolean boolean60 = xYPlot53.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker55);
        boolean boolean61 = xYPlot53.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = null;
        double double67 = dateAxis63.valueToJava2D(10.0d, rectangle2D65, rectangleEdge66);
        dateAxis63.setAutoTickUnitSelection(true);
        java.util.Date date70 = dateAxis63.getMaximumDate();
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis63.setTimeZone(timeZone71);
        java.awt.Font font73 = dateAxis63.getTickLabelFont();
        xYPlot53.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis63);
        double double75 = xYPlot53.getDomainCrosshairValue();
        java.awt.Color color77 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color78 = java.awt.Color.getColor("", color77);
        int int79 = color78.getGreen();
        xYPlot53.setRangeCrosshairPaint((java.awt.Paint) color78);
        java.awt.Stroke stroke81 = xYPlot53.getDomainGridlineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker83 = new org.jfree.chart.plot.IntervalMarker(9.0d, (double) (-1L), paint2, stroke18, (java.awt.Paint) color20, stroke81, (float) 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=0,g=0,b=128]" + "'", str21.equals("java.awt.Color[r=0,g=0,b=128]"));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 32.0f + "'", float35 == 32.0f);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 128 + "'", int79 == 128);
        org.junit.Assert.assertNotNull(stroke81);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (short) 0, marker12, layer13);
        int int15 = categoryPlot4.getDatasetCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis12.valueToJava2D(10.0d, rectangle2D14, rectangleEdge15);
        dateAxis12.setAutoTickUnitSelection(true);
        java.util.Date date19 = dateAxis12.getMaximumDate();
        dateAxis12.setTickMarkInsideLength((float) ' ');
        double double22 = dateAxis12.getAutoRangeMinimumSize();
        float float23 = dateAxis12.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = dateAxis27.valueToJava2D(10.0d, rectangle2D29, rectangleEdge30);
        dateAxis27.setAutoTickUnitSelection(true);
        java.util.Date date34 = dateAxis27.getMaximumDate();
        dateAxis25.setMinimumDate(date34);
        double double36 = dateAxis25.getUpperBound();
        java.awt.Font font37 = dateAxis25.getLabelFont();
        dateAxis25.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer40);
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker43.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean47 = valueMarker43.equals((java.lang.Object) rectangleInsets46);
        boolean boolean48 = xYPlot41.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker43);
        boolean boolean49 = xYPlot41.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.valueToJava2D(10.0d, rectangle2D53, rectangleEdge54);
        dateAxis51.setAutoTickUnitSelection(true);
        java.util.Date date58 = dateAxis51.getMaximumDate();
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis51.setTimeZone(timeZone59);
        java.awt.Font font61 = dateAxis51.getTickLabelFont();
        xYPlot41.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = null;
        double double71 = dateAxis67.valueToJava2D(10.0d, rectangle2D69, rectangleEdge70);
        dateAxis67.setAutoTickUnitSelection(true);
        java.util.Date date74 = dateAxis67.getMaximumDate();
        dateAxis67.setTickMarkInsideLength((float) ' ');
        double double77 = dateAxis67.getAutoRangeMinimumSize();
        float float78 = dateAxis67.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis80 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis82 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D84 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = null;
        double double86 = dateAxis82.valueToJava2D(10.0d, rectangle2D84, rectangleEdge85);
        dateAxis82.setAutoTickUnitSelection(true);
        java.util.Date date89 = dateAxis82.getMaximumDate();
        dateAxis80.setMinimumDate(date89);
        double double91 = dateAxis80.getUpperBound();
        java.awt.Font font92 = dateAxis80.getLabelFont();
        dateAxis80.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer95 = null;
        org.jfree.chart.plot.XYPlot xYPlot96 = new org.jfree.chart.plot.XYPlot(xYDataset65, (org.jfree.chart.axis.ValueAxis) dateAxis67, (org.jfree.chart.axis.ValueAxis) dateAxis80, xYItemRenderer95);
        java.awt.geom.Point2D point2D97 = xYPlot96.getQuadrantOrigin();
        xYPlot41.zoomRangeAxes((double) 15, plotRenderingInfo64, point2D97);
        categoryPlot4.zoomRangeAxes((double) '4', plotRenderingInfo9, point2D97);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 32.0f + "'", float23 == 32.0f);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 2.0d + "'", double77 == 2.0d);
        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 32.0f + "'", float78 == 32.0f);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 2.0d + "'", double91 == 2.0d);
        org.junit.Assert.assertNotNull(font92);
        org.junit.Assert.assertNotNull(point2D97);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double7 = rectangleInsets5.calculateBottomInset(0.0d);
        double double9 = rectangleInsets5.extendWidth((double) (short) 1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.0d + "'", double9 == 9.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.plot.Plot plot6 = dateAxis1.getPlot();
        dateAxis1.resizeRange(2.0d, 10.0d);
        double double10 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 9.0d + "'", double10 == 9.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        double double6 = dateAxis5.getUpperBound();
        objectList0.set((int) (short) 1, (java.lang.Object) dateAxis5);
        dateAxis5.setInverted(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Color color2 = java.awt.Color.getColor("ChartChangeEventType.GENERAL", 2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot4.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot15.getIndexOf(categoryItemRenderer16);
        int int18 = categoryPlot15.getDomainAxisCount();
        categoryPlot15.setRangeCrosshairValue((double) (short) 100, false);
        double double22 = categoryPlot15.getRangeCrosshairValue();
        boolean boolean23 = categoryPlot15.isOutlineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot28.getDomainAxis();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color30, paint31, paint32 };
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str35 = color34.toString();
        java.awt.Paint paint36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray37 = new java.awt.Paint[] { color34, paint36 };
        java.awt.Stroke[] strokeArray38 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray39 = new java.awt.Stroke[] {};
        java.awt.Shape shape40 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape41 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray42 = new java.awt.Shape[] { shape40, shape41 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray37, strokeArray38, strokeArray39, shapeArray42);
        categoryPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent45 = null;
        categoryPlot28.markerChanged(markerChangeEvent45);
        org.jfree.chart.util.SortOrder sortOrder47 = categoryPlot28.getRowRenderingOrder();
        categoryPlot15.setRowRenderingOrder(sortOrder47);
        categoryPlot4.setColumnRenderingOrder(sortOrder47);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 100.0d + "'", double22 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str35.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paintArray37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(strokeArray39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(shapeArray42);
        org.junit.Assert.assertNotNull(sortOrder47);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        java.lang.Object obj7 = categoryPlot4.clone();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray15 = null;
        float[] floatArray16 = color14.getComponents(floatArray15);
        float[] floatArray17 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray16);
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke19);
        float float21 = valueMarker20.getAlpha();
        boolean boolean22 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        java.awt.Stroke stroke23 = categoryPlot4.getOutlineStroke();
        org.jfree.data.general.Dataset dataset25 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 10.0d, dataset25);
        java.lang.String str27 = datasetChangeEvent26.toString();
        categoryPlot4.datasetChanged(datasetChangeEvent26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = categoryPlot4.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=10.0]" + "'", str27.equals("org.jfree.data.general.DatasetChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(drawingSupplier29);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        dateAxis1.setAutoTickUnitSelection(false, false);
        java.lang.Object obj7 = dateAxis1.clone();
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis10.valueToJava2D(10.0d, rectangle2D12, rectangleEdge13);
        dateAxis10.resizeRange((double) (short) 10, 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean20 = dateAxis19.isTickMarksVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = dateAxis22.java2DToValue(0.0d, rectangle2D24, rectangleEdge25);
        dateAxis22.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis31, categoryItemRenderer32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        int int35 = categoryPlot33.getIndexOf(categoryItemRenderer34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot33.setRenderer((int) (short) 10, categoryItemRenderer37, true);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        categoryPlot33.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        java.awt.Font font49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot33.setNoDataMessageFont(font49);
        dateAxis22.setTickLabelFont(font49);
        org.jfree.data.Range range52 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis22.setRange(range52);
        dateAxis19.setRange(range52, true, false);
        dateAxis10.setRange(range52, false, false);
        dateAxis1.setRange(range52, true, false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(range52);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets5.getLeft();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        java.awt.Paint paint12 = categoryPlot11.getOutlinePaint();
        boolean boolean13 = rectangleInsets5.equals((java.lang.Object) paint12);
        categoryPlot4.setBackgroundPaint(paint12);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets2.createInsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot4.setDataset(categoryDataset8);
        java.awt.Image image10 = categoryPlot4.getBackgroundImage();
        categoryPlot4.setRangeCrosshairValue((-1.0d), true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot4.setDataset(categoryDataset14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray22 = null;
        float[] floatArray23 = color21.getComponents(floatArray22);
        float[] floatArray24 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray23);
        float[] floatArray25 = color17.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color17, stroke26);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray32 = null;
        float[] floatArray33 = color31.getComponents(floatArray32);
        float[] floatArray34 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray33);
        float[] floatArray35 = color17.getRGBColorComponents(floatArray34);
        categoryPlot4.setRangeGridlinePaint((java.awt.Paint) color17);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        java.awt.Stroke stroke8 = dateAxis1.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis10.valueToJava2D(10.0d, rectangle2D12, rectangleEdge13);
        dateAxis10.setAutoTickUnitSelection(true);
        java.util.Date date17 = dateAxis10.getMaximumDate();
        dateAxis10.setFixedDimension(0.0d);
        org.jfree.chart.axis.Timeline timeline20 = dateAxis10.getTimeline();
        dateAxis1.setTimeline(timeline20);
        dateAxis1.setRangeWithMargins(2.0d, (double) '4');
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeline20);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.valueToJava2D(10.0d, rectangle2D5, rectangleEdge6);
        dateAxis3.setAutoTickUnitSelection(true);
        java.util.Date date10 = dateAxis3.getMaximumDate();
        dateAxis1.setMinimumDate(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10, timeZone12);
        int int14 = day13.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.valueToJava2D(10.0d, rectangle2D5, rectangleEdge6);
        dateAxis3.setAutoTickUnitSelection(true);
        java.util.Date date10 = dateAxis3.getMaximumDate();
        dateAxis1.setMinimumDate(date10);
        double double12 = dateAxis1.getUpperBound();
        java.awt.Paint paint13 = dateAxis1.getLabelPaint();
        java.awt.Paint paint14 = dateAxis1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot31.getRangeAxisLocation();
        xYPlot31.setBackgroundImageAlignment(100);
        xYPlot31.setRangeCrosshairValue(1.0d, true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        int int14 = categoryPlot12.getIndexOf(categoryItemRenderer13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot12.setRenderer((int) (short) 10, categoryItemRenderer16, true);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis20.valueToJava2D(10.0d, rectangle2D22, rectangleEdge23);
        dateAxis20.setAutoTickUnitSelection(true);
        categoryPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot12.setNoDataMessageFont(font28);
        dateAxis1.setTickLabelFont(font28);
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range31);
        java.lang.Object obj33 = dateAxis1.clone();
        boolean boolean34 = dateAxis1.isNegativeArrowVisible();
        double double35 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone10);
        java.awt.Font font12 = dateAxis2.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat15 = null;
        dateAxis14.setDateFormatOverride(dateFormat15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot21.getAxisOffset();
        double double23 = rectangleInsets22.getTop();
        dateAxis14.setLabelInsets(rectangleInsets22);
        java.text.DateFormat dateFormat25 = null;
        dateAxis14.setDateFormatOverride(dateFormat25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer27);
        java.awt.Paint paint29 = xYPlot28.getRangeTickBandPaint();
        boolean boolean30 = xYPlot28.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.configure();
        categoryAxis6.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setUpperMargin(1.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        double double9 = dateAxis8.getUpperBound();
        dateAxis8.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis13.valueToJava2D(10.0d, rectangle2D15, rectangleEdge16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis13.getStandardTickUnits();
        dateAxis8.setStandardTickUnits(tickUnitSource18);
        dateAxis8.setAutoRangeMinimumSize((double) 100);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis8.setLeftArrow(shape22);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis8.setRange(range24);
        dateAxis1.setRangeWithMargins(range24);
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setDownArrow(shape27);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str22 = lengthAdjustmentType21.toString();
        boolean boolean23 = axisLocation16.equals((java.lang.Object) lengthAdjustmentType21);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType21);
        valueMarker1.setValue(10.0d);
        java.awt.Color color27 = java.awt.Color.magenta;
        boolean boolean28 = valueMarker1.equals((java.lang.Object) color27);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str30 = lengthAdjustmentType29.toString();
        valueMarker1.setLabelOffsetType(lengthAdjustmentType29);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "NO_CHANGE" + "'", str22.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "NO_CHANGE" + "'", str30.equals("NO_CHANGE"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        valueMarker1.setValue((double) (-2));
        java.awt.Stroke stroke5 = valueMarker1.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat8 = null;
        dateAxis7.setDateFormatOverride(dateFormat8);
        dateAxis7.setAutoTickUnitSelection(false, false);
        java.awt.Paint paint13 = dateAxis7.getLabelPaint();
        valueMarker1.setOutlinePaint(paint13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker1.getLabelOffset();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis(9, categoryAxis17, true);
        java.awt.Paint paint20 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot4.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation22 = axisLocation21.getOpposite();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (short) 0, marker12, layer13);
        org.jfree.chart.plot.Plot plot15 = categoryPlot4.getParent();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot4.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(sortOrder16);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot12.getDomainAxis();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color14, paint15, paint16 };
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str19 = color18.toString();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color18, paint20 };
        java.awt.Stroke[] strokeArray22 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] {};
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] { shape24, shape25 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray17, paintArray21, strokeArray22, strokeArray23, shapeArray26);
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        categoryPlot12.markerChanged(markerChangeEvent29);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot12.getRowRenderingOrder();
        categoryPlot4.setRowRenderingOrder(sortOrder31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot4.getDomainAxisLocation(11);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker37.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean41 = valueMarker37.equals((java.lang.Object) rectangleInsets40);
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = categoryPlot4.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker37, layer42);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = valueMarker45.getLabelOffsetType();
        valueMarker45.setValue((double) (-2));
        java.awt.Stroke stroke49 = valueMarker45.getOutlineStroke();
        valueMarker37.setStroke(stroke49);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str19.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType46);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        java.awt.Paint paint89 = xYPlot31.getRangeZeroBaselinePaint();
        xYPlot31.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertNotNull(paint89);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        java.lang.String str25 = categoryAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color1 = color0.darker();
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getRGBColorComponents(floatArray2);
        java.lang.Class<?> wildcardClass4 = floatArray3.getClass();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        dateAxis1.setTickMarkInsideLength((float) ' ');
        double double11 = dateAxis1.getAutoRangeMinimumSize();
        dateAxis1.setFixedAutoRange(100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList();
        boolean boolean20 = objectList18.equals((java.lang.Object) 100L);
        int int21 = objectList18.size();
        boolean boolean22 = intervalMarker17.equals((java.lang.Object) objectList18);
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = intervalMarker17.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer24);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] { color33, paint34, paint35 };
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str38 = color37.toString();
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color37, paint39 };
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] {};
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray45 = new java.awt.Shape[] { shape43, shape44 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray36, paintArray40, strokeArray41, strokeArray42, shapeArray45);
        java.awt.Paint paint47 = defaultDrawingSupplier46.getNextPaint();
        xYPlot31.setDomainZeroBaselinePaint(paint47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        xYPlot31.setRenderer(xYItemRenderer49);
        boolean boolean51 = xYPlot31.isRangeZoomable();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
        double double59 = dateAxis55.valueToJava2D(10.0d, rectangle2D57, rectangleEdge58);
        dateAxis55.setAutoTickUnitSelection(true);
        java.util.Date date62 = dateAxis55.getMaximumDate();
        dateAxis53.setMinimumDate(date62);
        double double64 = dateAxis53.getUpperBound();
        java.awt.Paint paint65 = dateAxis53.getLabelPaint();
        xYPlot31.setDomainCrosshairPaint(paint65);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str38.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shapeArray45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.0d + "'", double64 == 2.0d);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean6 = categoryPlot4.equals((java.lang.Object) 10.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot4.getDomainAxisForDataset(100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        boolean boolean3 = categoryPlot0.removeDomainMarker(marker1, layer2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset(6);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        try {
            int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = dateAxis61.java2DToValue(0.0d, rectangle2D63, rectangleEdge64);
        java.awt.Shape shape66 = dateAxis61.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = dateAxis61.getLabelInsets();
        java.awt.Stroke stroke68 = dateAxis61.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        double double74 = dateAxis70.java2DToValue(0.0d, rectangle2D72, rectangleEdge73);
        java.awt.Shape shape75 = dateAxis70.getUpArrow();
        dateAxis61.setRightArrow(shape75);
        xYPlot31.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis61, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation79 = null;
        try {
            boolean boolean81 = xYPlot31.removeAnnotation(xYAnnotation79, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(shape75);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        java.lang.String str10 = plotChangeEvent9.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = plotChangeEvent9.getType();
        java.lang.String str12 = chartChangeEventType11.toString();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str12.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset((int) '4', categoryDataset16);
        int int18 = categoryPlot4.getRangeAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.resizeRange((double) (short) 10, 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis10.isTickMarksVisible();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis13.java2DToValue(0.0d, rectangle2D15, rectangleEdge16);
        dateAxis13.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        int int26 = categoryPlot24.getIndexOf(categoryItemRenderer25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot24.setRenderer((int) (short) 10, categoryItemRenderer28, true);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = dateAxis32.valueToJava2D(10.0d, rectangle2D34, rectangleEdge35);
        dateAxis32.setAutoTickUnitSelection(true);
        categoryPlot24.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot24.setNoDataMessageFont(font40);
        dateAxis13.setTickLabelFont(font40);
        org.jfree.data.Range range43 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range43);
        dateAxis10.setRange(range43, true, false);
        dateAxis1.setRange(range43, false, false);
        java.text.DateFormat dateFormat51 = null;
        dateAxis1.setDateFormatOverride(dateFormat51);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot4.setNoDataMessageFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        int int19 = categoryPlot17.getIndexOf(categoryItemRenderer18);
        int int20 = categoryPlot17.getDomainAxisCount();
        categoryPlot17.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot17.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot17.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot17.addDomainMarker(categoryMarker28);
        org.jfree.chart.text.TextAnchor textAnchor30 = categoryMarker28.getLabelTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor31 = categoryMarker28.getLabelTextAnchor();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = dateAxis34.valueToJava2D(10.0d, rectangle2D36, rectangleEdge37);
        dateAxis34.setAutoTickUnitSelection(true);
        java.util.Date date41 = dateAxis34.getMaximumDate();
        dateAxis34.setTickMarkInsideLength((float) ' ');
        double double44 = dateAxis34.getAutoRangeMinimumSize();
        float float45 = dateAxis34.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = dateAxis49.valueToJava2D(10.0d, rectangle2D51, rectangleEdge52);
        dateAxis49.setAutoTickUnitSelection(true);
        java.util.Date date56 = dateAxis49.getMaximumDate();
        dateAxis47.setMinimumDate(date56);
        double double58 = dateAxis47.getUpperBound();
        java.awt.Font font59 = dateAxis47.getLabelFont();
        dateAxis47.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer62);
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker65.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean69 = valueMarker65.equals((java.lang.Object) rectangleInsets68);
        boolean boolean70 = xYPlot63.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker65);
        boolean boolean71 = xYPlot63.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = null;
        double double77 = dateAxis73.valueToJava2D(10.0d, rectangle2D75, rectangleEdge76);
        dateAxis73.setAutoTickUnitSelection(true);
        java.util.Date date80 = dateAxis73.getMaximumDate();
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis73.setTimeZone(timeZone81);
        java.awt.Font font83 = dateAxis73.getTickLabelFont();
        xYPlot63.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis73);
        xYPlot63.clearRangeMarkers(500);
        org.jfree.chart.util.Layer layer87 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection88 = xYPlot63.getDomainMarkers(layer87);
        boolean boolean89 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker28, layer87);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 32.0f + "'", float45 == 32.0f);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.0d + "'", double58 == 2.0d);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNotNull(font83);
        org.junit.Assert.assertNotNull(layer87);
        org.junit.Assert.assertNull(collection88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.valueToJava2D(10.0d, rectangle2D5, rectangleEdge6);
        dateAxis3.setAutoTickUnitSelection(true);
        java.util.Date date10 = dateAxis3.getMaximumDate();
        dateAxis1.setMinimumDate(date10);
        double double12 = dateAxis1.getUpperBound();
        java.awt.Paint paint13 = dateAxis1.getLabelPaint();
        java.lang.String str14 = dateAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker1.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean5 = valueMarker1.equals((java.lang.Object) rectangleInsets4);
        double double7 = rectangleInsets4.trimHeight((double) 11.0f);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.clearRangeAxes();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE", timeZone15);
        java.lang.String str17 = dateAxis16.getLabelToolTip();
        int int18 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot4.getFixedLegendItems();
        java.awt.Stroke stroke20 = categoryPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.data.xy.XYDataset xYDataset41 = xYPlot31.getDataset(4);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        xYPlot31.setDomainGridlinePaint((java.awt.Paint) color42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        xYPlot31.setRangeTickBandPaint((java.awt.Paint) color44);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        boolean boolean32 = dateAxis15.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        boolean boolean89 = xYPlot31.isDomainCrosshairVisible();
        xYPlot31.setDomainZeroBaselineVisible(true);
        xYPlot31.configureRangeAxes();
        xYPlot31.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot31.getRangeAxisLocation();
        xYPlot31.setBackgroundImageAlignment(100);
        xYPlot31.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot4.getLegendItems();
        boolean boolean14 = categoryPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis6.setTickMarkInsideLength((float) ' ');
        double double16 = dateAxis6.getAutoRangeMinimumSize();
        float float17 = dateAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        java.util.Date date28 = dateAxis21.getMaximumDate();
        dateAxis19.setMinimumDate(date28);
        double double30 = dateAxis19.getUpperBound();
        java.awt.Font font31 = dateAxis19.getLabelFont();
        dateAxis19.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker37.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean41 = valueMarker37.equals((java.lang.Object) rectangleInsets40);
        boolean boolean42 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        boolean boolean43 = xYPlot35.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot35.getRangeAxisLocation();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot35);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        double double51 = dateAxis47.java2DToValue(0.0d, rectangle2D49, rectangleEdge50);
        boolean boolean52 = dateAxis47.isPositiveArrowVisible();
        dateAxis47.setLabelURL("");
        org.jfree.data.Range range55 = xYPlot35.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis47);
        org.jfree.chart.axis.AxisLocation axisLocation56 = xYPlot35.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 32.0f + "'", float17 == 32.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(range55);
        org.junit.Assert.assertNotNull(axisLocation56);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setCategoryLabelPositionOffset((-2));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        java.lang.Object obj7 = categoryPlot4.clone();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray15 = null;
        float[] floatArray16 = color14.getComponents(floatArray15);
        float[] floatArray17 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray16);
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke19);
        float float21 = valueMarker20.getAlpha();
        boolean boolean22 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot4.getLegendItems();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(legendItemCollection23);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit7);
        dateAxis1.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(dateTickUnit7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot17.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot17.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean23 = sortOrder20.equals((java.lang.Object) color22);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Color color0 = java.awt.Color.GREEN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis1.setTimeline(timeline4);
        org.jfree.chart.plot.Plot plot6 = dateAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        categoryAxis1.setVisible(true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        xYPlot31.setDomainCrosshairValue((double) (-2), false);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot31.getRangeAxisLocation(2);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation38 = null;
        try {
            xYPlot31.addAnnotation(xYAnnotation38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        boolean boolean89 = xYPlot31.isDomainCrosshairVisible();
        xYPlot31.setDomainZeroBaselineVisible(true);
        xYPlot31.setBackgroundImageAlignment((int) (byte) 100);
        java.util.List list94 = xYPlot31.getAnnotations();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(list94);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        boolean boolean89 = xYPlot31.isDomainCrosshairVisible();
        xYPlot31.setDomainZeroBaselineVisible(true);
        xYPlot31.setBackgroundImageAlignment((int) (byte) 100);
        java.awt.Color color94 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot31.setDomainZeroBaselinePaint((java.awt.Paint) color94);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(color94);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        boolean boolean12 = dateAxis1.isTickMarksVisible();
        dateAxis1.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot19.getDomainAxis();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] { color21, paint22, paint23 };
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str26 = color25.toString();
        java.awt.Paint paint27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color25, paint27 };
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] {};
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray33 = new java.awt.Shape[] { shape31, shape32 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray24, paintArray28, strokeArray29, strokeArray30, shapeArray33);
        categoryPlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier34);
        java.awt.Shape shape36 = defaultDrawingSupplier34.getNextShape();
        dateAxis1.setRightArrow(shape36);
        dateAxis1.setAutoRangeMinimumSize(10.0d);
        boolean boolean40 = dateAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str26.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shapeArray33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.String str2 = datasetRenderingOrder0.toString();
        java.lang.String str3 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str2.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str3.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = dateAxis61.java2DToValue(0.0d, rectangle2D63, rectangleEdge64);
        java.awt.Shape shape66 = dateAxis61.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = dateAxis61.getLabelInsets();
        java.awt.Stroke stroke68 = dateAxis61.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        double double74 = dateAxis70.java2DToValue(0.0d, rectangle2D72, rectangleEdge73);
        java.awt.Shape shape75 = dateAxis70.getUpArrow();
        dateAxis61.setRightArrow(shape75);
        xYPlot31.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis61, true);
        dateAxis61.setLabelToolTip("");
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(shape75);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double6 = rectangleInsets5.getTop();
        double double8 = rectangleInsets5.trimHeight((double) (byte) 10);
        double double10 = rectangleInsets5.calculateBottomOutset((double) 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("DatasetRenderingOrder.FORWARD");
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        java.awt.Stroke stroke59 = xYPlot31.getDomainGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis62, categoryItemRenderer63);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        int int66 = categoryPlot64.getIndexOf(categoryItemRenderer65);
        int int67 = categoryPlot64.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation69 = categoryPlot64.getRangeAxisLocation(0);
        xYPlot31.setRangeAxisLocation(axisLocation69);
        org.jfree.data.category.CategoryDataset categoryDataset71 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis72, valueAxis73, categoryItemRenderer74);
        org.jfree.chart.plot.PlotOrientation plotOrientation76 = categoryPlot75.getOrientation();
        categoryPlot75.setRangeGridlinesVisible(false);
        java.awt.Paint paint79 = categoryPlot75.getRangeGridlinePaint();
        boolean boolean80 = axisLocation69.equals((java.lang.Object) categoryPlot75);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNotNull(plotOrientation76);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        xYPlot31.clearDomainMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation91 = xYPlot31.getRangeAxisLocation((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertNotNull(axisLocation91);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis26.setMarkerBand(markerAxisBand31);
        java.lang.Object obj33 = numberAxis26.clone();
        numberAxis26.setNegativeArrowVisible(true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = dateAxis33.java2DToValue(0.0d, rectangle2D35, rectangleEdge36);
        dateAxis33.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        int int46 = categoryPlot44.getIndexOf(categoryItemRenderer45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        categoryPlot44.setRenderer((int) (short) 10, categoryItemRenderer48, true);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = dateAxis52.valueToJava2D(10.0d, rectangle2D54, rectangleEdge55);
        dateAxis52.setAutoTickUnitSelection(true);
        categoryPlot44.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis52);
        java.awt.Font font60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot44.setNoDataMessageFont(font60);
        dateAxis33.setTickLabelFont(font60);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis33.setRange(range63);
        java.lang.Object obj65 = dateAxis33.clone();
        boolean boolean66 = dateAxis33.isNegativeArrowVisible();
        int int67 = xYPlot31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        double double73 = dateAxis69.java2DToValue(0.0d, rectangle2D71, rectangleEdge72);
        boolean boolean74 = dateAxis69.isPositiveArrowVisible();
        dateAxis69.setFixedAutoRange(1.0E-8d);
        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = null;
        double double82 = dateAxis78.valueToJava2D(10.0d, rectangle2D80, rectangleEdge81);
        dateAxis78.setAutoTickUnitSelection(true);
        java.util.Date date85 = dateAxis78.getMaximumDate();
        dateAxis78.resizeRange(100.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit88 = dateAxis78.getTickUnit();
        java.util.Date date89 = dateAxis69.calculateHighestVisibleTickValue(dateTickUnit88);
        dateAxis33.setTickUnit(dateTickUnit88);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(obj65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(dateTickUnit88);
        org.junit.Assert.assertNotNull(date89);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        int int2 = day0.getYear();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = xYPlot31.getAxisOffset();
        int int55 = xYPlot31.getDomainAxisCount();
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        int int57 = xYPlot31.indexOf(xYDataset56);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        categoryPlot0.setInsets(rectangleInsets6);
        boolean boolean8 = categoryPlot0.getDrawSharedDomainAxis();
        float float9 = categoryPlot0.getBackgroundImageAlpha();
        boolean boolean10 = categoryPlot0.isSubplot();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickMarksVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource3);
        java.util.Date date5 = dateAxis1.getMinimumDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot4.setDataset(categoryDataset8);
        java.awt.Image image10 = categoryPlot4.getBackgroundImage();
        categoryPlot4.setRangeCrosshairValue((-1.0d), true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot4.setDataset(categoryDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        float float18 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        categoryPlot4.setDomainAxis(categoryAxis17);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        numberAxis26.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat33 = numberAxis26.getNumberFormatOverride();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean35 = numberAxis26.equals((java.lang.Object) paint34);
        org.jfree.data.Range range36 = numberAxis26.getDefaultAutoRange();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.axis.AxisState axisState38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        int int46 = categoryPlot44.getIndexOf(categoryItemRenderer45);
        java.lang.Object obj47 = categoryPlot44.clone();
        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryPlot44.getFixedDomainAxisSpace();
        float float49 = categoryPlot44.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot44.getDomainAxisEdge();
        try {
            java.util.List list51 = numberAxis26.refreshTicks(graphics2D37, axisState38, rectangle2D39, rectangleEdge50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(numberFormat33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNull(axisSpace48);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.5f + "'", float49 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        java.lang.Object obj7 = categoryPlot4.clone();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray15 = null;
        float[] floatArray16 = color14.getComponents(floatArray15);
        float[] floatArray17 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray16);
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke19);
        float float21 = valueMarker20.getAlpha();
        boolean boolean22 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        java.awt.Stroke stroke23 = categoryPlot4.getOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot4.getDomainAxisForDataset(10);
        java.awt.Paint paint26 = categoryPlot4.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
        java.lang.String str3 = plotOrientation1.toString();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot11.getIndexOf(categoryItemRenderer12);
        int int14 = categoryPlot11.getDomainAxisCount();
        categoryPlot11.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray18 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot11.setRenderers(categoryItemRendererArray18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation20, plotOrientation21);
        categoryPlot11.setDomainAxisLocation(axisLocation20, false);
        java.awt.Paint paint25 = categoryPlot11.getOutlinePaint();
        categoryAxis5.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint25);
        double double27 = categoryAxis5.getCategoryMargin();
        categoryAxis5.configure();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean31 = numberAxis30.isInverted();
        boolean boolean32 = categoryAxis5.equals((java.lang.Object) numberAxis30);
        java.text.NumberFormat numberFormat33 = null;
        numberAxis30.setNumberFormatOverride(numberFormat33);
        numberAxis30.setAutoRangeStickyZero(false);
        java.awt.Paint paint37 = numberAxis30.getTickLabelPaint();
        boolean boolean38 = plotOrientation1.equals((java.lang.Object) numberAxis30);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlotOrientation.VERTICAL" + "'", str3.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray18);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        dateAxis1.setLabelURL("");
        float float9 = dateAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean6 = numberAxis5.isInverted();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis5.setTickUnit(numberTickUnit7, true, true);
        numberAxis1.setTickUnit(numberTickUnit7);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(numberTickUnit7);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace19, false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        java.text.DateFormat dateFormat12 = null;
        dateAxis1.setDateFormatOverride(dateFormat12);
        java.text.DateFormat dateFormat14 = dateAxis1.getDateFormatOverride();
        dateAxis1.setRangeWithMargins(0.2d, (double) 2.0f);
        java.util.Date date18 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = dateAxis22.valueToJava2D(10.0d, rectangle2D24, rectangleEdge25);
        dateAxis22.setAutoTickUnitSelection(true);
        java.util.Date date29 = dateAxis22.getMaximumDate();
        dateAxis20.setMinimumDate(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date29, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date18, timeZone31);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(dateFormat14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone31);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        int int2 = day0.getYear();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Paint paint7 = dateAxis6.getTickMarkPaint();
        numberAxis1.setTickMarkPaint(paint7);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.plot.Plot plot6 = dateAxis1.getPlot();
        try {
            dateAxis1.setRange((double) 31, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-1), (int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        categoryPlot0.setInsets(rectangleInsets6);
        java.lang.String str8 = rectangleInsets6.toString();
        double double10 = rectangleInsets6.extendHeight((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]" + "'", str8.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 43.0d + "'", double10 == 43.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo2, point2D3, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis7.configure();
        categoryAxis7.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis12.configure();
        categoryAxis12.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis12.getCategoryLabelPositions();
        categoryAxis7.setCategoryLabelPositions(categoryLabelPositions16);
        categoryAxis7.setLabelToolTip("java.awt.Color[r=0,g=0,b=255]");
        java.util.List list20 = categoryPlot0.getCategoriesForAxis(categoryAxis7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = null;
        try {
            categoryPlot0.setInsets(rectangleInsets23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        int int39 = categoryPlot37.getIndexOf(categoryItemRenderer38);
        int int40 = categoryPlot37.getDomainAxisCount();
        categoryPlot37.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot37.getDomainMarkers(layer44);
        categoryPlot37.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot37.getLegendItems();
        xYPlot31.setFixedLegendItems(legendItemCollection47);
        boolean boolean49 = xYPlot31.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = dateAxis52.valueToJava2D(10.0d, rectangle2D54, rectangleEdge55);
        dateAxis52.setAutoTickUnitSelection(true);
        java.util.Date date59 = dateAxis52.getMaximumDate();
        dateAxis52.setTickMarkInsideLength((float) ' ');
        double double62 = dateAxis52.getAutoRangeMinimumSize();
        float float63 = dateAxis52.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = null;
        double double71 = dateAxis67.valueToJava2D(10.0d, rectangle2D69, rectangleEdge70);
        dateAxis67.setAutoTickUnitSelection(true);
        java.util.Date date74 = dateAxis67.getMaximumDate();
        dateAxis65.setMinimumDate(date74);
        double double76 = dateAxis65.getUpperBound();
        java.awt.Font font77 = dateAxis65.getLabelFont();
        dateAxis65.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer80 = null;
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot(xYDataset50, (org.jfree.chart.axis.ValueAxis) dateAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis65, xYItemRenderer80);
        java.lang.Object obj82 = xYPlot81.clone();
        java.awt.Color color83 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint84 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint85 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray86 = new java.awt.Paint[] { color83, paint84, paint85 };
        java.awt.Color color87 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str88 = color87.toString();
        java.awt.Paint paint89 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray90 = new java.awt.Paint[] { color87, paint89 };
        java.awt.Stroke[] strokeArray91 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray92 = new java.awt.Stroke[] {};
        java.awt.Shape shape93 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape94 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray95 = new java.awt.Shape[] { shape93, shape94 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier96 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray86, paintArray90, strokeArray91, strokeArray92, shapeArray95);
        java.awt.Paint paint97 = defaultDrawingSupplier96.getNextPaint();
        xYPlot81.setDomainZeroBaselinePaint(paint97);
        xYPlot31.setRangeGridlinePaint(paint97);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(legendItemCollection47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.0d + "'", double62 == 2.0d);
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 32.0f + "'", float63 == 32.0f);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 2.0d + "'", double76 == 2.0d);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(obj82);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(paintArray86);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str88.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(paintArray90);
        org.junit.Assert.assertNotNull(strokeArray91);
        org.junit.Assert.assertNotNull(strokeArray92);
        org.junit.Assert.assertNotNull(shape93);
        org.junit.Assert.assertNotNull(shape94);
        org.junit.Assert.assertNotNull(shapeArray95);
        org.junit.Assert.assertNotNull(paint97);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] { color33, paint34, paint35 };
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str38 = color37.toString();
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color37, paint39 };
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] {};
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray45 = new java.awt.Shape[] { shape43, shape44 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray36, paintArray40, strokeArray41, strokeArray42, shapeArray45);
        java.awt.Paint paint47 = defaultDrawingSupplier46.getNextPaint();
        xYPlot31.setDomainZeroBaselinePaint(paint47);
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        xYPlot31.setFixedRangeAxisSpace(axisSpace49, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = xYPlot31.getAxisOffset();
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        int int54 = xYPlot31.indexOf(xYDataset53);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str38.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shapeArray45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Color color1 = java.awt.Color.RED;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot6.getIndexOf(categoryItemRenderer7);
        int int9 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot6.setBackgroundImageAlignment(12);
        int int15 = categoryPlot6.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot6.setFixedRangeAxisSpace(axisSpace16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot6.setDomainAxis(9, categoryAxis19, true);
        java.awt.Paint paint22 = categoryPlot6.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot6.getDomainAxisLocation();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot6.setDomainGridlineStroke(stroke24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = dateAxis29.valueToJava2D(10.0d, rectangle2D31, rectangleEdge32);
        dateAxis29.setAutoTickUnitSelection(true);
        java.util.Date date36 = dateAxis29.getMaximumDate();
        dateAxis29.setTickMarkInsideLength((float) ' ');
        double double39 = dateAxis29.getAutoRangeMinimumSize();
        float float40 = dateAxis29.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = dateAxis44.valueToJava2D(10.0d, rectangle2D46, rectangleEdge47);
        dateAxis44.setAutoTickUnitSelection(true);
        java.util.Date date51 = dateAxis44.getMaximumDate();
        dateAxis42.setMinimumDate(date51);
        double double53 = dateAxis42.getUpperBound();
        java.awt.Font font54 = dateAxis42.getLabelFont();
        dateAxis42.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis42, xYItemRenderer57);
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker60.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean64 = valueMarker60.equals((java.lang.Object) rectangleInsets63);
        boolean boolean65 = xYPlot58.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker60);
        boolean boolean66 = xYPlot58.isDomainZoomable();
        java.awt.Stroke stroke67 = xYPlot58.getRangeGridlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker(4.0d, (java.awt.Paint) color1, stroke24, (java.awt.Paint) color26, stroke67, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 32.0f + "'", float40 == 32.0f);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.0d + "'", double53 == 2.0d);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(stroke67);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Color color1 = java.awt.Color.getColor("DatasetRenderingOrder.REVERSE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getRangeAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot4.getRenderer();
        org.jfree.chart.util.ObjectList objectList11 = new org.jfree.chart.util.ObjectList();
        boolean boolean13 = objectList11.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        double double17 = dateAxis16.getUpperBound();
        objectList11.set((int) (short) 1, (java.lang.Object) dateAxis16);
        int int19 = objectList11.size();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        objectList11.set(0, (java.lang.Object) color21);
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color21);
        java.awt.Stroke stroke24 = categoryPlot4.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace9);
        java.awt.Paint paint11 = categoryPlot4.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        int int3 = java.awt.Color.HSBtoRGB((float) 9, (float) (short) 1, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.resizeRange((double) (short) 10, 0.0d);
        double double9 = dateAxis1.getFixedDimension();
        boolean boolean10 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        int int54 = xYPlot31.getDatasetCount();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setTickMarkOutsideLength((float) (byte) 1);
        boolean boolean5 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot31.getRangeAxisLocation();
        xYPlot31.setDomainCrosshairValue(0.0d, false);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, categoryItemRenderer48);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        int int51 = categoryPlot49.getIndexOf(categoryItemRenderer50);
        int int52 = categoryPlot49.getDomainAxisCount();
        categoryPlot49.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot49.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = categoryPlot49.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot49.addDomainMarker(categoryMarker60);
        org.jfree.chart.text.TextAnchor textAnchor62 = categoryMarker60.getLabelTextAnchor();
        org.jfree.chart.util.Layer layer63 = null;
        boolean boolean64 = xYPlot31.removeRangeMarker(500, (org.jfree.chart.plot.Marker) categoryMarker60, layer63);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection58);
        org.junit.Assert.assertNotNull(textAnchor62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }
}

